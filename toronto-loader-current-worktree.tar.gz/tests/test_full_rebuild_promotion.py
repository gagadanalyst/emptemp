from __future__ import annotations

from pathlib import Path

import pytest

from scripts import promote_snowflake_snapshot_rebuild as snow_promote
from scripts import validate_full_rebuild_promotion as promotion


def _report(backend: str):
    return {
        "backend": backend,
        "status": "passed",
        "mode": "rebuild",
        "history_scope": "full",
        "full_history": True,
        "explicit_promotion_required": True,
        "warehouse_input_staging": "not_used",
        "selection": {"from_date": None, "to_date": None, "limit": None},
        "snapshot_count_discovered": 1,
        "snapshot_count_selected": 1,
        "snapshots": [
            {
                "snapshot_id": "123:1",
                "archive_sha256": "a" * 64,
                "release_tag": "toronto-raw-snapshot-archive-2026-11",
                "asset_name": "toronto-raw-snapshot-bundle-123-1.zip",
            }
        ],
        "history_validation": {"status": "passed"},
    }


def test_full_rebuild_promotion_requires_all_scope_and_joint_fields(monkeypatch):
    duck, snow = _report("duckdb"), _report("snowflake")
    recomputed = {
        "status": "passed",
        "mode": "rebuild",
        "history_scope": "full",
        "full_history": True,
        "explicit_promotion_required": True,
        "promotion_performed": False,
        "snapshot_count": 1,
        "snapshot_count_discovered": 1,
        "snapshot_count_selected": 1,
        "snapshots": duck["snapshots"],
        "backends": {"duckdb": {}, "snowflake": {}},
        "archive_provenance": "passed",
        "backend_snapshot_coverage": "identical",
        "scd2_integrity": "passed",
    }
    monkeypatch.setattr(promotion, "validate_reports", lambda *_args: recomputed)
    saved = dict(recomputed)
    assert promotion.validate_full_rebuild(duck, snow, saved) == recomputed

    partial = _report("duckdb")
    partial["history_scope"] = "partial"
    with pytest.raises(ValueError, match="full Mode 2"):
        promotion.validate_full_rebuild(partial, snow, saved)


def test_full_rebuild_promotion_rejects_missing_joint_promotion_guard(monkeypatch):
    duck, snow = _report("duckdb"), _report("snowflake")
    recomputed = {
        "status": "passed",
        "mode": "rebuild",
        "history_scope": "full",
        "full_history": True,
        "explicit_promotion_required": True,
        "promotion_performed": False,
        "snapshot_count": 1,
        "snapshot_count_discovered": 1,
        "snapshot_count_selected": 1,
        "snapshots": duck["snapshots"],
        "backends": {"duckdb": {}, "snowflake": {}},
        "archive_provenance": "passed",
        "backend_snapshot_coverage": "identical",
        "scd2_integrity": "passed",
    }
    monkeypatch.setattr(promotion, "validate_reports", lambda *_args: recomputed)
    saved = dict(recomputed)
    saved["promotion_performed"] = True
    with pytest.raises(ValueError, match="promotion_performed"):
        promotion.validate_full_rebuild(duck, snow, saved)


def test_current_archive_verification_rejects_stale_candidate(monkeypatch, tmp_path):
    expected = {
        "snapshots": [
            {
                "snapshot_id": "one",
                "archive_sha256": "a",
                "release_tag": "tag",
                "asset_name": "asset.zip",
            }
        ]
    }
    monkeypatch.setattr(
        promotion,
        "discover_archives",
        lambda *_args, **_kwargs: [
            type(
                "A",
                (),
                {
                    "snapshot_id": "two",
                    "archive_sha256": "b",
                    "release_tag": "tag",
                    "asset_name": "new.zip",
                },
            )()
        ],
    )
    with pytest.raises(ValueError, match="archive set changed"):
        promotion.verify_current_archives(
            expected, repository="owner/repo", archive_dir=tmp_path
        )


def test_snowflake_mode2_promoter_requires_run_scoped_schema_and_confirmation(
    monkeypatch,
):
    monkeypatch.setattr(
        snow_promote,
        "_connection",
        lambda _uri: (_ for _ in ()).throw(AssertionError("must not connect")),
    )
    with pytest.raises(ValueError, match="Unsafe Mode 2"):
        snow_promote.promote("unused", "RAW", "123", 1, confirmed=True)
    with pytest.raises(ValueError, match="does not belong"):
        snow_promote.promote(
            "unused", "TORONTO_SNAPSHOT_REPLAY_999", "123", 1, confirmed=True
        )
    with pytest.raises(PermissionError, match="confirmation"):
        snow_promote.promote(
            "unused", "TORONTO_SNAPSHOT_REPLAY_123", "123", 1, confirmed=False
        )


def test_promotion_workflow_validates_the_exact_source_run_attempt():
    workflow = (
        Path(__file__).resolve().parents[1]
        / ".github"
        / "workflows"
        / "promote-snapshot-rebuild.yml"
    ).read_text(encoding="utf-8")
    assert '"--attempt", attempt' in workflow
    assert '"attempt,name,status,conclusion,headBranch,event,jobs"' in workflow
    assert "selected source workflow attempt does not match" in workflow


def test_snowflake_promotion_job_can_dispatch_the_serving_workflow():
    workflow = (
        Path(__file__).resolve().parents[1]
        / ".github"
        / "workflows"
        / "promote-snapshot-rebuild.yml"
    ).read_text(encoding="utf-8")
    snowflake_job = workflow.split("  promote-snowflake:", 1)[1]
    assert "actions: write" in snowflake_job.split("    env:", 1)[0]
    assert "gh workflow run snowflake-serving-schema.yml" in snowflake_job
