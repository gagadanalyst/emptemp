from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from scripts import snapshot_replay_baseline as baseline


def test_duckdb_baseline_is_sha256_and_detects_file_mutation(tmp_path):
    database = tmp_path / "production.duckdb"
    database.write_bytes(b"production-baseline")
    expected = baseline.duckdb_signature(database)
    assert expected["backend"] == "duckdb"
    assert expected["size_bytes"] == len(b"production-baseline")
    path = tmp_path / "baseline.json"
    path.write_text(json.dumps(expected), encoding="utf-8")
    baseline.verify(path, baseline.duckdb_signature(database))

    database.write_bytes(b"changed-production-baseline")
    with pytest.raises(RuntimeError, match="changed after"):
        baseline.verify(path, baseline.duckdb_signature(database))


def test_duckdb_baseline_refuses_missing_or_empty_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        baseline.duckdb_signature(tmp_path / "missing.duckdb")
    empty = tmp_path / "empty.duckdb"
    empty.touch()
    with pytest.raises(FileNotFoundError):
        baseline.duckdb_signature(empty)


def test_snowflake_signature_checks_context_and_aggregates(monkeypatch):
    class Cursor:
        def __init__(self):
            self.results = [
                (
                    "TORONTO_INGEST_ROLE",
                    "TORONTO",
                    "RAW",
                    "TORONTO_XS_WH",
                    "BIHASTE",
                    "TU44125",
                ),
                (100, 80, 20, 101),
                (200, 190, 10, 202),
                (56, 28, 303),
                (2, 2, 404),
            ]
            self.queries = []

        def execute(self, query):
            self.queries.append(query)

        def fetchone(self):
            return self.results.pop(0)

        def close(self):
            pass

    class Connection:
        def __init__(self):
            self.cursor_value = Cursor()
            self.closed = False

        def cursor(self):
            return self.cursor_value

        def close(self):
            self.closed = True

    connection = Connection()
    temporary = SimpleNamespace(cleanup=lambda: None)
    monkeypatch.setattr(
        baseline, "_snowflake_connect", lambda _uri: (connection, temporary)
    )
    value = baseline.snowflake_signature("unused")
    assert value["account"] == "bihaste-tu44125"
    assert value["tables"]["RAW_ACTIVE_PERMITS"]["hash_agg"] == "101"
    assert value["tables"]["RAW_CLEARED_PERMITS"]["hash_agg"] == "202"
    assert value["snapshot_ledger"]["snapshots"] == 28
    assert value["dlt_pipeline_state"] == {
        "rows": 2,
        "pipelines": 2,
        "hash_agg": "404",
    }
    assert "_DLT_LOAD_ID" in connection.cursor_value.queries[-1]
    assert "UPDATED_AT" in connection.cursor_value.queries[-2]
    assert len(connection.cursor_value.queries) == 5
    assert connection.closed


def test_snowflake_signature_rejects_unexpected_context(monkeypatch):
    class Cursor:
        def execute(self, _query):
            pass

        def fetchone(self):
            return ("PUBLIC", "TORONTO", "RAW", "TORONTO_XS_WH", "BIHASTE", "TU44125")

        def close(self):
            pass

    class Connection:
        def cursor(self):
            return Cursor()

        def close(self):
            pass

    monkeypatch.setattr(
        baseline,
        "_snowflake_connect",
        lambda _uri: (Connection(), SimpleNamespace(cleanup=lambda: None)),
    )
    with pytest.raises(RuntimeError, match="canonical ingest context"):
        baseline.snowflake_signature("unused")


def test_snowflake_signature_rejects_incomplete_dlt_pipeline_state(monkeypatch):
    class Cursor:
        def __init__(self):
            self.results = [
                (
                    "TORONTO_INGEST_ROLE",
                    "TORONTO",
                    "RAW",
                    "TORONTO_XS_WH",
                    "BIHASTE",
                    "TU44125",
                ),
                (100, 80, 20, 101),
                (200, 190, 10, 202),
                (56, 28, 303),
                (2, 1, 404),
            ]

        def execute(self, _query):
            pass

        def fetchone(self):
            return self.results.pop(0)

        def close(self):
            pass

    class Connection:
        def cursor(self):
            return Cursor()

        def close(self):
            pass

    monkeypatch.setattr(
        baseline,
        "_snowflake_connect",
        lambda _uri: (Connection(), SimpleNamespace(cleanup=lambda: None)),
    )
    with pytest.raises(RuntimeError, match="DLT pipeline state"):
        baseline.snowflake_signature("unused")


def test_mode1_workflow_fingerprints_production_before_candidate_copy_and_promotion():
    workflow = (
        Path(__file__).resolve().parents[1]
        / ".github"
        / "workflows"
        / "snapshot-replay.yml"
    ).read_text(encoding="utf-8")
    duck_capture = workflow.index(
        "--output data/staging/duckdb/production-baseline.json"
    )
    duck_copy = workflow.index("python scripts/prepare_duckdb_candidate.py")
    duck_replay = workflow.index("id: replay", duck_copy)
    duck_verify = workflow.index(
        "--expected data/staging/duckdb/production-baseline.json"
    )
    duck_promote = workflow.index(
        "python scripts/promote_duckdb_candidate.py", duck_verify
    )
    assert duck_capture < duck_copy < duck_replay < duck_verify < duck_promote
    assert "id: prepare_duckdb_candidate" in workflow

    snow_capture = workflow.index(
        "--output data/staging/snowflake/production-baseline.json"
    )
    snow_clone = workflow.index("python scripts/prepare_snowflake_raw_candidate.py")
    snow_replay = workflow.index('--mode "$REPLAY_MODE"', snow_clone)
    snow_verify = workflow.index(
        "--expected data/staging/snowflake/production-baseline.json"
    )
    snow_promote = workflow.index(
        "python scripts/promote_snowflake_raw_candidate.py", snow_verify
    )
    assert snow_capture < snow_clone < snow_replay < snow_verify < snow_promote
