# Toronto Housing Bottleneck Analytics — Snowflake + DuckDB

An end-to-end Analytics Engineering project using City of Toronto building-permit data, with **Snowflake and DuckDB as supported warehouse backends**. A single Python + dlt ingestion pipeline validates source snapshots, and one shared dbt project builds analytical models for both; the Streamlit dashboard selects its data source through an explicit backend setting.

**[Live dashboard](https://toronto-housing-bottleneck.streamlit.app/)** · **[dbt documentation](https://gagadanalyst.github.io/toronto-housing-bottleneck-analytics/)** · **[Snowflake operations guide](infra/snowflake/README.md)** · **[Published DuckDB and snapshots](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/releases/tag/warehouse-latest)**

## Analytical questions this project answers

Using current logical Active permit revisions and records marked `Closed`, the dashboard investigates:

1. **How is the current Active permit backlog distributed across application years and permit types?** Compare eligible and ineligible revisions and see how the backlog varies by cohort.

2. **How old are eligible Active permits?** Examine age distributions, median and 90th-percentile age, and counts of records older than 365, 730, and 1,095 calendar days.

3. **Where is the older Active backlog concentrated?** Identify application-year cohorts and permit types contributing the largest counts of permits aged more than 365 days.

4. **For matched permits recorded as `Closed`, how much calendar time elapses between application, issuance, and completion?** Compare counts, median, and 90th-percentile durations for application-to-issue, issue-to-completion, and application-to-completion intervals using the same matched cohort.

5. **How do Closed-permit lifecycle intervals vary by application year and permit type?** Compare lifecycle measures across the corresponding year/type cohorts.

6. **What data-quality conditions affect these measures?** Examine missing and conflicting fields, unusable or out-of-order dates, and exclusions from the Active-age and matched Closed cohorts.

**Interpretation guardrails.** Each observation is a building-permit revision, not a home or dwelling unit. Active age is elapsed calendar days from application date to the analysis `as_of_date`; these are ongoing, right-censored ages, not final processing times. The pooled matched Closed lifecycle analysis uses records with all three dates present and chronological order (`application_date <= issued_date <= completed_date`). The broader Closed-permit timelines page evaluates each date pair independently and excludes negative intervals from published duration statistics. Both describe selected records, not all applications. These are descriptive comparisons, not causal explanations of processing time, housing supply, affordability, or the wider development pipeline.

## What the project demonstrates

| Area | What is implemented |
|---|---|
| Ingestion | Python, dlt, Toronto CKAN API extraction, retries, explicit source types, validation, and Parquet snapshots. |
| Warehouse history | SCD Type 2 tracking for source changes observed between ingestion runs. |
| Analytics engineering | One dbt project for DuckDB and Snowflake, with staging models, revision-level facts, dimensions, marts, contracts, tests, and documentation. |
| Reliability | Regression tests, freshness and completeness checks, a verified rolling-release publication with recovery safeguards, and separate CI/CD workflows. |
| Data product | A deployed Streamlit dashboard with explicit DuckDB/Snowflake backend selection and Active/Cleared data-quality reporting. |

The analysis is descriptive, not causal. It examines observed active-permit ages and dates recorded for permits marked `Closed`; it does not claim to explain why a permit took a given amount of time.

## Architecture

```mermaid
%%{init: {"theme":"base","themeVariables":{"primaryColor":"#EAF8FD","primaryTextColor":"#28343E","primaryBorderColor":"#21B6E8","lineColor":"#21B6E8","secondaryColor":"#E9EEF3","tertiaryColor":"#FFFFFF","fontFamily":"Arial, sans-serif"}}}%%
flowchart TB
    A[City of Toronto: Active Permits]
    C[City of Toronto: Cleared Permits]
    E[Python + dlt: extract, type, validate]
    P[Validated Active and Cleared Parquet snapshots + manifest]
    AR[Monthly immutable raw snapshot Releases]
    D[DuckDB RAW: SCD2 history]
    S[Snowflake RAW: SCD2 history, optional and gated]
    TD[Shared dbt project: DuckDB target]
    TS[Shared dbt project: Snowflake target]
    W[DuckDB warehouse: RAW + dbt relations]
    SM[Snowflake analytics serving schema]
    R[Rolling warehouse-latest release]
    DOCS[Generated dbt documentation]
    APP[Streamlit dashboard<br/>DASHBOARD_BACKEND selects the source]

    A --> E
    C --> E
    E --> P
    P --> AR
    AR -->|Pending approved archives in extraction order| D
    AR -->|Pending approved archives in extraction order| S
    D --> TD
    S --> TS
    TD --> W
    TS --> SM
    W -->|DuckDB warehouse| R
    P -->|Active and Cleared Parquet snapshots| R
    TD --> DOCS
    DOCS -->|dbt documentation ZIP| R
    DOCS --> Pages[GitHub Pages]
    R -->|DASHBOARD_BACKEND=duckdb| APP
    SM -->|DASHBOARD_BACKEND=snowflake| APP
```

Each refresh extracts the two configured sources once and validates the resulting snapshots. The approved raw bundles are retained in monthly immutable GitHub Releases. DuckDB CD and the optional, gated Snowflake RAW workflow replay the still-unpromoted approved archive backlog in extraction-time order; the CD handoff identifies its archive, while a daily Snowflake reconciliation schedule covers a missed handoff. After a successful Snowflake RAW promotion, the separate serving workflow builds the analytics schema. Snowflake RAW was initialized from a baseline snapshot; subsequent refreshes extend observed SCD2 history rather than recreate a fresh baseline. `DASHBOARD_BACKEND` selects which backend the same dashboard reads; a connection failure is shown rather than silently substituting results from the other warehouse.

## Source scope and analytical design

The current ingestion scope is limited to two City of Toronto datasets: [Active Permits](https://open.toronto.ca/dataset/building-permits-active-permits/) and [Cleared Permits](https://open.toronto.ca/dataset/building-permits-cleared-permits/). Both source configurations use `warehouse_since: 2020-01-01` on `APPLICATION_DATE`; full-source Parquet snapshots are retained independently of that warehouse cutoff.

The project deliberately does not ingest Development Applications, Preliminary Zoning Reviews, or Address Points. Those were considered during discovery but remain deferred until profiling shows that their grain, identifiers, linkage coverage, and join cardinality support reliable analysis. The [dataset-scope decision record](docs/decisions/0001-dataset-scope.md) explains the trade-offs.

| Model | Grain and purpose |
|---|---|
| `stg_active_permits`, `stg_cleared_permits` | One row per raw SCD2 source version; casts source fields while retaining selected raw values and version metadata. |
| `fct_active_permit_revision` | One row per current logical revision keyed by `permit_num`, `revision_num`, and `permit_type`; consolidates duplicate physical rows and surfaces disagreements. |
| `fct_cleared_permit_revision` | Same logical key; preserves signed lifecycle intervals and exposes analysis durations only when non-negative. |
| `dim_date` | Continuous calendar date dimension for dates observed in the Cleared fact. |
| `dim_permit_type` | Distinct permit types observed in either source fact, tested against both revision facts. |
| `mart_active_permit_age` | Current Active revisions with age, an eligibility flag, and a reason-coded exclusion. |
| `mart_active_backlog_by_year_type` | Current Active backlog counts by application year and permit type, including age eligibility, >365/730/1,095-day counts, and age summary statistics. |
| `mart_cleared_lifecycle_by_year_type` | Calendar-day lifecycle summaries by application year, permit type, and date pair; reports median, 90th percentile, maximum, counts, and negative intervals. |
| `mart_cleared_lifecycle_matched_by_year_type` | Matched Closed lifecycle intervals by application year, permit type, and measure, using records with all three dates present and chronologically ordered. |

The dimensions are separately modeled and tested; the serving marts are purpose-built outputs and do not imply that every dimension is joined into every mart. Strict dbt static analysis is enabled by default. The Cleared staging model keeps a documented baseline exception because the analyzer cannot resolve DuckDB's timezone expression without a verified semantics-safe alternative.

**Metric rules.** Active age is calendar days from `application_date` to dbt's `as_of_date` (normally derived from the run start, with a variable for reproducible comparisons). Missing or conflicting status/application dates, and terminal or exceptional statuses (`abandoned`, `cancelled`, `closed`), are excluded from the age cohort with reason codes. The Active backlog mart retains eligible and ineligible counts but calculates age thresholds and age statistics only for eligible records. The matched Closed lifecycle cohort requires all three dates and chronological order (`application_date <= issued_date <= completed_date`), so all three intervals use the same denominator. The broader Cleared lifecycle mart retains signed intervals for diagnosis; published duration statistics exclude negative intervals. Measures are calendar days, not business days.

## Important findings and decisions

- **CKAN is not a stable row-count endpoint.** Observed source totals have changed between requests, and the JSON resource has returned HTTP 502; HTTP 409 and 500 responses have also been observed. Extraction retries and restarts a changing paginated pull, validates required columns and completed row counts, and fails safely rather than accepting an incomplete snapshot.
- **Source types are part of the data contract.** Explicit source-declared types and type hints protect identifiers and numeric-looking text—including values with leading zeros—from accidental conversion. Raw values are retained beside selected typed fields for inspection.
- **SCD2 versions should represent meaningful changes.** The logical revision key is `permit_num` + `revision_num` + `permit_type`. The tracked-row hash excludes CKAN's `_id` and normalizes selected numeric fields to avoid false versions caused by source identity or representation. Regression checks cover unchanged replay and a controlled tracked-attribute change ([SCD2 test PR](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/pull/76)).
- **Snowflake starts from a fresh baseline.** The new `TORONTO.RAW` history was initialized from a complete validated snapshot. Old DuckDB SCD2 history was not migrated, and missed days were not reconstructed. Snowflake history records changes observed from this baseline forward; validity windows are bounded by ingestion observations and do not prove exact real-world transition times.
- **One extraction feeds both backends.** The same validated snapshot bundle is used for DuckDB and Snowflake. Both targets use the same dbt model definitions and business rules; only necessary warehouse-specific SQL is isolated. There are no parallel model trees or duplicated extraction pipelines.
- **A Snowflake failure must not take down DuckDB publication.** DuckDB, Parquet, and dbt documentation publication remain the normal CI/CD path. Snowflake work runs in separate, gated workflows. The release publisher verifies the assets, keeps a backup of the last-known-good publication, and attempts rollback if replacement fails; a recovery artifact is preserved if rollback also fails.
- **The dashboard and workflow gate are separate controls.** `DASHBOARD_BACKEND` chooses the dashboard's data source. The GitHub repository variable `SNOWFLAKE_OPERATIONS_ENABLED` controls whether Snowflake workflow jobs may run. Switching the dashboard to DuckDB alone does not disable GitHub Actions compute.

## Data-quality snapshot

These source and model counts describe the published DuckDB warehouse observed on **October 18, 2026**. They are a historical illustration of the checks, not current dashboard totals or expected permanent counts. The live dashboard calculates its KPIs from whichever backend is selected at runtime.

| Check | Observed value | Meaning |
|---|---:|---|
| Active source rows across SCD2 history | 101,598 | Includes current and expired versions. |
| Current physical Active rows | 99,149 | Before consolidating duplicate physical rows. |
| Logical current Active revisions | 99,145 | One per logical revision key. |
| Active revisions eligible for age analysis | 99,074 | After the published status/date rules. |
| Active revisions excluded from age analysis | 71 | 2 missing status; 69 terminal or exceptional status. |
| Active builder-name conflict groups | 4 | Conflicting values retained as diagnostics. |
| Current physical / logical Cleared revisions | 186,430 / 186,425 | Five excess physical rows after consolidation. |
| Cleared builder-name conflict groups | 5 | Conflicts are surfaced rather than arbitrarily resolved. |
| Cleared lifecycle-date conflict groups | 0 observed | No conflict found for the modeled lifecycle-date fields in that snapshot. |

## Validation evidence

The following results are tied to specific workflow runs and inputs; they are not guarantees about later refreshes.

| Validation | Evidence |
|---|---|
| Post-recovery reliability validation (November 9, 2026) | On merge commit [`6999487`](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/commit/69994872b36df99970d734abeaad9b9bd6dc2444), [main CI](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/42612234201), [secret scan](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/42612231561), [CD / DuckDB publication](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/42612402884), [Snowflake RAW refresh](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/42612648618), and [Snowflake serving build](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/42613324641) all succeeded. CD validated and promoted its DuckDB candidate, published the immutable recovery checkpoint and rolling assets, and deployed dbt documentation. The RAW workflow validated and promoted its isolated candidate, then dispatched the serving build; serving verified its upstream RAW run, dbt models, dashboard relations, metadata, and read access before promotion. This is dated run evidence, not a guarantee about later refreshes. |
| Earlier automated refresh (November 2, 2026) | On commit [`bf27af2`](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/commit/bf27af2cfc8e99936777a0332b752981da4de81a), [CI #124](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/41396261400), [CD #92](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/41396374837), [Snowflake RAW #37](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/41396850955), and [Snowflake serving #38](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/41397052684) succeeded. The serving build passed 52/52 dbt resources and verified 98,591 current logical Active revisions, 189,857 current logical Cleared revisions, and 300 lifecycle-summary groups (288,448 logical revisions combined). These are counts from that refresh, not permanent expected totals. |
| Fresh-baseline SCD2 behaviour | The [successful Snapshot Baseline and Replay run](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40491637116), added in [PR #76](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/pull/76), verified that an unchanged replay added no versions and a controlled `STATUS` change created the expected version. |
| DuckDB/Snowflake parity | [Run 40482009588](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40482009588), using `as_of_date=2026-10-27`: compared dimensions, facts, and marts had zero row-value mismatches, and dashboard summary metrics matched. Staging was compared on schema, grain/count, and semantic types rather than row by row. |
| Automatic refresh chain | On commit [`e8bb994`](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/commit/e8bb994c8ec664d2da7d12d1c296a1b15da3dc49), [CI](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40622105661), [CD/publication](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40622186735), [canonical RAW refresh](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40622867433), and [serving build](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40623059248) all succeeded on **October 27, 2026, Toronto time**. RAW and serving runs triggered automatically in sequence. |
| Gate-off / DuckDB fallback | On October 28, 2026, the GitHub variable was set to `false`. [Manual CI](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40630130221) and [the resulting CD publication](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40630228426) succeeded on the same commit. The automatically triggered [RAW refresh](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40631433875) and [serving build](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/40631450406) skipped as intended. The project owner confirmed the public dashboard loaded successfully after switching `DASHBOARD_BACKEND` to `duckdb`. |

For the parity run, `MART_ACTIVE_PERMIT_AGE` had 98,869 rows (98,798 eligible and 71 excluded), `FCT_CLEARED_PERMIT_REVISION` had 188,819 rows, and the lifecycle mart had 300 summary groups. The comparison covered 481,927 lifecycle date pairs before excluding three negative intervals from duration statistics. These counts belong to that isolated parity baseline, not a later canonical RAW refresh. The parity job on PR #82 was skipped because the Snowflake workflow gate was off during that PR; the separately linked parity run provides the comparison evidence.

## Automation, publication, and operating controls

The architecture diagram above describes the data path; this separate view shows the automated GitHub Actions path from validation through DuckDB publication to the separately gated Snowflake refresh. Separate manually dispatched baseline/replay, Snowflake dbt validation, and smoke workflows, plus gated pull-request parity, are described below but not drawn here.

```mermaid
%%{init: {"theme":"base","themeVariables":{"primaryColor":"#EAF8FD","primaryTextColor":"#28343E","primaryBorderColor":"#21B6E8","lineColor":"#21B6E8","secondaryColor":"#E9EEF3","tertiaryColor":"#FFFFFF","fontFamily":"Arial, sans-serif"}}}%%
flowchart TB
    PR[Pull request] --> CI[CI checks, tests, security and packaging]
    TRIG[Path-eligible main push / daily 23:00 America/Toronto / manual dispatch] --> CI
    CI -->|Successful non-PR CI run on main| CD[CD: extract, validate, test dbt and publish DuckDB assets]
    CD --> DOCS[Deploy dbt docs after successful data publication]
    CD -->|CD handoff and Snowflake gate enabled; replay pending approved Release archives in extraction order| RAW[Refresh Snowflake RAW]
    SWEEP[Daily Snowflake archive reconciliation] --> RAW
    RAW -->|Both source ledger entries succeeded; explicit workflow_dispatch carries RAW run ID| SERVE[Build Snowflake analytics serving schema]
```

- **CI** validates Python linting/formatting, tests, dependency security, packaging, and dashboard dependencies. Pull requests also build and test dbt against the latest published DuckDB warehouse and check documentation packaging. The daily CI schedule is **23:00 America/Toronto** so the subsequent CD source refresh runs in the late-night Toronto window, reducing exposure to observed CKAN API instability. The schedule uses the `America/Toronto` IANA timezone to follow local time across daylight-saving changes. Main-branch push triggers are path-filtered, and manual dispatch is available. Late-night timing does not replace retries, completeness checks, or snapshot validation; it cannot guarantee upstream API availability.
- **CD** runs only after successful eligible CI on `main` and checks out that exact commit. It extracts and validates both sources, runs SCD2/warehouse checks and dbt tests, and publishes the rolling assets. Hosted dbt documentation deploys only after successful data publication. The Snowflake refresh consumes the validated snapshot bundle from that CD run, rather than extracting the sources again.
- **Rolling release** `warehouse-latest` contains the DuckDB warehouse, Active and Cleared Parquet snapshots, and a dbt documentation ZIP. It is a replaceable latest release—not a versioned history of immutable warehouse states. The validated snapshot bundle used by automatic Snowflake refresh is a workflow artifact, not an additional release asset.
- **Snowflake gate.** The exact repository variable value `SNOWFLAKE_OPERATIONS_ENABLED=true` enables the guarded jobs in `snowflake-canonical-raw-refresh.yml`, `snowflake-serving-schema.yml`, `snowflake-dbt.yml`, `snowflake-live-ingestion-smoke.yml`, `snowflake-parity.yml`, and `snowflake.yml`. If false or unset, the guarded jobs skip before connecting; a workflow record marked `skipped` is expected. The gate does not cancel a job already running. Pull-request parity can consume Snowflake compute when the gate is enabled.
- **DuckDB candidate and publication boundary.** CD restores the last promoted database, copies it to a run-specific candidate, and replays the immutable archive backlog into that candidate. SCD2 invariants, per-source ledgers, quarantine reconciliation and the quarantine threshold are checked before dbt; dbt builds against a separate copy of the candidate. Only a fully validated dbt result is atomically moved into the runner's production database path. After candidate validation and dbt success, the immutable DuckDB recovery checkpoint is advanced before the rolling `warehouse-latest` publication. If the rolling Release update fails, the next run can safely restore this validated candidate and retry publication instead of reverting to an older source ledger. The four `warehouse-latest` assets are published through the existing verified backup/rollback publisher. GitHub Release asset replacement is sequential with verified rollback, not a single multi-asset transaction.
- **Snowflake RAW staging and promotion.** The RAW workflow clones `TORONTO.RAW` into `TORONTO.RAW_STAGE_<run_id>_<attempt>`, rebases the cloned DLT pipeline state to the candidate dataset, and replays all pending immutable archives there. Both source ledgers, DLT metadata, SCD2 intervals and quarantine reconciliation are validated before `ALTER SCHEMA TORONTO.RAW SWAP WITH ...`. The swap is the RAW cutover; the prior production RAW remains under the stage schema name as a rollback copy. DLT state is rebased to `RAW` after the swap, with a generation marker allowing interrupted state rebases to resume. A failed load or validation leaves canonical RAW unchanged.
- **Snowflake serving staging and promotion.** After a successful RAW promotion, the serving workflow verifies the exact successful RAW run, creates a fresh `ANALYTICS_STAGE_<run_id>_<attempt>` schema, and directs dbt to build and test all models there. It verifies all six dashboard relations, refresh metadata and dashboard read grants, then swaps the candidate schema into `TORONTO.ANALYTICS`. A failed build leaves the prior serving schema untouched; after promotion, the prior schema remains under the candidate name. RAW and ANALYTICS are separate atomic swap boundaries, not one Snowflake transaction.
- **Quarantine and the 25% gate.** NULL/blank business keys and every row in a conflicting duplicate-key group are excluded from clean SCD2 and retained with their full original payload and immutable archive provenance in `raw.toronto_scd2_quarantine` / `TORONTO.RAW.TORONTO_SCD2_QUARANTINE` after a successful Snowflake RAW swap (or in the run-specific RAW candidate schema while validation is in progress). Redundant identical duplicate occurrences are also retained for audit, but the first identical row is loaded and those redundant occurrences do not count as bad rows. Promotion is blocked when the total newly quarantined bad rows for either source across the candidate generation reach **25% or more** of that source's pre-run production current-row count. Active and Cleared are assessed independently; existing quarantine rows from the promoted baseline do not accumulate toward this test. Rejected DuckDB candidates publish their quarantine rows to a separate audit Release, never to the normal recovery-checkpoint Release. Rejected Snowflake candidate schemas remain available for inspection. There is no historical quarantine backfill: the original historical Parquet archives remain the record for the earlier 28 snapshots.
- **Independent backends and retries.** DuckDB and Snowflake promote independently; there is no distributed transaction across the two engines. Each CD run restores the latest verified immutable DuckDB recovery checkpoint, builds and validates a run-scoped candidate, and only then replaces the runner's working database. The immutable recovery checkpoint is advanced after candidate validation and before the replaceable `warehouse-latest` release is published. A retry before checkpoint advancement restores the last published checkpoint and replays the approved immutable archive backlog; if `warehouse-latest` publication fails after checkpoint advancement, the next CD run restores that already-validated checkpoint and can retry publication without losing the loaded history. Snowflake RAW and serving have separate schema-swap boundaries. A pre-promotion candidate failure leaves the corresponding canonical schema unchanged; a failure involving a completed swap or failed automatic rollback must be inspected before retrying. If RAW is already promoted and only serving failed, retry serving with the successful RAW run ID instead of reloading RAW. See the [snapshot recovery runbook](docs/snapshot-archive-replay-baseline.md) and [Snowflake operations guide](infra/snowflake/README.md) for the recovery boundaries and commands.

For a trial-end or planned shutdown, set `SNOWFLAKE_OPERATIONS_ENABLED` to `false` or remove it; separately set the deployed Streamlit `DASHBOARD_BACKEND` to `duckdb`; verify the public dashboard loads the published DuckDB asset and a fresh DuckDB publication succeeds; inspect and stop/wait for any already-running Snowflake jobs; then remove unused Snowflake credentials. Trial expiry and resource monitors are not substitutes for disabling the workflow gate. See the [Snowflake operations guide](infra/snowflake/README.md) for account setup, role grants, manual workflow conditions, secrets, and verification steps.

**Gate-off validation completed on October 28, 2026.** With `SNOWFLAKE_OPERATIONS_ENABLED=false`, the manual CI run and subsequent DuckDB CD publication succeeded, while the automatically triggered Snowflake RAW refresh and serving build skipped. The project owner also confirmed that the public dashboard loaded successfully after changing `DASHBOARD_BACKEND` to `duckdb`. This demonstrates that Snowflake can be disabled without changing the DuckDB publication path. For a future planned shutdown, still check for already-running Snowflake jobs and verify the exact account trial end in Snowsight; trial expiry and resource monitors are not substitutes for the workflow gate.

## Repository security and local credentials

The `secret-scan.yml` workflow runs Gitleaks on pull requests, pushes to `main`, manual dispatches, and a weekly schedule. Local Streamlit secrets (`.streamlit/secrets.toml`) and common private-key file extensions are ignored by Git. The ignore rules do not remove files already committed.

For a deliberate local file and full-history audit, install Gitleaks and run:

```bash
gitleaks dir . --redact
gitleaks git . --redact --log-opts="--all"
```

If a real credential is detected, treat it as exposed and rotate/revoke it; deleting the line from the latest revision is not enough to make a historical secret safe.

## Live dashboard

**[Open the dashboard](https://toronto-housing-bottleneck.streamlit.app/)**. The dashboard supports both DuckDB and Snowflake; `DASHBOARD_BACKEND` selects the source (`duckdb` or `snowflake`). If neither the environment variable nor the Streamlit secret is set, the app defaults to DuckDB. Both paths query the same dbt analytical relations rather than calling Toronto CKAN directly. Connection or query errors are shown rather than silently switching backends. Results are cached for 24 hours, with a manual refresh option. The sidebar's last-successful-refresh timestamp is displayed in Toronto local time (ET) and comes from the last successful DuckDB publication or the Snowflake refresh-metadata table. If a DuckDB refresh fails before publication, its unpromoted timestamp does not replace the timestamp in the published artifact. The dashboard has four sections, each with a distinct analytical purpose:

- **The story** — decision-oriented overview of the current Active backlog by application-year cohort and permit type. It compares eligible and ineligible records, highlights older backlog thresholds, and reports age statistics. It also presents pooled lifecycle durations for matched Closed permits and an application-year/permit-type cohort explorer using that same matched cohort.
- **Active permits** — interactive exploration of ongoing Active-permit ages by permit type, including distributions, median and 90th-percentile age, and individual permit-revision details. Filters allow the viewer to narrow the analysis by permit type and age.
- **Closed-permit timelines** — lifecycle comparisons for records marked `Closed`, by application year, permit type and date interval. This page uses the broader lifecycle mart and reports date-pair counts, usable non-negative duration counts, and group-level duration summaries.
- **Data quality & definitions** — logical-revision findings, overlapping check counts, Active age eligibility and exclusions, Cleared date completeness, metric definitions and interpretation caveats.

**How to interpret the two lifecycle views.** The Story page calculates pooled median and 90th-percentile durations across individual permit revisions in one matched Closed cohort: all three dates must be present and chronologically ordered. The Closed-permit timelines page uses the broader lifecycle mart, which summarizes records within application-year and permit-type groups. Its displayed median of group medians and median of group 90th percentiles are summaries of group-level statistics, not pooled permit-level median and P90 values. The two views therefore answer related questions but use different cohorts and aggregation levels.

The "revisions with findings" KPIs count each logical revision once; per-check counts can overlap and should not be added. Active age exclusions are reported separately from data-quality findings. Cleared checks cover all current statuses, and date completeness separates conflicting values from missing or unusable values. A populated completion date is a source value, not confirmation that a permit is marked `Closed`.

## Review the project locally

Python **3.14.x** is used for ingestion and tests. From the repository root:

```bash
git clone https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics.git
cd toronto-housing-bottleneck-analytics
python3.14 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m pytest -q \
  --ignore=tests/test_warehouse_load.py \
  --ignore=tests/integration/test_scd2_active_permits.py
```

That test command is intended to run without a locally extracted Toronto dataset or warehouse. Other tests may require captured data, a warehouse, or network access; see the [test guide](tests/README.md). The full end-to-end setup test downloads a source dataset and should be run deliberately.

To build dbt against the latest published warehouse, use a **separate dbt virtual environment** and a copy of the database so you do not modify the downloaded release asset:

```bash
mkdir -p data/warehouse "$HOME/.venvs"
curl -fL \
  https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/releases/download/warehouse-latest/toronto.duckdb \
  -o data/warehouse/toronto.duckdb
cp data/warehouse/toronto.duckdb data/warehouse/toronto-dbt-local.duckdb
export DBT_DUCKDB_PATH="$PWD/data/warehouse/toronto-dbt-local.duckdb"
python3.14 -m venv "$HOME/.venvs/toronto-housing-dbt"
source "$HOME/.venvs/toronto-housing-dbt/bin/activate"
python -m pip install --upgrade pip
python -m pip install -r dbt/requirements.txt
cp dbt/profiles.yml.example dbt/profiles.yml
cd dbt
dbt deps --profiles-dir .
dbt build --profiles-dir .
dbt docs generate --profiles-dir . --output-dir target/docs-site
cd ..
```

Serve `dbt/target/docs-site` with `python3 -m http.server 8000` from that directory to view the generated docs at `http://localhost:8000/`.

To run the dashboard locally, create a separate environment for its pinned dependencies:

```bash
python3.14 -m venv "$HOME/.venvs/toronto-housing-dashboard"
source "$HOME/.venvs/toronto-housing-dashboard/bin/activate"
python -m pip install -r dashboard/requirements.txt
streamlit run dashboard/app.py
```

The local dashboard downloads the published DuckDB asset and therefore needs network access. To use Snowflake locally, configure `DASHBOARD_BACKEND` and the `[snowflake]` values in Streamlit secrets; never commit private keys or passphrases.

## Repository guide

| Path | Purpose |
|---|---|
| `src/toronto_housing_ingestion/`, `open_data_config.yml` | Extraction, validation, source typing, and warehouse loading. |
| `tests/` | Unit/integration tests, source-fallback tests, warehouse checks, and SCD2 regressions. |
| `dbt/models/staging/` | Source staging, type normalization, metadata, docs, and tests. |
| `dbt/models/marts/`, `dbt/macros/` | Facts, dimensions, marts, tests, and minimal adapter-specific SQL. |
| `.github/workflows/ci.yml`, `cd.yml` | Validation, production extraction, dbt builds, rolling publication, and docs deployment. |
| `.github/workflows/snowflake*.yml` | Optional gated Snowflake baseline, refresh, serving, smoke, and parity workflows. |
| `.github/workflows/secret-scan.yml` | Gitleaks checks for secrets on PRs, main pushes, manual dispatch, and weekly schedule. |
| `dashboard/app.py` | Streamlit data product with explicit backend selection. |
| `infra/snowflake/` | Snowflake setup SQL and operating guide. |
| `docs/decisions/0001-dataset-scope.md` | Dataset-selection rationale and gates for expanding source scope. |

## Limitations and deliberate non-goals

- **Active ages are right-censored:** the final issue or completion date is not yet known from an active record.
- **The `Closed` cohort is selected by recorded status:** it is not a complete or unbiased sample of all applications, especially for recent application years. 2026 is partial.
- **Durations are calendar days:** negative intervals remain diagnostic but are excluded from summaries.
- **SCD2 is observed history, not a complete event ledger:** changes between snapshots and exact real-world status-transition times cannot be inferred.
- **The release rolls forward:** it does not preserve every previous warehouse version as an immutable archive.
- **No causal claims:** the available fields do not establish why a permit took longer.
- **Deferred work:** additional datasets, historical DuckDB-to-Snowflake SCD2 reconciliation, a new orchestration framework, parallel dbt model trees, and a dbt Semantic Layer are outside the current scope. A semantic layer may be considered once metric definitions and consumption needs are stable.

## Project timeline and development practice

The earliest preserved artifacts date to **September 27, 2026 (UTC)**; the first public Git commit was **October 4**. Ingestion and core checks came first. GitHub Actions publication was added in mid-October; dbt pull-request validation, the Streamlit dashboard, hosted docs, and the CI/CD split followed on October 18 ([CI run](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/39179649087), [CD run](https://github.com/gagadanalyst/toronto-housing-bottleneck-analytics/actions/runs/39179772013)). Late October brought the fresh Snowflake baseline, same-snapshot parity validation, explicit dashboard backend selection, and automatic RAW/serving refresh. The progression from preserved artifact to deployed dashboard was about three calendar weeks, not a claim about hands-on hours.

### AI-assisted development and ownership

I owned the project requirements, scope, acceptance criteria, and final decisions on architecture and technical trade-offs across ingestion, SCD2 history, dbt, CI/CD, and the optional Snowflake path. I used LLMs as development aids to research unfamiliar concepts and APIs, compare implementation options, draft and refine code and documentation, and troubleshoot failures.

I reviewed and adapted AI-generated suggestions rather than treating them as authoritative. I verified behaviour through tests, dbt and data-validation queries, GitHub Actions results, and checks of the deployed dashboard and workflow outcomes. The final implementation decisions, validation, and documented limitations remain my responsibility.
