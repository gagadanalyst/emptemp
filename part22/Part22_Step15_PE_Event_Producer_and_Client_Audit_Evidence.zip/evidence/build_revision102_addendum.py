from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path('/mnt/data/hp_part22_step15')
BASE=Path('/mnt/data/hp_part22_step14/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision101_Part22_Step14_Startup_Load_and_00400000_Trace_Addendum.docx')
OUT=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision102_Part22_Step15_PE_Event_Producer_and_Client_Audit_Addendum.docx'
doc=Document(BASE)
sec=doc.add_section(WD_SECTION.NEW_PAGE)
sec.top_margin=Inches(0.62); sec.bottom_margin=Inches(0.62)
sec.left_margin=Inches(0.68); sec.right_margin=Inches(0.68)
sec.header_distance=Inches(0.28); sec.footer_distance=Inches(0.28)
sec.header.is_linked_to_previous=False; sec.footer.is_linked_to_previous=False
NAVY='17365D'; BLUE='1F4E79'; CYAN='00A6C7'; LIGHT='D9EAF7'; PALE='EEF5FA'; GRAY='595959'; MID='7F8C8D'; WHITE='FFFFFF'; WARN='FFF2CC'; GREEN='E2F0D9'; RED='FCE4D6'
header=sec.header.paragraphs[0]; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=header.add_run('HP DESKJET 2855e  |  INDEPENDENT PRINTING / SCANNING INVESTIGATION')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(MID)
footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('Revision 102 - Part 22, Step 15 addendum  |  19 November 2026  |  Page ')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.color.rgb=RGBColor.from_string(MID)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)
def celltxt(cell,text,bold=False,color=None,size=7.6):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color:r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def table(headers,rows,widths=None,font=7.3):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; t.style='Table Grid'
    for i,h in enumerate(headers): celltxt(t.rows[0].cells[i],h,True,WHITE,font); shade(t.rows[0].cells[i],BLUE)
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            celltxt(cells[i],val,False,None,font)
            if ri%2: shade(cells[i],PALE)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t
def para(text='',style=None,boldlead=None,color=None,italic=False,size=None,after=Pt(3)):
    p=doc.add_paragraph(style=style); p.paragraph_format.space_after=after
    if boldlead and text.startswith(boldlead):
        a=p.add_run(boldlead); a.bold=True; b=p.add_run(text[len(boldlead):]); runs=[a,b]
    else:runs=[p.add_run(text)]
    for r in runs:
        r.font.name='Aptos'
        if color:r.font.color.rgb=RGBColor.from_string(color)
        if italic:r.italic=True
        if size:r.font.size=Pt(size)
    return p
def bullet(text,size=7.9):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(1.5)
    r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size); return p
def callout(title,body,fill=LIGHT):
    t=doc.add_table(rows=1,cols=1); t.autofit=False; t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0); shade(c,fill); c.text=''
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(title); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9.1); r.font.color.rgb=RGBColor.from_string(NAVY)
    p2=c.add_paragraph(body); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.02
    for r in p2.runs:r.font.name='Aptos'; r.font.size=Pt(7.8)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
def newpage(kicker,title,subtitle=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(14); p.paragraph_format.space_after=Pt(4)
    r=p.add_run(kicker); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9.5); r.font.color.rgb=RGBColor.from_string(CYAN)
    p=doc.add_paragraph(style='Title'); p.paragraph_format.space_after=Pt(4); p.add_run(title)
    if subtitle: para(subtitle,color=GRAY,size=8.2,after=Pt(7))

# PAGE 21
newpage('PART 22  /  STEP 15','The 0x1347F event has a named PE producer schema',
        'Revision 102 addendum extending Revision 101  |  Static firmware analysis  |  19 November 2026')
callout('Step 15 result at a glance',
        'The strongest new connection is a named PE event producer: all seven component D-records registered under ID 0x0001347F share context pointer 0xE09680D9. That Thumb callback constructs from ROMFS descriptor 0xE0D421E0, whose embedded names are ipc_evt_prod_pe_event and IpcEvtProdPeEvent, with field labels event_id and event. The same event registration is consumed by PE, RTP manager, job tracking, copy, quiet-mode control, firmware update and SMPW. This establishes a shared PE-event producer/subscriber architecture in the static image; it does not yet prove the exact event payload that causes print blocking.',GREEN)
para('The Part 8 component D-record inventory was re-read and filtered by exact ID 0x0001347F. Seven records match. Each record has flags 0, the same ID, a component-specific callback pointer, and the same context pointer 0xE09680D9. This is a concrete cross-component relationship, not a string-only coincidence.',size=8.1)
table(['Component','D record VMA','Callback VMA','Shared context'],[
('jm_copy','0xE09EE21C','0xE0510588','0xE09680D8'),
('job_tracker','0xE0A99DA8','0xE054D5C0','0xE09680D8'),
('pe','0xE0B32AD4','0xE070E980','0xE09680D8'),
('quiet_mode_cntrl','0xE0B5BC04','0xE0788A10','0xE09680D8'),
('rest_fw_update','0xE0B5F6E4','0xE07B4400','0xE09680D8'),
('rtp_manager','0xE0B624C0','0xE07BCBE0','0xE09680D8'),
('smpw','0xE0B82058','0xE083C350','0xE09680D8'),
],[1.35,1.45,1.45,1.45],7.0)
para('The table lists the untagged code VMA for each Thumb function pointer. The stored ROMFS pointers are Thumb-tagged (address + 1). The stored shared-context pointer is likewise 0xE09680D9.',size=7.7,color=GRAY,italic=True)
callout('Why this matters',
        'The previous work had identified PE and RTP as subscribers to 0x1347F. Step 15 shows that five other named subsystems share the same registration context. This strongly favors a PE-originated broadcast/event contract over a private PE-to-RTP call. The common context descriptor gives the event a firmware-level name and schema.',LIGHT)

# PAGE 22
p=doc.add_page_break()
newpage('PART 22  /  STEP 15','The shared context resolves to IpcEvtProdPeEvent',
        'The context pointer is a Thumb entry into a small wrapper that supplies a static descriptor to the generic component/object initializer.')
para('ROMFS stores 0xE09680D9 in the context field of all seven 0x1347F D records. The untagged code address is 0xE09680D8. Its visible instructions are:',size=8.2)
table(['Address','Instruction','Effect'],[
('0xE09680D8','mov r3, r2','Preserves third argument'),
('0xE09680DA','mov r2, r1','Moves second argument'),
('0xE09680DC','mov r1, r0','Moves first argument'),
('0xE09680DE','movw r0, #0x21E0','Low half of descriptor address'),
('0xE09680E2','movt r0, #0xE0D4','r0 = 0xE0D421E0'),
('0xE09680E6','b.w 0xE066BAA8','Forwards descriptor and arguments'),
('0xE066BAA8','wrapper to 0xE066B590','Enters generic descriptor/object initializer'),
],[1.0,2.0,2.7],7.0)
para('The static descriptor at 0xE0D421E0 contains the following exact strings:',size=8.1)
table(['ROMFS VMA','String','Role suggested by descriptor placement'],[
('0xE0D4221C','ipc_evt_prod_pe_event','Machine-readable schema/type key'),
('0xE0D42234','IpcEvtProdPeEvent','Class/type name'),
('0xE0D422D4','event_id','Field/property label'),
('0xE0D422E0','event','Field/property label'),
],[1.45,2.0,2.25],7.2)
para('The wrapper points to 0xE0D421E0 and passes it to the generic initializer. The descriptor contains additional pointer/size/type fields, but their full layout and runtime instance semantics have not been reconstructed. The safe finding is the exact name/type/field linkage, not a claim that the complete C++ object has been recovered.',size=8.0)
callout('Static conclusion',
        'The 0x1347F subscriber context is statically tied to a schema named ipc_evt_prod_pe_event / IpcEvtProdPeEvent. The descriptor explicitly contains event_id and event fields. This is strong evidence that the subscriber registrations share a PE event-producer schema. The producer invocation and emitted event contents are not yet identified.',GREEN)

# PAGE 23
p=doc.add_page_break()
newpage('PART 22  /  STEP 15','Seven subscribers share one event envelope',
        'Callbacks inspect a nested event object at [r1 + 0x14], then discriminate its type at nested offset +0x0C.')
table(['Subscriber','Nested payload types observed','Behavior established from instructions'],[
('jm_copy','0x1A, 0x42','Routes the recognized PE-event payload to copy/job-local processing.'),
('job_tracker','0x1A, 0x16','Type 0x1A updates job-tracker state and sends structured state; type 0x16 updates another tracked record.'),
('pe','0x3A, 0x44, 0x02, 0x6C','Adds/removes indexed PE object pointers, updates a singleton pointer, and sets an internal latch for type 0x6C.'),
('quiet_mode_cntrl','0x89, 0x02','Handles quiet-mode object/state updates.'),
('rest_fw_update','0x7B','Routes this event subtype into firmware-update state handling.'),
('rtp_manager','0x1A, 0x50, 0xE9','Routes selected payload subtypes to RTP object and state processing.'),
('smpw','0x8B, 0x8C','Sets an SMPW object status byte at offset +0x44 according to subtype.'),
],[1.25,1.45,3.0],6.9)
para('The same event ID therefore does not mean the same action in every component. Each subscriber has a type-specific interpretation of the shared nested payload. This is consistent with a typed event envelope that supports multiple PE-related event variants.',size=8.0)
callout('Most relevant PE/RTP overlap',
        'PE and RTP both subscribe under 0x1347F and both inspect the nested payload at +0x14 / +0x0C. PE type 0x3A/0x44/0x02 paths manage PE object references; RTP type 0x1A/0x50/0xE9 paths manage RTP state. This is a concrete cross-component event relationship. However, none of the inspected branches compares the nested type directly with DSID_PRINT_ENGINE_BLOCKED 0x12196 or calls rtp_manager.block_print / unblock_print.',WARN)

# PAGE 24
p=doc.add_page_break()
newpage('PART 22  /  STEP 15','PE event flag is an object-lifecycle latch, not the print-block bit',
        'The 0x6C subtype was followed to its global flag writer and consumer to avoid misclassifying it.')
para('PE callback 0xE070E980 handles event ID 0x1347F. Its dispatch uses the nested record type at [record + 0x0C]:',size=8.2)
table(['Type','PE action','Global state'],[
('0x3A','Takes index from record +0x28 and pointer from event +0x10; calls E070E8F8','Stores pointer in 0xC1906AE4[index], index < 0xB5'),
('0x44','Calls E070E950 with record pointer','Stores pointer at 0xC1906DB8 when record fields match'),
('0x02','Calls E070E910/E070E968 to remove/clear object reference','Clears matching entries in 0xC1906AE4 and 0xC1906DB8'),
('0x6C','Writes byte 1','0xC1906F5C'),
],[0.65,3.4,1.65],7.1)
para('The 0xC1906F5C flag is consumed by PE method 0xE070E568. If set, it obtains the object held at 0xC1909FA8 through helper 0xE06FF648, obtains or creates a related object stored at 0xC1906F60, returns that pointer through the caller-provided output argument, and releases the temporary global reference through 0xE06FF618.',size=8.0)
para('The same flag is also set in the PE initialization sequence: 0xE070FBF0 calls 0xE070EBF8, which writes 1 to 0xC1906F5C. This second writer is important: the flag participates in PE initialization/object management, not solely in reaction to a runtime 0x1347F event.',size=8.0)
callout('Interpretation boundary',
        'The 0x6C event subtype sets a PE internal lifecycle latch used to retrieve/manage a shared object reference. There is no demonstrated equality to DSID_PRINT_ENGINE_BLOCKED (0x12196), no direct write to the PE blocked-state field, and no direct call to RTP block/unblock. Do not describe this flag as the print lock.',WARN)

# PAGE 25
p=doc.add_page_break()
newpage('PART 22  /  STEP 15','Power-client audit and what the event finding changes',
        'This step also closes the remaining direct POWER_CLIENT_PE_POLICY lead within the resolved .srtext acquire-call set.')
table(['Acquire reference','Client mask','Resolved client','Status'],[
('0xE058C654','0x00000100','OPT_SENSOR','Direct'),
('0xE058C6AA / 0xE058C8BC / 0xE058CB22','0x00000400','SYS','Direct'),
('0xE0671B46','0x00000200','SCAN','Direct'),
('0xE071447C','0x00000010','UDW','Direct'),
('0xE0741712','0x00000008','PEN','Direct'),
('0xE0928584','0x00000001','MECH','Direct'),
('0xE093DF2E / 0xE093E354','0x00000800','BOARD','Library-internal'),
('0xE093E3F4','0x00000010','UDW','Library-internal'),
('0xE0561B64','incoming mask; known callers pass 0x8','PEN','Wrapper'),
('0xE073C4D8','incoming mask; known callers pass 0x8','PEN','Wrapper'),
('0xE093E2A4','caller supplied','Unknown external/indirect','Exported wrapper; no direct caller recovered'),
],[1.8,1.5,1.3,1.15],6.8)
callout('PE_POLICY result',
        'The corrected PE_POLICY client mask is 0x00400000. None of the 14 direct references to the common acquire helper in the inspected .srtext supplies that mask. The two dynamic wrappers have known direct callers that pass PEN (0x8). An exported lib_power API wrapper may still be invoked indirectly by code not represented in the direct-call graph, so the conclusion is limited to resolved direct .srtext call sites.',GREEN)
para('Step 15 changes the investigation priority. The best new path is no longer the 0x00400000 stack value or the opaque .load_text bytes alone. It is the named producer schema IpcEvtProdPeEvent and the callback registration path shared by PE, RTP, job_tracker and other modules.',size=8.1)
para('Still unresolved',style='Heading 2')
bullet('Which concrete function emits event_id 0x1347F and which event subtype corresponds to the blocked-print transition.')
bullet('Whether the PE type 0x6C lifecycle event relates to the print-engine service dependency or is unrelated object management.')
bullet('Whether any indirect lib_power API consumer requests PE_POLICY outside the direct .srtext call graph.')
bullet('How the subscribedPagesOutAccountProblem alert 66220 is translated into any PE/RTP/IPP print-admission decision.')

# PAGE 26
p=doc.add_page_break()
newpage('PART 22  /  STEP 15','Step 15 conclusion and next targeted trace',
        'Static-only increment. No printer interaction, firmware modification, reset, flash, print job, scan job or network request was performed.')
callout('Most useful finding to date',
        'The firmware has a named PE event-producer schema, IpcEvtProdPeEvent, whose shared context constructor is referenced by seven component D-records under event ID 0x1347F. PE and RTP are both subscribers, as are job_tracker, jm_copy, quiet_mode_cntrl, rest_fw_update and smpw. This is the first strong named architectural bridge linking PE/RTP behavior to a broader event bus. It provides a concrete producer-side target for tracing the actual print-state transition.',GREEN)
table(['Question','Step 15 result','Status'],[
('What is 0x1347F tied to?','Shared context descriptor names ipc_evt_prod_pe_event / IpcEvtProdPeEvent and contains event_id / event fields.','Strong static metadata linkage'),
('Which components subscribe?','Seven D-array records: jm_copy, job_tracker, pe, quiet_mode_cntrl, rest_fw_update, rtp_manager, smpw.','Confirmed'),
('Does PE notify RTP through this path?','Both are registered for the same producer/context and consume the same event envelope.','Strong architectural relationship; runtime delivery not observed'),
('Is PE subtype 0x6C the print lock?','It sets a PE object-lifecycle flag; no direct blocked-state write or RTP block call.','Not established'),
('Does PE_POLICY participate in direct power requests?','No direct .srtext acquire-helper call uses 0x00400000.','Not observed in direct call set'),
('Is subscribedPagesOutAccountProblem connected?','No producer payload or enforcement path to alert 66220 recovered yet.','Unresolved'),
],[1.7,3.35,1.1],7.0)
para('Proposed next focused trace',style='Heading 2')
para('Trace the PE event producer instance and its publish/emit call sites: follow the constructor/metadata object created from 0xE0D421E0, locate the method that populates the event_id and event fields, then identify all producers of ID 0x1347F and map their nested event subtypes to PE, job_tracker and RTP state changes. Prioritize payload subtype values that modify PE service state or cause RTP to update its internal print admission path. Keep the alert 66220 path separate until an explicit data/control edge is found.',size=8.1)
callout('Stop point',
        'Step 15 has produced a useful, reproducible producer/subscriber architecture and an explicit negative result for direct PE_POLICY requests. The next unresolved edge is the actual event emission and its payload semantics. Do not infer print blocking from the shared event registration alone.',WARN)
para('Evidence package: Part22_Step15_PE_Event_Producer_and_Client_Audit_Evidence.zip. It includes the seven D records, callback behavior inventory, ROMFS producer descriptor, focused disassembly, power-client call audit, source hashes, verifier and SHA-256 manifest.',italic=True,color=GRAY,size=7.8)

# Metadata
props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 102 Part 22 Step 15 Addendum'
props.subject='Named PE event producer IpcEvtProdPeEvent, shared 0x1347F subscriber trace, PE event latch, and power client audit'
props.author='OpenAI'
props.keywords='HP DeskJet 2855e, firmware, IpcEvtProdPeEvent, PE event, RTP, POWER_CLIENT_PE_POLICY, 0x1347F'
doc.save(OUT)
print(OUT)
