# Part 22, Step 15 - PE event producer and power-client audit

## Scope

Static-only continuation from the verified Step 14/Revision 101 baseline. The work reuses the reconstructed main `.srtext` and ROMFS object images and the Part 8 component D-record crosswalk. No printer communication, print/scan request, firmware write, reset, flash, or device-state change was performed.

## Principal result

Seven component D-records subscribe under ID `0x0001347F`: `jm_copy`, `job_tracker`, `pe`, `quiet_mode_cntrl`, `rest_fw_update`, `rtp_manager`, and `smpw`. All seven use the same context pointer, Thumb address `0xE09680D9` (code at `0xE09680D8`). That wrapper loads the static ROMFS descriptor at `0xE0D421E0` and forwards it to generic helper `0xE066BAA8` / `0xE066B590`.

The descriptor contains the exact strings:

- `ipc_evt_prod_pe_event` at `0xE0D4221C`
- `IpcEvtProdPeEvent` at `0xE0D42234`
- `event_id` at `0xE0D422D4`
- `event` at `0xE0D422E0`

This is strong static metadata linkage between all seven `0x1347F` subscriber records and a named PE event-producer schema/class. The producer's actual runtime publish call and specific event payload remain unresolved.

## Callback behavior

The callback handlers use a common nested-event envelope and discriminate nested type values at `[event + 0x14] + 0x0C`. The observed values differ by component:

- `jm_copy`: `0x1A`, `0x42`
- `job_tracker`: `0x1A`, `0x16`
- `pe`: `0x3A`, `0x44`, `0x02`, `0x6C`
- `quiet_mode_cntrl`: `0x89`, `0x02`
- `rest_fw_update`: `0x7B`
- `rtp_manager`: `0x1A`, `0x50`, `0xE9`
- `smpw`: `0x8B`, `0x8C`

This supports a shared, typed PE-event envelope consumed by several components. It does not establish that every event subtype is a print-state event.

## PE latch classification

The PE callback's subtype `0x6C` sets byte `0xC1906F5C`. PE method `0xE070E568` reads this byte and uses shared-object reference helpers around global `0xC1909FA8`, storing a related pointer at `0xC1906F60`. The same latch is set during PE initialization by `0xE070FBF6 -> 0xE070EBF8`.

Therefore, the defensible classification is an internal PE object-lifecycle/initialization latch. It is not established as `DSID_PRINT_ENGINE_BLOCKED` (`0x12196`), and no direct call from this path to RTP `block_print` / `unblock_print` was recovered.

## Power-client audit

The 14 acquire-helper references in the main `.srtext` were classified. All statically resolved request masks correspond to `MECH`, `PEN`, `UDW`, `OPT_SENSOR`, `SCAN`, `SYS`, or `BOARD`. None supplies the corrected `POWER_CLIENT_PE_POLICY` mask `0x00400000`. Two mask-forwarding wrappers have known direct callers that pass PEN (`0x8`). The exported `lib_power` wrapper can still be called indirectly by code outside this direct-call set; the result is not an absolute proof of global non-use.

## What remains unresolved

1. The concrete code that emits event ID `0x1347F` and the precise values/semantics of all event payload subtypes.
2. Whether one of these payload subtypes represents a PE print-admission or blocked-state transition.
3. The runtime pointer handoff from the named Sirius dependency records and the actual RTP provider in slot 12.
4. Any data/control edge from alert 66220 / `subscribedPagesOutAccountProblem` to PE blocked state or RTP block/unblock.
5. Whether an indirect consumer outside the resolved main `.srtext` requests `POWER_CLIENT_PE_POLICY`.

## Verification

`verify_part22_step15.py` verifies source hashes, all seven D-record tuples and their shared context pointer, exact ROMFS descriptor bytes and field strings, callback-address evidence, the PE latch path, and the bounded power-client audit. Expected result: `68/68 PASS`.

`SHA256SUMS` contains the SHA-256 manifest for all evidence files except the manifest itself.
