#!/usr/bin/env python3
from pathlib import Path
import hashlib, pandas as pd, struct, sys
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name, condition, detail=''):
    checks.append((name,bool(condition),detail))

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

# Reproducible source identities
expected={
 'source_srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
 'source_romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
}
for fn,digest in expected.items():
 p=ROOT/fn
 check(f'{fn} exists',p.exists(),str(p))
 check(f'{fn} sha256',p.exists() and sha(p)==digest,sha(p) if p.exists() else 'missing')

# Seven D records for 0x1347F
csv=ROOT/'shared_pe_event_0x1347f_d_subscribers.csv'
df=pd.read_csv(csv)
expected_rows={
 'jm_copy':('0xE09EE21C','0xE0510589','0xE09680D9'),
 'job_tracker':('0xE0A99DA8','0xE054D5C1','0xE09680D9'),
 'pe':('0xE0B32AD4','0xE070E981','0xE09680D9'),
 'quiet_mode_cntrl':('0xE0B5BC04','0xE0788A11','0xE09680D9'),
 'rest_fw_update':('0xE0B5F6E4','0xE07B4401','0xE09680D9'),
 'rtp_manager':('0xE0B624C0','0xE07BCBE1','0xE09680D9'),
 'smpw':('0xE0B82058','0xE083C351','0xE09680D9'),
}
check('seven D subscribers',len(df)==7,f'rows={len(df)}')
check('D records all id 0x1347F',len(df)==7 and set(df['id'])=={'0x0001347F'},str(df['id'].tolist()))
check('D records all flags zero',len(df)==7 and set(df['flags'])=={'0x00000000'},str(df['flags'].tolist()))
check('component set',set(df['component'])==set(expected_rows),','.join(sorted(df['component'].tolist())))
for comp,(record,callback,context) in expected_rows.items():
 row=df[df.component==comp]
 ok=len(row)==1 and str(row.iloc[0]['record_address'])==record and str(row.iloc[0]['callback'])==callback and str(row.iloc[0]['context'])==context
 check(f'{comp} D record tuple',ok,str(row.to_dict('records')))

# Descriptor bytes and named schema fields
rom=ROOT/'source_romfs_objs_rebuilt.bin'
b=rom.read_bytes(); base=0xE09919C0
vma=0xE0D421E0; off=vma-base
raw=(ROOT/'romfs'/'ipc_evt_prod_pe_event_descriptor.bin').read_bytes()
check('descriptor slice length',len(raw)==0x130,f'len=0x{len(raw):X}')
check('descriptor byte equality',raw==b[off:off+0x130])
for s,a in [(b'ipc_evt_prod_pe_event',0xE0D4221C),(b'IpcEvtProdPeEvent',0xE0D42234),(b'event_id',0xE0D422D4),(b'event',0xE0D422E0)]:
 i=a-base
 check(f'descriptor string {s.decode()}',i>=0 and b[i:i+len(s)+1]==s+b'\x00',hex(base+i) if i>=0 else 'not found')
check('descriptor pointer to type name',struct.unpack_from('<I',b,off+4)[0]==0xE0D4221C)
check('descriptor pointer to C++ class name',struct.unpack_from('<I',b,off+8)[0]==0xE0D42234)

# Shared wrapper and generic initializer target
wrap=(ROOT/'romfs'/'event_context_wrapper_and_descriptor.txt').read_text()
for token in ['e09680d8','0xe0d421e0','0xe066baa8','ipc_evt_prod_pe_event','IpcEvtProdPeEvent','event_id','event']:
 check(f'context wrapper evidence contains {token}',token.lower() in wrap.lower())

# Callback behavior map and source disassembly excerpt
beh=pd.read_csv(ROOT/'event_0x1347f_callback_behavior.csv')
check('seven callback behavior rows',len(beh)==7)
for _,r in beh.iterrows():
 check(f'{r.component} callback VMA present',str(r.function_vma).lower().replace('0x','') in (ROOT/'disassembly'/'event_0x1347f_and_pe_latch.dis').read_text().lower())
text=(ROOT/'disassembly'/'event_0x1347f_and_pe_latch.dis').read_text()
for token in ['e0510588:','e054d5c0:','e070e980:','e0788a10:','e07b4400:','e07bcbe0:','e083c350:','0x347f','0x3a','0x44','0x6c','0x8b','0x8c','0x7b']:
 check(f'disassembly evidence {token}',token.lower() in text.lower())
for token in ['#0x6f5c','#0x6ae4','#0x6db8','#0x9fa8','e070e568','e070ebf8']:
 check(f'PE latch evidence {token}',token.lower() in text.lower())

# Power audit is bounded to 14 direct helper references in the previously audited main .srtext.
power=pd.read_csv(ROOT/'power_client_acquire_call_audit.csv')
check('14 acquire call references represented',len(power)==14,f'rows={len(power)}')
check('no resolved PE_POLICY mask',not any(str(x).strip().lower()=='0x00400000' for x in power['client_mask_argument']),str(power['client_mask_argument'].tolist()))
check('dynamic exported wrapper preserved as caveat',any((power['site']=='0xE093E2A4') & power['client_mask_argument'].astype(str).str.contains('caller supplied')))
check('PEN dynamic wrapper callers classified',any(power['notes'].astype(str).str.contains('PEN')))
check('known SCAN mask classified',any((power['client_mask_argument']=='0x00000200') & (power['client_name']=='SCAN')))
check('known BOARD mask classified',any((power['client_mask_argument']=='0x00000800') & (power['client_name']=='BOARD')))

# Explicit limit/interpretation guardrails in findings text
findings=(ROOT/'STEP15_FINDINGS.txt').read_text()
for phrase in ['not fully recovered','unresolved','that equivalence is not established','not proof']:
    check(f'limit guardrail text: {phrase}',phrase in findings.lower())

passed=sum(1 for _,ok,_ in checks if ok); failed=len(checks)-passed
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
print(f'\nRESULT: {passed}/{len(checks)} PASS; {failed} FAIL')
if failed: sys.exit(1)
