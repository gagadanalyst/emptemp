# Part 22 / Step 32 evidence

This package audits the identified write paths for the Pen TooEarly mask and corrects the Step 31 callback reachability conclusion.

## Key results
- Pen service 0x1FF211 reads main state-bank field 0x1F and secondary property field 0x32 (plus a separately gated 0x800 contribution).
- Service writer 0xE07399E8 and notification router 0xE0737C08 only OR bits into the existing mask; they cannot clear a stored TooEarly bit by omission.
- Main reconciliation routine 0xE07281A0 writes zero to main field 0x1F only in the cleanup branch where both comparator classifications are below 2.
- Secondary reconciliation routine 0xE0729298 either copies main field 0x1F to secondary field 0x32 or explicitly zeroes secondary fields 0x32..0x36.
- Validator 0xE0728658 has opaque per-supply/context/property gates; their business meaning is not established.
- Bulk zero routine 0xE0737650 contains matching zero writes but no direct branch/call or absolute pointer reference was found in the scanned binary/ELF/ROMFS inputs; reachability is unproven.
- The apparent callback call at 0xE0748F26 is not reachable through registered callback 0xE0748B08 because guard 0xE073C150 returns 1 in this image.

## Contents
- `disassembly/`: focused ARM/Thumb instruction excerpts.
- `crosswalks/tooearly_mask_write_path_crosswalk.csv`: classified write-path matrix.
- `analysis/`: direct branch and absolute pointer scans, router descriptor bytes, and Step 31 callback correction.
- `baselines/`: unmodified Step 31 and Part 1 evidence archives.
- `SOURCE_INPUTS.txt`: SHA-256 provenance for the source binary/disassembly inputs.
- `verification_output.txt`: focused structural checks.
- `STEP32_FINDINGS.txt`: concise findings and interpretation limits.

Static analysis only. No printer communication, print/scan job, firmware modification, DSID write, event injection, account change, or bypass was performed.
