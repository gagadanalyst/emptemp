from __future__ import annotations
import csv, hashlib, shutil, struct, zipfile
from pathlib import Path

ROOT = Path('/mnt/data/hp_part22_step26')
EV = ROOT / 'evidence'
SRC = Path('/mnt/data/hp_part22_step25/evidence')
ALL_DIS = Path('/mnt/data/hp_part22_step24/all.dis')
ROMFS_BASE = 0xE09919C0

# Carry forward exact source binaries and prior verified baseline.
for name in ['hp_lbi_sections.elf', 'srtext_rebuilt.bin', 'romfs_objs_rebuilt.bin']:
    shutil.copy2(SRC / name, EV / name)
shutil.copy2(SRC / 'SOURCE_HASHES.txt', EV / 'SOURCE_HASHES.txt')
shutil.copy2(Path('/mnt/data/hp_part22_step25/Part22_Step25_SiriusInstance_Publisher_Callback_Binding_Evidence.zip'), EV / 'prior_baseline' / 'Part22_Step25_SiriusInstance_Publisher_Callback_Binding_Evidence.zip')
for name in ['C1443000_service_setter.dis', 'C1443000_constructor.dis', 'C1443000_service_setter_thunk.dis', 'C1443000_constructor_call.dis']:
    p = SRC / 'disassembly' / name
    if p.exists(): shutil.copy2(p, EV / 'disassembly' / name)

lines = ALL_DIS.read_text(errors='replace').splitlines()

def extract_range(start: int, end: int) -> str:
    out=[]
    for line in lines:
        try: addr=int(line.split(':',1)[0],16)
        except (ValueError, IndexError): continue
        if start <= addr < end: out.append(line)
    if not out: raise RuntimeError(f'No disassembly lines for {start:#x}-{end:#x}')
    return '\n'.join(out)+'\n'

ranges = {
    'pink_mask_update_callsite.dis': (0xE030B478, 0xE030B538),
    'pink_mask_writer_method_E0308438.dis': (0xE0308438, 0xE0308472),
    'dynamic_status_callsite_E030BB38.dis': (0xE030BB38, 0xE030BC08),
    'same_table_method_E0307A38.dis': (0xE0307A38, 0xE0307A6A),
    'constat_system_info_copy_E0308520.dis': (0xE0308520, 0xE03085B0),
    'separate_reason_writer_E03076C0.dis': (0xE03076C0, 0xE03077F0),
    'alternate_interface_method_E0308228.dis': (0xE0308228, 0xE030826A),
    'alternate_interface_copy_E03088E0.dis': (0xE03088E0, 0xE0308908),
}
for name, (a,b) in ranges.items():
    (EV/'disassembly'/name).write_text(extract_range(a,b))

# ROMFS vtable words around both candidate address points.
romfs=(EV/'romfs_objs_rebuilt.bin').read_bytes()
def word_at_va(va: int) -> int:
    off=va-ROMFS_BASE
    return struct.unpack_from('<I',romfs,off)[0]

vtable_lines=[]
for base, end in [(0xE09AEA38,0xE09AEC10), (0xE09AED08,0xE09AED28)]:
    vtable_lines.append(f'ROMFS words, VMA {base:#010x} through {end:#010x}')
    for va in range(base,end,4):
        vtable_lines.append(f'{va:08X}  {word_at_va(va):08X}')
    vtable_lines.append('')
(EV/'romfs'/'vtable_address_point_words.txt').write_text('\n'.join(vtable_lines)+'\n')

# Crosswalks.
with (EV/'crosswalks'/'step26_vtable_crosswalk.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['table_base','slot_offset','entry_address','thumb_pointer','code_address','behavior','confidence'])
    w.writerow(['0xE09AEA38','0x54','0xE09AEA8C','0xE0308439','0xE0308438','PINK supply error-mask OR writer; takes index in r1 and scalar mask in r2','Strong static match; runtime service pointer unresolved'])
    w.writerow(['0xE09AEA38','0x174','0xE09AEBAC','0xE0307A39','0xE0307A38','Copies ConStat system-info output; r1 is output structure','Strong table arithmetic match; runtime service pointer unresolved'])
    w.writerow(['alternate candidate base 0xE09AEBA4','0x174','0xE09AED18','0xE03076C1','0xE03076C0','ConStat reason-group writer','Different address-point table; not the +0x174 entry of 0xE09AEA38'])
    w.writerow(['alternate candidate base 0xE09AEBA4','0x54','0xE09AEBF8','0xE0308229','0xE0308228','Copies per-supply data to caller output via 0xE03088E0; r2 acts as output pointer','Argument shape conflicts with scalar mask supplied by 0xE030B478'])

with (EV/'crosswalks'/'step26_callsite_argument_map.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['callsite','receiver_source','slot','r1','r2','r3','best_matching_target','interpretation'])
    w.writerow(['0xE030B478','[0xE0308F10() + 0x20] = [0xC1443000 + 0x20]','+0x54','r7 (supply index)','r5 (scalar PINK mask)','not used for method args','0xE0308438','OR mask into per-supply record at +0x1AC8 + index*8 + 4; then notification helper'])
    w.writerow(['0xE030BB38','[0xE0308F10() + 0x20] = [0xC1443000 + 0x20]','+0x174','r11 (output/context argument)','r4 (derived value candidate)','r5 (flag/record value)','0xE0307A38 in matching table','Copies ConStatSystemInfoT including can_print; does not establish reason insertion'])

# Detailed findings.
findings = '''PART 22 — STEP 26 FINDINGS
Revision 112 | 20 November 2026

TITLE
ConStat vtable mapping and reason-path correction

GOLDEN FINDING
The Step 22 assertion that 0xE030BB38 reaches reason-insertion method 0xE03076C0 through virtual slot +0x174 on the same injected provider used by the PINK mask updater is not supported by the matching vtable layout. The ROMFS address point that coherently maps the +0x54 scalar-mask writer also maps +0x174 to 0xE0307A38, a ConStat system-info copy/status method. Its downstream copy routine places this+0x2F8 into ConstatSystemInfoT.can_print at output +0x8C.

1. SHARED RECEIVER FIELD
0xE0308F10 returns 0xC1443000. The setter at 0xE0308D90 maps service 0x001FF211 to root field +0x20. Both call sites 0xE030B478 and 0xE030BB38 call 0xE0308F10, load [r0+0x20], read the receiver vptr, and invoke a virtual slot on that provider field.

2. MATCHING VTABLE ADDRESS POINT
The candidate ROMFS address point is 0xE09AEA38. Its entry +0x54 is at 0xE09AEA8C and contains Thumb pointer 0xE0308439 (code 0xE0308438). Its entry +0x174 is at 0xE09AEBAC and contains Thumb pointer 0xE0307A39 (code 0xE0307A38).

0xE0308438 receives a supply index in r1 and scalar error mask in r2, resolves the index, loads the error word from this + 0x1AC8 + index*8 + 4, ORs the mask, stores the result, and calls 0xE0305708. This is a strong semantic match for the +0x54 call at 0xE030B478.

3. THE +0x174 METHOD IS A STATUS-COPY PATH
At 0xE030BBCA-0xE030BBDC, the code calls the same provider field through slot +0x174. Under the matching table above, the target is 0xE0307A38. This method uses r1 as an output structure, invokes 0xE0308520, and returns a provider field. It does not consume r2/r3 as a ConStat reason insertion request.

0xE0308520 copies several fields from the internal ConStat object to a caller structure. In particular:
  this + 0x2F8 -> output + 0x8C (ConstatSystemInfoT.can_print)
  this + 0x2FC -> output + 0x90

This establishes a CanPrint/system-info data path, not the claimed dynamic reason insertion.

4. KEEP 0xE03076C0 SEPARATE
0xE03076C0 remains a real routine that manipulates ConStat reason groups at this + 0x8F4 and touches the PINK mask area at this + 0x1AC8. Its function pointer is present at ROMFS address 0xE09AED18. That is not the +0x174 entry of the matching 0xE09AEA38 table. To treat it as a +0x174 entry requires another address point, 0xE09AEBA4; the +0x54 entry for that alternate base is 0xE0308228, whose code passes r2 to 0xE03088E0 as an output-structure pointer. That signature conflicts with the scalar mask supplied by 0xE030B478.

The vptr returned at runtime for service 0x001FF211 is still unresolved. Therefore this is a correction to the earlier asserted same-interface mapping. It is not proof that no other interface can call 0xE03076C0.

5. CONSEQUENCE FOR TOOEARLY -> CONSTAT 0x13
PINK supplyInksubTooEarly remains mask 0x00020000. ConStat INKSUB_REPLACED_EARLY remains reason code 0x13. The old E030BB38 candidate no longer proves that the derived 1-or-4 value reaches the reason-insertion method. The executable conversion is still unresolved.

6. NEXT TARGET
Resolve service 0x001FF211 through the generic component registry and establish its actual runtime vptr. Then find genuine callers of 0xE03076C0 (or another verified reason-insertion entry) and follow any path carrying mask 0x00020000 or reason 0x13.

SCOPE
Static firmware analysis only. No printer communication, runtime status request, IPP/eSCL job, firmware write, reset, or physical action occurred.
'''
(EV/'STEP26_FINDINGS.txt').write_text(findings)

readme='''# Part 22, Step 26 evidence — ConStat vtable and reason-path correction

Revision 112 (20 November 2026).

## Purpose

Correct the earlier Step 22 attribution of the `0xE030BB38` virtual call to `0xE03076C0`. The evidence reconciles the PINK mask-writer slot (`+0x54`) and the dynamic status-query slot (`+0x174`) against the same candidate ROMFS vtable address point.

## Main findings

- `0xE0308F10` returns root `0xC1443000`; service `0x001FF211` populates root field `+0x20`.
- `0xE030B478` loads that provider and calls vtable `+0x54` with a supply index and scalar PINK mask. The best-fitting ROMFS address point `0xE09AEA38` maps this slot to `0xE0308438`, which ORs the scalar mask into the per-supply word at `this + 0x1AC8 + index*8 + 4`.
- The same table's `+0x174` slot maps to `0xE0307A38`, not `0xE03076C0`. `0xE0307A38` calls `0xE0308520` and copies the ConStat system-info structure, including `can_print` at output offset `+0x8C`.
- `0xE03076C0` remains a reason-group writer, but its ROMFS function-pointer location is not the `+0x174` entry of the matched table. The actual runtime vptr for `0x001FF211` remains unresolved.
- Therefore the E030BB38 dynamic-value path is withdrawn as evidence for `TooEarly` mask `0x00020000` -> ConStat reason `0x13`.

## Evidence contents

- Exact source binaries carried forward from Step 25: `hp_lbi_sections.elf`, `srtext_rebuilt.bin`, `romfs_objs_rebuilt.bin`.
- Focused disassembly for all relevant call sites and methods.
- ROMFS vtable address-point words and service/callsite crosswalk CSVs.
- Prior Step 25 evidence ZIP retained as the baseline.
- Reproducible focused verifier and checksums.

## Verification

Run:

```bash
python evidence/verify_step26.py
sha256sum -c DELIVERY_SHA256SUMS.txt
unzip -t Part22_Step26_ConStat_Vtable_and_Reason_Path_Correction_Evidence.zip
```

The verifier checks source hashes, table arithmetic, callsite slots, method behavior, output field offsets, and the distinct `0xE03076C0` table entry.

Static-only: no printer interaction, job submission, firmware write, reset, or physical device action.
'''
(EV/'README_PART22_STEP26.md').write_text(readme)

# Verify the Step 25 source hashes exactly before sealing.
source_hashes = (EV/'SOURCE_HASHES.txt').read_text().splitlines()
for line in source_hashes:
    if not line.strip(): continue
    expected, name = line.split(None,1)
    actual=hashlib.sha256((EV/name.strip()).read_bytes()).hexdigest()
    if actual != expected: raise RuntimeError(f'Source hash mismatch for {name}: {actual} != {expected}')
print('Copied source binaries and verified carried-forward hashes.')
