from __future__ import annotations
import hashlib, struct, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EV=ROOT/'evidence'
SRC_HASHES=(EV/'SOURCE_HASHES.txt').read_text().splitlines()
checks=[]
def check(name, condition):
    checks.append((name, bool(condition)))

def read(rel): return (EV/rel).read_text(errors='replace')

# Exact carried-forward source identity.
for line in SRC_HASHES:
    if not line.strip(): continue
    expected,name=line.split(None,1)
    p=EV/name.strip()
    check(f'source hash {name.strip()}', p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected)

call54=read('disassembly/pink_mask_update_callsite.dis')
method54=read('disassembly/pink_mask_writer_method_E0308438.dis')
call174=read('disassembly/dynamic_status_callsite_E030BB38.dis')
method174=read('disassembly/same_table_method_E0307A38.dis')
copy=read('disassembly/constat_system_info_copy_E0308520.dis')
reason=read('disassembly/separate_reason_writer_E03076C0.dis')
alt54=read('disassembly/alternate_interface_method_E0308228.dis')
altcopy=read('disassembly/alternate_interface_copy_E03088E0.dis')

# +0x54 PINK mask update call path.
check('PINK updater calls root accessor 0xE0308F10','e0308f10' in call54.lower())
check('PINK updater loads dependency field +0x20','[r0, #0x20]' in call54.lower())
check('PINK updater loads vtable slot +0x54','[r1, #0x54]' in call54.lower())
check('PINK updater supplies r1 index','mov\tr1, r7' in call54 or 'mov\tr1, r7' in call54.replace(' ', '\t'))
check('PINK updater supplies r2 mask','mov\tr2, r5' in call54 or 'mov\tr2, r5' in call54.replace(' ', '\t'))
check('mask method begins at 0xE0308438','e0308438:' in method54.lower())
check('mask method resolves supply index','e0307890' in method54.lower())
check('mask method uses per-supply mask base +0x1AC8','0x1ac8' in method54.lower())
check('mask method scales supply index by eight','lsl #3' in method54.lower())
check('mask method reads error word at record +0x04','[r2, #0x4]' in method54.lower())
check('mask method ORs incoming r5 mask','orrs\tr0, r5' in method54.lower() or 'orrs r0, r5' in method54.lower())
check('mask method stores updated error word','str\tr0, [r2, #0x4]' in method54.lower() or 'str r0, [r2, #0x4]' in method54.lower())
check('mask method calls notifier 0xE0305708','e0305708' in method54.lower())

# +0x174 call and matching-table target.
check('status routine calls root accessor 0xE0308F10','e0308f10' in call174.lower())
check('status routine loads same dependency field +0x20','[r0, #0x20]' in call174.lower())
check('status routine loads vtable slot +0x174','0x174' in call174.lower())
check('status call passes saved r1 argument','mov\tr1, r11' in call174.lower() or 'mov r1, r11' in call174.lower())
check('status call passes derived r2 argument','mov\tr2, r4' in call174.lower() or 'mov r2, r4' in call174.lower())
check('status call passes r3 flags','mov\tr3, r5' in call174.lower() or 'mov r3, r5' in call174.lower())
check('same-table method target begins at 0xE0307A38','e0307a38:' in method174.lower())
check('same-table method calls 0xE0308520','e0308520' in method174.lower())
check('same-table method saves r1 as output pointer','movs\tr4, r1' in method174.lower() or 'movs r4, r1' in method174.lower())
check('same-table method calls status validation helper','e03028b0' in method174.lower())
check('same-table method does not call 0xE03076C0','e03076c0' not in method174.lower())

# Output structure copy mapping.
check('ConStat copy routine loads source +0x2F8','[r0, #0x2f8]' in copy.lower())
check('ConStat copy routine stores output +0x8C','[r1, #0x8c]' in copy.lower())
check('ConStat copy routine loads source +0x2FC','[r0, #0x2fc]' in copy.lower())
check('ConStat copy routine stores output +0x90','[r1, #0x90]' in copy.lower())

# E03076C0 and alternate table disambiguation.
check('reason writer function exists','e03076c0:' in reason.lower())
check('reason writer manipulates group array +0x8F4','0x8f4' in reason.lower())
check('reason writer touches PINK array +0x1AC8','0x1ac8' in reason.lower())
check('alternate +0x54 method exists at 0xE0308228','e0308228:' in alt54.lower())
check('alternate method passes r2 to copy helper 0xE03088E0','e03088e0' in alt54.lower())
check('alternate copy helper uses r2 as destination','[r2, #0xc]' in altcopy.lower() or 'str r1, [r2, #0xc]' in altcopy.lower())

# ROMFS address-point arithmetic.
rom=(EV/'romfs_objs_rebuilt.bin').read_bytes(); base=0xE09919C0
def word(va): return struct.unpack_from('<I',rom,va-base)[0]
check('ROMFS table base +0x54 entry is E0308439',word(0xE09AEA38+0x54)==0xE0308439)
check('ROMFS table base +0x174 entry is E0307A39',word(0xE09AEA38+0x174)==0xE0307A39)
check('E03076C1 is at separate ROMFS address E09AED18',word(0xE09AED18)==0xE03076C1)
check('alternate base +0x54 entry is E0308229',word(0xE09AEBA4+0x54)==0xE0308229)
check('alternate base +0x174 entry is E03076C1',word(0xE09AEBA4+0x174)==0xE03076C1)
check('table arithmetic distinguishes alternate base from matched base',(0xE09AED18-0x174)==0xE09AEBA4 and (0xE09AEA38+0x174)==0xE09AEBAC)

# Deliverable presence and previous baseline.
docx_path=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision112_Part22_Step26_ConStat_Vtable_and_Reason_Path_Correction_Addendum.docx'
pdf_path=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision112_Part22_Step26_ConStat_Vtable_and_Reason_Path_Correction_Addendum.pdf'
check('Revision 112 DOCX exists',docx_path.is_file())
check('Revision 112 PDF exists',pdf_path.is_file())
check('DOCX ZIP structure is valid',docx_path.is_file() and zipfile.ZipFile(docx_path).testzip() is None)
try:
    import fitz
    pdf=fitz.open(pdf_path) if pdf_path.is_file() else None
    check('PDF page count is two',pdf is not None and pdf.page_count==2)
    check('PDF is US Letter',pdf is not None and all(abs(p.rect.width-612)<0.1 and abs(p.rect.height-792)<0.1 for p in pdf))
except Exception:
    check('PDF page count is two',False)
    check('PDF is US Letter',False)
check('prior Step 25 baseline retained',(EV/'prior_baseline'/'Part22_Step25_SiriusInstance_Publisher_Callback_Binding_Evidence.zip').is_file())

fail=[n for n,ok in checks if not ok]
lines=[f'Step 26 focused verifier: {len(checks)-len(fail)}/{len(checks)} PASS']
lines += [('PASS' if ok else 'FAIL')+' | '+name for name,ok in checks]
(EV/'verification_output.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
if fail: raise SystemExit(1)
