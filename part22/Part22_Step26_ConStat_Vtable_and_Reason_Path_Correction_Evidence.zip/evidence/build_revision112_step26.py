from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = Path('/mnt/data/hp_part22_step26/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision112_Part22_Step26_ConStat_Vtable_and_Reason_Path_Correction_Addendum.docx')

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def set_cell_text(cell, text, bold=False, size=8.3, color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(text)
    r.bold = bold
    r.font.name = 'Aptos'
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_bullet(doc, text, level=0):
    p = doc.add_paragraph(style='List Bullet' if level == 0 else 'List Bullet 2')
    p.paragraph_format.space_after = Pt(2)
    p.add_run(text)
    return p

def add_code(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.18)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    r.font.name = 'Consolas'
    r.font.size = Pt(8)
    r.font.color.rgb = RGBColor(35, 55, 75)
    return p

doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.55)
sec.bottom_margin = Inches(0.55)
sec.left_margin = Inches(0.68)
sec.right_margin = Inches(0.68)

styles = doc.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal'].font.size = Pt(9)
styles['Normal'].paragraph_format.space_after = Pt(4)
styles['Normal'].paragraph_format.line_spacing = 1.0
for name, sz, col in [('Title', 19, (31, 63, 91)), ('Heading 1', 13, (31, 63, 91)), ('Heading 2', 10.5, (39, 91, 130))]:
    st = styles[name]
    st.font.name = 'Aptos Display'
    st.font.size = Pt(sz)
    st.font.bold = True
    st.font.color.rgb = RGBColor(*col)
    st.paragraph_format.space_before = Pt(5)
    st.paragraph_format.space_after = Pt(3)

# Header/footer
header = sec.header.paragraphs[0]
header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
hr = header.add_run('HP DESKJET FIRMWARE | PART 22 STATIC INVESTIGATION')
hr.font.name = 'Aptos'; hr.font.size = Pt(7); hr.font.color.rgb = RGBColor(100, 110, 120)
footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
fr = footer.add_run('Revision 112 | Step 26 | 20 November 2026 | Static analysis only')
fr.font.name = 'Aptos'; fr.font.size = Pt(7); fr.font.color.rgb = RGBColor(100, 110, 120)

p = doc.add_paragraph()
p.paragraph_format.space_after = Pt(1)
r = p.add_run('REVISION 112  /  PART 22  /  STEP 26')
r.bold = True; r.font.size = Pt(8); r.font.color.rgb = RGBColor(39, 91, 130)

t = doc.add_paragraph(style='Title')
t.paragraph_format.space_after = Pt(3)
t.add_run('ConStat vtable mapping and reason-path correction')

p = doc.add_paragraph()
p.paragraph_format.space_after = Pt(6)
r = p.add_run('Finding: the earlier E030BB38 → E03076C0 reason-insertion attribution is not supported by the matching vtable layout.')
r.bold = True; r.font.size = Pt(10); r.font.color.rgb = RGBColor(153, 77, 28)

p = doc.add_paragraph()
p.add_run('Scope. ').bold = True
p.add_run('Reconcile the two virtual calls made through the injected provider at C1443000 + 0x20. The purpose is to determine whether the PINK mask updater and the previously alleged ConStat reason-insertion path share one interface table. No printer communication or firmware modification was performed.')

doc.add_heading('1. One injected object, two virtual-call sites', level=1)
p = doc.add_paragraph()
p.add_run('The ConStat helper root accessor ').bold = True
p.add_run('0xE0308F10 returns C1443000. Its dependency setter maps service ID 0x001FF211 to field +0x20. Both examined routines retrieve that field before making their virtual call:')

rows = [
    ('Call site', 'Virtual slot', 'Matching-table entry', 'Observed operation'),
    ('0xE030B478', '+0x54', '0xE09AEA8C → 0xE0308438', 'Receives supply index + scalar mask; ORs the mask into the per-supply record at this + 0x1AC8 + index*8 + 0x04.'),
    ('0xE030BB38', '+0x174', '0xE09AEBAC → 0xE0307A38', 'Receives an output-buffer argument; calls 0xE0308520 to copy ConStat system information, including can_print.'),
]
tab = doc.add_table(rows=0, cols=4)
tab.alignment = WD_TABLE_ALIGNMENT.CENTER
tab.style = 'Table Grid'
for ri, row in enumerate(rows):
    cells = tab.add_row().cells
    for ci, txt in enumerate(row):
        set_cell_text(cells[ci], txt, bold=(ri == 0), size=7.8 if ri else 8.0, color=(255,255,255) if ri == 0 else None)
        if ri == 0: shade(cells[ci], '1F3F5B')
        elif ri == 1: shade(cells[ci], 'EAF2F8')
        elif ri == 2: shade(cells[ci], 'F4F6F7')
for row in tab.rows:
    row.cells[0].width = Inches(1.0)
    row.cells[1].width = Inches(0.75)
    row.cells[2].width = Inches(1.55)
    row.cells[3].width = Inches(3.6)

p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(5)
p.add_run('Matching address point: ').bold = True
p.add_run('ROMFS table base 0xE09AEA38. Its +0x54 entry is 0xE0308439 (Thumb pointer), and its +0x174 entry is 0xE0307A39. The same table therefore gives a coherent mapping for both call sites.')

add_code(doc, '0xE09AEA38 + 0x54  = 0xE09AEA8C  ->  0xE0308438\n0xE09AEA38 + 0x174 = 0xE09AEBAC  ->  0xE0307A38')

# manual page break
doc.add_page_break()

p = doc.add_paragraph()
p.paragraph_format.space_after = Pt(1)
r = p.add_run('REVISION 112  /  PART 22  /  STEP 26')
r.bold = True; r.font.size = Pt(8); r.font.color.rgb = RGBColor(39, 91, 130)

doc.add_heading('2. Why E030BB38 is not the demonstrated reason insertion', level=1)
p = doc.add_paragraph()
p.add_run('At 0xE030BBCA–0xE030BBDC, ').bold = True
p.add_run('the routine reloads the same C1443000 + 0x20 provider, reads the function pointer at vtable +0x174, and calls it with r1 = the saved caller argument, r2 = a derived value, and r3 = a flag/record value.')

p = doc.add_paragraph()
p.add_run('Under the matching table at 0xE09AEA38, ').bold = True
p.add_run('that slot is 0xE0307A38, not 0xE03076C0. The implementation uses r1 as an output structure, calls 0xE0308520, and copies the ConStat status fields. The copy routine writes the internal field at this +0x2F8 to output +0x8C, which the ROMFS type metadata identifies as ConstatSystemInfoT.can_print. It also copies this +0x2FC to output +0x90. The derived r2/r3 values are not consumed by this implementation.')

add_code(doc, '0xE0307A38 -> 0xE0308520\nthis + 0x2F8  ->  ConstatSystemInfoT + 0x8C  (can_print)\nthis + 0x2FC  ->  ConstatSystemInfoT + 0x90')

p = doc.add_paragraph()
p.add_run('Therefore, ').bold = True
p.add_run('the previous claim that this E030BB38 call forwards its dynamically derived 1-or-4 value to the ConStat reason-insertion function 0xE03076C0 must be withdrawn. The recovered call is a status-data path on the matching interface, not proof of a reason-code conversion.')

doc.add_heading('3. Keep E03076C0 as a separate, unresolved insertion path', level=1)
p = doc.add_paragraph()
p.add_run('Function 0xE03076C0 remains real code. ').bold = True
p.add_run('It manipulates ConStat reason groups beginning at this +0x8F4 and also touches the separate PINK mask area at this +0x1AC8. Its pointer occurs at ROMFS address 0xE09AED18. That location is not the +0x174 entry of the matching table based at 0xE09AEA38. Treating it as that slot requires a different address point (0xE09AEBA4), whose +0x54 entry is 0xE0308228; that method treats r2 as an output-structure pointer, which conflicts with the scalar-mask argument passed by the PINK update call.')

p = doc.add_paragraph()
p.add_run('Interpretation. ').bold = True
p.add_run('The available static layout does not support identifying 0xE03076C0 as the +0x174 target of the same injected service object used by 0xE030B478. The exact runtime vptr returned for service 0x001FF211 is still unresolved, so this is a correction to the earlier asserted mapping, not a claim that no other interface can ever reach 0xE03076C0.')

doc.add_heading('4. Consequence for the missing TooEarly mapping', level=1)
add_bullet(doc, 'PINK supplyInksubTooEarly remains bitmask 0x00020000; ConStat INKSUB_REPLACED_EARLY remains reason code 0x13.')
add_bullet(doc, 'The PINK mask update and the CanPrint status-copy call share the same injected provider field at C1443000 + 0x20, under the best-fitting vtable reconstruction.')
add_bullet(doc, 'The old E030BB38 dynamic-reason candidate no longer establishes a 0x13 insertion path. The executable conversion is still not found.')

p = doc.add_paragraph()
p.add_run('Next target. ').bold = True
p.add_run('Resolve service 0x001FF211 through the generic component registry to establish the actual runtime vptr; then identify genuine callers of 0xE03076C0 (or another verified ConStat insertion method) and follow any path carrying the 0x00020000 TooEarly flag or reason code 0x13.')

p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(4)
p.add_run('Static-analysis boundary. ').bold = True
p.add_run('No live printer state was read. No Print-Job, Validate-Job, ScanJobs request, firmware write, reset, or physical device action was performed. This addendum corrects the Step 22 call attribution; it does not identify which condition was active during the user’s failed print attempt.')

# final small source note
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(4)
r = p.add_run('Evidence basis: hp_lbi_sections.elf, srtext_rebuilt.bin, and romfs_objs_rebuilt.bin carried forward from Step 25. Their SHA-256 values are listed in the accompanying evidence package. Focused verifier: 49 checks.')
r.italic = True; r.font.size = Pt(7.5); r.font.color.rgb = RGBColor(90, 100, 110)

OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUT)
print(OUT)
