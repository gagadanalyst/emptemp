# Part 22, Step 26 evidence — ConStat vtable and reason-path correction

Revision 112 (20 November 2026).

## Purpose

Correct the earlier Step 22 attribution of the `0xE030BB38` virtual call to `0xE03076C0`. The evidence reconciles the PINK mask-writer slot (`+0x54`) and the dynamic status-query slot (`+0x174`) against the same candidate ROMFS vtable address point.

## Main findings

- `0xE0308F10` returns root `0xC1443000`; service `0x001FF211` populates root field `+0x20`.
- `0xE030B478` loads that provider and calls vtable `+0x54` with a supply index and scalar PINK mask. The best-fitting ROMFS address point `0xE09AEA38` maps this slot to `0xE0308438`, which ORs the scalar mask into the per-supply word at `this + 0x1AC8 + index*8 + 4`.
- The same table's `+0x174` slot maps to `0xE0307A38`, not `0xE03076C0`. `0xE0307A38` calls `0xE0308520` and copies the ConStat system-info structure, including `can_print` at output offset `+0x8C`.
- `0xE03076C0` remains a reason-group writer, but its ROMFS function-pointer location is not the `+0x174` entry of the matched table. The actual runtime vptr for `0x001FF211` remains unresolved.
- Therefore the E030BB38 dynamic-value path is withdrawn as evidence for `TooEarly` mask `0x00020000` -> ConStat reason `0x13`.

## Evidence contents

- Exact source binaries carried forward from Step 25: `hp_lbi_sections.elf`, `srtext_rebuilt.bin`, `romfs_objs_rebuilt.bin`.
- Focused disassembly for all relevant call sites and methods.
- ROMFS vtable address-point words and service/callsite crosswalk CSVs.
- Prior Step 25 evidence ZIP retained as the baseline.
- Reproducible focused verifier and checksums.

## Verification

Run:

```bash
python evidence/verify_step26.py
sha256sum -c DELIVERY_SHA256SUMS.txt
unzip -t Part22_Step26_ConStat_Vtable_and_Reason_Path_Correction_Evidence.zip
```

The verifier checks source hashes, table arithmetic, callsite slots, method behavior, output field offsets, and the distinct `0xE03076C0` table entry.

Static-only: no printer interaction, job submission, firmware write, reset, or physical device action.
