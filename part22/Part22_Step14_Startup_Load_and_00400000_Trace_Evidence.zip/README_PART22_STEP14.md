# HP DeskJet 2855e firmware investigation - Part 22, Step 14

## Scope

Offline static analysis only. This step followed the FHX main-image `.startup_text`, `.startup_rodata`, `.load_text` and `.load_rodata` section descriptors, then re-examined the unresolved virtual call at `.srtext` address `0xE0837994` and its `0x00400000` stack argument.

No printer communication, firmware update, firmware write, reset, debug activation, print/scan job, or device-state change was performed.

## Main results

1. The FHX directory at payload offset `0xBD8` describes a contiguous startup/load image based at `0xE0230000`. The exact section slices and hashes are in `sections/section_inventory.json`.
2. `.startup_text` (604 bytes) decodes as ARM/A32 processor initialization. It performs CP15 cache, TLB, translation-table and system-control operations. Its branch-reached code in `.startup_rodata` continues the low-level mapping/exception setup. No named component/dependency resolver was recovered in the decoded path.
3. `.load_text` is correctly located at payload offset `0x13380`, VMA `0xE0243380`, size `0x2A3C`. It does not decode coherently in ARM/A32 or Thumb probes. Its transform/packing is unknown; it is not claimed to be encrypted.
4. The `0xE0837994` virtual call uses `r1=0x23`, `r2=&"/reprint"`, `r3=0x19000`, and stack argument 0 `0x00400000`. Nearby operations use path-like strings (`/system`, `/tmp`, `/shm`, `/copy`, `/ishare`, `/photo`, `/uithm`, `/reprint`). The concrete vtable method is unknown, but this call does not match the known `lib_power` acquire ABI. The earlier Step 13 `0x00400000` lead is therefore reclassified as not evidence of `POWER_CLIENT_PE_POLICY` use.
5. The full `.srtext` disassembly records 14 references to acquire helper `0xE093DC50` and 12 to release helper `0xE093DC68`. The only direct BL reference to `0xE0837848` is internal at `0xE08379CE`; the runtime vtable target remains unresolved.

## Important interpretation limits

- The branch-reached code examined in `.startup_rodata` establishes that this section is mixed code/data in relevant regions; the whole section was not assigned one instruction mode.
- Failed ARM/Thumb disassembly of `.load_text` does not prove encryption or absence of code. It means the required transform is not recovered.
- The three raw `0x00400000` byte-sequence occurrences in `.load_text` are all unaligned offsets (`0x110E`, `0x1C5E`, `0x1C7F`). They are not evidence of a literal word or active power-client request.
- No path from these findings to `rtp_manager.block_print`, `unblock_print`, or the PE blocked-state writer was established.

## Reproduction

The evidence archive includes `fhx_secure_payload_rebuilt.bin` and `srtext_rebuilt.bin` used for the extraction and call-site trace.

```bash
python extract_fhx_sections_step14.py
python verify_part22_step14.py
```

The `.load_text` ARM/Thumb probes are preserved in `load_text_arm_probe.dis` and `load_text_thumb_probe.dis`. The disassembly generator is `generate_load_text_probes.sh`; it expects `clang` and `llvm-objdump`.

The full `.srtext` disassembly generated for the cross-reference audit was large and is not duplicated in this ZIP. Its source bytes are included as `srtext_rebuilt.bin`; the exact relevant xref lines and the `0xE0837994` function context are preserved in `srtext_direct_xref_audit.txt` and `indirect_00400000_context.disasm.txt`.

## Findings document

`HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision101_Part22_Step14_Startup_Load_and_00400000_Trace_Addendum.docx` extends the standalone Revision 100 addendum. It is not merged into the earlier 194-page cumulative report.

PDF render is included for convenience. Revision 101 contains 20 pages: its first 15 pages are pixel-identical to Revision 100 at 30 dpi; the five new pages were visually inspected at 120 dpi.
