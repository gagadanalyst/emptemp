.syntax unified
.thumb
.section .text,"ax",%progbits
.global _start
.thumb_func
_start:
.incbin "/mnt/data/hp_part22_step14/evidence/sections/load_text.bin"
