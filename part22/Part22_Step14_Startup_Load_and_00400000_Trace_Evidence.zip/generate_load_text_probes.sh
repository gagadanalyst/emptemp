#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TMP="$HERE/probe"
mkdir -p "$TMP"
cat > "$TMP/load_arm.S" <<'EOF'
.syntax unified
.arm
.section .text,"ax",%progbits
.global _start
_start:
.incbin "/mnt/data/hp_part22_step14/evidence/sections/load_text.bin"
EOF
cat > "$TMP/load_thumb.S" <<'EOF'
.syntax unified
.thumb
.section .text,"ax",%progbits
.global _start
.thumb_func
_start:
.incbin "/mnt/data/hp_part22_step14/evidence/sections/load_text.bin"
EOF
clang --target=armv7-none-eabi -c -o "$TMP/load_arm.o" "$TMP/load_arm.S"
clang --target=thumbv7m-none-eabi -c -o "$TMP/load_thumb.o" "$TMP/load_thumb.S"
llvm-objdump -D --triple=armv7-none-eabi --adjust-vma=0xe0243380 "$TMP/load_arm.o" > "$TMP/load_arm.dis"
llvm-objdump -D --triple=thumbv7m-none-eabi --adjust-vma=0xe0243380 "$TMP/load_thumb.o" > "$TMP/load_thumb.dis"
