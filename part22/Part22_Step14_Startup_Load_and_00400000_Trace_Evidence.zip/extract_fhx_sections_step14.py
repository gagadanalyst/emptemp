#!/usr/bin/env python3
"""Extract Part 22 Step 14 startup/load sections from the verified FHX payload."""
from pathlib import Path
import struct, hashlib, json

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / "evidence" / "fhx_secure_payload_rebuilt.bin"
OUT = ROOT / "evidence" / "sections"
DIR_OFFSET = 0xBD8
IMAGE_BASE = 0xE0230000
EXPECTED = {
    ".startup_text": (0xE0232BB8, 0x25C, 0x2),
    ".startup_rodata": (0xE0232E14, 0x1056A, 0x1),
    ".load_text": (0xE0243380, 0x2A3C, 0x2),
    ".load_rodata": (0xE0245DBC, 0x84, 0x4),
}
EXPECTED_SHA256 = {
    ".startup_text": "3fafadd180b7c81255d95b53449ea5a04bbeefcb57f66e6b7bd0587f7db9c919",
    ".startup_rodata": "c40e5dbc133bdff224728901f213e17d0acd601b2d3cd90af87b77cab1511014",
    ".load_text": "076972cfbc82f086ffd94de83977da14ce233fc6559aba69b305944e08137af2",
    ".load_rodata": "979aec14ea7d5ad7e020f6530126b20019ae3d2e5466fd383e4c71e45a155702",
}

def sha(b): return hashlib.sha256(b).hexdigest()

def read_directory(data):
    pos = DIR_OFFSET
    entries = {}
    while pos < len(data):
        end = data.find(b"\0", pos)
        if end < 0: raise ValueError("unterminated FHX section name")
        name = data[pos:end].decode("ascii", "strict")
        meta = (end + 4) & ~3
        if meta + 24 > len(data): raise ValueError("truncated FHX descriptor")
        vals = struct.unpack_from("<6I", data, meta)
        entries[name] = {"name_offset":pos,"descriptor_offset":meta,"fields":vals}
        pos = meta + 24
        if name == ".endram": break
    return entries

def main():
    blob = PAYLOAD.read_bytes()
    OUT.mkdir(parents=True, exist_ok=True)
    entries = read_directory(blob)
    result = []
    for name, (vma, size, flags) in EXPECTED.items():
        if name not in entries: raise SystemExit(f"missing descriptor {name}")
        vals = entries[name]["fields"]
        if vals[2] != vma or vals[3] != size or vals[4] != flags:
            raise SystemExit(f"descriptor mismatch for {name}: {vals}")
        off = vma - IMAGE_BASE
        section = blob[off:off+size]
        if len(section) != size: raise SystemExit(f"truncated section {name}")
        digest = sha(section)
        if digest != EXPECTED_SHA256[name]: raise SystemExit(f"hash mismatch {name}: {digest}")
        fname = name.lstrip(".") + ".bin"
        (OUT / fname).write_bytes(section)
        result.append({"name":name,"vma":hex(vma),"size":hex(size),"flags":hex(flags),
                       "payload_offset":hex(off),"sha256":digest,
                       "descriptor_fields":[hex(x) for x in vals]})
    (OUT / "section_inventory.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"payload_size":len(blob),"payload_sha256":sha(blob),"sections":result},indent=2))

if __name__ == "__main__": main()
