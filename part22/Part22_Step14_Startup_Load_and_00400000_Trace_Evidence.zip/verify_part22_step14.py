#!/usr/bin/env python3
"""Reproducible static checks for HP DeskJet 2855e Part 22 Step 14."""
from pathlib import Path
import hashlib, json, struct, sys

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / "fhx_secure_payload_rebuilt.bin"
SR = ROOT / "srtext_rebuilt.bin"
SECTIONS = ROOT / "sections"
INVENTORY = json.loads((SECTIONS / "section_inventory.json").read_text())
EXPECTED_PAYLOAD_SHA = "aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858"
EXPECTED_SR_SHA = "10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7"
EXPECTED = {
    ".startup_text": (0xE0232BB8, 0x25C, 0x2, 0x2BB8, "3fafadd180b7c81255d95b53449ea5a04bbeefcb57f66e6b7bd0587f7db9c919"),
    ".startup_rodata": (0xE0232E14, 0x1056A, 0x1, 0x2E14, "c40e5dbc133bdff224728901f213e17d0acd601b2d3cd90af87b77cab1511014"),
    ".load_text": (0xE0243380, 0x2A3C, 0x2, 0x13380, "076972cfbc82f086ffd94de83977da14ce233fc6559aba69b305944e08137af2"),
    ".load_rodata": (0xE0245DBC, 0x84, 0x4, 0x15DBC, "979aec14ea7d5ad7e020f6530126b20019ae3d2e5466fd383e4c71e45a155702"),
}
checks=[]
def ck(name, cond, detail=""):
    checks.append((name, bool(cond), detail))

def sha(b): return hashlib.sha256(b).hexdigest()

def read_dir(data):
    pos=0xBD8; d={}
    while pos < len(data):
        end=data.find(b"\0",pos)
        if end<0: break
        n=data[pos:end].decode("ascii","strict")
        meta=(end+4)&~3
        if meta+24>len(data): break
        d[n]=struct.unpack_from("<6I",data,meta)
        pos=meta+24
        if n==".endram": break
    return d

blob=PAYLOAD.read_bytes()
ck("FHX payload size", len(blob)==12888320, str(len(blob)))
ck("FHX payload SHA-256", sha(blob)==EXPECTED_PAYLOAD_SHA, sha(blob))
source_sr=SR.read_bytes()
ck(".srtext source size", len(source_sr)==0x743634, hex(len(source_sr)))
ck(".srtext source SHA-256", sha(source_sr)==EXPECTED_SR_SHA, sha(source_sr))

desc=read_dir(blob)
ck("FHX directory parsed through .endram", ".endram" in desc, f"{len(desc)} descriptors incl terminator")
for name,(vma,size,flags,off,digest) in EXPECTED.items():
    vals=desc.get(name)
    ck(name+" descriptor present", vals is not None)
    if vals is not None:
        ck(name+" descriptor VMA", vals[2]==vma, hex(vals[2]))
        ck(name+" descriptor size", vals[3]==size, hex(vals[3]))
        ck(name+" descriptor flags", vals[4]==flags, hex(vals[4]))
    chunk=blob[off:off+size]
    ck(name+" mapped image offset", off==vma-0xE0230000, hex(off))
    ck(name+" extracted size", len(chunk)==size, hex(len(chunk)))
    ck(name+" section SHA-256", sha(chunk)==digest, sha(chunk))
    file=SECTIONS/(name.lstrip(".")+".bin")
    ck(name+" extracted file equality", file.exists() and file.read_bytes()==chunk)

# Directory and payload section adjacency.
ck("startup_text meets startup_rodata", 0xE0232BB8+0x25C==0xE0232E14)
ck("startup_rodata to load_text two-byte pad", 0xE0232E14+0x1056A==0xE024337E and 0xE0243380-0xE024337E==2)
ck("load_text meets load_rodata", 0xE0243380+0x2A3C==0xE0245DBC)

st=(SECTIONS/"startup_text.bin").read_bytes()
srdata=(SECTIONS/"startup_rodata.bin").read_bytes()
load=(SECTIONS/"load_text.bin").read_bytes()
# ARM/A32 code anchors in startup_text.
ck("startup_text first instruction is MOV r0,#0", st[:4]==struct.pack("<I",0xE3A00000),st[:4].hex())
ck("startup_text contains CP15 cache op", struct.pack("<I",0xEE400F10) in st)
ck("startup_text terminal branch into startup_rodata", struct.unpack_from("<I",st,0x250)[0]==0xEA0000CE,hex(struct.unpack_from("<I",st,0x250)[0]))
# Branch target at 0xE0233148 in startup_rodata starts the observed 21-entry loop continuation.
ck("startup_rodata branch target continuation", struct.unpack_from("<I",srdata,0x334)[0]==0xE28BB001,hex(struct.unpack_from("<I",srdata,0x334)[0]))
ck("startup_rodata sets TTBR via CP15 c2", struct.pack("<I",0xEE020F10) in srdata)

# Raw known values/strings in startup/load slices. Raw-only negatives are not a semantic proof.
known=[0xC1D62B4C,0xC1D62B50,0xC1D5E884,0xC1906644,0xE093DC50,0xE093E2A0,0xE07BCF10,0x0001229F,0xC19FD4C8,0xE07C1211,0xE07C1219,0xE0251788]
for name,data in [("startup_text",st),("startup_rodata",srdata),("load_text",load)]:
    for v in known:
        ck(name+f" raw no known address {v:08x}", struct.pack("<I",v) not in data)
    for s in [b"siriusInstance",b"lib_power",b"POWER_CLIENT",b"rtp_manager"]:
        ck(name+f" raw no string {s.decode()}", s not in data)

pat=struct.pack("<I",0x00400000)
pos=[]; i=0
while True:
    i=load.find(pat,i)
    if i<0: break
    pos.append(i); i+=1
ck("load_text raw 0x00400000 occurrences", pos==[0x110E,0x1C5E,0x1C7F], str([hex(x) for x in pos]))
ck("all load_text raw 0x00400000 matches are unaligned", all(x%4 for x in pos), str([hex(x) for x in pos]))

# Exact .srtext excerpt for the indirect call and path-name data.
ctx=(ROOT/"indirect_00400000_context.disasm.txt").read_text(errors="replace")
for line in [
    "e0837982: f44f 0180", # mov r1, #0x400000
    "e0837986: e88d 04c2", # stack args
    "e083798a: f20f 02ac", # ADR -> /reprint
    "e083798e: f44f 33c8", # r3 = 0x19000
    "e0837992: 2123",       # r1 = selector 0x23
    "e0837994: 47e0",       # BLX r12
]:
    ck("virtual-call context "+line.split(":")[0], line in ctx, line)
# Path strings from .srtext VMA mapping.
for addr,path in [(0xE0837A00,b"/system"),(0xE0837A08,b"/tmp"),(0xE0837A10,b"/shm"),(0xE0837A18,b"/copy"),(0xE0837A20,b"/ishare"),(0xE0837A28,b"/photo"),(0xE0837A30,b"/uithm"),(0xE0837A38,b"/reprint")]:
    off=addr-0xE0246070
    end=source_sr.find(b"\0",off)
    ck("path string "+path.decode(), source_sr[off:end]==path, hex(addr))

# The complete xref pass was generated with LLVM from srtext_rebuilt.bin; audit subset included.
xref=(ROOT/"srtext_direct_xref_audit.txt").read_text()
ck("full .srtext direct/helper xref: 14 acquire refs", "0xe093dc50: occurrences in full disassembly=14" in xref)
ck("full .srtext direct/helper xref: 12 release refs", "0xe093dc68: occurrences in full disassembly=12" in xref)
ck("E0837848 only internal direct BL", "0xe0837848: occurrences in full disassembly=1" in xref and "e08379ce:" in xref)
ck("E0837994 no direct branch xref", "0xe0837994: occurrences in full disassembly=0" in xref)
ck("no direct disassembly target E093E2A0", "0xe093e2a0: occurrences in full disassembly=0" in xref)

bad=[x for x in checks if not x[1]]
print(f"Part 22 Step 14 verification: {len(checks)-len(bad)}/{len(checks)} PASS, {len(bad)} FAIL")
for name,ok,detail in checks:
    print(("PASS" if ok else "FAIL")+" | "+name+(" | "+detail if detail else ""))
if bad: sys.exit(1)
