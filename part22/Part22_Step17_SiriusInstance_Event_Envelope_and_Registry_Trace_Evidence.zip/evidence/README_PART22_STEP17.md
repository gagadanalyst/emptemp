# Part 22 - Step 17 Evidence Package

## Golden finding

The callback read by the PE event relay is a field in a named `siriusInstance` object rooted at `0xC190A128`, not an unrelated global. The ROMFS string at `0xE0B33984` is `siriusInstance`. The ROMFS-exposed initializer path writes the name pointer at object offset `+0x18`; the callback setter at `0xE0712198` stores its incoming `r1` at `0xC190A144`, exactly object offset `+0x1C`. A separate accessor at `0xE0712050` returns the same base.

When the callback slot is non-null, the PE relay at `0xE07126B8` constructs a 24-byte `IpcEvtProdPeEvent` envelope from the ROMFS descriptor at `0xE0D421C8` and calls the callback with outer ID `0x0001347F` in `r0` and the envelope address in `r1`. Metadata names the schema `ipc_evt_prod_pe_event`, type `IpcEvtProdPeEvent`, object size `0x18`, and two fields `event_id` and `event`.

After the optional callback path, the relay scans a separate 32-entry registry at `0xC190A148`, with a `0x5C8` record stride. The seven component D-record callbacks from Step 15 are **not** proven to be the contents of this registry.

## What this does not establish

- The runtime caller of setter `0xE0712198` and the actual callback address passed in `r1` remain unknown.
- The callback's implementation and any IPC or remote delivery behavior remain unknown.
- The exact mapping of the two named event fields to individual stack offsets/values is not established.
- The relationship between the 32-entry registry and the seven Step 15 D-record subscriber registrations is not proven.
- No event subtype is tied to alert 66220, `DSID_PRINT_ENGINE_BLOCKED` (`0x12196`), RTP `block_print`, or `unblock_print`.

All analysis is static. No printer communication, network request, firmware change, flash, reset, print job, or scan job was performed.

## Package contents

- `STEP17_FINDINGS.txt` - technical findings and confidence boundaries.
- `disassembly/step17_focus.dis` - focused disassembly for object initialization, accessors, setter, relay, registry logic, and 24-byte copy helper.
- `disassembly/bin/` - exact code slices from the reconstructed `.srtext` image plus `STEP17_CODE_SLICE_MAP.csv`.
- `romfs/` - exact ROMFS byte slices and word-oriented dump for the named object, event schema, and nearby resource metadata.
- `metadata/` - object layout, event envelope, registry loop, and Steps 15-17 crosswalk tables.
- `source_srtext_rebuilt.bin`, `source_romfs_objs_rebuilt.bin` - source images used for address-to-byte verification.
- `final/Revision104_Step17_Addendum.docx` and `.pdf` - cumulative findings document (Revision 103 plus four new pages).
- `qa/` - rendered evidence pages 32-35 from both DOCX and PDF output.
- `Previous_Step16_Evidence_Package.zip` and `Revision103_Step16_Addendum.docx` - prior-step baseline artifacts.
- `verify_part22_step17.py` and `verification_output.txt` - reproducible binary/document QA checks.
- `SOURCE_INPUTS.txt`, `DOCX_QA.txt`, `pdfinfo.txt`, `SHA256SUMS` - provenance and validation records.

## Verification

The verifier passed **71/71 checks**. The final PDF is 35 pages, US Letter (612 x 792 points). All 31 inherited pages were pixel-identical to a fresh 72 dpi rendering of the exact Revision 103 source DOCX. New pages 32-35 were visually inspected in DOCX and PDF renders; each pair of corresponding DOCX/PDF page images is pixel-identical at 120 dpi.

The manifest hashes all files inside this package except the manifest itself. Run from the `evidence` directory:

```bash
sha256sum -c SHA256SUMS
```
