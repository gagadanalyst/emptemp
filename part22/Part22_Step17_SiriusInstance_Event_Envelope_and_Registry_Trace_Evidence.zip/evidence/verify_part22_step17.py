from pathlib import Path
import hashlib, struct, subprocess, sys
from docx import Document
from PIL import Image, ImageChops

ROOT=Path('/mnt/data/hp_part22_step17')
E=ROOT/'evidence'
checks=[]
def check(name,condition,detail=''):
    checks.append((name,bool(condition),detail))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def u32(buf,base,addr): return struct.unpack_from('<I',buf,addr-base)[0]
def at(buf,base,addr,n): return buf[addr-base:addr-base+n]

rom_path=E/'source_romfs_objs_rebuilt.bin'; sr_path=E/'source_srtext_rebuilt.bin'
rom=rom_path.read_bytes(); sr=sr_path.read_bytes(); rb=0xE09919C0; sb=0xE0246070
check('ROMFS source size',len(rom)==4459788,str(len(rom)))
check('SR text source size',len(sr)==7616052,str(len(sr)))
check('ROMFS source SHA-256',sha(rom_path)=='227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',sha(rom_path))
check('SR text source SHA-256',sha(sr_path)=='10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',sha(sr_path))

# Named object and ROMFS initializer/setter pointers
check('siriusInstance exact ROMFS string',at(rom,rb,0xE0B33984,15)==b'siriusInstance\x00',at(rom,rb,0xE0B33984,15))
check('ROMFS initializer Thumb pointer',u32(rom,rb,0xE0B33A38)==0xE07120D1,hex(u32(rom,rb,0xE0B33A38)))
check('ROMFS setter Thumb pointer',u32(rom,rb,0xE0B33A6C)==0xE0712199,hex(u32(rom,rb,0xE0B33A6C)))
check('object base to callback field offset',0xC190A144-0xC190A128==0x1C,hex(0xC190A144-0xC190A128))
check('object base to registry region offset',0xC190A148-0xC190A128==0x20,hex(0xC190A148-0xC190A128))

# Function instruction slices: exact binary bytes from reconstructed .srtext.
expected={
 'initializer': (0xE0711FF0,bytes.fromhex('43 f6 d8 12 43 f6 18 2c ce f2 b3 02 ce f2 b3 0c a0 e8 04 10 00 22 13 46 94 46 a0 e8 0c 10 0b 46 80 e8 0c 00 14 38 70 47')),
 'base_accessor': (0xE0712050,bytes.fromhex('4a f2 28 10 cc f2 90 10 70 47')),
 'name_initializer_entry': (0xE07120D8,bytes.fromhex('43 f6 84 11 4a f2 28 10 ce f2 b3 01 cc f2 90 10 ff f7 82 bf')),
 'callback_setter': (0xE0712198,bytes.fromhex('4a f2 44 10 cc f2 90 10 01 60 70 47')),
 'relay_callback_envelope': (0xE071274E,bytes.fromhex('38 68 68 b1 02 a8 55 f2 ac fc 01 20 05 a9 81 e8 31 00 3a 68 43 f2 7f 40 02 a9 c0 f2 01 00 90 47')),
 'registry_loop': (0xE0712778,bytes.fromhex('00 20 02 e0 01 30 20 28 10 da 4f f4 b9 61 00 fb 01 f5 07 f1 04 0a 5a f8 05 10 a1 42 f2 d1 ff f7 07 fd 18 b9 05 eb 0a 00 ff f7 62 fd')),
 '24_byte_copy_helper': (0xE09680B0,bytes.fromhex('10 b4 42 f2 c8 14 ce f2 d4 04 02 46 0b cc 0b c2 94 e8 0b 00 82 e8 0b 00 10 bc 70 47')),
}
for name,(addr,want) in expected.items():
    actual=at(sr,sb,addr,len(want))
    check(f'{name} exact instruction bytes',actual==want,actual.hex())

# ROMFS typed event descriptor and labels
check('envelope descriptor points to type metadata',u32(rom,rb,0xE0D421C8)==0xE0D421E0,hex(u32(rom,rb,0xE0D421C8)))
check('schema-name pointer',u32(rom,rb,0xE0D421E4)==0xE0D4221C,hex(u32(rom,rb,0xE0D421E4)))
check('type-name pointer',u32(rom,rb,0xE0D421E8)==0xE0D42234,hex(u32(rom,rb,0xE0D421E8)))
check('schema-name string',at(rom,rb,0xE0D4221C,len(b'ipc_evt_prod_pe_event\0'))==b'ipc_evt_prod_pe_event\0','ipc_evt_prod_pe_event')
check('type-name string',at(rom,rb,0xE0D42234,len(b'IpcEvtProdPeEvent\0'))==b'IpcEvtProdPeEvent\0','IpcEvtProdPeEvent')
check('event object size 0x18',u32(rom,rb,0xE0D421F4)==0x18,hex(u32(rom,rb,0xE0D421F4)))
check('event object named-field count 2',u32(rom,rb,0xE0D421F8)==2,hex(u32(rom,rb,0xE0D421F8)))
check('event_id field label',at(rom,rb,0xE0D422D4,len(b'event_id\0'))==b'event_id\0','event_id')
check('event field label',at(rom,rb,0xE0D422E0,len(b'event\0'))==b'event\0','event')
check('pe_events.list string',at(rom,rb,0xE0B33FC8,len(b'pe_events.list\0'))==b'pe_events.list\0','pe_events.list')
check('ROMFS notification key 0x11570',u32(rom,rb,0xE0B33FD8)==0x00011570,hex(u32(rom,rb,0xE0B33FD8)))
check('DSID_PE_EVENT_ID_NOTIFY label',at(rom,rb,0xE0B33FF0,len(b'DSID_PE_EVENT_ID_NOTIFY\0'))==b'DSID_PE_EVENT_ID_NOTIFY\0','DSID_PE_EVENT_ID_NOTIFY')

# Metadata and source disassembly crosswalk files
for f in ['STEP17_FINDINGS.txt','disassembly/step17_focus.dis','metadata/SIRIUS_INSTANCE_OBJECT_LAYOUT.csv','metadata/IPC_EVENT_ENVELOPE.csv','metadata/REGISTRY_LOOP.csv','metadata/STEP15_STEP17_EVENT_PATH_CROSSWALK.csv','romfs/step17_romfs_words.txt','disassembly/bin/STEP17_CODE_SLICE_MAP.csv']:
    p=E/f; check(f'evidence file exists: {f}',p.is_file(),str(p.stat().st_size) if p.exists() else 'missing')

# Extracted code slices match source image
import csv
with (E/'disassembly/bin/STEP17_CODE_SLICE_MAP.csv').open() as f:
    for row in csv.DictReader(f):
        path=E/'disassembly/bin'/row['filename']; addr=int(row['start_vma'],16); n=int(row['length_bytes'])
        check(f'code slice matches source: {row["filename"]}',path.read_bytes()==at(sr,sb,addr,n),f'{addr:#x}+{n:#x}')

# Deliverable structure and visual QA
DOCX=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision104_Part22_Step17_SiriusInstance_Event_Envelope_and_Registry_Trace_Addendum.docx'
PDF=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision104_Part22_Step17_SiriusInstance_Event_Envelope_and_Registry_Trace_Addendum.pdf'
check('Revision104 DOCX exists',DOCX.is_file(),str(DOCX.stat().st_size) if DOCX.exists() else 'missing')
check('Revision104 PDF exists',PDF.is_file(),str(PDF.stat().st_size) if PDF.exists() else 'missing')
if DOCX.exists():
    d=Document(DOCX); txt='\n'.join(p.text for p in d.paragraphs)+'\n'+'\n'.join(c.text for t in d.tables for row in t.rows for c in row.cells)
    for term in ['siriusInstance','IpcEvtProdPeEvent','0xC190A144','0xC190A148','32-entry','0x0001347F','not yet proven']:
        check(f'DOCX contains {term}',term.lower() in txt.lower(),term)
    check('DOCX cumulative section/page count structure',len(d.sections)>=2,str(len(d.sections)))
if PDF.exists():
    info=subprocess.check_output(['pdfinfo',str(PDF)],text=True)
    check('PDF has 35 pages','Pages:           35' in info, next((x for x in info.splitlines() if x.startswith('Pages:')),''))
    check('PDF US Letter','Page size:       612 x 792 pts (letter)' in info, next((x for x in info.splitlines() if x.startswith('Page size:')),''))
    txt=subprocess.check_output(['pdftotext',str(PDF),'-'],text=True)
    for term in ['siriusInstance','IpcEvtProdPeEvent','0xC190A144','0xC190A148','32-entry','0x0001347F']:
        check(f'PDF text contains {term}',term.lower() in txt.lower(),term)

base=ROOT/'qa_revision103_baseline_72dpi'; qa=ROOT/'qa_rev104_72dpi'
identical=[]; diffs=[]
for i in range(1,32):
    a=base/f'page-{i}.png'; b=qa/f'page-{i}.png'
    if not a.exists() or not b.exists(): diffs.append((i,'missing')); continue
    ia=Image.open(a).convert('RGB'); ib=Image.open(b).convert('RGB')
    if ia.size!=ib.size or ImageChops.difference(ia,ib).getbbox() is not None: diffs.append((i,'not identical'))
    else: identical.append(i)
check('Inherited Revision103 pages pixel-identical',len(identical)==31,f'{len(identical)}/31; diffs={diffs}')
for i in range(32,36):
    check(f'DOCX rendered page {i} exists', (qa/f'page-{i}.png').is_file(), str((qa/f'page-{i}.png').stat().st_size) if (qa/f'page-{i}.png').exists() else 'missing')
    check(f'PDF rendered page {i} exists', (ROOT/'qa_pdf_120'/f'page-{i}.png').is_file(), str((ROOT/'qa_pdf_120'/f'page-{i}.png').stat().st_size) if (ROOT/'qa_pdf_120'/f'page-{i}.png').exists() else 'missing')

passed=sum(ok for _,ok,_ in checks); failed=len(checks)-passed
out='PART 22 STEP 17 VERIFICATION\n=============================\n'+''.join(f'{"PASS" if ok else "FAIL"}: {name}'+(f' ({detail})' if detail else '')+'\n' for name,ok,detail in checks)+f'\nRESULT: {passed}/{len(checks)} PASS; {failed} FAIL\n'
(E/'verification_output.txt').write_text(out)
print(out)
if failed: sys.exit(1)
