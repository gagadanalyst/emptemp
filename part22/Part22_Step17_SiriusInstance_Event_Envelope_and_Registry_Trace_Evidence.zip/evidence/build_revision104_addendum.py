from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path('/mnt/data/hp_part22_step17')
BASE=Path('/mnt/data/hp_part22_step16/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision103_Part22_Step16_PE_Events_Publisher_Registration_Trace_Addendum.docx')
OUT=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision104_Part22_Step17_SiriusInstance_Event_Envelope_and_Registry_Trace_Addendum.docx'
doc=Document(BASE)
sec=doc.add_section(WD_SECTION.NEW_PAGE)
sec.top_margin=Inches(0.62); sec.bottom_margin=Inches(0.62)
sec.left_margin=Inches(0.68); sec.right_margin=Inches(0.68)
sec.header_distance=Inches(0.28); sec.footer_distance=Inches(0.28)
sec.header.is_linked_to_previous=False; sec.footer.is_linked_to_previous=False
NAVY='17365D'; BLUE='1F4E79'; CYAN='00A6C7'; LIGHT='D9EAF7'; PALE='EEF5FA'; GRAY='595959'; MID='7F8C8D'; WHITE='FFFFFF'; WARN='FFF2CC'; GREEN='E2F0D9'; RED='FCE4D6'
header=sec.header.paragraphs[0]; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=header.add_run('HP DESKJET 2855e  |  INDEPENDENT PRINTING / SCANNING INVESTIGATION')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(MID)
footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('Revision 104 - Part 22, Step 17 addendum  |  19 November 2026  |  Page ')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.color.rgb=RGBColor.from_string(MID)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

# Typography and layout helpers
def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)
def celltxt(cell,text,bold=False,color=None,size=7.4):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color:r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def table(headers,rows,widths=None,font=7.2):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; t.style='Table Grid'
    for i,h in enumerate(headers): celltxt(t.rows[0].cells[i],h,True,WHITE,font); shade(t.rows[0].cells[i],BLUE)
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            celltxt(cells[i],val,False,None,font)
            if ri%2: shade(cells[i],PALE)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t
def para(text='',style=None,color=None,italic=False,size=8.0,after=Pt(3),bold=False):
    p=doc.add_paragraph(style=style); p.paragraph_format.space_after=after
    r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color:r.font.color.rgb=RGBColor.from_string(color)
    if italic:r.italic=True
    return p
def bullet(text,size=7.9):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(1.5)
    r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size); return p
def callout(title,body,fill=LIGHT):
    t=doc.add_table(rows=1,cols=1); t.autofit=False; t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0); shade(c,fill); c.text=''
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(title); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9.0); r.font.color.rgb=RGBColor.from_string(NAVY)
    p2=c.add_paragraph(body); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.02
    for r in p2.runs:r.font.name='Aptos'; r.font.size=Pt(7.8)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
def newpage(kicker,title,subtitle=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(11); p.paragraph_format.space_after=Pt(4)
    r=p.add_run(kicker); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9.2); r.font.color.rgb=RGBColor.from_string(CYAN)
    p=doc.add_paragraph(style='Title'); p.paragraph_format.space_after=Pt(4); p.add_run(title)
    if subtitle: para(subtitle,color=GRAY,size=8.0,after=Pt(6))

# PAGE 32: Named object
newpage('PART 22  /  STEP 17','The publisher callback is a field in a named siriusInstance object',
        'Revision 104 addendum extending Revision 103  |  Static firmware analysis  |  19 November 2026')
callout('Step 17 golden finding',
        'The PE event relay callback is not an unrelated global. It occupies offset +0x1C in a separately initialized object rooted at 0xC190A128. The ROMFS string at 0xE0B33984 names that object “siriusInstance”. The initializer writes the name pointer at +0x18, while the registered setter at 0xE0712198 writes the supplied callback pointer at +0x1C. The PE event relay reads that exact field. This ties callback storage to a named object layout and explains why the setter and relay share the same address.',GREEN)
para('The ROMFS-exposed initializer entry points to Thumb address 0xE07120D1. The code at 0xE07120D8 constructs the name pointer and object base, then tail-branches to initializer 0xE0711FF0. A separate accessor at 0xE0712050 returns the same base address 0xC190A128.',size=8.0)
table(['Object offset','Address','Initializer / setter value','Interpretation'],[
('0x00','0xC190A128','0xE0B339D8','Metadata or vtable-like pointer; semantics not decoded'),
('0x04','0xC190A12C','0xE0B33A18','Secondary metadata pointer; semantics not decoded'),
('0x08','0xC190A130','0','Initialized zero'),
('0x0C','0xC190A134','0','Initialized zero'),
('0x10','0xC190A138','0','Initialized zero'),
('0x14','0xC190A13C','0','Initialized zero'),
('0x18','0xC190A140','0xE0B33984','Pointer to “siriusInstance” string'),
('0x1C','0xC190A144','r1 supplied to 0xE0712198','Publisher callback slot'),
('0x20','0xC190A148','Adjacent region','Base of separate 32-entry registry'),
],[0.78,1.3,1.65,2.6],6.9)
callout('Exact address relationship',
        '0xC190A144 - 0xC190A128 = 0x1C. The setter writes to the next word after the initialized object name pointer. The callback slot is therefore a field in this named object layout, not a distinct unrelated data symbol.',LIGHT)
para('Qualification: the firmware image contains the initializer and accessor paths, but static analysis does not prove that this initializer executed on the target device during the earlier print attempt. It proves the object layout and the code paths that initialize, expose, write, and read it.',color=GRAY,size=7.7,italic=True,after=Pt(0))

# PAGE 33: Setter and envelope

doc.add_page_break()
newpage('PART 22  /  STEP 17','The relay builds a typed 24-byte IpcEvtProdPeEvent envelope',
        'The callback slot is optional; when populated, the relay constructs a schema-backed object and calls it with event ID 0x1347F.')
para('The event relay at 0xE07126B8 reads the callback pointer from 0xC190A144 at 0xE071274E. A zero value branches around envelope construction and callback invocation. For a non-null pointer, it calls helper 0xE09680B0 with destination sp+8.',size=8.0)
table(['Evidence address','Observed content','Supported meaning'],[
('0xE09680B0','Loads six words from ROMFS descriptor 0xE0D421C8 and stores six words to destination','Copies 24 bytes into the stack envelope'),
('0xE0D421C8','Descriptor base','Source for the 24-byte initialized object'),
('0xE0D421E0','Type metadata pointer','Metadata descriptor for the copied object'),
('0xE0D421E4','“ipc_evt_prod_pe_event”','Schema name'),
('0xE0D421E8','“IpcEvtProdPeEvent”','Type name'),
('0xE0D421F4','0x18','Object size: 24 bytes'),
('0xE0D421F8','2','Two named fields'),
('0xE0D422D4','“event_id”','First named field label'),
('0xE0D422E0','“event”','Second named field label'),
],[1.25,2.55,2.2],7.0)
para('After copying the descriptor, the relay writes three words at stack offsets sp+0x14, sp+0x18 and sp+0x1C. It then loads r0=0x0001347F, sets r1=sp+8, and executes BLX through the pointer held at 0xC190A144.',size=8.0)
callout('What the call proves',
        'The stored callback receives the outer notification ID 0x0001347F in r0 and a pointer to the stack-resident 24-byte IpcEvtProdPeEvent envelope in r1. The schema identifies the object and its named fields. The exact field-to-offset/value mapping and the callback implementation are not yet decoded.',GREEN)
callout('Null callback behavior',
        'When 0xC190A144 is zero, the relay skips both the 24-byte envelope construction and the indirect callback call. It does not return immediately: it continues into the subsequent local registry processing described on the next page.',WARN)

# PAGE 34: registry

doc.add_page_break()
newpage('PART 22  /  STEP 17','A separate 32-entry registry is processed after the optional callback',
        'The relay continues into local object/registry work whether or not the callback pointer is populated.')
para('After the optional callback path, the relay invokes a virtual method through the pe_events-side object and then initializes a loop index to zero. The loop computes a record address from base 0xC190A148 plus index times 0x5C8, compares the record’s first word with the current object pointer, and tests matching-entry state.',size=8.0)
table(['Property','Observed value','Evidence / interpretation'],[
('Registry base','0xC190A148','Exactly 0x20 bytes after siriusInstance base 0xC190A128'),
('Record stride','0x5C8 bytes','Multiply index by 0x5C8 at 0xE0712782-0xE071278A'),
('Loop bound','0x20 (32 entries)','Compare index against 0x20 at 0xE071277E'),
('Entry match','[base + index*0x5C8] == r4','Only matching records proceed to validation'),
('Entry state fields','+0x5A8, +0x5B0, +0x5B8','Checked by helper 0xE07121A8'),
('Matching-entry follow-up','0xE07121A8 then possibly 0xE0712268','Validation and cleanup path; not a broadcast'),
],[1.42,1.55,3.03],7.0)
para('A separate routine beginning at 0xE0712238 also iterates the same registry base with the same 0x5C8 stride and 32-entry limit. This supports describing the memory as a 32-entry object registry used by registration/lookup and cleanup logic.',size=7.9)
callout('Important separation',
        'The 32-entry registry is structurally adjacent to the callback field and is scanned by the same relay, but it is not yet proven to be the runtime representation of the seven component D-record subscribers discovered in Step 15. No explicit mapping from those seven component records to these 32 entries has been found.',WARN)
para('The strongest bounded interpretation is therefore: siriusInstance contains (1) an optional publisher callback field at +0x1C and (2) an adjacent registry region at +0x20. The relay conditionally emits a typed event through the first, then processes the second independently.',size=8.0)

# PAGE 35: Conclusions and unresolved target

doc.add_page_break()
newpage('PART 22  /  STEP 17','The event path is now architecturally clearer, but the print-block cause remains open',
        'Step 17 closes the object-layout and typed-envelope questions; it does not claim to identify the printer’s policy decision.')
para('Confirmed by the reconstructed firmware image:',size=8.0,bold=True)
bullet('The ROMFS string at 0xE0B33984 is “siriusInstance”.',7.8)
bullet('The initializer sequence constructs object base 0xC190A128, writes the name pointer at +0x18, and zeros the intervening fields.',7.8)
bullet('The accessor at 0xE0712050 returns 0xC190A128.',7.8)
bullet('The setter at 0xE0712198 stores its incoming r1 at 0xC190A144 = object base +0x1C.',7.8)
bullet('The PE event relay at 0xE07126B8 reads that field and, when non-null, passes event ID 0x1347F and a 24-byte IpcEvtProdPeEvent envelope to it.',7.8)
bullet('After the optional callback, the relay scans a separate 32-entry registry at 0xC190A148 with 0x5C8-byte records.',7.8)
callout('What remains unresolved',
        'The runtime caller of setter 0xE0712198 and the actual callback address passed in r1 remain unknown. Runtime delivery to any remote endpoint is not observed. The 32-entry registry is not mapped to the seven D-record subscribers. No payload subtype has been tied to alert 66220, DSID_PRINT_ENGINE_BLOCKED (0x12196), RTP block_print, or unblock_print.',WARN)
para('This finding refines the Step 16 event path: callback storage is part of a named siriusInstance object, the callback accepts a typed schema-backed envelope, and local registry maintenance proceeds after the optional notification. It does not alter the earlier conclusion that RTP block/unblock, the PE blocked-state DSID, the inpr report lock, and eSCL scanner admission are distinct controls until a direct code/data edge proves otherwise.',size=7.9)
para('Next focused target',style='Heading 2',size=9.0)
para('Trace the metadata-exposed setter invocation to identify the component or framework that supplies r1. Separately, determine whether the seven component D records are materialized into the 32-entry registry, using explicit pointer, index, or callback equivalence rather than name proximity. If the callback implementation is recovered, inspect its actual event transport and event payload field mapping before associating any message with print admission or subscription state.',size=7.9)
callout('Safety and scope',
        'No printer communication, network request, firmware modification, flash, reset, print job, or scan job was performed. All Step 17 conclusions are static reconstructions from the preserved firmware binaries and metadata.',LIGHT)

props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 104 Part 22 Step 17 Addendum'
props.subject='siriusInstance object layout, PE event callback slot, IpcEvtProdPeEvent envelope and 32-entry registry trace'
props.author='OpenAI'
props.keywords='HP DeskJet 2855e, firmware, siriusInstance, IpcEvtProdPeEvent, 0x1347F, C190A144, registry'
doc.save(OUT)
print(OUT)
