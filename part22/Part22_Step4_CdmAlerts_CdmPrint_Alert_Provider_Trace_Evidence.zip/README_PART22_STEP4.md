# Part 22, Step 4 — CdmAlerts and CdmPrint alert-provider trace

## Scope

Static-only trace of `CdmAlertsAlertProvider.cpp` and `CdmPrintAlertProvider.cpp`, using the previously verified 2629A reconstructed `.srtext` and `.romfs_objs` sections. The goal was to determine whether the subscription/page-out alert is produced here, whether CDM alert ID 66220 is assigned in the examined code, and whether a direct edge connects either provider to the RTP/PE print-block mechanisms.

No printer requests, device interaction, firmware writes, resets, debug activation, or configuration changes were performed.

## Main findings

1. `subscribedPagesOutAccountProblem` is present in `.srtext` at `0xE02764F8`, in `.romfs_objs` at `0xE0C2DFF6`, and as `Category__subscribedPagesOutAccountProblem` at `0xE0C2DFEC`.
2. The string is referenced by two sites in an alert capability registration builder: `0xE02759E8` and `0xE0276192`. Their adjacent scalar values are `0x102BB` (66,235) and `0x1027F` (66,175). The nearby resource and component name identify the context as `/cdm/alert/v1/capabilities` / `CdmAlertsCapsProvider.cpp`. This is evidence of capability vocabulary/registration, not proof of the runtime alert producer or the meaning of those scalar namespaces.
3. `CdmAlertsAlertProvider` implements the generic `/cdm/alert/v1/alerts` resource. Its response handler at `0xE0277500` uses the object reached from global `0xC136E6F0`, obtains an alert-record range through nested virtual method `+0x14`, and serializes records through an indirect thunk at `0xE02795E0`. The concrete record producer and serializer target remain unresolved.
4. `CdmPrintAlertProvider` provides `/cdm/print/v2/alerts` and `/cdm/print/v2/printAction`. Its handler at `0xE02B2CB0` and helper at `0xE02B2B88` use a different runtime object cluster rooted at `0xC1372FA4` / `0xC1372F98`, traverse action/alert records, and dispatch through unresolved callbacks. This is not evidence that it creates `subscribedPagesOutAccountProblem` or changes the RTP/PE block state.
5. Device alert ID `66220` decimal is `0x000102AC`. That exact little-endian value is absent from both reconstructed sections. It does not match either adjacent scalar registration value.
6. Scoped direct-edge checking found no direct BL/B.W call or same-register MOVW/MOVT materialization of RTP helper `0xE07BDFA8`, block/unblock wrappers `0xE07C1211` / `0xE07C1219`, PE writer `0xE0251788`, or RTP provider table/slot `0xC19FD498` / `0xC19FD4C8` in the three examined ranges. Indirect callback/vtable paths remain unresolved.

## Best next target

Resolve the constructor/binder for the concrete object consumed by `CdmAlertsAlertProvider` through global `0xC136E6F0`, especially the implementation behind nested vtable `+0x14`. That is the nearest recovered path to the runtime alert-record producer. Step 4 stops here pending separate approval.

## Evidence files

- `cdm_alert_capability_builder_excerpt.txt`
- `cdm_alert_rest_provider_excerpt.txt`
- `cdm_print_alert_provider_main_excerpt.txt`
- `cdm_print_provider_helpers_excerpt.txt`
- `resource_string_and_category_locations.txt`
- `romfs_provider_method_pointer_blocks.txt`
- `alert_numeric_id_and_key_reference_audit.txt`
- `direct_edge_audit.txt`
- `STEP4_FINDINGS.txt`
- `SOURCE_INPUTS.txt`
- `verify_part22_step4.py`
- `verification_output.txt`
- `SHA256SUMS.txt`

## Reproduction

Use the same three exact input files named in `SOURCE_INPUTS.txt` and run:

```bash
python verify_part22_step4.py srtext_rebuilt.bin romfs_objs_rebuilt.bin srtext_disasm_all.txt
```

The packaged verification output records the observed result. The verifier checks input sizes and hashes, string/resource addresses, the two key-reference sites and scalar constructors, absence of 0x000102AC in both section files, scoped direct-call and MOVW/MOVT address references, and selected ROMFS method-pointer values.
