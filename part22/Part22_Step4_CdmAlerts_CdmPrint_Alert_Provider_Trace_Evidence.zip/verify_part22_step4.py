#!/usr/bin/env python3
"""Verify selected Step 4 firmware lineage, string offsets, and scoped call edges."""
from __future__ import annotations
import hashlib
import re
import struct
import sys
from pathlib import Path

SR_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('srtext_rebuilt.bin')
ROM_PATH = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('romfs_objs_rebuilt.bin')
DIS_PATH = Path(sys.argv[3]) if len(sys.argv) > 3 else Path('srtext_disasm_all.txt')
SR_BASE = 0xE0246070
ROM_BASE = 0xE09919C0
EXPECTED_SR_SHA = '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7'
EXPECTED_ROM_SHA = '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3'

sr = SR_PATH.read_bytes()
rom = ROM_PATH.read_bytes()
dis_lines = DIS_PATH.read_text(errors='replace').splitlines()

checks = []
def check(name: str, ok: bool, detail: str = '') -> None:
    checks.append((name, bool(ok), detail))

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

check('srtext section size', len(sr) == 7_616_052, str(len(sr)))
check('romfs section size', len(rom) == 4_459_788, str(len(rom)))
check('srtext SHA-256', sha(sr) == EXPECTED_SR_SHA, sha(sr))
check('romfs SHA-256', sha(rom) == EXPECTED_ROM_SHA, sha(rom))

strings = [
    (sr, SR_BASE, 0xE02756F0, b'CdmAlertsCapsProvider.cpp'),
    (sr, SR_BASE, 0xE02764F8, b'subscribedPagesOutAccountProblem'),
    (sr, SR_BASE, 0xE0277594, b'/cdm/alert/v1/alerts'),
    (sr, SR_BASE, 0xE02775E0, b'CdmAlertsAlertProvider.cpp'),
    (sr, SR_BASE, 0xE02B25CC, b'/cdm/print/v2/alerts'),
    (sr, SR_BASE, 0xE02B261C, b'CdmPrintAlertProvider.cpp'),
    (sr, SR_BASE, 0xE02B2DD8, b'com.hp.cdm.service.print.version.2.resource.printAction'),
    (sr, SR_BASE, 0xE02B2E10, b'/cdm/print/v2/printAction'),
    (rom, ROM_BASE, 0xE0C2DFEC, b'Category__subscribedPagesOutAccountProblem'),
    (rom, ROM_BASE, 0xE0C2DFF6, b'subscribedPagesOutAccountProblem'),
]
for b,base,addr,needle in strings:
    off=addr-base
    actual=b[off:off+len(needle)]
    check(f'string @ 0x{addr:08X}', actual == needle, actual.decode('ascii','replace'))

# Alert key is present twice in code at the two verified ADR locations.
line_map={}
for line in dis_lines:
    m=re.match(r'([0-9a-fA-F]{8}):\s*(.*)',line)
    if m:
        line_map[int(m.group(1),16)] = m.group(2)
check('alert-key ADR reference 1', 0xE02759E8 in line_map and 'adr' in line_map[0xE02759E8], line_map.get(0xE02759E8,''))
check('alert-key ADR reference 2', 0xE0276192 in line_map and 'adr' in line_map[0xE0276192], line_map.get(0xE0276192,''))
check('capability scalar 0x102BB', 0xE02759F8 in line_map and '0x2ba' in line_map[0xE02759F8].lower(), line_map.get(0xE02759F8,''))
check('capability scalar 0x1027F', 0xE02761A2 in line_map and '0x27e' in line_map[0xE02761A2].lower(), line_map.get(0xE02761A2,''))

# Exact 66220 numeric value is not found in either reconstructed section.
needle=(0x102AC).to_bytes(4,'little')
check('0x102AC byte-pattern absent in srtext', needle not in sr, f'count={sr.count(needle)}')
check('0x102AC byte-pattern absent in romfs', needle not in rom, f'count={rom.count(needle)}')
aligned_sr=[i for i in range(0,len(sr)-3,4) if sr[i:i+4]==needle]
aligned_rom=[i for i in range(0,len(rom)-3,4) if rom[i:i+4]==needle]
check('0x102AC aligned word absent in srtext', not aligned_sr, str(aligned_sr))
check('0x102AC aligned word absent in romfs', not aligned_rom, str(aligned_rom))

# Direct branch/call and split MOVW/MOVT reference audit, restricted to the examined component ranges.
ranges=[
    ('CdmAlerts capability builder',0xE0275500,0xE0276200),
    ('CdmAlerts response provider',0xE02773C8,0xE02776AE),
    ('CdmPrintAlertProvider',0xE02B23D0,0xE02B3450),
]
for label,start,end in ranges:
    lines=[]
    for addr,body in line_map.items():
        if start <= addr < end:
            lines.append((addr,body))
    text='\n'.join(body.lower() for _,body in lines)
    for target in [0xE07BDFA8,0xE0251788]:
        pattern=f'0x{target:08x}'
        hits=[(a,b) for a,b in lines if pattern in b.lower() and re.search(r'\b(bl|b\.w)\b',b.lower())]
        check(f'{label}: no direct call to 0x{target:08X}', not hits, '; '.join(f'{a:08X}:{b}' for a,b in hits))
    # Reconstruct MOVW/MOVT pairs in the same register (up to 24 instructions apart).
    pairs=[]
    for idx,(addr,body) in enumerate(lines):
        m=re.search(r'movw\s+(r\w+),\s*#(0x[0-9a-f]+|[0-9]+)',body,re.I)
        if not m: continue
        reg=m.group(1).lower(); low=int(m.group(2),0)
        for a2,b2 in lines[idx+1:idx+25]:
            mt=re.search(r'movt\s+'+re.escape(reg)+r',\s*#(0x[0-9a-f]+|[0-9]+)',b2,re.I)
            if mt:
                high=int(mt.group(1),0)
                pairs.append((addr,reg,(high<<16)|low))
                break
    protected=[0xE07BDFA8,0xE07C1211,0xE07C1219,0xE0251788,0xC19FD498,0xC19FD4C8]
    for target in protected:
        hits=[(a,r,v) for a,r,v in pairs if v==target]
        check(f'{label}: no MOVW/MOVT materialization of 0x{target:08X}', not hits, str(hits))

# ROMFS method-pointer evidence at exact entries.
rom_words={
    0xE0998B44:0xE0277419,
    0xE0998B68:0xE02795E9,
    0xE099FFF0:0xE02B1D91,
    0xE09A007C:0xE02B2CB1,
}
for addr,expected in rom_words.items():
    got=struct.unpack_from('<I',rom,addr-ROM_BASE)[0]
    check(f'ROMFS pointer @ 0x{addr:08X}', got == expected, f'0x{got:08X}')

passed=sum(ok for _,ok,_ in checks)
print(f'STEP4 VERIFICATION: {passed}/{len(checks)} checks passed')
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
if passed != len(checks):
    raise SystemExit(1)
