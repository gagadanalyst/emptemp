from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from pathlib import Path

ROOT=Path('/mnt/data/hp_part22_step29')
out=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision115_Part22_Step29_Lock_Control_and_Pen_Service_Audit.docx'
doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(0.62); sec.bottom_margin=Inches(0.62); sec.left_margin=Inches(0.72); sec.right_margin=Inches(0.72)
sec.header_distance=Inches(0.28); sec.footer_distance=Inches(0.28)

# Palette
NAVY='14324A'; BLUE='176B87'; PALE='EAF2F6'; LIGHT='F4F7F9'; GREY='53636F'; RED='9C3B35'; GREEN='2C6B53'; WHITE='FFFFFF'

# Base styles
styles=doc.styles
normal=styles['Normal']; normal.font.name='Aptos'; normal.font.size=Pt(9.2); normal.font.color.rgb=RGBColor.from_string('26343D')
normal.paragraph_format.space_after=Pt(4); normal.paragraph_format.line_spacing=1.08
for stylename,size,color in [('Title',22,NAVY),('Heading 1',15,NAVY),('Heading 2',11,BLUE),('Heading 3',9.5,NAVY)]:
    s=styles[stylename]; s.font.name='Aptos Display' if stylename in ('Title','Heading 1') else 'Aptos'; s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor.from_string(color)
    s.paragraph_format.space_before=Pt(8 if stylename!='Title' else 0); s.paragraph_format.space_after=Pt(4)

# Header/footer
header=sec.header.paragraphs[0]
header.text='HP DESKJET 2855e  |  FIRMWARE INVESTIGATION'
header.style='Caption'; header.runs[0].font.name='Aptos'; header.runs[0].font.size=Pt(7.5); header.runs[0].font.bold=True; header.runs[0].font.color.rgb=RGBColor.from_string(BLUE)
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=footer.add_run('Revision 115  |  Part 22, Step 29  |  '); r.font.size=Pt(7.5); r.font.color.rgb=RGBColor.from_string(GREY)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

# Helpers
def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)
def set_cell_text(cell,text,bold=False,color='26343D',size=8.2):
    cell.text=''
    p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(1); p.paragraph_format.space_before=Pt(1); p.paragraph_format.line_spacing=1.0
    r=p.add_run(text); r.bold=bold; r.font.name='Aptos'; r.font.size=Pt(size); r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def set_repeat_table_header(row):
    trPr=row._tr.get_or_add_trPr(); tblHeader=OxmlElement('w:tblHeader'); tblHeader.set(qn('w:val'),'true'); trPr.append(tblHeader)
def table(headers, rows, widths=None, fs=8.0):
    t=doc.add_table(rows=1, cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'
    t.autofit=False
    hdr=t.rows[0]; set_repeat_table_header(hdr)
    for i,h in enumerate(headers):
        set_cell_text(hdr.cells[i],h,True,WHITE,fs); shade(hdr.cells[i],NAVY)
        if widths: hdr.cells[i].width=Inches(widths[i])
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            set_cell_text(cells[i],val,False,'26343D',fs)
            if ri%2==1: shade(cells[i],LIGHT)
            if widths: cells[i].width=Inches(widths[i])
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t
def bullet(text, level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    p.paragraph_format.space_after=Pt(2); p.paragraph_format.left_indent=Inches(0.22+level*0.18)
    p.add_run(text)
    return p
def callout(label, body, fill=PALE, label_color=BLUE):
    t=doc.add_table(rows=1,cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; c=t.cell(0,0); c.width=Inches(6.95); shade(c,fill)
    c.text=''; p=c.paragraphs[0]; p.paragraph_format.space_before=Pt(5); p.paragraph_format.space_after=Pt(5); p.paragraph_format.left_indent=Inches(.12); p.paragraph_format.right_indent=Inches(.12)
    rr=p.add_run(label+'  '); rr.bold=True; rr.font.color.rgb=RGBColor.from_string(label_color); rr.font.size=Pt(9)
    rr=p.add_run(body); rr.font.size=Pt(8.8); rr.font.color.rgb=RGBColor.from_string('26343D')
    doc.add_paragraph().paragraph_format.space_after=Pt(1)

# PAGE 1
p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(2)
r=p.add_run('PART 22  /  STEP 29'); r.bold=True; r.font.size=Pt(9); r.font.color.rgb=RGBColor.from_string(BLUE)
p=doc.add_paragraph(style='Title'); p.add_run('Lock-Control and Pen-Service Provider Audit')
p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(7)
r=p.add_run('Revision 115  |  20 November 2026  |  Static firmware analysis'); r.font.size=Pt(8.5); r.font.color.rgb=RGBColor.from_string(GREY)

callout('BOTTOM LINE', 'The firmware contains internal clear operations, but this analysis did not find a safe, user-operable firmware unlock procedure. The RTP gate, Print Engine blocked flag, Ink Subscription mask, and INPR report lock are separate mechanisms. None is proven to override a genuine account, cartridge, or subscription restriction.', fill='FCEFED', label_color=RED)

doc.add_heading('1. Internal control paths confirmed', level=1)
rows=[
 ['RTP manager gate','block_print 0xE07C1211 sets 1; unblock_print 0xE07C1219 sets 0. Helper 0xE07BDFA8 calls provider vtable +0xA0 through pointer slot 0xC19FD4C8.','Internal gate setter confirmed; exact provider instance and relationship to subscription restrictions unresolved.'],
 ['Print Engine blocked flag','Writer 0xE0251788 updates DSID_PRINT_ENGINE_BLOCKED (0x00012196). PE event payload 0x8B sets it; 0x8C clears it through the dispatch at 0xE0251ED0.','Internal clear branch confirmed; legitimate production source of event 0x8C is not identified.'],
 ['ConStat / PINK mask','0xE030B2A8 reads service 0x1FF211 via vtable +0x50 and extracts bit 17 (0x00020000). 0xE030B478 updates through +0x54; selector 1/state 3 omits bit 17.','Potential TooEarly state transition; provider method binding and upstream state-3 condition remain unresolved.'],
 ['INPR report lock','Lock byte 0xC148E498; reader 0xE0353BD0; writer 0xE0353BDC.','Separate reporting lock; no established connection to the other controls.'],
]
table(['Subsystem','Confirmed firmware behavior','What this does / does not prove'],rows,[1.15,3.05,2.75],7.45)

callout('RTP METHOD-REGISTRY FINDING', 'The named methods rtp_manager.block_print and rtp_manager.unblock_print are entries in a 40-slot descriptor table (39 named methods plus a null terminator) registered during RTP initialization by 0xE07C1170. This proves internal method-dispatch registration, but the transport, access controls, and any supported external endpoint remain unresolved.', fill=PALE, label_color=BLUE)

p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(2)
r=p.add_run('Important separation. '); r.bold=True; r.font.color.rgb=RGBColor.from_string(NAVY)
p.add_run('These controls must not be treated as interchangeable “print locks.” Clearing one state does not establish that the others clear, nor that a blocked print job becomes eligible to execute.')

# PAGE 2
doc.add_page_break()
doc.add_heading('2. Service 0x001FF211: corrected provider/consumer crosswalk', level=1)
p=doc.add_paragraph('The descriptor crosswalk identifies the component that advertises the PINK per-supply mask service and the components that depend on it. This corrects an earlier tentative interpretation of the nearby region-relock metadata.')
rows=[
 ['pen','A / record 1','0xE0B4A988','Advertises service 0x001FF211'],
 ['xm','B / record 7','0xE0BB62CC','Consumes service 0x001FF211'],
 ['region_relock','B / record 4','0xE0B5D2F8','Also consumes service 0x001FF211'],
]
table(['Component','Descriptor entry','Record address','Interpretation'],rows,[1.15,1.25,1.35,3.2],8.0)

callout('CORRECTION', 'The six-entry method table at 0xE0B5D358 belongs to the region_relock consumer descriptor. It is not the Pen provider vtable. The proximity of the “region_relock” label to the service ID had led to an incorrect tentative association.', fill='FFF5E8', label_color='9B5B14')

doc.add_heading('Provider implementation remains unresolved', level=2)
bullet('Two larger Pen-module pointer-table candidates (0xE0B4B158 and 0xE0B4C840) were inspected at offsets +0x50 and +0x54.')
bullet('Their target functions do not currently match the ConStat mask-reader and mask-writer calling conventions and observed behavior closely enough to bind them as the dynamic implementation.')
bullet('Conclusion: Pen is the component-level provider of service 0x001FF211, but the exact runtime object pointer and dynamic method targets used by ConStat remain unresolved.')

doc.add_heading('3. What the TooEarly bit tells us', level=1)
bullet('The PINK reader extracts bit 17 (0x00020000), the previously identified supplyInksubTooEarly bit, and writes it to a caller-provided status byte.')
bullet('For selector 1, updater states 1 and 2 include bit 17; state 3 submits 0x00000040 without bit 17. This is consistent with a changed supply state, but the actual provider semantics and upstream state selection are not proven.')
bullet('No direct path has been demonstrated that converts PINK bit 0x00020000 into ConStat reason INKSUB_REPLACED_EARLY (0x13 / decimal 19).')
callout('DO NOT FORCE STATE 3', 'The observed mask update is an internal firmware API, not a supported user command. Forcing it could make displayed state inconsistent with the actual cartridge/account condition; this analysis does not recommend doing so.', fill='FCEFED', label_color=RED)

# PAGE 3
doc.add_page_break()
doc.add_heading('4. What this means for restoring printing', level=1)
p=doc.add_paragraph('There is no safe external IPP, eSCL, or EWS command identified in this analysis that invokes these internal clear operations. The firmware evidence does not support manually changing the DSID, injecting PE event 0x8C, calling the RTP callback directly, or forcing a PINK mask update.')

doc.add_heading('Legitimate diagnostic route', level=2)
bullet('Check the current HP Smart / Embedded Web Server message and record the exact cartridge or account condition shown now.')
bullet('Confirm that the printer and cartridges are associated with the correct account, enrollment status, and supported region. Use HP support for account eligibility, replacement-timing, or region-related exceptions that the normal workflow does not resolve.')
bullet('After the underlying condition is resolved through the supported process, re-check IPP printer-state-reasons and submit a small test job. Do not assume that scanning success proves printing has been unblocked.')

callout('HISTORICAL DEVICE EVIDENCE - NOT RETESTED HERE', 'Earlier user-supplied observations included an EWS “Cartridge or Account Issue” message and a critical IPP subscribedPagesOut alert. Those observations are consistent with checking the account/cartridge eligibility path first, but they do not by themselves prove the cause of the no-print behavior.', fill=PALE, label_color=BLUE)

p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(4)
r=p.add_run('PrinterRegionReset resource note. '); r.bold=True; r.font.color.rgb=RGBColor.from_string(NAVY)
p.add_run('A resource string named PrinterRegionReset was located in the firmware. Its script behavior, access checks, and supported invocation have not been established. Its presence is not evidence of a public endpoint or permission to reset region state.')

doc.add_heading('5. Next static-analysis targets', level=1)
rows=[
 ['1','Resolve the exact runtime Pen provider object supplied to ConStat at C1443000+0x20 and map its +0x50/+0x54 methods by ABI and storage behavior.'],
 ['2','Find production callers and source conditions that feed reason value 19 (0x13) into 0xE03076C0; exclude the constat_fake_udw.cpp callback family.'],
 ['3','Identify the legitimate producer of PE clear event 0x8C and establish whether it follows a genuine recovery condition or normal lifecycle completion.'],
]
table(['Priority','Unresolved question'],rows,[0.8,6.15],7.8)

doc.add_heading('Scope and safety', level=1)
p=doc.add_paragraph('This step used static copies of the firmware image, reconstructed sections, disassembly, and earlier component-registry evidence. No printer communication, print or scan job, firmware write, patch, event injection, account change, or device-state modification was performed.')
p.paragraph_format.space_after=Pt(3)

# small provenance line
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(5)
r=p.add_run('Evidence package: '); r.bold=True; r.font.color.rgb=RGBColor.from_string(NAVY)
r=p.add_run('Part22_Step29_Lock_Control_and_Pen_Service_Audit_Evidence.zip. See STEP29_FINDINGS.txt, focused disassembly excerpts, service crosswalk CSVs, source hashes, and verification_output.txt.'); r.font.size=Pt(8); r.font.color.rgb=RGBColor.from_string(GREY)

# metadata
doc.core_properties.title='HP DeskJet 2855e - Part 22 Step 29 Lock-Control and Pen-Service Provider Audit'
doc.core_properties.subject='Static firmware analysis of internal print-block controls and Pen service 0x001FF211'
doc.core_properties.author='OpenAI'
doc.core_properties.keywords='HP DeskJet 2855e, firmware, RTP, Print Engine, ConStat, PINK, Ink Subscription'
doc.save(out)
print(out)
