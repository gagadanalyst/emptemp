# Part 22, Step 29 - Lock-control and Pen-service provider audit

Revision 115, dated 2026-11-20.

## Main result

The firmware has internal clearing mechanisms for the RTP manager gate, Print Engine blocked flag, and ConStat/PINK per-supply mask. They are separate controls. This analysis does not establish a supported external unlock command or prove that any one of them clears an Ink Subscription entitlement/cartridge restriction. The RTP block/unblock wrappers are now confirmed as named entries in an internal method-dispatch table, but its transport and access-control path remain unresolved.

## Key correction

Service `0x001FF211` is advertised by component `pen` and consumed by `xm` and `region_relock`. The six-entry method table at `0xE0B5D358` belongs to the `region_relock` consumer and is not the Pen provider vtable. Two candidate Pen tables were inspected but not accepted because their target methods did not match the ConStat reader/writer ABI closely enough.

## Contents

- `STEP29_FINDINGS.txt`: detailed finding and limitations.
- `disassembly/`: focused Thumb disassembly excerpts for the ConStat mask reader/updater and PE event dispatch.
- `*_excerpt.txt`: RTP and PE control excerpts.
- `service_0x1FF211_component_crosswalk.csv`: provider/consumer component crosswalk.
- `rtp_manager_method_registry.csv`: 39 named RTP methods and the null terminator, including block/unblock function pointers.
- `disassembly/rtp_method_registry_setup_excerpt.dis`: RTP initialization and method-table registration callsites.
- `region_relock_descriptor_raw.csv`: raw descriptor words and method table entries.
- `pen_candidate_table_slots.csv`: candidate Pen table methods and ABI assessment.
- `SOURCE_INPUTS.txt`: sizes and SHA-256 hashes of the reconstructed firmware inputs and full disassembly used.
- `verification_output.txt`: focused invariant checks (18/18 PASS).
- `SHA256SUMS.txt`: hashes for all evidence files, excluding this checksum file itself.
- The user-facing Revision 115 DOCX and PDF are included in this evidence directory and linked separately.

The original Part 1 RTP provider package remains a separate preserved Library artifact. The source inputs listed in `SOURCE_INPUTS.txt` were statically materialized from that package / previously reconstructed firmware sections; this Step 29 ZIP does not duplicate the full firmware binaries or 130+ MB full disassembly.

## Safety and scope

Static analysis only. No printer communication, print/scan job, firmware write, patch, event injection, account change, or device-state modification was performed. Do not force the internal state transitions described in the report.
