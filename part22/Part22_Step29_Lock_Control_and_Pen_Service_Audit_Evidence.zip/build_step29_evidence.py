from pathlib import Path
import csv, struct, hashlib, zipfile, json
ROOT=Path('/mnt/data/hp_part22_step29')
BIN=Path('/mnt/data/hp_firmware_recovery/extracted/part1_rtp_provider_trace/romfs_objs_rebuilt.bin')
DIS=Path('/mnt/data/hp_firmware_recovery/srtext_full_thumb.dis')
BASE=0xE09919C0
blob=BIN.read_bytes()

def word(addr): return struct.unpack_from('<I', blob, addr-BASE)[0]
def words(addr,n): return [word(addr+4*i) for i in range(n)]

# Descriptor raw records from the non-standard region_relock metadata header.
header=0xE0B5D238
fields=words(header,16)
with (ROOT/'evidence/region_relock_descriptor_raw.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['address','field','value'])
    for i,v in enumerate(fields): w.writerow([f'0x{header+4*i:08X}',f'header_word_{i}',f'0x{v:08X}'])
    for i in range(6): w.writerow([f'0x{0xE0B5D278+4*i:08X}',f'array_A_word_{i}',f'0x{word(0xE0B5D278+4*i):08X}'])
    for i in range(30): w.writerow([f'0x{0xE0B5D290+4*i:08X}',f'array_B_word_{i}',f'0x{word(0xE0B5D290+4*i):08X}'])
    for i in range(12): w.writerow([f'0x{0xE0B5D358+4*i:08X}',f'region_relock_table_word_{i}',f'0x{word(0xE0B5D358+4*i):08X}'])

# Focused crosswalk from Part 8's interpreted A/B records, preserved here as verified values.
rows=[
 ['pen','A',1,'0xE0B4A988','0x001FF211','advertises'],
 ['xm','B',7,'0xE0BB62CC','0x001FF211','consumes'],
 ['region_relock','B',4,'0xE0B5D2F8','0x001FF211','consumes'],
 ['region_relock','B',0,'0xE0B5D298','0x00F8AE47','consumes'],
 ['region_relock','B',1,'0xE0B5D2B0','0x00DEED54','consumes'],
 ['region_relock','B',2,'0xE0B5D2C8','0x00F14AFF','consumes'],
 ['region_relock','B',3,'0xE0B5D2E0','0x00C95785','consumes'],
]
with (ROOT/'evidence/service_0x1FF211_component_crosswalk.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['component','array','index','record_address','service_id','interpretation']); w.writerows(rows)

# The two Pen-module candidate function-pointer runs and the actual +0x50/+0x54 entries.
with (ROOT/'evidence/pen_candidate_table_slots.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['candidate_table','slot_offset','entry_address','thumb_pointer','code_address','inspected_target','abi_assessment'])
    for base in [0xE0B4B158,0xE0B4C840]:
        for slot in [0x50,0x54]:
            ptr=word(base+slot)
            code=ptr & ~1
            w.writerow([f'0x{base:08X}',f'0x{slot:02X}',f'0x{base+slot:08X}',f'0x{ptr:08X}',f'0x{code:08X}',
                {0xE0746758:'0xE0739910',0xE0746760:'0xE07399A8',0xE0746C40:'0xE072D338',0xE0746C48:'0xE072D110'}.get(code,'not mapped'),
                'not accepted as service implementation; inspected behavior does not establish required mask get/set ABI'])

# Build deterministic hashes for the source binary sections, full disassembly, and all evidence files.
source_paths=[BIN,DIS,Path('/mnt/data/hp_firmware_recovery/extracted/part1_rtp_provider_trace/srtext_rebuilt.bin'),Path('/mnt/data/hp_firmware_recovery/extracted/part1_rtp_provider_trace/hp_lbi_sections.elf')]
with (ROOT/'evidence/SOURCE_INPUTS.txt').open('w') as f:
    f.write('Step 29 source provenance\n=========================\n')
    for p in source_paths:
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        f.write(f'{p}\n  size={p.stat().st_size}\n  sha256={h}\n')
    f.write('\nAll inputs are static copies materialized from the prior investigation evidence package or its reconstructed firmware sections.\n')

# Focused invariant verifier.
checks=[]
def ck(label,cond): checks.append((label,bool(cond)))
text=DIS.read_text(errors='replace')
ck('RTP block wrapper sets r0=1 at 0xE07C1211', 'e07c1210: 2001' in text.lower())
ck('RTP unblock wrapper sets r0=0 at 0xE07C1219', 'e07c1218: 2000' in text.lower())
ck('RTP helper loads provider slot at 0xC19FD4C8', 'ldr\tr0, [r2, #0x30]' in text.lower() or 'ldr\tr0, [r2, #0x30]' in text.lower())
ck('PE writer uses DSID 0x00012196', 'f242 1196' in text.lower())
ck('ConStat reader uses virtual slot +0x50', '6d0a' in text.lower() and 'e030b31e' in text.lower())
ck('ConStat updater uses virtual slot +0x54', '6d4b' in text.lower() and 'e030b52c' in text.lower())
ck('ConStat reader extracts bit 17', 'ubfx\tr0, r5, #0x11, #0x1' in text.lower())
ck('Pen advertises service 0x1FF211', word(0xE0B4A988+8)==0x001FF211)
ck('XM consumes service 0x1FF211', word(0xE0BB62CC+8)==0x001FF211)
ck('region_relock metadata has five dependency records', word(0xE0B5D240)==0xE0B5D290 and word(0xE0B5D244)==5)
ck('region_relock dependency list contains 0x1FF211', word(0xE0B5D2F8)==0x001FF211)
ck('region_relock table has six method entries before nulls', words(0xE0B5D35C,6)==[0xE0797503,0xE079751D,0xE0797533,0xE0797537,0xE0797539,0xE079754B])
ck('Candidate Pen tables slot entries reproduced', word(0xE0B4B158+0x50)==0xE0746759 and word(0xE0B4B158+0x54)==0xE0746761 and word(0xE0B4C840+0x50)==0xE0746C41 and word(0xE0B4C840+0x54)==0xE0746C49)
ck('PE event dispatcher retains set and clear calls', '2001' in Path('/mnt/data/hp_firmware_recovery/e025_event_dispatch_excerpt.dis').read_text(errors='replace').lower() and '2000' in Path('/mnt/data/hp_firmware_recovery/e025_event_dispatch_excerpt.dis').read_text(errors='replace').lower())

out='STEP 29 VERIFICATION\n====================\n'+'\n'.join(('PASS' if ok else 'FAIL')+' - '+name for name,ok in checks)+f'\n\nResult: {sum(ok for _,ok in checks)}/{len(checks)} PASS\n'
(ROOT/'evidence/verification_output.txt').write_text(out)
if not all(ok for _,ok in checks):
    raise SystemExit(out)

# Evidence checksum file (excludes itself and the final ZIP).
files=sorted(p for p in (ROOT/'evidence').rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
with (ROOT/'evidence/SHA256SUMS.txt').open('w') as f:
    for p in files: f.write(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}\n')
print(out)
