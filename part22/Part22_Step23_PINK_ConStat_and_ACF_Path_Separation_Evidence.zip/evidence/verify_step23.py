from pathlib import Path
import hashlib, struct, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
EV=ROOT/'evidence'
SRC=Path('/mnt/data/hp_resume/unpacked/part1_rtp_provider_trace')
checks=[]
def check(name, ok, detail=''):
    checks.append((name,bool(ok),detail))

required=[
 'STEP23_FINDINGS.txt','SOURCE_INPUTS.txt','pinksupply_selector_to_flag.csv',
 'reason_insertion_candidate_audit.csv','printhead_failure_report_callers.csv',
 'cdm_supply_resource_registrations.csv','srtext_string_locations.csv',
 'romfs/tray2_counter_descriptor_context.txt','romfs/tray2_counter_descriptor_0xE0B372E4.bin',
 'disassembly/pink_selector_mask_setter.dis','disassembly/mask_provider_candidate.dis',
 'disassembly/conStat_reason_insertion.dis','disassembly/candidate_reason_helper.dis',
 'disassembly/candidate_status_value_helper.dis','disassembly/printhead_failure_report.dis',
 'disassembly/not_enrolled_reason_caller.dis','disassembly/no_rtp_reason_caller.dis',
 'disassembly/other_report_reason_caller.dis','disassembly/unrelated_pe_event_type_0x13.dis',
 'disassembly/cdm_assessment_registration.dis','disassembly/cdm_public_provider_registration.dis',
 'disassembly/cdm_private_provider_registration.dis','disassembly/cdm_alerts_provider_registration.dis'
]
for rel in required: check('evidence file '+rel,(EV/rel).is_file() and (EV/rel).stat().st_size>0)

# Exact input provenance: the rebuilt .srtext is the .srtext section of the supplied ELF.
elf=(SRC/'hp_lbi_sections.elf').read_bytes()
raw=(SRC/'srtext_rebuilt.bin').read_bytes()
section=elf[0x54:0x54+0x743634]
check('srtext rebuild exactly matches ELF .srtext section',section==raw,
      f'section_bytes={len(section)} raw_bytes={len(raw)}')

rom=(SRC/'romfs_objs_rebuilt.bin').read_bytes(); base=0xE09919C0
needle=b'DSID_PE_TRAY2_OPEN_CLOSE_COUNTER\0'; off=rom.find(needle)
check('ROMFS DSID_PE_TRAY2_OPEN_CLOSE_COUNTER found at expected VMA',off>=0 and base+off==0xE0B372C0,
      f'offset={off:#x} vma={(base+off):#x}' if off>=0 else 'not found')
check('report descriptor address follows DSID declaration',0xE0B372E4>0xE0B372C0 and 0xE0B372E4-base+0x90<=len(rom))

# Textual evidence checks.
find=(EV/'STEP23_FINDINGS.txt').read_text()
for token in ['0xE030B478','0x00020000','0xE030BB38','0xE071B0D0','0xC192A090','0xE0B372E4','0x0D','0x12','0x14','not proven']:
    check('findings include '+token,token.lower() in find.lower())

# Disassembly excerpt sanity checks.
checks_text={
 'PINK setter has target code':'pink_selector_mask_setter.dis':['e030b478','0x20000','0x10000'],
 'reason helper contains candidate':'candidate_reason_helper.dis':['e030bb38'],
 'report path includes provider descriptor':'printhead_failure_report.dis':['e0b372e4','printhead_failure'],
 'Not-Enrolled caller contains 0x12':'not_enrolled_reason_caller.dis':['0x12','e071b0d0'],
 'No-RTP caller contains 0x14':'no_rtp_reason_caller.dis':['0x14','e071b0d0'],
}
for label,(fname,toks) in checks_text.items():
    p=EV/'disassembly'/fname
    txt=p.read_text(errors='ignore').lower() if p.exists() else ''
    check(label,all(t.lower() in txt for t in toks),f'required={toks}')

# Delivery file checks.
for p in ROOT.glob('*.docx'): check('DOCX artifact '+p.name,p.stat().st_size>10000)
for p in ROOT.glob('*.pdf'): check('PDF artifact '+p.name,p.stat().st_size>5000)

ok=sum(x[1] for x in checks); bad=len(checks)-ok
lines=[f'Step 23 verifier: {ok}/{len(checks)} PASS; {bad} FAIL']
for n,good,d in checks: lines.append(('PASS' if good else 'FAIL')+'\t'+n+(('\t'+d) if d else ''))
out='\n'.join(lines)+'\n'
(EV/'verification_output.txt').write_text(out)
print(out)
if bad: sys.exit(1)
