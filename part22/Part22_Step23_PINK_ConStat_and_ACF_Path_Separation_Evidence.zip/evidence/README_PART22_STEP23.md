# Part 22 — Step 23 evidence package

## Scope

Static-only cross-check of the PINK supply-error mask setter, ConStat consumable-reason insertion candidates, and the PE-policy `printhead_failure` reporting path. Also records the distinct CDM supply-provider registration paths to avoid conflating resource updates with CanPrint reason insertion.

## Key findings

- `0xE030B478` selects PINK masks: `supplyInksubTooEarly=0x00020000`, `supplyInksubNotEnrolled=0x00010000`, `supplySharedSelectShorted=0x00200000` (state-argument branches are recorded in the CSV).
- The candidate dynamic reason function `0xE030BB38` resolves only to reason `1` or `4`, not `0x13`; nearby decoded reason helpers use `0`–`4`.
- `0xE071B0D0` constructs a `printhead_failure` report with incoming reason stored in a structured payload, then invokes the dynamically injected provider at `0xC192A090` through vtable slot `+0`. It supplies descriptor `0xE0B372E4`, adjacent to ROMFS `DSID_PE_TRAY2_OPEN_CLOSE_COUNTER` at `0xE0B372C0`.
- The report routine does not directly call `0xE03076C0`; the provider implementation and downstream receiver remain unresolved.
- The separate PE-policy payload value `0x13` at `0xE071E1D0` is not proven to be the PINK/ConStat `INKSUB_REPLACED_EARLY` reason.

## Important limits

This package does not establish which reason was active on the printer. It does not prove that the `printhead_failure` provider forwards its payload into the six-group ConStat aggregate. Runtime provider/vtable binding must be resolved before the earlier `+0x54` implementation assignment is treated as authoritative because caller/callee argument shapes require reconciliation.

No printer communication, firmware change, physical print, or scan attempt was performed.

## Contents

- `STEP23_FINDINGS.txt` — detailed findings.
- `disassembly/` — focused instruction slices extracted from the supplied ELF.
- `romfs/` — DSID label and descriptor bytes around `0xE0B372E4`.
- CSV crosswalks — PINK selector-to-mask mapping, bounded reason-helper audit, reporting-callers, and CDM resource registrations.
- `SOURCE_INPUTS.txt` — hashes and sizes of the source ELF and rebuilt binaries.
- `verify_step23.py` — focused evidence verifier.
- `verification_output.txt` — verifier results.
