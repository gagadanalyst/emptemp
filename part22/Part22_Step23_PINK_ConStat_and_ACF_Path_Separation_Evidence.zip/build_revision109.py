from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION
from pathlib import Path

OUT=Path('/mnt/data/hp_part22_step23')
name='HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision109_Part22_Step23_PINK_ConStat_and_ACF_Path_Separation_Addendum.docx'

doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(0.7); sec.bottom_margin=Inches(0.65); sec.left_margin=Inches(0.78); sec.right_margin=Inches(0.78)
sec.header_distance=Inches(0.3); sec.footer_distance=Inches(0.3)

# Base styles
styles=doc.styles
styles['Normal'].font.name='Aptos'; styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'),'Aptos')
styles['Normal'].font.size=Pt(9.3); styles['Normal'].font.color.rgb=RGBColor(38,48,60)
styles['Normal'].paragraph_format.space_after=Pt(5)
for sname,size,color in [('Title',24,'17365D'),('Heading 1',16,'17365D'),('Heading 2',12,'245A81'),('Heading 3',10,'245A81')]:
    st=styles[sname]; st.font.name='Aptos Display'; st._element.rPr.rFonts.set(qn('w:eastAsia'),'Aptos Display')
    st.font.size=Pt(size); st.font.bold=True; st.font.color.rgb=RGBColor.from_string(color)
    st.paragraph_format.space_before=Pt(10); st.paragraph_format.space_after=Pt(5)

# Header/footer
header=sec.header.paragraphs[0]
header.text='HP DeskJet 2855e  |  Independent Printing / Scanning Investigation'
header.style='Caption'; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
footer.add_run('Revision 109 — Part 22, Step 23  |  Static firmware analysis only  |  Page ')
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

# Helpers
def shade(cell, fill='EAF1F7'):
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)
def set_cell_text(cell,text,bold=False,color=None,size=8.5):
    cell.text=''
    p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(1); p.paragraph_format.space_before=Pt(1)
    r=p.add_run(str(text)); r.bold=bold; r.font.size=Pt(size)
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def table(headers,rows,widths=None):
    t=doc.add_table(rows=1, cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'
    for i,h in enumerate(headers): set_cell_text(t.rows[0].cells[i],h,True,'FFFFFF',8.5); shade(t.rows[0].cells[i],'245A81')
    for row in rows:
        c=t.add_row().cells
        for i,val in enumerate(row): set_cell_text(c[i],val,size=8.1)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t
def bullet(text):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(text); return p
def note(text, fill='EAF1F7'):
    t=doc.add_table(rows=1,cols=1); t.style='Table Grid'; c=t.cell(0,0); shade(c,fill); c.text=''
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(2); p.paragraph_format.space_before=Pt(2)
    r=p.add_run(text); r.bold=True; r.font.size=Pt(9.2)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
def code(text):
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(0.18); p.paragraph_format.right_indent=Inches(0.12)
    p.paragraph_format.space_before=Pt(2); p.paragraph_format.space_after=Pt(5)
    r=p.add_run(text); r.font.name='Cascadia Mono'; r._element.rPr.rFonts.set(qn('w:eastAsia'),'Cascadia Mono'); r.font.size=Pt(8)
    return p

# PAGE 1
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('HP DeskJet 2855e'); r.bold=True; r.font.size=Pt(14); r.font.color.rgb=RGBColor(36,90,129)
p=doc.add_paragraph(style='Title'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.add_run('PINK / ConStat / ACF Path Separation')
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Revision 109  |  Part 22 — Step 23 Addendum'); r.font.size=Pt(12); r.bold=True
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Static firmware reconstruction • 19 November 2026'); r.italic=True; r.font.size=Pt(9)

doc.add_heading('Executive finding',level=1)
note('The PINK “Too Early” mask is explicitly selected and forwarded by firmware code, but the conversion from that mask to ConStat reason 0x13 is still not proven. Two previously suspected bridges are now narrowed: the “dynamic reason” helper cannot produce 0x13, and the printhead_failure path is a separate injected reporting/DSID route rather than a direct call to the CanPrint reason inserter.')
doc.add_paragraph('This step focuses on separating three mechanisms that had begun to look like one path: (1) PINK supply-error bit updates, (2) insertion of consumable-error reasons into the six-group ConStat CanPrint aggregate, and (3) PE-policy / ACF reporting. Their common vocabulary and related numeric values are not, by themselves, proof that one automatically invokes another.')
doc.add_heading('What is now established',level=2)
for s in [
    'E030B478 maps selector 1 to PINK supplyInksubTooEarly (0x00020000), selector 4 to supplyInksubNotEnrolled (0x00010000), and selector 3 to supplySharedSelectShorted (0x00200000), subject to the handler’s state argument.',
    'E030BB38 cannot produce ConStat reason 0x13: its computed reason is restricted to 1 or 4.',
    'E071B0D0 packages reasons 0x0D, 0x12, or 0x14 into a printhead_failure report payload and invokes an injected provider at C192A090; no direct call to E03076C0 is present in that routine.',
    'The PE-policy event payload containing 0x13 at E071E1D0 is a separate event/state path and is not evidence of INKSUB_REPLACED_EARLY.'
]: bullet(s)
doc.add_heading('Root-cause status',level=2)
doc.add_paragraph('The firmware explicitly blocks CanPrint for ConStat consumable reasons 0x12, 0x13, and 0x14 (established in the previous investigation). This step does not identify which reason was active on the user’s printer. It also does not establish a live provider binding or runtime condition state.')

# PAGE 2
doc.add_page_break()
doc.add_heading('1. PINK mask-selection wrapper — exact flag selection',level=1)
doc.add_paragraph('Function 0xE030B478 translates selector and state inputs into PINK_supply_errors_t mask values and forwards the selected value to an injected provider method. The mapping below is from the immediate-value branches in the function, cross-checked against the ROMFS enum names and values.')
table(['Selector r4','PINK enum name','Mask','State detail'],[
    ['1','supplyInksubTooEarly','0x00020000','r6 = 1 or 2 selects this mask; r6 = 3 selects auxiliary bit 0x40'],
    ['4','supplyInksubNotEnrolled','0x00010000','r6 = 1 or 2 selects this mask; r6 = 3 selects auxiliary bit 0x80'],
    ['3','supplySharedSelectShorted','0x00200000','r6 = 1 or 2 selects this mask; r6 = 3 selects auxiliary bit 0x1000'],
])
doc.add_paragraph('The separate No-RTP PINK mask remains 0x00040000. The prior correction that 0x00200000 belongs to supplySharedSelectShorted is retained. The selector function itself builds a mask and calls an injected provider method; it does not directly call the previously identified ConStat reason-insertion candidate.')
code('0xE030B478  →  mask selection  →  provider object from E0308F10()+0x20  →  indirect vtable call at slot +0x54')
doc.add_heading('Important ABI caveat',level=2)
doc.add_paragraph('The mask-selection wrapper passes a scalar mask in r2 (for example 0x00020000). One static candidate previously associated with the provider’s +0x54 slot, 0xE0308228, treats r2 as a pointer to an output structure. In addition, adjacent table entries create a possible one-word base/slot-alignment ambiguity. Therefore the +0x54 implementation assignment must not be treated as proven until the runtime vptr, vtable base, and service binding are recovered. The caller-side mask mapping remains clear; the receiving implementation remains unresolved.')
note('Correction to prior interpretation: the +0x54 provider implementation is not yet verified. Its target and the vtable base must be resolved with a compatible calling convention before claiming that it updates the PINK mask.', 'FFF2CC')

# PAGE 3
doc.add_page_break()
doc.add_heading('2. The “dynamic reason” candidate cannot be 0x13',level=1)
doc.add_paragraph('The function 0xE030BB38 looked promising because it computes a reason value and submits it through the shared ConStat provider interface. Tracing its input values excludes it as the source of INKSUB_REPLACED_EARLY (0x13).')
table(['Function','Reason value passed','Result'],[
    ['0xE030BB38','1 when r8 == 1; otherwise the result of 0xE0303060','Only 1 or 4'],
    ['0xE0303060','Returns 1 or 4 on its two branches','Cannot return 0x13'],
    ['0xE030BC08','State-dependent switch','0, 2, or 3'],
    ['0xE030BCB0','Fixed value','3'],
    ['0xE030BD30','Fixed value','4'],
    ['0xE0303E18','Default wrapper argument','2'],
])
doc.add_paragraph('This is a bounded exclusion of the decoded helpers. It does not prove that no other dynamic or indirect caller in the entire firmware can insert reason 0x13.')
doc.add_heading('Why this matters',level=2)
doc.add_paragraph('The CanPrint aggregator’s insertion routine 0xE03076C0 treats any inserted consumable reason other than the explicit exception code 0x25 as non-printable. A reason value of 0x13 would therefore be blocking, but the candidate helper above does not generate it. The PINK TooEarly flag and ConStat reason 0x13 remain separate representations until an actual conversion edge is found.')

# PAGE 4
doc.add_page_break()
doc.add_heading('3. printhead_failure is a separate report/provider path',level=1)
doc.add_paragraph('Function 0xE071B0D0 accepts a reason code, saves it in a structured stack payload, requests the named action/key “printhead_failure” via 0xE0722C20, and then invokes a dynamically injected provider at 0xC192A090. The provider is obtained from the field at 0xC192A068 + 0x28 and called through vtable slot +0.')
code('0xC192A068 + 0x28 = 0xC192A090')
code('0xE071B0D0 → save reason in payload → “printhead_failure” request → provider vtable +0 with descriptor 0xE0B372E4')
doc.add_heading('Descriptor cross-reference',level=2)
doc.add_paragraph('The ROMFS string at 0xE0B372C0 is DSID_PE_TRAY2_OPEN_CLOSE_COUNTER. The descriptor passed by 0xE071B0D0 is 0xE0B372E4, immediately following that DSID declaration. This establishes a DSID-associated reporting descriptor in the call. The exact semantics of provider vtable slot +0 and its downstream receiver are not statically recovered, so this addendum does not claim that the routine increments the counter or updates the ConStat reason list.')
table(['Caller','Reason supplied','Call form'],[
    ['0xE071E68C','0x0D','Direct call to 0xE071B0D0'],
    ['0xE071F9F6','0x12','Tail branch to 0xE071B0D0 after Not-Enrolled state checks'],
    ['0xE071F22A','0x14','Direct call after callback receives selector 0x100'],
])
doc.add_heading('Direct connection test',level=2)
doc.add_paragraph('No direct call from 0xE071B0D0 to 0xE03076C0 appears in the decoded routine. The reasons 0x12 and 0x14 are included in the report payload, but that does not prove the report provider forwards them to the six-group CanPrint aggregate. The provider implementation and receiver remain unresolved.')
note('This separates “the firmware reports a subscription-related failure” from “the firmware inserts a blocking ConStat consumable reason.” A bridge between those operations still has to be demonstrated.', 'EAF2E8')

# PAGE 5
doc.add_page_break()
doc.add_heading('4. Do not confuse the other PE event value 0x13',level=1)
doc.add_paragraph('A nearby PE-policy function, 0xE071E1D0, constructs a separate structured message containing numeric type 0x13 and sends it through 0xE071E0A0. Its caller/state context is part of a separate PE-policy event path adjacent to the Fpen_change handling. It does not call 0xE03076C0 and is not proven to correspond to PINK supplyInksubTooEarly or ConStat INKSUB_REPLACED_EARLY.')
note('Numeric equality is not semantic identity. PINK enum masks, ConStat consumable-error reasons, PE event types, and CDM registration selectors are distinct value domains.', 'FFF2CC')
doc.add_heading('5. CDM supply resources are separate paths',level=1)
doc.add_paragraph('The firmware contains separate CDM provider modules for public supplies, private supplies, supply assessment, and supply alerts. Their registration routines use different selectors and resource names. These are plausible data and reporting routes for supply/account state, but the decoded registration paths are not themselves a PINK-to-ConStat conversion.')
table(['Provider module','Resource','Registration selector(s)'],[
    ['CdmSupplyPublicProvider','suppliesPublic','0x8E, 0x93, 0xFE'],
    ['CdmSupplyPrivateProvider','suppliesPrivate','0xE2'],
    ['CdmSupplyAssessmentProvider','supplyAssessment','0x15E'],
    ['CdmSupplyAlertsProvider','alerts','0xE5, 0xFB'],
])
doc.add_paragraph('Selector values are recorded as arguments to the generic event-registration interface. They are not assumed to be PE nested event IDs merely because some values numerically overlap PE event types.')

# PAGE 6
doc.add_page_break()
doc.add_heading('6. What this means for the printer and the next target',level=1)
doc.add_paragraph('The strongest firmware-supported hypothesis remains that a subscription-related supply condition can feed the PE CanPrint readiness decision. The previous investigation established the ConStat blocking policy for reasons 0x12, 0x13, and 0x14, and this step confirms PINK code explicitly selects a distinct TooEarly mask value (0x00020000). The missing proof is the exact runtime bridge from that PINK state to the ConStat reason insertion mechanism.')
doc.add_heading('Next investigation target — resolve the provider, not the number',level=2)
for s in [
    'Recover the component/service binding that populates the provider field used by E030B478 and the runtime vtable pointer for the +0x54 call.',
    'Reconcile the caller’s scalar-mask argument with the candidate implementation signature before accepting the earlier +0x54 → 0xE0308228 assignment.',
    'Trace the separate injected provider at C192A090 to its service ID and actual receiver; determine whether its printhead_failure payload is forwarded to ConStat, an ACF report store, or only a DSID/telemetry path.',
    'Continue searching for an executable conversion from PINK supplyInksubTooEarly (0x00020000) to ConStat INKSUB_REPLACED_EARLY (0x13), without using the unrelated PE event 0x13 as evidence.'
]: bullet(s)
doc.add_heading('Operational safety boundary',level=2)
doc.add_paragraph('This remains static analysis. No printer network calls, state changes, firmware patching, flashing, print attempts, or scan attempts were made. A future repair recommendation must be based on the actual cause and a supported/reversible recovery path; forcing a displayed CanPrint or blocked-state flag is not a validated fix.')
doc.add_heading('Deliverables and verification',level=2)
doc.add_paragraph('The accompanying evidence ZIP contains the focused disassembly slices, ROMFS descriptor bytes, PINK selector crosswalk, bounded reason-insertion audit, printhead_failure caller map, CDM provider registration map, source hashes, and a verification script. This is a standalone addendum because the prior Revision 108 source DOCX was not available in the restored workspace; it has not been merged into the earlier long-form report.')
doc.add_paragraph('Conclusion: Step 23 closes several false or incomplete links and narrows the next target to runtime service/vtable resolution. It does not yet identify which subscription condition was active on this specific printer.')

# Save
path=OUT/name
doc.save(path)
print(path)
