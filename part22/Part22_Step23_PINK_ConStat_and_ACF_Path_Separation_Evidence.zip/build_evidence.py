from pathlib import Path
import subprocess, hashlib, struct, csv, json

ROOT=Path('/mnt/data/hp_part22_step23')
EV=ROOT/'evidence'
SRC=Path('/mnt/data/hp_resume/unpacked/part1_rtp_provider_trace')
ELF=SRC/'hp_lbi_sections.elf'
ROM=SRC/'romfs_objs_rebuilt.bin'
SRT=SRC/'srtext_rebuilt.bin'
TRIPLE='thumbv7m-none-eabi'

def dis(name,start,stop):
    out=EV/'disassembly'/name
    cmd=['llvm-objdump','-d','--triple='+TRIPLE,f'--start-address={start}',f'--stop-address={stop}',str(ELF)]
    r=subprocess.run(cmd,capture_output=True,text=True,check=True)
    out.write_text(r.stdout)
    return out

# Bounded disassembly slices. Addresses are ARM/Thumb code VMAs.
items=[
 ('pink_selector_mask_setter.dis','0xE030B478','0xE030B610'),
 ('mask_provider_candidate.dis','0xE0308228','0xE03083B0'),
 ('conStat_reason_insertion.dis','0xE03076C0','0xE03078A0'),
 ('candidate_reason_helper.dis','0xE030BB38','0xE030BC08'),
 ('candidate_status_value_helper.dis','0xE0303060','0xE03030C0'),
 ('printhead_failure_report.dis','0xE071B0D0','0xE071B25A'),
 ('not_enrolled_reason_caller.dis','0xE071F9D8','0xE071FA30'),
 ('no_rtp_reason_caller.dis','0xE071F200','0xE071F250'),
 ('other_report_reason_caller.dis','0xE071E650','0xE071E6C0'),
 ('unrelated_pe_event_type_0x13.dis','0xE071E088','0xE071E3E0'),
 ('cdm_assessment_registration.dis','0xE02CDD80','0xE02CE000'),
 ('cdm_public_provider_registration.dis','0xE02CF1B8','0xE02CF690'),
 ('cdm_private_provider_registration.dis','0xE02D02A0','0xE02D1090'),
 ('cdm_alerts_provider_registration.dis','0xE02D0F80','0xE02D1600'),
]
for n,a,b in items: dis(n,a,b)

# Exact source-file strings in the rebuilt .srtext image.
srt=SRT.read_bytes()
srt_strings=[
 ('printhead_failure',b'printhead_failure'),
 ('CdmSupplyAssessmentProvider.cpp',b'CdmSupplyAssessmentProvider.cpp'),
 ('CdmSupplyPublicProvider.cpp',b'CdmSupplyPublicProvider.cpp'),
 ('CdmSupplyPrivateProvider.cpp',b'CdmSupplyPrivateProvider.cpp'),
 ('CdmSupplyAlertsProvider.cpp',b'CdmSupplyAlertsProvider.cpp'),
 ('supplyAssessmentNeedConnect',b'supplyAssessmentNeedConnect'),
 ('waitingForSupplyAssessment',b'waitingForSupplyAssessment'),
]
with (EV/'srtext_string_locations.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['string','file_offset_hex','vma_hex','found'])
    for name,needle in srt_strings:
        off=srt.find(needle)
        vma=0xE0246070+off if off>=0 else None
        w.writerow([name,hex(off) if off>=0 else '',hex(vma) if vma else '',bool(off>=0)])

# ROMFS label + following descriptor bytes for the DSID string used by the report function.
rom=ROM.read_bytes(); base=0xE09919C0
needle=b'DSID_PE_TRAY2_OPEN_CLOSE_COUNTER\0'
off=rom.find(needle)
if off<0: raise SystemExit('DSID descriptor string not found')
addr=base+off
lines=[f'ROMFS object base: {base:#010x}',f'DSID string file offset: {off:#x}',f'DSID string VMA: {addr:#010x}',f'DSID descriptor constant used by E071B0D0: 0xE0B372E4',f'DSID descriptor offset: {0xE0B372E4-base:#x}',f'DSID string bytes: {needle.hex()}', 'Words from descriptor and nearby data:']
for j in range(0,0x90,4):
    a=0xE0B372E4+j
    o=a-base
    v=struct.unpack_from('<I',rom,o)[0]
    lines.append(f'  {a:#010x}  {v:#010x}')
(EV/'romfs'/'tray2_counter_descriptor_context.txt').write_text('\n'.join(lines)+'\n')
(EV/'romfs'/'tray2_counter_dsid_string.bin').write_bytes(needle)
(EV/'romfs'/'tray2_counter_descriptor_0xE0B372E4.bin').write_bytes(rom[0xE0B372E4-base:0xE0B372E4-base+0x90])

# Crosswalks based only on recovered instruction paths.
with (EV/'pinksupply_selector_to_flag.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['selector_r4','PINK flag','mask','state condition','note'])
    w.writerows([
      ['1','supplyInksubTooEarly','0x00020000','r6==1 or r6==2','r6==3 sets separate 0x40 bit'],
      ['4','supplyInksubNotEnrolled','0x00010000','r6==1 or r6==2','r6==3 sets separate 0x80 bit'],
      ['3','supplySharedSelectShorted','0x00200000','r6==1 or r6==2','r6==3 sets separate 0x1000 bit'],
    ])
with (EV/'reason_insertion_candidate_audit.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['function','path result supplied as reason','evidence','can produce 0x13?'])
    w.writerows([
      ['0xE030BB38','1 if r8==1; otherwise E0303060 result (1 or 4)','E0303060 has only 1/4 return paths','No'],
      ['0xE030BC08','0/2/3 depending on state argument','decoded switch cases','No'],
      ['0xE030BCB0','3','fixed reason argument','No'],
      ['0xE030BD30','4','fixed reason argument','No'],
      ['0xE0303E18','2','default wrapper argument','No'],
    ])
with (EV/'printhead_failure_report_callers.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['caller','reason value','call type','interpretation'])
    w.writerows([
      ['0xE071E68C','0x0D','BL to 0xE071B0D0','PE policy printhead failure report path'],
      ['0xE071F9F6','0x12','tail branch to 0xE071B0D0','Not-enrolled path'],
      ['0xE071F22A','0x14','BL to 0xE071B0D0','No-RTP notification callback path'],
    ])
with (EV/'cdm_supply_resource_registrations.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['provider','resource path or resource','registration selector(s)','status'])
    w.writerows([
      ['CdmSupplyPublicProvider','suppliesPublic','0x8E, 0x93, 0xFE','separate public-supplies CDM path'],
      ['CdmSupplyPrivateProvider','suppliesPrivate','0xE2','separate private-supplies CDM path'],
      ['CdmSupplyAssessmentProvider','supplyAssessment','0x15E','separate assessment CDM path'],
      ['CdmSupplyAlertsProvider','alerts','0xE5, 0xFB','separate alerts CDM path'],
    ])

# Source input provenance.
with (EV/'SOURCE_INPUTS.txt').open('w') as f:
    for p in [ELF,ROM,SRT]:
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        f.write(f'{p.name}\t{p.stat().st_size}\tSHA256={h}\n')

# Step findings.
findings='''PART 22 — STEP 23 FINDINGS\nPE/PINK error paths, ConStat reason insertion, and ACF reporting separation\n\n1. Direct PINK flag setter recovered\nFunction 0xE030B478 maps selector r4=1 to PINK supply flag supplyInksubTooEarly (0x00020000), selector r4=4 to supplyInksubNotEnrolled (0x00010000), and selector r4=3 to supplySharedSelectShorted (0x00200000). For r6==1 or 2, those flags are selected; r6==3 selects separate auxiliary bits (0x40, 0x80, 0x1000 respectively). This is a mask-selection path; it does not itself call the ConStat reason-insertion routine 0xE03076C0.\n\n2. The earlier dynamic reason candidate is excluded\nFunction 0xE030BB38 supplies reason 1 when its r8 input is 1; otherwise it uses the result of 0xE0303060. The latter has only two return values: 1 and 4. Therefore this path cannot generate ConStat consumable reason 0x13. The neighboring insertion helpers examined also use values 0–4 (0xE030BC08), 3 (0xE030BCB0), and 4 (0xE030BD30); the wrapper at 0xE0303E18 uses 2. These observations exclude the previously suspected helper path, not every possible dynamic caller in the image.\n\n3. printhead_failure is a separate report/provider route\nFunction 0xE071B0D0 saves its incoming reason code in a stack payload field, requests the named action/key “printhead_failure” through 0xE0722C20, then calls an injected provider pointer loaded from 0xC192A068+0x28 (address 0xC192A090) through vtable slot +0. It supplies descriptor 0xE0B372E4. The adjacent ROMFS declaration at 0xE0B372C0 is the string DSID_PE_TRAY2_OPEN_CLOSE_COUNTER. The provider implementation and its downstream receiver are not statically resolved here. There is no direct call from 0xE071B0D0 to 0xE03076C0.\n\nKnown callers of 0xE071B0D0: 0xE071E68C passes 0x0D; the Not-Enrolled path at 0xE071F9F6 tail-branches with 0x12; and the No-RTP callback at 0xE071F22A passes 0x14. These values are included in the report payload; they are not evidence that the reporting provider directly inserts those values into the six-group ConStat aggregate.\n\n4. A nearby PE event value 0x13 is not the missing ConStat reason mapping\n0xE071E1D0 constructs a separate structured PE-policy message containing 0x13 and sends it via 0xE071E0A0. Its caller/state context is adjacent to the Fpen_change path. It is not proven to be PINK supplyInksubTooEarly or ConStat INKSUB_REPLACED_EARLY. Numeric equality across these event/reason domains must not be treated as a conversion.\n\n5. CDM supply providers are separate resources\nThe code contains separate CdmSupplyPublicProvider, CdmSupplyPrivateProvider, CdmSupplyAssessmentProvider, and CdmSupplyAlertsProvider modules with distinct registration selectors and resource routes. They are plausible data/reporting paths for supply/account state, but the static paths examined do not directly establish a conversion to ConStat reason 0x13 or a call to 0xE03076C0. Registration selector values are not assumed to be PE nested event IDs.\n\n6. Remaining uncertainty / corrected next target\nThe PINK TooEarly bit setter is confirmed, but the live provider method it calls and the conversion from that state into ConStat reason 0x13 remain unresolved. A vtable-target/signature check is required before accepting the earlier assignment of slot +0x54 to a particular implementation: 0xE030B478 passes a scalar mask in r2, whereas one static candidate 0xE0308228 treats r2 as a pointer to a structure. The runtime vptr/service binding must be resolved. No printer interaction, firmware write, or physical print/scan attempt was performed.\n'''
(EV/'STEP23_FINDINGS.txt').write_text(findings)

# README and output manifest later.
print('Evidence files built:',sum(1 for p in EV.rglob('*') if p.is_file()))
print('DSID label offset:',hex(off),'VMA:',hex(addr))
