from pathlib import Path
import hashlib, subprocess, re, sys, zipfile
root=Path('/mnt/data/hp_part22_step23')
ev=root/'evidence'
checks=[]
def c(n,b,d=''):
 checks.append((n,bool(b),d))
elf=Path('/mnt/data/hp_resume/unpacked/part1_rtp_provider_trace/hp_lbi_sections.elf').read_bytes()
raw=Path('/mnt/data/hp_resume/unpacked/part1_rtp_provider_trace/srtext_rebuilt.bin').read_bytes()
rom=Path('/mnt/data/hp_resume/unpacked/part1_rtp_provider_trace/romfs_objs_rebuilt.bin').read_bytes()
c('source ELF present',len(elf)>1000000)
c('rebuilt .srtext exactly equals ELF section bytes',elf[0x54:0x54+0x743634]==raw)
needle=b'DSID_PE_TRAY2_OPEN_CLOSE_COUNTER\0'; off=rom.find(needle)
c('DSID string found at VMA 0xE0B372C0',off>=0 and 0xE09919C0+off==0xE0B372C0)
c('descriptor data at 0xE0B372E4 available',0xE0B372E4-0xE09919C0+0x90<=len(rom))
c('PINK flag crosswalk present',(ev/'pinksupply_selector_to_flag.csv').is_file())
c('reason helper audit present',(ev/'reason_insertion_candidate_audit.csv').is_file())
c('printhead failure callers present',(ev/'printhead_failure_report_callers.csv').is_file())
c('CDM resource registration map present',(ev/'cdm_supply_resource_registrations.csv').is_file())
for f,needle in [('pink_selector_mask_setter.dis','e030b478'),('candidate_reason_helper.dis','e030bb38'),('printhead_failure_report.dis','e071b0d0'),('not_enrolled_reason_caller.dis','e071f9d8'),('no_rtp_reason_caller.dis','e071f220')]:
 p=ev/'disassembly'/f; c('disassembly '+f,p.is_file() and needle in p.read_text(errors='ignore').lower())
find=(ev/'STEP23_FINDINGS.txt').read_text()
c('findings distinguish PINK and ConStat', 'separate representations' in find)
c('findings qualify printhead_failure provider', 'provider implementation' in find)
# DOCX package integrity and PDF validation
for f in root.glob('*.docx'):
 try:
  with zipfile.ZipFile(f) as z: good=z.testzip() is None
 except: good=False
 c('DOCX integrity',good)
for f in root.glob('*.pdf'):
 try:
  info=subprocess.run(['pdfinfo',str(f)],capture_output=True,text=True,check=True).stdout
  pages=int(re.search(r'^Pages:\s+(\d+)',info,re.M).group(1))
  size='612 x 792 pts' in info or '612 x 792 pts (letter)' in info
  c('PDF page count and size',pages>=5 and size,f'pages={pages}')
  c('PDF text extraction',bool(subprocess.run(['pdftotext',str(f),'-'],capture_output=True,text=True,check=True).stdout.strip()))
 except Exception as e: c('PDF inspect',False,str(e))
# Evidence ZIP integrity
for f in root.glob('*.zip'):
 try:
  with zipfile.ZipFile(f) as z: good=z.testzip() is None; count=len(z.namelist())
 except Exception as e: good=False; count=0
 c('evidence ZIP integrity',good,f'entries={count}')
# Contact sheet and rendered pages
c('PDF contact sheet exists',(root/'qa'/'pdf_contact_sheet.png').is_file())
lines=[f'Step 23 QA: {sum(x[1] for x in checks)}/{len(checks)} PASS; {sum(not x[1] for x in checks)} FAIL']
for n,b,d in checks: lines.append(('PASS' if b else 'FAIL')+'\t'+n+(('\t'+d) if d else ''))
(root/'qa'/'QA_SUMMARY.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
if any(not x[1] for x in checks): sys.exit(1)
