from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

src = Path('/mnt/data/hp_part22_step18/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision105_Part22_Step18_PE_Condition_Aggregator_and_Block_State_Trace_Addendum.docx')
out = Path('/mnt/data/hp_part22_step19/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision106_Part22_Step19_PE_Wait_For_CanPrint_Nonzero_Condition_Registration_Addendum.docx')
doc = Document(src)

# Minimal in-place corrections to Step 18 statements now disproved by the direct aggregate scan.
replacements = {
    'The method at 0xE0713E80 is an argument adapter to the common relay 0xE07126B8. It forwards the caller\'s event object from r1 as relay r0, evaluator object from r2 as relay r1, and condition token from r3 as relay r2. The allocator then stores those latter two values at record offsets +0x5B0 and +0x5B8, exactly the fields consumed by the aggregate evaluator.':
    'The method at 0xE0713E80 is an argument adapter to the common relay 0xE07126B8. It forwards the caller\'s event object from r1 as relay r0, caller context from r2 as relay r1, and condition token from r3 as relay r2. The allocator stores the context at record +0x5B0 and token at +0x5B8. The aggregate scan consumes +0x5B8 but does not read +0x5B0.',
    'This identifies the interface through which an external caller can provide an evaluator object and token to the aggregate. The known pe_events.sensor_error method (0xE0713858), print_quality_degraded method (0xE0713970), and aggregate emitter (0xE07123D8) pass zeros for these arguments. They do not themselves provide a nonzero evaluator/token pair. The caller of the virtual method 0xE0713E80 remains unresolved; this is now the precise upstream boundary to trace.':
    'This identifies the interface through which a component can register an event context and condition token. The pe_events.sensor_error method (0xE0713858), print_quality_degraded method (0xE0713970), and aggregate emitter (0xE07123D8) pass zero context/token values. Step 19 now identifies a nonzero-token caller: the pe_wait_for_canprint component method at 0xE07269F8 reaches this virtual interface through 0xE07268A8 and supplies token 1.',
    'Not established: which runtime caller supplied that slot’s evaluator object and token, or which source condition caused the aggregate to change.':
    'Not established: whether the pe_wait_for_canprint method-table entry executed on the user\'s printer, whether token 1 was active during the failed Print-Job, or which live source condition changed the aggregate.'
}
for p in doc.paragraphs:
    if p.text in replacements:
        p.text = replacements[p.text]
for p in doc.paragraphs:
    if 'Those methods route to condition-evaluator wrappers' in p.text:
        p.text = ('Function 0xE0712378 iterates indices 0 through 31. It skips records with a zero slot identifier or a zero +0x5B8 token. For a qualifying entry it obtains the provider object from siriusInstance +0x18 and calls its virtual methods at +0x54 and +0x58, passing the record\'s +0x5B8 token. The aggregate scan does not load +0x5B0; that field retains caller context and its further use is unresolved.')
# Move the short payload distinction into section 5's lead paragraph to prevent a single orphan line/page.
for p in list(doc.paragraphs):
    if p.text.startswith('The emitter at 0xE07123D8 constructs a nested PE event'):
        p.text = ('The emitter at 0xE07123D8 constructs a nested PE event and calls relay 0xE07126B8. Its nested type is selected from the aggregate. Payload +0x28 is set for active states; +0x2C distinguishes aggregate state 2.')
    elif p.text.startswith('For either active aggregate state, the emitter sets event +0x28'):
        p._element.getparent().remove(p._element)

# Correct the row that mislabeled +0x5B0 as the evaluator object used by the aggregate.
for table in doc.tables:
    for row in table.rows:
        if len(row.cells) >= 3 and row.cells[0].text.strip() == '+0x5B0':
            row.cells[1].text = 'Original caller r1 (retained context value)'
            row.cells[2].text = 'Not read by the aggregate scan; further use unresolved'
        if len(row.cells) >= 3 and row.cells[0].text.strip() == '+0x5B8':
            row.cells[1].text = 'Original caller r2 condition token'
            row.cells[2].text = 'Nonzero gate; passed to shared provider at siriusInstance +0x18'
        if len(row.cells) >= 3 and row.cells[0].text.strip() == 'r2: evaluator object':
            row.cells[0].text = 'r2: caller context'
            row.cells[1].text = 'r1'
            row.cells[2].text = 'Record +0x5B0; retained context, not read by aggregate scan'
        if len(row.cells) >= 3 and row.cells[0].text.strip() == 'r3: condition token':
            row.cells[0].text = 'r3: condition token'
            row.cells[1].text = 'r2'
            row.cells[2].text = 'Record +0x5B8; nonzero token queried by aggregate'

# Compact the old evidence index so the revised cumulative report does not split it across a mostly empty page.
if len(doc.tables) > 10:
    t = doc.tables[10]
    compact_rows = [
        ('disassembly/event_relay_0xE07126B8.dis', 'Relay, registry allocation, callback dispatch and cleanup.'),
        ('disassembly/sirius_instance_condition_api_method.dis', 'Virtual adapter forwards event object, caller context and token to relay.'),
        ('disassembly/aggregate_and_emit_0x8B_0x8C.dis', '32-slot scan, provider token query, transition detection and 0x8B/0x8C emitter.'),
        ('disassembly/smgr_pe_event_callback.dis', 'Outer 0x1347F validation and nested PE event dispatch.'),
        ('disassembly/pe_block_and_secondary_state_writers.dis', 'Primary DSID writer, internal PE state update, and ROMFS metadata crosswalks.'),
    ]
    while len(t.rows) > 1:
        t._tbl.remove(t.rows[-1]._tr)
    for left, right in compact_rows:
        cells = t.add_row().cells
        cells[0].text = left
        cells[1].text = right
        for cell in cells:
            for p0 in cell.paragraphs:
                p0.paragraph_format.space_after = Pt(0)
                for run in p0.runs:
                    run.font.size = Pt(8)
    for row in t.rows:
        row.height = None
        for cell in row.cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

# Remove the inherited hard page break immediately before section 6; after the corrected shorter text it created an otherwise blank page.
pars = doc.paragraphs
for i, p in enumerate(pars):
    if p.text.startswith('6. Condition-registration interface identified') and i > 0:
        prev = pars[i-1]
        if not prev.text and prev._p.xpath('.//w:br[@w:type="page"]'):
            prev._element.getparent().remove(prev._element)
        break

# Update the title/footers to show the corrected cumulative revision.
for p in doc.paragraphs:
    if 'Revision 105 Addendum' in p.text:
        p.text = p.text.replace('Revision 105 Addendum', 'Revision 106 Addendum')
    if p.text.strip() == 'PART 22  /  STEP 18':
        p.text = 'PART 22  /  STEPS 18-19'
for section in doc.sections:
    for p in section.footer.paragraphs:
        if p.text:
            for r in p.runs:
                r.text = r.text.replace('REVISION 105 ADDENDUM', 'REVISION 106 ADDENDUM').replace('PART 22 / STEP 18', 'PART 22 / STEPS 18-19')

# Helpers for consistent appendix styling.
def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)

def set_cell_text(cell, text, bold=False, color=None, size=9):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    r = p.add_run(str(text))
    r.bold = bold
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_heading(text, level=1):
    p = doc.add_paragraph(style=f'Heading {level}')
    p.paragraph_format.keep_with_next = True
    p.add_run(text)
    return p

def add_body(text, bold_prefix=None):
    p = doc.add_paragraph(style='Normal')
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.08
    if bold_prefix and text.startswith(bold_prefix):
        r = p.add_run(bold_prefix); r.bold = True
        p.add_run(text[len(bold_prefix):])
    else:
        p.add_run(text)
    return p

def add_table(headers, rows, widths=None, font_size=8.5):
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = 'Table Grid'
    t.autofit = False
    hdr = t.rows[0]
    trPr = hdr._tr.get_or_add_trPr()
    repeat = OxmlElement('w:tblHeader')
    repeat.set(qn('w:val'), 'true')
    trPr.append(repeat)
    for i, h in enumerate(headers):
        set_cell_text(hdr.cells[i], h, bold=True, color=(255,255,255), size=font_size)
        shade(hdr.cells[i], '174A6E')
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, value in enumerate(row):
            set_cell_text(cells[i], value, size=font_size)
            if ri % 2 == 0:
                shade(cells[i], 'EAF1F6')
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return t

def page_title(kicker, title, subtitle):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(kicker.upper())
    r.bold = True; r.font.size = Pt(9); r.font.color.rgb = RGBColor(24,107,153)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(title)
    r.bold = True; r.font.size = Pt(22); r.font.color.rgb = RGBColor(28,65,96)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(12)
    r = p.add_run(subtitle)
    r.font.size = Pt(9); r.font.color.rgb = RGBColor(95,110,125)

# Remove the inherited empty trailing paragraph after the prior evidence table; otherwise the next-page break can create a blank page.
while doc.paragraphs and not doc.paragraphs[-1].text.strip():
    trailing = doc.paragraphs[-1]
    trailing._element.getparent().remove(trailing._element)
# Appendix starts on a clean page using page-break-before (no extra paragraph to spill onto a blank page).
page_title('Part 22 / Step 19', 'The missing nonzero registration caller', 'Revision 106 correction and addendum | 19 November 2026')
doc.paragraphs[-3].paragraph_format.page_break_before = True
add_heading('Executive finding', 1)
add_body('The pe_wait_for_canprint component contains an indirect virtual call through siriusInstance that reaches the common PE event relay with a nonzero condition token. This is the first in-image nonzero-token registration caller identified in the current firmware trace. The earlier Step 18 audit searched direct calls to the relay and therefore missed this vtable path.')
add_body('The component method-table entry at ROMFS address 0xE0B39708 contains Thumb pointer 0xE07269F9 (code 0xE07269F8). That method branches to 0xE07268A8, which invokes siriusInstance vtable slot +0x08. The method pointer at vtable address 0xE0B34134 is 0xE0713E81 (code 0xE0713E80), an adapter into relay 0xE07126B8.')
add_heading('Corrected registry interpretation', 2)
add_table(['Registry field','Correct meaning','Aggregate scan use'], [
    ['+0x5B0','Original caller r1; in this registration, context value 0x2802','Not read by function 0xE0712378'],
    ['+0x5B8','Original caller r2; in this registration, condition token 1','Read; zero tokens are skipped and nonzero tokens are queried'],
    ['siriusInstance +0x18','Injected provider for service ID 0x0005742E','Virtual methods +0x54 / +0x58 evaluate token status'],
], [1.35, 2.65, 2.45], 8.3)
add_body('This corrects the Step 18 text that described +0x5B0 as an evaluator-object pointer consumed by the aggregate. The aggregate scan does not load +0x5B0. The actual provider object used in the scan is the dynamically injected object at siriusInstance +0x18.')
add_body('Important distinction: 0x2802 is the context value; the nonzero condition token is 1. They are separate arguments and are stored at different record offsets.')

# Page 7
doc.add_page_break()
page_title('Step 19 evidence', 'Exact virtual-call and relay argument path', 'Thumb disassembly and ROMFS vtable crosswalk')
add_heading('Call chain', 1)
add_table(['Stage','Address / value','Static evidence'], [
    ['Component method table','0xE0B39708 -> 0xE07269F9','pe_wait_for_canprint ROMFS record; Thumb entry resolves to 0xE07269F8'],
    ['Component method','0xE07269F8 -> 0xE07268A8','Unconditional branch to the condition-registration routine'],
    ['Virtual interface','0xE0B34134 -> 0xE0713E81','siriusInstance vtable slot +0x08; code at 0xE0713E80'],
    ['Adapter','0xE0713E80 -> 0xE07126B8','Forwards object/context/token into the shared relay'],
    ['Relay allocator','0xE0712280','Stores caller context at +0x5B0 and token at +0x5B8'],
    ['Aggregate scan','0xE0712378','Reads +0x5B8 and queries shared provider with that token'],
], [1.45, 1.65, 3.35], 8.2)
add_heading('Arguments supplied by pe_wait_for_canprint', 2)
add_table(['Argument','Value','Relay/registry effect'], [
    ['r1','0xC192F06C','Relay event/context object; payload context'],
    ['r2','0x00002802','Stored at record +0x5B0 as caller context'],
    ['r3','0x00000001','Stored at record +0x5B8 as nonzero condition token'],
    ['Stack argument 0','0xE0726851','Thumb callback pointer to code 0xE0726850'],
], [1.35, 1.5, 3.6], 8.4)
add_body('The first virtual call in 0xE07268A8 uses r1=0xC192F06C, r2=0x2802, r3=1, and places callback pointer 0xE0726851 in the first stack argument. It then calls the adjacent siriusInstance slot +0x0C with the same context object. No claim is made here that the component method was executed during the user\'s failed print attempt; its presence and behavior in the firmware are statically established.')

# Page 8
doc.add_page_break()
page_title('Step 19 evidence', 'Shared service ID 0x5742E', 'The component and aggregate use the same injected provider interface')
add_heading('Two service setters, one service ID', 1)
add_table(['Consumer object','Setter address','Service ID mapping','Stored provider field'], [
    ['siriusInstance','0xE07140D0','0x0005742E','+0x18'],
    ['pe_wait_for_canprint','0xE07269B0','0x0005742E','+0x10'],
], [1.6, 1.35, 1.55, 1.85], 8.4)
add_body('The aggregate at 0xE0712378 loads siriusInstance, then loads its +0x18 field and calls the provider vtable methods at +0x54 and +0x58 with the nonzero token from entry +0x5B8. The service setter at 0xE07140D0 maps ID 0x5742E to exactly that field.')
add_heading('pe_wait_for_canprint use of the same service', 2)
add_table(['Function','Provider use','Observed argument / effect'], [
    ['0xE0726768','loads component field +0x10; calls vtable +0x08','Subscribes with string "wait_for_canprint", r2=0, r3=0x3C, stack values 1 and 1; stores returned handle at 0xC192F064'],
    ['0xE0726798','loads component field +0x10; calls vtable +0x10','Uses 0xC192F064 handle for unregister'],
    ['0xE0726808','uses SiriusInstance and provider field +0x10','Calls further provider methods including +0x10 and +0x40 with the stored handle'],
], [1.05, 2.1, 3.2], 8.0)
add_body('This is a strong shared-interface connection: pe_wait_for_canprint subscribes to the named wait_for_canprint key through its own injected field +0x10 under service ID 0x5742E, while the PE aggregate queries tokens through siriusInstance +0x18, also bound under service ID 0x5742E. The matching service ID establishes the same service interface; static firmware does not prove the two fields contain the same runtime pointer. The provider implementation class and constructor remain unresolved.')

# Page 9
doc.add_page_break()
page_title('Step 19 results', 'What this does and does not prove', 'Newly narrowed print-admission condition path')
add_heading('Additional callback behavior', 1)
add_body('The callback supplied by pe_wait_for_canprint is code 0xE0726850. Its selector checks accept values 0x10, 0x1A, 0x87, and 0x90, and route into the wait/subscription state-management helpers. The string key wait_for_canprint and subscription event/type argument 0x3C are explicit. The product meaning of the callback selector values has not been established from a named enum crosswalk.')
add_heading('Established', 2)
for s in [
    'The pe_wait_for_canprint method table contains a path that registers a nonzero condition token (1) through siriusInstance.',
    'The call reaches relay 0xE07126B8 through vtable slot +0x08 -> 0xE0713E80.',
    'The relay stores context 0x2802 at +0x5B0 and token 1 at +0x5B8.',
    'The aggregate scan reads +0x5B8, not +0x5B0, and calls the provider at siriusInstance +0x18 through slots +0x54 / +0x58.',
    'Service ID 0x5742E populates siriusInstance +0x18 and pe_wait_for_canprint +0x10; pe_wait_for_canprint subscribes to wait_for_canprint through that provider.'
]:
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(3); p.add_run(s)
add_heading('Still unresolved', 2)
for s in [
    'Whether the pe_wait_for_canprint method-table entry executed on this printer and whether token 1 was active during the failed Print-Job.',
    'The concrete provider implementation/class behind service ID 0x5742E and the precise meaning of context value 0x2802.',
    'The semantic mapping of callback selector values 0x10, 0x1A, 0x87, and 0x90.',
    'A direct causal link to alert 66220, Instant Ink/account status, RTP block_print/unblock_print, or the WSCN scanner-status path.'
]:
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(3); p.add_run(s)
add_body('The next highest-value target is the concrete provider registered for service ID 0x5742E: identify its component record and implementation of the query methods at vtable +0x54 and +0x58, then determine how token 1 becomes active or inactive. Runtime memory inspection would be needed to identify which registry slot was live during the failed job; no such inspection was performed.')
add_heading('Evidence and safety scope', 2)
add_body('The evidence ZIP includes the source ELF, rebuilt .srtext and ROMFS images, focused Thumb disassembly, ROMFS crosswalk, argument/service map, verifier, and hashes. All analysis is static-only. No printer connection, print retry, scan attempt, or firmware modification was made.')

# Normalize font in new appendix content without overwriting existing styles.
for p in doc.paragraphs:
    if p.style.name == 'Normal':
        for r in p.runs:
            if r.font.name is None:
                r.font.name = 'Aptos'
            if r.font.size is None:
                r.font.size = Pt(9.5)

# Update core properties.
doc.core_properties.title = 'HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 106'
doc.core_properties.subject = 'Step 19 - PE wait_for_canprint nonzero condition registration'
doc.core_properties.comments = 'Revision 106 corrects Step 18 registry-field interpretation and adds the pe_wait_for_canprint nonzero-token caller trace.'
doc.save(out)
print(out)
