# Part 22 / Step 19 - `pe_wait_for_canprint` nonzero condition registration

## Golden finding
The `pe_wait_for_canprint` component has an indirect virtual registration call through `siriusInstance` that reaches the shared PE condition relay with a nonzero condition token (`1`). The call passes context value `0x2802`, event/context object `0xC192F06C`, and callback `0xE0726850`.

This closes a missing in-image caller path that was not found by the previous direct-call-only audit.

## Correction to Step 18
The aggregate scan at `0xE0712378` uses registry field `+0x5B8` (token) and does not load `+0x5B0`. Step 18's description of `+0x5B0` as an evaluator object pointer consumed by aggregate virtual wrappers is corrected. The +0x5B0 value is retained caller context; its further role is unresolved. The actual provider used for token evaluation is the injected object at `siriusInstance +0x18`.

## Shared provider link
Service ID `0x0005742E` maps to `siriusInstance +0x18` and to `pe_wait_for_canprint +0x10`. The latter uses the service's vtable +0x08 to subscribe to `wait_for_canprint` and vtable +0x10 to unregister. The aggregate checks nonzero tokens through the provider field at `siriusInstance +0x18`. The matching service ID establishes the same service interface, but static firmware does not prove that `pe_wait_for_canprint +0x10` and `siriusInstance +0x18` contain the same runtime pointer.

## Evidence contents
- `source/`: source ELF, rebuilt .srtext, rebuilt ROMFS objects, plus original Part 1 README and service record extract.
- `disassembly/`: exact Thumb disassembly for the PE Wait registration/subscription path, relay frontend, SiriusInstance vtable and service setters, registry/aggregate scan.
- `romfs/`: component/vtable address crosswalk and argument/service CSV.
- `STEP19_FINDINGS.txt`: complete concise finding and limitations.
- `verify_step19.py`: focused reproducibility verifier.
- `SHA256SUMS`: hashes for every package file, excluding the manifest itself.

Static-only scope. No device communication or runtime verification was performed.
