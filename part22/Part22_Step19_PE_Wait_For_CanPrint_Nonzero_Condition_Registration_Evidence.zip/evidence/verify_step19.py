from __future__ import annotations
import hashlib
import re
import struct
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'source'
DIS = ROOT / 'disassembly'
ROM = ROOT / 'romfs'
DOCX = ROOT / 'deliverables' / 'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision106_Part22_Step19_PE_Wait_For_CanPrint_Nonzero_Condition_Registration_Addendum.docx'
PDF = ROOT / 'deliverables' / 'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision106_Part22_Step19_PE_Wait_For_CanPrint_Nonzero_Condition_Registration_Addendum.pdf'

checks: list[tuple[str, bool, str]] = []
def check(name: str, condition: bool, detail: str='') -> None:
    checks.append((name, bool(condition), detail))

def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def readtxt(path: Path) -> str:
    return path.read_text(encoding='utf-8', errors='replace')

# Source identity checks (copied from the preserved Part 1 evidence archive).
expected_hashes = {
    'hp_lbi_sections.elf': '25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
    'romfs_objs_rebuilt.bin': '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
    'srtext_rebuilt.bin': '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
}
for name, expected in expected_hashes.items():
    p=SRC/name
    actual=sha256(p) if p.exists() else ''
    check(f'source hash: {name}', actual==expected, f'actual={actual}')

# ROMFS descriptor and vtable pointers.
romfs=(SRC/'romfs_objs_rebuilt.bin').read_bytes()
romfs_base=0xE09919C0
def u32_at_vma(addr: int) -> int:
    off=addr-romfs_base
    if off<0 or off+4>len(romfs): raise ValueError(hex(addr))
    return struct.unpack_from('<I',romfs,off)[0]
check('pe_wait method-table pointer', u32_at_vma(0xE0B39708)==0xE07269F9, hex(u32_at_vma(0xE0B39708)))
check('siriusInstance vtable slot +0x08', u32_at_vma(0xE0B34134)==0xE0713E81, hex(u32_at_vma(0xE0B34134)))
check('siriusInstance vtable slot +0x0C', u32_at_vma(0xE0B34138)==0xE0713EA1, hex(u32_at_vma(0xE0B34138)))
check('ROMFS component name', b'pe_wait_for_canprint\0' in romfs, 'pe_wait_for_canprint string present')
check('ROMFS dependency name', b'siriusInstance\0' in romfs, 'siriusInstance string present')

# Disassembly-based call and argument path checks.
pewait=readtxt(DIS/'pe_wait_for_canprint_registration_and_subscription.dis')
sirius=readtxt(DIS/'sirius_instance_vtable_and_service_binding.dis')
agg=readtxt(DIS/'condition_registry_and_aggregate_scan.dis')
relay=readtxt(DIS/'event_relay_frontend.dis')
setter=readtxt(DIS/'pe_wait_dependency_setter.dis')
check('component method branches to 0xE07268A8', 'e07269f8:' in setter.lower() and 'b.w\t0xe07268a8' in setter.lower())
check('registration event object C192F06C', 'movw\tr4, #0xf06c' in pewait.lower() or 'movw\tr1, #0xf06c' in pewait.lower() or '0xc192f06c' in pewait.lower(), 'register function uses C192F06C')
check('registration context 0x2802', '#0x2802' in pewait.lower(), 'literal context value')
check('registration token 1', 'movs\tr3, #0x1' in pewait.lower(), 'r3=1 at registration')
check('registration callback E0726851', '0xe0726851' in pewait.lower() or '#0x6851' in pewait.lower(), 'Thumb callback pointer')
check('PE Wait calls SiriusInstance vtable slot +0x08', 'ldr\tr5, [r1, #0x8]' in pewait.lower() or 'ldr\tr5, [r1, #0x8]' in pewait.lower(), 'virtual slot +0x08')
check('PE Wait service subscribe key', 'wait_for_canprint' in pewait.lower() or b'wait_for_canprint' in (SRC/'srtext_rebuilt.bin').read_bytes(), 'named provider key')
check('PE Wait provider event/type 0x3C', '#0x3c' in pewait.lower(), 'subscription event/type')
check('PE Wait stores returned handle at C192F064', '#0xf064' in pewait.lower() and 'str\tr0, [r4]' in pewait.lower(), 'provider subscription handle')
check('PE Wait unregister uses provider vtable slot +0x10', 'ldr\tr2, [r1, #0x10]' in pewait.lower(), 'unsubscribe slot +0x10')
check('siriusInstance adapter forwards to shared relay', 'bl\t0xe07126b8' in sirius.lower(), 'adapter call target')
check('relay calls registry allocator', 'bl\t0xe0712280' in relay.lower(), 'allocator call')
check('allocator stores caller context at +0x5B0', '#0x5b0' in agg.lower() and 'str.w\tr10, [r6, #0x5b0]' in agg.lower(), 'caller r1 retained at +0x5B0')
check('allocator stores token at +0x5B8', 'str.w\tr1, [r0, #0x5b8]' in agg.lower() or 'str.w\tr9' in agg.lower() and '#0x5b8' in agg.lower(), 'token stored at +0x5B8')
# Isolate aggregate scan function block and verify it loads +5B8 but not +5B0.
match=re.search(r'e0712378:.*?e07123d0:', agg, re.S|re.I)
block=match.group(0).lower() if match else ''
check('aggregate reads +0x5B8', '#0x5b8' in block and 'ldr.w\tr1, [r6, #0x5b8]' in block)
check('aggregate does not read +0x5B0', '#0x5b0' not in block, 'corrected Step 18 interpretation')
check('aggregate obtains provider at siriusInstance +0x18', 'ldr\tr0, [r0, #0x18]' in block)
check('aggregate queries provider slots +0x54 and +0x58', '[r2, #0x54]' in block and '[r2, #0x58]' in block)

# Both setters bind service ID 0x5742E to the documented object offsets.
check('SiriusInstance service 0x5742E -> +0x18', 'movw\tr2, #0x742e' in sirius.lower() and 'movt\tr2, #0x5' in sirius.lower() and 'str\tr3, [r0, #0x18]' in sirius.lower())
check('PE Wait service 0x5742E -> +0x10', 'movw\tr2, #0x742e' in setter.lower() and 'movt\tr2, #0x5' in setter.lower() and 'str\tr3, [r0, #0x10]' in setter.lower())

# Human-readable crosswalk / report / deliverable checks.
findings=readtxt(ROOT/'STEP19_FINDINGS.txt')
readme=readtxt(ROOT/'README_STEP19.md')
check('findings distinguish context 0x2802 from token 1', 'context identifier   = 0x00002802' in findings and 'condition token      = 0x00000001' in findings)
check('findings state runtime condition remains unresolved', 'prove that token 1 was active' in findings and 'runtime memory' in findings.lower())
check('findings qualify runtime pointer equality', 'pointer equality is not established' in findings and 'same runtime pointer or separate instances' in findings)
check('report file exists', DOCX.exists() and DOCX.stat().st_size > 25000)
check('PDF exists', PDF.exists() and PDF.stat().st_size > 20000)

try:
    import fitz
    pdf=fitz.open(PDF)
    check('PDF page count is 9', len(pdf)==9, f'pages={len(pdf)}')
except Exception as e:
    check('PDF page count is 9', False, str(e))

print(f'Step 19 focused verification: {sum(1 for _,ok,_ in checks if ok)}/{len(checks)} PASS')
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
failed=[c for c in checks if not c[1]]
if failed:
    sys.exit(1)
