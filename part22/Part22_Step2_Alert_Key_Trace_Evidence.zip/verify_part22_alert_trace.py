#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: python verify_part22_alert_trace.py hp_lbi_sections.elf srtext_rebuilt.bin romfs_objs_rebuilt.bin")
e, s, r = (Path(x).read_bytes() for x in sys.argv[1:])
checks = [
    ("ELF .srtext == extracted srtext", e[0x54:0x54+0x743634] == s),
    ("ELF .romfs_objs == extracted romfs", e[0x743688:0x743688+0x440d0c] == r),
    ("alert literal in .srtext at 0x30488", s.find(b"subscribedPagesOutAccountProblem\0") == 0x30488),
    ("Category__ label in ROMFS at 0x29c62c", r.find(b"Category__subscribedPagesOutAccountProblem\0") == 0x29c62c),
    ("second alert string in ROMFS at 0x29c636", r.find(b"subscribedPagesOutAccountProblem\0") == 0x29c636),
]
needle = bytes.fromhex("000102ac")
hits=[]; start=0
while True:
    start=r.find(needle,start)
    if start<0: break
    hits.append(start); start+=1
checks.append(("only unaligned BE sliding-window hit for 0x102AC at 0x31639", hits == [0x31639] and hits[0] % 4 == 1))
checks.append(("no aligned BE 0x102AC in ROMFS", not any(x % 4 == 0 for x in hits)))
checks.append(("no BE/LE 0x102AC literal in .srtext", bytes.fromhex("000102ac") not in s and bytes.fromhex("ac020100") not in s))
for name, ok in checks: print(("PASS" if ok else "FAIL"), name)
print("SHA256 ELF", hashlib.sha256(e).hexdigest())
print("SHA256 .srtext", hashlib.sha256(s).hexdigest())
print("SHA256 .romfs_objs", hashlib.sha256(r).hexdigest())
if not all(ok for _,ok in checks): raise SystemExit(1)
