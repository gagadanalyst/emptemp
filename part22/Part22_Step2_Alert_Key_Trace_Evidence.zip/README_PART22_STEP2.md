# Part 22, Step 2 — static subscription alert-key trace

## Scope
Offline static analysis of the package-verified 2629A LBI sections only. No printer request, firmware write/flash, reset, debug activation, or device modification.

## Main result
The exact string `subscribedPagesOutAccountProblem` occurs in `.srtext` at VMA `0xE02764F8` and in `.romfs_objs` at VMA `0xE0C2DFF6`. `.romfs_objs` also contains `Category__subscribedPagesOutAccountProblem` at VMA `0xE0C2DFEC`. The `.srtext` disassembly has two direct `ADR.W` references to the exact alert-key string at `0xE02759E8` and `0xE0276192`. Each site appends the string pointer to a vector-like field and then appends a 32-bit scalar to a second vector-like field. The scalar values are `0x102BB` (66235) and `0x1027F` (66175), not the runtime CDM alert number 66220. The scalar namespace is not identified.

## Important correction
A raw big-endian search initially appeared to find `0x000102AC` (66220) at ROMFS offset `0x31639`. This is a false positive: the byte window starts one byte into an eight-byte record at `0x31638` (`E7 00 01 02 AC E5 1E C0`). It is not a four-byte-aligned numeric field. No aligned 0x102AC value was found in `.romfs_objs`, nor exact 32-bit 0x102AC literal in `.srtext`.

## Source labels
The section has source-file literals for `CdmAlertsAlertProvider.cpp`, `CdmRtpAlertProvider.cpp`, and `subscriptionManager.cpp`. Their observed ADR references pass file names and source line numbers to diagnostic helpers. They are provenance/logging references, not proof that the alert path calls the print-block API.

## What is not established
No direct data/control-flow edge is established from this alert-key registration to `rtp_manager.block_print` / `unblock_print`, `DSID_PRINT_ENGINE_BLOCKED` (`0x12196`), or IPP selector `0xDE`. The runtime CDM ID 66220 is not mapped to the two scalar values above. The actual alert-producing logic and downstream enforcement path remain unresolved.

## Integrity / reproducibility
The section files used are preserved separately in the Library and are not duplicated in this ZIP. `verify_part22_alert_trace.py` checks section equality, literal locations, and the numeric false-positive audit. Run it with paths to `hp_lbi_sections.elf`, `srtext_rebuilt.bin`, and `romfs_objs_rebuilt.bin`. Full input SHA-256 values are in `SHA256SUMS`.

## Next gate
Step 2 is complete. Proposed Step 3, not started: static data/control-flow tracing of the source-labelled `CdmRtpAlertProvider` and `subscriptionManager` routines and their connection (if any) to PE/RTP/IPP print admission. Wait for user approval before continuing.
