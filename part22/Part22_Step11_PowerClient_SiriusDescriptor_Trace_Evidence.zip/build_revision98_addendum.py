from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from pathlib import Path

OUT=Path('/mnt/data/hp_part22_step11/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision98_Part22_Step11_PowerClient_SiriusDescriptor_Addendum.docx')

doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(0.62)
sec.bottom_margin=Inches(0.62)
sec.left_margin=Inches(0.68)
sec.right_margin=Inches(0.68)
sec.header_distance=Inches(0.28)
sec.footer_distance=Inches(0.28)

# Palette
NAVY='17365D'; BLUE='1F4E79'; CYAN='00A6C7'; LIGHT='D9EAF7'; PALE='EEF5FA'; GRAY='595959'; MID='7F8C8D'; WHITE='FFFFFF'; WARN='FFF2CC'; GREEN='E2F0D9'

# Base styles
styles=doc.styles
normal=styles['Normal']
normal.font.name='Aptos'
normal.font.size=Pt(9)
normal.font.color.rgb=RGBColor(38,38,38)
normal.paragraph_format.space_after=Pt(4)
normal.paragraph_format.line_spacing=1.08
for nm,size,col in [('Title',25,NAVY),('Heading 1',17,NAVY),('Heading 2',12,BLUE),('Heading 3',10,CYAN)]:
    st=styles[nm]
    st.font.name='Aptos Display' if nm in ('Title','Heading 1') else 'Aptos'
    st.font.size=Pt(size)
    st.font.bold=True
    st.font.color.rgb=RGBColor.from_string(col)
    st.paragraph_format.space_before=Pt(7 if nm!='Title' else 0)
    st.paragraph_format.space_after=Pt(4)
    st.paragraph_format.keep_with_next=True

# Header/footer
header=sec.header.paragraphs[0]
header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=header.add_run('HP DESKJET 2855e  |  INDEPENDENT PRINTING / SCANNING INVESTIGATION')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(MID)
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('Revision 98 - Part 22, Step 11 addendum  |  19 November 2026  |  Page ')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.color.rgb=RGBColor.from_string(MID)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

# Helpers
def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr()
    shd=tcPr.find(qn('w:shd'))
    if shd is None:
        shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def set_cell_text(cell, text, bold=False, color=None, size=8.4):
    cell.text=''
    p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0)
    p.paragraph_format.space_before=Pt(0)
    p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text))
    r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers, rows, widths=None, font=8.2):
    t=doc.add_table(rows=1, cols=len(headers))
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    t.autofit=False
    t.style='Table Grid'
    for i,h in enumerate(headers):
        set_cell_text(t.rows[0].cells[i],h,True,WHITE,font)
        shade(t.rows[0].cells[i],BLUE)
    for ridx,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            set_cell_text(cells[i],val,False,None,font)
            if ridx%2==1: shade(cells[i],PALE)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t

def para(text='', boldlead=None, style=None, color=None, italic=False, size=None):
    p=doc.add_paragraph(style=style)
    if boldlead and text.startswith(boldlead):
        a=p.add_run(boldlead); a.bold=True
        b=p.add_run(text[len(boldlead):])
        runs=[a,b]
    else:
        runs=[p.add_run(text)]
    for r in runs:
        if color: r.font.color.rgb=RGBColor.from_string(color)
        if italic: r.italic=True
        if size: r.font.size=Pt(size)
    return p

def bullet(text, level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    p.paragraph_format.space_after=Pt(2)
    p.add_run(text)
    return p

def callout(title, body, fill=LIGHT):
    t=doc.add_table(rows=1, cols=1)
    t.autofit=False
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0); shade(c,fill)
    c.text=''
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(2)
    rr=p.add_run(title); rr.bold=True; rr.font.color.rgb=RGBColor.from_string(NAVY); rr.font.size=Pt(10)
    p2=c.add_paragraph(body); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.05
    for rr in p2.runs: rr.font.size=Pt(8.7)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

# PAGE 1
p=doc.add_paragraph()
p.paragraph_format.space_before=Pt(36); p.paragraph_format.space_after=Pt(6)
r=p.add_run('PART 22  /  STEP 11'); r.bold=True; r.font.size=Pt(11); r.font.color.rgb=RGBColor.from_string(CYAN)
p=doc.add_paragraph(style='Title')
p.add_run('Power-client bit map and\nSirius descriptor trace')
p=doc.add_paragraph()
p.paragraph_format.space_before=Pt(5); p.paragraph_format.space_after=Pt(14)
r=p.add_run('Revision 98 addendum to Revision 97  |  Static firmware analysis  |  19 November 2026')
r.font.size=Pt(10); r.font.color.rgb=RGBColor.from_string(GRAY)

callout('Principal correction to Step 10',
        'The recovered firmware has 24 POWER_CLIENT strings, but POWER_CLIENT_NONE is a sentinel, leaving 23 active client bits. POWER_CLIENT_PE_POLICY maps to bit 22 (0x00400000), not 0x00800000. SCAN maps to 0x00000200 and PEN maps to 0x00000008.',WARN)

para('Step 11 followed the two leads from Step 10: the actual client-bit sources feeding the shared power acquire/release helpers, and the framework-facing consumer path for the siriusInstance descriptor accessor.')

para('What is established',style='Heading 2')
bullet('The native report and bulk-clear routines independently confirm the same 23-bit client mapping. They include PE_POLICY and would report or release it if bit 22 were active.')
bullet('A full direct branch/call audit found 14 acquire-helper and 12 release-helper references. No resolved direct acquire call site supplies 0x00400000 as a fixed immediate.')
bullet('The rtpadapter ROMFS record contains adjacent rtpadapter and siriusInstance labels, the siriusInstance accessor pointer, and the lib_power interface/client table in one 0xDC8-byte object.')
bullet('The descriptor accessor returns the address of field +4 in a global descriptor. Its runtime invoker and the concrete provider bound under siriusInstance remain unknown.')

para('Interpretation',style='Heading 2')
para('The power subsystem demonstrably supports PE_POLICY as a named client, but this step does not show that the print engine requests that client bit, that the bit is active, or that power policy triggers the RTP/PE print-block state. The Sirius descriptor is more than an isolated string, but its runtime resolution is not yet proven.')

callout('Document boundary',
        'This is a standalone Step 11 addendum intended to accompany Revision 97. The Revision 97 DOCX itself was not present in the active workspace, so its 194-page cumulative body could not be merged or re-rendered here. This addendum does not replace Revision 97.',PALE)

# PAGE 2: client map
doc.add_page_break()
doc.add_paragraph('1. Corrected POWER_CLIENT mapping',style='Heading 1')
para('The client-name table begins at ROMFS VMA 0xE0BC098C. Each slot occupies 0x1E (30) bytes. The native report routine at 0xE093E480 begins with client slot 1 and bit mask 1, then advances the name slot and shifts the mask. The bulk-clear routine at 0xE093E4F8 independently computes 1 << (slot - 1). Both loops terminate before slot 24.')
rows=[]
for i,n in enumerate(['POWER_CLIENT_NONE','POWER_CLIENT_MECH','POWER_CLIENT_AASIC1','POWER_CLIENT_AASIC2','POWER_CLIENT_PEN','POWER_CLIENT_UDW','POWER_CLIENT_REPORTS','POWER_CLIENT_UIAUX_SVC','POWER_CLIENT_PHOTO','POWER_CLIENT_OPT_SENSOR','POWER_CLIENT_SCAN','POWER_CLIENT_SYS','POWER_CLIENT_BOARD','POWER_CLIENT_ISC','POWER_CLIENT_USBHC','POWER_CLIENT_SERVO','POWER_CLIENT_SHAID','POWER_CLIENT_IMAGE_MGR','POWER_CLIENT_FP','POWER_CLIENT_EC','POWER_CLIENT_U232','POWER_CLIENT_WID_SENSOR','POWER_CLIENT_RDD','POWER_CLIENT_PE_POLICY']):
    if i==0: rows.append((str(i),'sentinel','-','POWER_CLIENT_NONE'))
    else: rows.append((str(i),str(i-1),f'0x{1<<(i-1):08X}',n))
table(['Slot','Bit index','Mask','Name'],rows,[0.55,0.8,1.25,4.0],7.6)

callout('Why the old mask was wrong',
        'Step 10 counted the NONE sentinel as an active client. The code does not: the first mask bit corresponds to MECH at slot 1. PE_POLICY is slot 23, so its bit index is 22 and its mask is 0x00400000. The 0x00800000 value would be bit 23, outside this recovered 23-client map.',WARN)

para('Selected corrected identities',style='Heading 2')
table(['Client','Correct mask','Step 10 value','Correction'],[
    ('PEN','0x00000008','0x00000010','One bit lower'),
    ('UDW','0x00000010','Previously called PEN','Separate client'),
    ('SCAN','0x00000200','0x00000400','One bit lower'),
    ('SYS','0x00000400','Previously called SCAN','Separate client'),
    ('PE_POLICY','0x00400000','0x00800000','One bit lower'),
],[1.4,1.4,1.75,2.05],8.0)

# PAGE 3: shared power methods
doc.add_page_break()
doc.add_paragraph('2. Shared acquire/release path and caller audit',style='Heading 1')
para('The power API uses the first argument as a resource index and the second argument as a client-bit mask. The acquire entry at 0xE093DC50 forwards to 0xE093DF60, which merges the requested mask into the per-resource client state. The release entry at 0xE093DC68 forwards to 0xE093E028, which removes the requested bits and handles associated reference/resource transitions.')
table(['Address','Observed mask input','Decoded client / path'],[
    ('0xE0561B64','Dynamic input; resource 0x32','Input value forwarded as mask'),
    ('0xE058C654','0x00000100','OPT_SENSOR'),
    ('0xE058C6AA','0x00000400','SYS'),
    ('0xE058C8BC','0x00000400','SYS'),
    ('0xE058CB22','0x00000400','SYS'),
    ('0xE0671B46','0x00000200','SCAN'),
    ('0xE071447C','0x00000010','UDW'),
    ('0xE073C4D8','Wrapper argument','All eight observed callers pass 0x8 = PEN'),
    ('0xE0741712','0x00000008','PEN'),
    ('0xE0928584','0x00000001','MECH'),
    ('0xE093DF2E','0x00000800','BOARD'),
    ('0xE093E2A4','Dynamic r2 forwarded as mask','lib_power acquire method'),
    ('0xE093E354','0x00000800','BOARD'),
    ('0xE093E3F4','0x00000010','UDW'),
],[1.15,1.6,3.8],7.5)

para('Direct xref counts from the complete retained .srtext disassembly',style='Heading 2')
table(['Helper','Direct refs','Function'],[
    ('0xE093DC50','14','Acquire/add client mask'),
    ('0xE093DC68','12','Release/remove client mask'),
],[1.25,1.0,4.3],8.3)

para('The eight direct callers of the 0xE073C4C8 acquire wrapper all load r1 = 0x8 before the call; its release sibling is used with the same mask. Under the corrected table, these are PEN requests. The previous interpretation of 0x10 as PEN was incorrect; 0x10 is UDW.')

# PAGE 4: PE policy
doc.add_page_break()
doc.add_paragraph('3. What the code proves about PE_POLICY',style='Heading 1')
para('The client-mask array is at 0xC1D624F4 and covers 403 resource entries. The complete direct address-reference audit identified five code sites touching that array:')
table(['Address','Observed role'],[
    ('0xE093DD0E','Initializes/zeros the 403-entry client-mask array'),
    ('0xE093DF86','Acquire path: reads and updates the selected resource mask'),
    ('0xE093E04A','Release path: reads and clears the selected resource mask'),
    ('0xE093E484','Active-client reporting reads the mask and renders names'),
    ('0xE093E4FC','Bulk clear enumerates set bits and releases each client'),
],[1.35,5.0],8.1)

para('The report loop at 0xE093E480 tests one bit at a time and maps bit 22 to the string POWER_CLIENT_PE_POLICY at 0xE0BC0C3E. The clear loop at 0xE093E4F8 computes 1 << 22 for slot 23 and calls the ordinary release helper if that bit is set. Therefore PE_POLICY is a real member of the generic client-state model, not just an unused diagnostic string.')

callout('Important distinction',
        'A generic report/clear implementation that understands PE_POLICY does not prove that any component sets that bit. The resolved direct acquire calls use fixed masks for MECH, PEN, UDW, OPT_SENSOR, SCAN, SYS or BOARD. No direct call site supplies 0x00400000 as a fixed immediate.',GREEN)

para('Two dynamic paths remain open',style='Heading 2')
bullet('The public lib_power acquire method at 0xE093E2A0 is stored as Thumb pointer 0xE093E2A1 at 0xE0BC05F4. It forwards the caller-provided second method argument (r2) as the client mask. The method has no direct static caller in the retained code.')
bullet('The wrapper at 0xE0561B60 forwards its input value as a client mask for resource 0x32. No direct call site or ROMFS function-pointer reference to that wrapper was found in the retained images.')

para('A separate 0x00400000 immediate occurs in filesystem request setup around 0xE0837982, but the surrounding code builds requests for filesystem paths such as /system, /tmp, /shm, /copy, /photo, /ishare, /uithm and /reprint. It does not call the power helper and is not evidence of a PE_POLICY request.')

# PAGE 5: sirius descriptor
doc.add_page_break()
doc.add_paragraph('4. Sirius descriptor and rtpadapter relationship',style='Heading 1')
para('The full ROMFS record begins at 0xE0BC0084 and its first word declares size 0xDC8. The same record contains both the adapter/dependency labels and the power API metadata:')
table(['VMA','Observed content','Significance'],[
    ('0xE0BC0100','rtpadapter','Adapter label in the record'),
    ('0xE0BC010C','siriusInstance','Adjacent Sirius-named label'),
    ('0xE0BC0534','Thumb pointer 0xE093E291','Accessor method pointer'),
    ('0xE0BC05E0','lib_power','Power API label'),
    ('0xE0BC05F4','Thumb pointer 0xE093E2A1','Acquire method entry'),
    ('0xE0BC05F8','Thumb pointer 0xE093E2A9','Release method entry'),
    ('0xE0BC0654','siriusInstance','Descriptor key string'),
    ('0xE0BC098C','POWER_CLIENT_NONE','Beginning of the client-name table'),
],[1.25,2.3,2.8],7.8)

para('The initializer pointer block at VMA 0xE0DD26B0 contains 0xE093E311, the Thumb entry for initializer 0xE093E310. The initializer calls builder 0xE093E250 with global 0xC1D62B4C and the string at 0xE0BC0654. The builder stores three fields:')
table(['Global field','Stored value','Interpretation'],[
    ('0xC1D62B4C','0xE0BC05EC','First descriptor pointer/field'),
    ('0xC1D62B50','0xE0BC0630','Second descriptor pointer/field'),
    ('0xC1D62B54','0xE0BC0654','Pointer to "siriusInstance"'),
],[1.55,1.5,3.3],8.0)

para('Accessor 0xE093E290 loads the global address 0xC1D62B4C and returns its address plus four, i.e. 0xC1D62B50. It returns the address of the second field, not the contents at that field. The Thumb pointer 0xE093E291 appears once in ROMFS, at 0xE0BC0534; no direct BL/B.W caller was found in .srtext.')

callout('What this strengthens - and what it does not',
        'The siriusInstance key is now tied to a constructed descriptor and an accessor pointer embedded in the same rtpadapter record that contains lib_power. This is strong evidence of a framework-facing dependency/descriptor relationship. It does not identify the resolver, prove that the descriptor is invoked, or equate it with the separate live object previously observed at 0xC190662C.',PALE)

# PAGE 6: conclusion and provenance
doc.add_page_break()
doc.add_paragraph('5. Step 11 conclusions and next target',style='Heading 1')
para('Confirmed',style='Heading 2')
bullet('The correct PE_POLICY client mask in this firmware is 0x00400000 (bit 22).')
bullet('The 403-entry client-state array is initialized, modified by shared acquire/release helpers, reported by name and bulk-cleared through five identified code sites.')
bullet('The `rtpadapter` record contains the `siriusInstance` descriptor/accessor and `lib_power` method metadata in one ROMFS object.')
para('Not confirmed',style='Heading 2')
bullet('No resolved direct caller requests PE_POLICY with mask 0x00400000. Dynamic method inputs remain unresolved.')
bullet('No evidence that the PE_POLICY client bit is active at runtime or that it causes `rtp_manager.block_print`, `DSID_PRINT_ENGINE_BLOCKED`, or the IPP restriction observed during testing.')
bullet('No proof that the runtime object resolved under `siriusInstance` is the same as the previously identified singleton at 0xC190662C.')

para('Proposed Step 12',style='Heading 2')
para('Trace the generic component/dependency dispatcher that consumes the rtpadapter ROMFS record and invokes the accessor at 0xE0BC0534. In parallel, identify the runtime caller of the lib_power acquire method at 0xE0BC05F4 / 0xE093E2A1 and determine whether any PE-specific path supplies 0x00400000. This is the narrowest remaining static route to connect PE_POLICY to actual print-engine behavior.')

para('Evidence provenance',style='Heading 2')
para('Source firmware artifacts were recovered from the previously saved Library package “Part 1 RTP Provider Trace Evidence Package”. The original ELF SHA-256 is 25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7; the reconstructed .srtext SHA-256 is 10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7; the reconstructed ROMFS SHA-256 is 227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3. Exact sizes and the secure payload hash are in SOURCE_INPUTS.txt in the accompanying evidence ZIP.')
para('Verification: 51/51 reproducible static checks passed, including source hashes, ELF section equality, the complete 0xDC8 ROMFS record, all 24 client-name slots, helper xrefs, five client-mask table references, descriptor pointer counts, and initializer/accessor dataflow.')
para('Operational boundary: no printer access, network request, updater execution, firmware write, debug activation or runtime state change was performed in Step 11.',italic=True,color=GRAY,size=8.2)

# Metadata
doc.core_properties.title='HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 98 Step 11 Addendum'
doc.core_properties.subject='Power client bit mapping and Sirius descriptor trace'
doc.core_properties.author='OpenAI'
doc.core_properties.keywords='HP DeskJet 2855e, firmware, POWER_CLIENT_PE_POLICY, rtpadapter, siriusInstance'
doc.save(OUT)
print(OUT)
