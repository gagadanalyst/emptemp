#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, re, struct, subprocess, sys

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description='Verify Part 22 Step 11 against preserved Part 1 firmware inputs.')
parser.add_argument('--source-dir', type=Path, default=Path('/mnt/data/hp_step11_work/base/part1_rtp_provider_trace'), help='Directory containing hp_lbi_sections.elf, srtext_rebuilt.bin, romfs_objs_rebuilt.bin and fhx_secure_payload_rebuilt.bin (extract the Library Part 1 evidence ZIP first).')
parser.add_argument('--disasm', type=Path, default=None, help='Optional full .srtext disassembly text. If omitted, llvm-objdump is run against hp_lbi_sections.elf.')
args = parser.parse_args()
SRC = args.source_dir
ELF = SRC / 'hp_lbi_sections.elf'
SRTEXT = SRC / 'srtext_rebuilt.bin'
ROMFS = SRC / 'romfs_objs_rebuilt.bin'
checks = []

def check(label, ok):
    checks.append((label, bool(ok)))
    print(('PASS' if ok else 'FAIL') + '  ' + label)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

expected_hashes = {
 'hp_lbi_sections.elf':'25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
 'srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
 'romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
 'fhx_secure_payload_rebuilt.bin':'aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858',
}
for name,h in expected_hashes.items():
    p=SRC/name
    check(f'{name} SHA-256 matches preserved Part 1 evidence', p.exists() and sha(p)==h)

elf=ELF.read_bytes(); sr=SRTEXT.read_bytes(); rom=ROMFS.read_bytes()
check('srtext size equals 0x743634', len(sr)==0x743634)
check('romfs_objs size equals 0x440D0C', len(rom)==0x440D0C)
check('ELF embedded .srtext equals rebuilt image', elf[0x54:0x54+len(sr)]==sr)
check('ELF embedded .romfs_objs equals rebuilt image', elf[0x743688:0x743688+len(rom)]==rom)

# VMA and object bounds.
ROM_VMA=0xE09919C0
OBJ_VMA=0xE0BC0084
OBJ_OFF=OBJ_VMA-ROM_VMA
OBJ_LEN=0xDC8
obj=rom[OBJ_OFF:OBJ_OFF+OBJ_LEN]
check('rtpadapter object header declares 0xDC8 bytes', struct.unpack_from('<I',rom,OBJ_OFF)[0]==OBJ_LEN)
check('rtpadapter object remains within ROMFS section', len(obj)==OBJ_LEN)

def cstr(vma):
    off=vma-ROM_VMA
    end=rom.find(b'\0',off)
    return rom[off:end].decode('ascii','replace')

for addr,s in [(0xE0BC0100,'rtpadapter'),(0xE0BC010C,'siriusInstance'),(0xE0BC05E0,'lib_power'),(0xE0BC0654,'siriusInstance'),(0xE0BC098C,'POWER_CLIENT_NONE'),(0xE0BC0AB8,'POWER_CLIENT_SCAN'),(0xE0BC0C3E,'POWER_CLIENT_PE_POLICY')]:
    check(f'ROMFS string {s} at 0x{addr:08X}', cstr(addr)==s)

# 24 string slots, 0x1E-byte stride; first is sentinel.
expected_names=['POWER_CLIENT_NONE','POWER_CLIENT_MECH','POWER_CLIENT_AASIC1','POWER_CLIENT_AASIC2','POWER_CLIENT_PEN','POWER_CLIENT_UDW','POWER_CLIENT_REPORTS','POWER_CLIENT_UIAUX_SVC','POWER_CLIENT_PHOTO','POWER_CLIENT_OPT_SENSOR','POWER_CLIENT_SCAN','POWER_CLIENT_SYS','POWER_CLIENT_BOARD','POWER_CLIENT_ISC','POWER_CLIENT_USBHC','POWER_CLIENT_SERVO','POWER_CLIENT_SHAID','POWER_CLIENT_IMAGE_MGR','POWER_CLIENT_FP','POWER_CLIENT_EC','POWER_CLIENT_U232','POWER_CLIENT_WID_SENSOR','POWER_CLIENT_RDD','POWER_CLIENT_PE_POLICY']
name_base=0xE0BC098C
parsed=[]
for i in range(24):
    off=name_base-ROM_VMA+i*0x1E
    parsed.append(rom[off:off+0x1E].split(b'\0',1)[0].decode())
check('24 client-name slots decode in expected order', parsed==expected_names)
check('slot 0 is the NONE sentinel', parsed[0]=='POWER_CLIENT_NONE')
check('slot 1 MECH maps to mask 0x00000001', 1<<(1-1)==0x1)
check('slot 4 PEN maps to mask 0x00000008', 1<<(4-1)==0x8)
check('slot 5 UDW maps to mask 0x00000010', 1<<(5-1)==0x10)
check('slot 10 SCAN maps to mask 0x00000200', 1<<(10-1)==0x200)
check('slot 11 SYS maps to mask 0x00000400', 1<<(11-1)==0x400)
check('slot 12 BOARD maps to mask 0x00000800', 1<<(12-1)==0x800)
check('slot 23 PE_POLICY maps to mask 0x00400000', 1<<(23-1)==0x400000)
check('slot 23 PE_POLICY does not map to 0x00800000', 1<<(23-1)!=0x800000)

# Relevant function-pointer entries in the object.
def word(vma): return struct.unpack_from('<I',rom,vma-ROM_VMA)[0]
check('descriptor accessor Thumb pointer at 0xE0BC0534', word(0xE0BC0534)==0xE093E291)
check('lib_power acquire Thumb pointer at 0xE0BC05F4', word(0xE0BC05F4)==0xE093E2A1)
check('lib_power release Thumb pointer at 0xE0BC05F8', word(0xE0BC05F8)==0xE093E2A9)
check('lib_power API names include control/get_active_clients/clear_clients', all(x in obj for x in [b'lib_pwr.control\0',b'lib_pwr.get_active_clients\0',b'lib_pwr.clear_clients\0']))

# Pointer multiplicities in full ROMFS.
def count_word(v): return len(re.findall(re.escape(struct.pack('<I',v)),rom))
check('e093e291 accessor pointer occurs once in ROMFS', count_word(0xE093E291)==1)
check('e093e279 alternative accessor pointer absent from ROMFS', count_word(0xE093E279)==0)
check('e093e311 initializer pointer occurs once in ROMFS', count_word(0xE093E311)==1)
check('initializer pointer is at VMA 0xE0DD26B0', word(0xE0DD26B0)==0xE093E311)

# Full .srtext disassembly xrefs.
if args.disasm:
    dis=args.disasm.read_text()
else:
    proc=subprocess.run(['llvm-objdump','-D','--triple=thumbv7em-none-eabi','--section=.srtext',str(ELF)],capture_output=True,text=True)
    if proc.returncode != 0:
        print('ERROR: llvm-objdump failed; supply --disasm with a full .srtext disassembly.')
        sys.exit(2)
    dis=proc.stdout
acq=[int(x,16) for x in re.findall(r'^([0-9a-f]+):.*\b(?:bl|b\.w)\s+0xe093dc50\b',dis,re.M|re.I)]
rel=[int(x,16) for x in re.findall(r'^([0-9a-f]+):.*\b(?:bl|b\.w)\s+0xe093dc68\b',dis,re.M|re.I)]
expected_acq=[0xE0561B64,0xE058C654,0xE058C6AA,0xE058C8BC,0xE058CB22,0xE0671B46,0xE071447C,0xE073C4D8,0xE0741712,0xE0928584,0xE093DF2E,0xE093E2A4,0xE093E354,0xE093E3F4]
expected_rel=[0xE0561B6C,0xE058C67C,0xE058C6D4,0xE0671B72,0xE071449C,0xE073C4F8,0xE074172E,0xE0928578,0xE093DF1E,0xE093E2AC,0xE093E402,0xE093E548]
check('14 direct acquire-helper xrefs match full audit', sorted(acq)==sorted(expected_acq))
check('12 direct release-helper xrefs match full audit', sorted(rel)==sorted(expected_rel))
check('acquire helper branches to core at 0xE093DF60', 'e093dc5e:' in dis and 'b.w\t0xe093df60' in dis)
check('release helper branches to core at 0xE093E028', 'e093dc76:' in dis and 'b.w\t0xe093e028' in dis)
# Exact global table references in code: five MOVW/MOVT pairs to C1D6:24F4.
lines=dis.splitlines(); refs=[]
for i,line in enumerate(lines):
    if 'movw' in line.lower() and '#0x24f4' in line.lower():
        # paired MOVT must set the same destination register to 0xC1D6 within next 3 instructions
        regm=re.search(r'movw\s+(r\d+),\s*#0x24f4',line,re.I)
        if not regm: continue
        reg=regm.group(1)
        nexts=' '.join(lines[i+1:i+4])
        if re.search(r'movt\s+'+re.escape(reg)+r',\s*#0xc1d6',nexts,re.I):
            refs.append(int(line.split(':',1)[0],16))
expected_mask_refs=[0xE093DD0E,0xE093DF86,0xE093E04A,0xE093E484,0xE093E4FC]
check('five direct xrefs to C1D624F4 match init/acquire/release/report/clear sites', sorted(refs)==sorted(expected_mask_refs))
check('client report routine begins at 0xE093E480', 'e093e480:' in dis)
check('bulk clear routine begins at 0xE093E4F8', 'e093e4f8:' in dis)
check('no direct BL/B.W call to descriptor accessor e093e290', not re.search(r'^.*:\s+.*\b(?:bl|b\.w)\s+0xe093e290\b',dis,re.M|re.I))
check('initializer e093e310 calls descriptor builder e093e250', re.search(r'e093e320:.*b\.w\s+0xe093e250',dis,re.I) is not None)
check('descriptor builder stores three words from r2/r3/r12', 'e093e262:' in dis and 'stm.w\tr0, {r2, r3, r12}' in dis)
check('accessor returns address of global + 4', 'e093e29c:' in dis and 'addne\tr0, r1, #0x4' in dis)
check('accessor obtains global C1D62B4C', 'e093e290:' in dis and '#0x2b4c' in dis and '#0xc1d6' in dis)
check('descriptor string field is loaded from ROMFS VMA E0BC0654', 'movw\tr1, #0x654' in dis and 'movt\tr1, #0xe0bc' in dis)

# No fixed PE_POLICY mask in any direct acquire call's short pre-call window.
# This is deliberately limited to resolved call-site code; it does not exclude dynamic args.
call_lines=[]
for i,line in enumerate(lines):
    if re.search(r'\b(?:bl|b\.w)\s+0xe093dc50\b',line,re.I):
        pre='\n'.join(lines[max(0,i-8):i])
        call_lines.append(pre)
check('no direct acquire call-site window loads r1 with fixed 0x00400000', all(not re.search(r'mov(?:s|\.w)?\s+r1,\s*#0x400000',p,re.I) for p in call_lines))
# Dynamic API wrapper and the unreferenced fixed-resource wrapper are separately visible.
check('public lib_power acquire wrapper forwards r2 to r1 before core', 'e093e2a2:' in dis and 'mov\tr1, r2' in dis and 'e093e2a4:' in dis)
check('resource-0x32 wrapper forwards input r0 as mask', 'e0561b60:' in dis and 'mov\tr1, r0' in dis and 'movs\tr0, #0x32' in dis)

# Write verification summary.
passed=sum(ok for _,ok in checks); failed=len(checks)-passed
print(f'\nRESULT: {passed}/{len(checks)} PASS; {failed} FAIL')
if failed: sys.exit(1)
