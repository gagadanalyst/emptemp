# Part 22, Step 11 — Power-client bit map and Sirius descriptor trace

## Scope

Static-only follow-up to Revision 97. The analysis uses the preserved Part 1 RTP Provider Trace evidence package from Library, whose retained LBI section images are hash-identified in `SOURCE_INPUTS.txt`. It does not interact with the printer, network, firmware updater, or device state.

## Principal correction to Step 10

The 24 ROMFS strings are **one sentinel plus 23 active client names**. `POWER_CLIENT_NONE` occupies slot 0 and is not a bit. The firmware's report and bulk-clear loops iterate slots 1 through 23 and map slot `n` to bit `n-1`. Consequently:

- `POWER_CLIENT_PEN` = bit 3 = `0x00000008`
- `POWER_CLIENT_UDW` = bit 4 = `0x00000010`
- `POWER_CLIENT_SCAN` = bit 9 = `0x00000200`
- `POWER_CLIENT_PE_POLICY` = bit 22 = `0x00400000`

The prior Step 10 assignments (`PEN=0x10`, `SCAN=0x400`, `PE_POLICY=0x00800000`) were one bit too high. `0x00800000` is not represented in the recovered 23-client active-name loop.

## PE_POLICY use

The power acquire helper at `0xE093DC50` updates the resource/client mask array at `0xC1D624F4`; the release helper at `0xE093DC68` clears bits from it. The report routine at `0xE093E480` maps active bits back to client names. The bulk-clear routine at `0xE093E4F8` walks the 23 client bits and calls the release helper for each active bit.

A full direct branch/call audit found 14 acquire-helper references and 12 release-helper references. None of the resolved direct acquire call sites supplies the corrected `PE_POLICY` mask `0x00400000` as a fixed immediate. The resolved fixed masks map to MECH, PEN, UDW, OPT_SENSOR, SCAN, SYS, or BOARD. Two interfaces remain dynamic: an unreferenced wrapper at `0xE0561B60` forwards its input as a mask for resource `0x32`, and the `lib_power` method at `0xE093E2A0` forwards its second runtime argument as the mask. The latter has a function pointer in the `rtpadapter` ROMFS block, but no static caller was found. Therefore the firmware supports PE_POLICY in the generic mask model, but this pass does not prove that the PE_POLICY bit is actually requested at runtime.

## Sirius descriptor

The `rtpadapter` ROMFS record begins at `0xE0BC0084`, has a declared size of `0xDC8`, and contains:

- `rtpadapter` at `0xE0BC0100`
- `siriusInstance` at `0xE0BC010C`
- descriptor accessor function pointer `0xE093E291` at `0xE0BC0534`
- `lib_power` at `0xE0BC05E0`
- a second `siriusInstance` key at `0xE0BC0654`
- the power-client name table beginning at `0xE0BC098C`

The function pointer block at ROMFS VMA `0xE0DD26B0` contains Thumb pointer `0xE093E311` to initializer `0xE093E310`. That initializer calls builder `0xE093E250`, which writes three words to global `0xC1D62B4C`: `0xE0BC05EC`, `0xE0BC0630`, and `0xE0BC0654`. Accessor `0xE093E290` returns the address of the second field (`0xC1D62B50`), not the value stored there. The accessor pointer occurs once in the ROMFS record; no direct code-call reference to it was found.

This is strong static evidence of a Sirius-named descriptor/accessor associated with the `rtpadapter` record, which also contains the `lib_power` interface. It does not establish which runtime provider resolves the key, whether it resolves to the separate singleton previously observed at `0xC190662C`, or whether the power API is used by the PE print-policy path.

## Next useful target

Trace the generic component/dependency dispatcher that consumes the `rtpadapter` record and invokes the accessor at `0xE0BC0534`, then identify the runtime caller of the `lib_power` method pointer at `0xE0BC05F4`. The key test is whether any PE-policy caller supplies `0x00400000` to `0xE093E2A0` or the shared acquire helper.

## Evidence files

- `rtpadapter_romfs_block_0xDC8.bin` — complete 0xDC8-byte ROMFS record.
- `power_client_name_table.txt` — all 24 slots and corrected bit masks.
- `power_helper_callsite_contexts.txt` — full direct acquire/release call-site excerpts.
- `direct_power_helper_xrefs.txt` — direct xref addresses.
- `client_mask_global_xrefs.txt` — complete xrefs to the 403-entry mask table.
- `*_disasm.txt` — focused native code excerpts.
- `romfs_*.txt` — object, descriptor, interface and initializer pointer context.
- `verify_part22_step11.py` and `verification_output.txt` — reproducible static checks. Run `python verify_part22_step11.py --source-dir /path/to/part1_rtp_provider_trace` after extracting the preserved Part 1 Library evidence ZIP; LLVM `llvm-objdump` is used automatically unless a full disassembly is supplied with `--disasm`.
- `SOURCE_INPUTS.txt` — exact source hashes and sizes.

The 7.6 MB `.srtext` image and complete 4.46 MB ROMFS image are not duplicated in this small evidence ZIP; they remain available in the Library Part 1 RTP Provider Trace evidence package identified by the hashes in `SOURCE_INPUTS.txt`.
