from pathlib import Path
import hashlib, json, zipfile, textwrap, struct

base=Path('/mnt/data/hp_part22_step5')
out=base/'output'; ex=out/'excerpts'; ex.mkdir(parents=True,exist_ok=True)
disasm=Path('/mnt/data/hp_fw_inputs/srtext_disasm_all.txt')
lines=disasm.read_text(errors='replace').splitlines()

def excerpt(start, end=None, count=None):
    ix=next(i for i,l in enumerate(lines) if l.startswith(start.lower()+':'))
    if end:
        try: j=next(i for i,l in enumerate(lines[ix+1:],ix+1) if l.startswith(end.lower()+':'))
        except StopIteration: j=min(len(lines),ix+(count or 60))
    else:
        j=min(len(lines),ix+(count or 40))
    return '\n'.join(lines[ix:j])+'\n'

files={
'01_singleton_constructor.txt': excerpt('e02769c8','e0276aa0'),
'02_global_initializer_wrapper.txt': excerpt('e0277070','e0277094'),
'03_alert_list_consumer_abi.txt': excerpt('e0277500','e0277586'),
'04_candidate_vtable_method_rejected.txt': excerpt('e0276288','e027634e'),
'05_secondary_adjustors_and_init.txt': excerpt('e027703c','e0277070'),
'06_dependency_registry_clear_and_register.txt': excerpt('e0277100','e02771ae'),
'07_registry_consumers.txt': excerpt('e0275500',count=55)+'\n'+excerpt('e0276b90',count=52)+'\n'+excerpt('e02771b0','e027720a'),
'08_external_veneers.txt': excerpt('e02795d8','e02795ec'),
}
for name,content in files.items(): (ex/name).write_text(content)

rom=Path('/mnt/data/hp_fw_inputs/extracted/inputs/romfs_objs_rebuilt.bin').read_bytes()
ROM_BASE=0xE09919C0

def words(addr,n):
    off=addr-ROM_BASE
    vals=struct.unpack_from('<'+'I'*n,rom,off)
    return '\n'.join(f'0x{addr+i*4:08X}: 0x{v:08X}' for i,v in enumerate(vals))
romdump=(
'ROMFS reconstructed section address map (little-endian 32-bit words)\n'
+ '\n[siriusInstance descriptor] 0xE09986CC\n'
+ rom[0xE09986CC-ROM_BASE:0xE09986CC-ROM_BASE+0x90].split(b'\x00')[0].decode('ascii','replace')+'\n'
+ '\n[primary and secondary vtable pointers stored by constructor]\n'
+ words(0xE09989F4,8)+'\n'
+ words(0xE0998A4C,8)+'\n'
+ '\n[candidate vtable block and +0x14 entry]\n'
+ words(0xE09988EC,12)+'\n'
)
(ex/'09_romfs_descriptor_vtables.txt').write_text(romdump)
(ex/'10_global_instance_list_insert.txt').write_text(excerpt('e0981216','e0981234'))

source_inputs='''Part 22 Step 5 — source inputs and integrity\n\nInput artifacts used locally; full large source files are not duplicated in this ZIP.\n\n- tassel_LBI_verified.bin\n  SHA-256: 2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e\n- extracted/inputs/srtext_rebuilt.bin\n  SHA-256: 10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7\n  VMA base: 0xE0246070\n- extracted/inputs/romfs_objs_rebuilt.bin\n  SHA-256: 227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3\n  VMA base: 0xE09919C0\n- srtext_disasm_all.txt\n  SHA-256: f900a16029dd0a8d9a1a87cb74c41ce616ebd556ae503c0591212ef241400377\n\nThe verifier re-hashes the reconstructed sections and complete disassembly before checking addresses. The full LBI and full disassembly are deliberately not duplicated in this compact evidence archive; all excerpted code and extracted mappings are included.\n'''
(out/'SOURCE_INPUTS.txt').write_text(source_inputs)

findings='''# Part 22 Step 5 — findings\n\n## Scope\nStatic-only analysis of the verified 2629A LBI. No printer/network/device interaction, no firmware modifications, and no debug-mode activation.\n\n## Singleton and alert-list contract\n- Global alert root: `0xC136E6F0`; object storage: `0xC136E6F4`.\n- Global initializer `0xE0277070` calls constructor `0xE02769C8` with descriptor `0xE09986CC` (`siriusInstance`).\n- Constructor stores primary vptr `0xE09989F4`, secondary vptr `0xE0998A4C`; it zeroes object offsets +0x08, +0x0C, +0x10 before publishing `this` at `0xE0276A86`.\n- Alert-list consumer `0xE0277500` reads `root+0x10` (`0xC136E704`) then invokes nested vtable slot +0x14. It passes r1 as a two-word begin/end output pair and r2 as a capacity pointer (value 8). It later consumes the returned `[begin,end)` pointer range.\n- No direct MOVW/MOVT absolute materialization of `0xC136E704` was found in the full reconstructed `.srtext` disassembly. The assignment/binding of this nested pointer remains unresolved.\n\n## Candidate method rejected\n- A ROMFS block at `0xE09988EC` has +0x14 entry `0xE0276289` (Thumb).\n- Body `0xE0276288` treats r1 as a large request/response context, stores at +0x248 and allocates `0x1F2E8` bytes. This does not match the alert-list consumer's begin/end pair + capacity pointer ABI.\n- Therefore it is not accepted as the implementation behind `root+0x10` slot +0x14. No code found installing its vptr into `0xC136E704`.\n\n## External veneers\n- `0xE02795D8` jumps through literal `0x38100424`; `0xE02795E0` jumps through literal `0x381005A0`. Both targets lie outside the reconstructed `.srtext` and `.romfs_objs` sections. Owner/implementation unknown.\n\n## Secondary dependency-registration mechanism\n- Secondary vtable `0xE0998A4C` entry at `0xE0998A60` -> Thumb adjustor `0xE0277041`; thunk at `0xE0277040` subtracts 4 from `this` and branches to `0xE0277130`.\n- Registration method `0xE0277130` conditionally stores r3 into four global words starting `0xC136E4A4`. Correctly decoded incoming selectors (not raw compare immediates):\n  - `0x0001234C` -> `0xC136E4A8`\n  - `0x00012A80` -> `0xC136E4A4`\n  - `0x00012238` -> `0xC136E4AC`\n  - `0x00012D5D` -> `0xC136E4B0`\n- Additional selector cases `0x0061862B`, `0x003BEB01` and `0x00021E52` write the passed object's fields +0x10, +0x0C and +0x08 respectively; they are not global registry slots.\n- Clear method `0xE0277100` zeroes the four-word registry. Consumers include `0xE0276B90`/`0xE0277228` for slot 0, `0xE02771B0` for slot 1 and slot 2, and `0xE0275500` for slot 2 (virtual +0x28). Slot 3 consumer not mapped.\n- This registration registry is separate from the nested alert-list pointer at `0xC136E704`; this method does not write that field.\n\n## Enforcement boundary\nNo direct branch/call to RTP helper `0xE07BDFA8`, wrappers `0xE07C1211` / `0xE07C1219`, or PE blocked-state writer `0xE0251788` from the examined alert subsystem path. This is a bounded direct-edge result only; indirect callbacks and code outside reconstructed sections remain unresolved. No connection between alert 66,220 and RTP/PE print-block state is established.\n\n## Next bounded target (requires separate approval)\nTrace the upstream framework invocation of the secondary registration vtable and the runtime binding that populates `0xC136E704`; preserve the explicit distinction between the four-slot registry and the alert-list interface.\n'''
(out/'STEP5_FINDINGS.md').write_text(findings)

readme='''# Part 22 Step 5 evidence package\n\nThis archive supports Revision 92, Part 22 Step 5 of the HP DeskJet 2855e independent printing/scanning investigation. It contains the recovered disassembly excerpts, ROMFS table decoding, source hashes, a reproducible verifier and its output.\n\n## Reproduce the static checks\n\nRun `python verify_part22_step5.py` in an environment where the source inputs listed in `SOURCE_INPUTS.txt` are mounted under `/mnt/data/hp_fw_inputs/`. It does not access a printer, network or firmware update interface.\n\nExpected result: `RESULT: all Part 22 Step 5 static checks passed`.\n\n## Important scope boundary\n\nThe evidence identifies the `siriusInstance` singleton, alert-list interface contract and a separate four-slot dependency-registration table. It does not identify the code that assigns `0xC136E704`, the concrete vtable method behind its +0x14 call, or a path from the subscription alert to the known RTP/PE print-block implementation.\n\nThe full 107 MB disassembly and original firmware blob are not included in this compact ZIP. Their SHA-256 hashes are recorded in `SOURCE_INPUTS.txt`; the exact relevant excerpts are included.\n'''
(out/'README.md').write_text(readme)

docx_path=Path('/mnt/data/hp_part22_step5/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision92_Part22_Step5_Sirius_Alert_Provider_Binding_Trace.docx')
pdf_path=Path('/mnt/data/hp_part22_step5/qa/rev92_finalpdf/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision92_Part22_Step5_Sirius_Alert_Provider_Binding_Trace.pdf')
qa=(f'''Part 22 Step 5 DOCX QA\n\n- Source findings document: Revision 91 (173 pages).\n- Output findings document: Revision 92 (176 pages; US Letter).\n- LibreOffice PDF export completed successfully and reports 176 pages.\n- Inherited pages 1–173 compared as raster images at 40 dpi: 173/173 pixel-identical to Revision 91.\n- New pages 174–176 rendered at 120 dpi and visually inspected: no clipping, overlap, broken tables or footer/page-label issues observed.\n- The packaged DOCX skill renderer timed out partway through image production; final visual QA therefore used direct isolated LibreOffice PDF export followed by Poppler rendering. The successful full PDF export and page-level comparisons are the QA basis.\n- Revision 92 DOCX SHA-256: {hashlib.sha256(docx_path.read_bytes()).hexdigest()}\n- QA PDF SHA-256: {hashlib.sha256(pdf_path.read_bytes()).hexdigest()}\n''')
(out/'DOCX_QA.txt').write_text(qa)

# Copy verifier and output to archive root.
(out/'verify_part22_step5.py').write_text((out/'verify_part22_step5.py').read_text())

# hashes for evidence files (excluding checksum itself and zip)
files_to_hash=[p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt']
with (out/'SHA256SUMS.txt').open('w') as f:
    for p in sorted(files_to_hash):
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        f.write(f'{h}  {p.relative_to(out).as_posix()}\n')

zip_path=base/'Part22_Step5_Sirius_Alert_Provider_Binding_Trace_Evidence.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob('*')):
        if p.is_file(): z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip(); infos=z.infolist()
    if bad: raise SystemExit(f'CRC failure: {bad}')
print('ZIP',zip_path,'bytes',zip_path.stat().st_size,'entries',len(infos),'CRC=PASS')
print('Evidence files',len(files_to_hash)+1)
print('SHA256',hashlib.sha256(zip_path.read_bytes()).hexdigest())
