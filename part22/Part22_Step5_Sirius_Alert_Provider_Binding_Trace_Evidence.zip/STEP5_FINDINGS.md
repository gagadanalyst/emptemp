# Part 22 Step 5 — findings

## Scope
Static-only analysis of the verified 2629A LBI. No printer/network/device interaction, no firmware modifications, and no debug-mode activation.

## Singleton and alert-list contract
- Global alert root: `0xC136E6F0`; object storage: `0xC136E6F4`.
- Global initializer `0xE0277070` calls constructor `0xE02769C8` with descriptor `0xE09986CC` (`siriusInstance`).
- Constructor stores primary vptr `0xE09989F4`, secondary vptr `0xE0998A4C`; it zeroes object offsets +0x08, +0x0C, +0x10 before publishing `this` at `0xE0276A86`.
- Alert-list consumer `0xE0277500` reads `root+0x10` (`0xC136E704`) then invokes nested vtable slot +0x14. It passes r1 as a two-word begin/end output pair and r2 as a capacity pointer (value 8). It later consumes the returned `[begin,end)` pointer range.
- No direct MOVW/MOVT absolute materialization of `0xC136E704` was found in the full reconstructed `.srtext` disassembly. The assignment/binding of this nested pointer remains unresolved.

## Candidate method rejected
- A ROMFS block at `0xE09988EC` has +0x14 entry `0xE0276289` (Thumb).
- Body `0xE0276288` treats r1 as a large request/response context, stores at +0x248 and allocates `0x1F2E8` bytes. This does not match the alert-list consumer's begin/end pair + capacity pointer ABI.
- Therefore it is not accepted as the implementation behind `root+0x10` slot +0x14. No code found installing its vptr into `0xC136E704`.

## External veneers
- `0xE02795D8` jumps through literal `0x38100424`; `0xE02795E0` jumps through literal `0x381005A0`. Both targets lie outside the reconstructed `.srtext` and `.romfs_objs` sections. Owner/implementation unknown.

## Secondary dependency-registration mechanism
- Secondary vtable `0xE0998A4C` entry at `0xE0998A60` -> Thumb adjustor `0xE0277041`; thunk at `0xE0277040` subtracts 4 from `this` and branches to `0xE0277130`.
- Registration method `0xE0277130` conditionally stores r3 into four global words starting `0xC136E4A4`. Correctly decoded incoming selectors (not raw compare immediates):
  - `0x0001234C` -> `0xC136E4A8`
  - `0x00012A80` -> `0xC136E4A4`
  - `0x00012238` -> `0xC136E4AC`
  - `0x00012D5D` -> `0xC136E4B0`
- Additional selector cases `0x0061862B`, `0x003BEB01` and `0x00021E52` write the passed object's fields +0x10, +0x0C and +0x08 respectively; they are not global registry slots.
- Clear method `0xE0277100` zeroes the four-word registry. Consumers include `0xE0276B90`/`0xE0277228` for slot 0, `0xE02771B0` for slot 1 and slot 2, and `0xE0275500` for slot 2 (virtual +0x28). Slot 3 consumer not mapped.
- This registration registry is separate from the nested alert-list pointer at `0xC136E704`; this method does not write that field.

## Enforcement boundary
No direct branch/call to RTP helper `0xE07BDFA8`, wrappers `0xE07C1211` / `0xE07C1219`, or PE blocked-state writer `0xE0251788` from the examined alert subsystem path. This is a bounded direct-edge result only; indirect callbacks and code outside reconstructed sections remain unresolved. No connection between alert 66,220 and RTP/PE print-block state is established.

## Next bounded target (requires separate approval)
Trace the upstream framework invocation of the secondary registration vtable and the runtime binding that populates `0xC136E704`; preserve the explicit distinction between the four-slot registry and the alert-list interface.
