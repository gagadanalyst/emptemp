#!/usr/bin/env python3
"""Static verifier for Part 22 Step 5. No device I/O or firmware writes."""
from __future__ import annotations
import hashlib, re, struct
from pathlib import Path

ROOT = Path('/mnt/data/hp_fw_inputs')
DISASM = ROOT / 'srtext_disasm_all.txt'
SRTEXT = ROOT / 'extracted/inputs/srtext_rebuilt.bin'
ROMFS = ROOT / 'extracted/inputs/romfs_objs_rebuilt.bin'
LBI = ROOT / 'tassel_LBI_verified.bin'
BASE_SRTEXT = 0xE0246070
BASE_ROMFS = 0xE09919C0

expected = {
    DISASM: 'f900a16029dd0a8d9a1a87cb74c41ce616ebd556ae503c0591212ef241400377',
    SRTEXT: '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
    ROMFS: '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
}

def sha(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def must(cond: bool, label: str) -> None:
    print(('PASS ' if cond else 'FAIL ') + label)
    if not cond: raise SystemExit(1)

def read32(blob: bytes, base: int, va: int) -> int:
    off=va-base
    return struct.unpack_from('<I',blob,off)[0]

asm=DISASM.read_text(errors='replace')
sr=SRTEXT.read_bytes(); rom=ROMFS.read_bytes()
for p,d in expected.items():
    must(sha(p)==d, f'SHA256 {p.name}')

# Singleton initializer and descriptor
must('e0277070:' in asm and 'bl\t0xe02769c8' in asm[asm.find('e0277070:'):asm.find('e0277092:')], 'global-init wrapper calls singleton constructor')
ctor=asm[asm.find('e02769c8:'):asm.find('e0276aa0:')]
must('stm.w\tr4, {r0, r2, r3, r5, r12}' in ctor, 'constructor writes primary/secondary vptrs and three zero words')
must('mov\tr3, r5' in ctor and 'mov\tr12, r5' in ctor, 'constructor zero-initializes nested +0x10 interface field')
must('movw\tr6, #0xe6f0' in ctor and 'movt\tr6, #0xc136' in ctor and 'str\tr4, [r6]' in ctor and 'e0276a86:' in ctor, 'constructor publishes this pointer through C136E6F0')
init=asm[asm.find('e0277070:'):asm.find('e0277094:')]
must('movw\tr0, #0xd864' in init and 'movt\tr0, #0xc01d' in init and 'bl\t0xe0981216' in init, 'initializer separately registers node 0xC01DD864')
list_helper=asm[asm.find('e0981216:'):asm.find('e0981234:')]
must('movw\tr1, #0x3bd4' in list_helper and 'movt\tr1, #0xc1d6' in list_helper and 'str\tr0, [r1]' in list_helper, 'node helper inserts into global list rooted at C1D63BD4')
roms=rom[0x86CC-(BASE_ROMFS-0x0):] if False else rom

def cstr_at(va:int)->str:
    off=va-BASE_ROMFS
    return rom[off:off+120].split(b'\x00',1)[0].decode('ascii','replace')
must(cstr_at(0xE09986CC).startswith('siriusInstance'), 'ROMFS instance descriptor begins siriusInstance')
must(cstr_at(0xE0998704).startswith('com.hp.cdm.service.alert.version.1.resource.alert'), 'descriptor contains alert resource service ID')

# Handler ABI: r0 = nested ptr, r1 = begin/end output pair, r2 = capacity pointer.
handler=asm[asm.find('e0277500:'):asm.find('e02776b0:')]
must('ldr\tr0, [r0, #0x10]' in handler and 'ldr\tr3, [r2, #0x14]' in handler and 'blx\tr3' in handler, 'alert handler reads nested object and dispatches virtual slot +0x14')
must('movs\tr2, #0x8' in handler and 'mov\tr2, sp' in handler and 'add\tr1, sp, #0x8' in handler, 'alert handler supplies capacity=8 and begin/end output pair')
must('ldr\tr2, [sp, #0xc]' in handler and 'ldr\tr3, [sp, #0x8]' in handler, 'handler consumes begin/end output pair')

# The only matching ROMFS table entry is a candidate, but its method ABI mismatches.
vptr=read32(rom,BASE_ROMFS,0xE0998900)
must(vptr==0xE0276289, 'ROMFS block at E09988EC has +0x14 entry E0276289')
method=asm[asm.find('e0276288:'):asm.find('e027634e:')]
must('str.w\tr0, [r5, #0x248]' in method, 'candidate method treats r1 as a large response object (offset +0x248)')
must('movw\tr0, #0xf2e8' in method and 'movt\tr0, #0x1' in method, 'candidate allocates 0x1F2E8-byte object')
must(cstr_at(0xE02756F0).startswith('CdmAlertsCapsProvider.cpp') if 0xE02756F0>=BASE_ROMFS else sr[0xE02756F0-BASE_SRTEXT:0xE02756F0-BASE_SRTEXT+40].split(b'\x00')[0]==b'CdmAlertsCapsProvider.cpp', 'candidate method source metadata points to CdmAlertsCapsProvider.cpp')

# External serialization veneer
must(read32(sr,BASE_SRTEXT,0xE02795E4)==0x381005A0, 'serializer veneer E02795E0 literal target is 0x381005A0')
must(read32(sr,BASE_SRTEXT,0xE02795DC)==0x38100424, 'adjacent helper veneer E02795D8 literal target is 0x38100424')

# Secondary interface is a four-slot service-registration table.
vt2=[read32(rom,BASE_ROMFS,va) for va in range(0xE0998A54,0xE0998A70,4)]
must(vt2[3]==0xE0277041, 'secondary vtable routes registration adjustor thunk E0277041')
adj=asm[asm.find('e0277040:'):asm.find('e0277070:')]
must('sub.w\tr0, r0, #0x4' in adj and 'b.w\t0xe0277130' in adj, 'adjustor thunk dispatches to registration method E0277130')
reg=asm[asm.find('e0277130:'):asm.find('e02771b0:')]
for marker in ['0x2d5d','0xffff','0xf4db','0x58ce','0xbda4','0xf0f5']:
    must(marker in reg, f'registration method contains compare constant {marker}')
# Convert compare immediates into the actual incoming selector values.
base=0x12D5D
selector_map={base-0xA11:0xC136E4A8, base-0x2DD:0xC136E4A4, base-0xB25:0xC136E4AC, base:0xC136E4B0}
must(selector_map=={0x1234C:0xC136E4A8,0x12A80:0xC136E4A4,0x12238:0xC136E4AC,0x12D5D:0xC136E4B0}, 'decoded incoming selectors map to the four C136E4A4 registry slots')
must('str\tr3, [r2, #0x8]' in reg and 'str\tr3, [r2, #0x4]' in reg and 'str\tr3, [r2]' in reg and 'str\tr3, [r2, #0xc]' in reg, 'registration method writes all four C136E4A4 registry slots')
extra={base+0x6058CE:0x10,base+0x3ABDA4:0x0C,base+0xF0F5:0x08}
must(extra=={0x61862B:0x10,0x3BEB01:0x0C,0x21E52:0x08}, 'decoded non-registry selectors update object offsets +0x10/+0x0C/+0x08')

clear=asm[asm.find('e0277100:'):asm.find('e0277120:')]
must('str.w\tr3, [r2, r1, lsl #2]' in clear, 'clear method zeroes four registry entries')
cap=asm[asm.find('e0275500:'):asm.find('e02755d0:')]
must('ldr\tr0, [r1, #0x8]' in cap and 'ldr\tr2, [r1, #0x28]' in cap, 'capability provider consumes registry slot 2 via virtual +0x28')
consumer=asm[asm.find('e02771b0:'):asm.find('e0277210:')]
must('ldr\tr0, [r4, #0x8]' in consumer and 'ldr\tr0, [r4, #0x4]' in consumer, 'registration consumer reads registry slots 1 and 2')
slot0=asm[asm.find('e0276b90:'):asm.find('e0276c00:')]
must('ldr\tr0, [r5]' in slot0, 'alert component consumes registry slot 0')

# No local direct reference to C136E704, and global root publication is single-site.
pat=re.compile(r'([0-9a-f]+):\s+movw\s+(r\d+), #0x([0-9a-f]+)')
constants=[]
lines=asm.splitlines()
for i,line in enumerate(lines):
    m=pat.search(line)
    if not m: continue
    addr=int(m.group(1),16); reg=m.group(2); lo=int(m.group(3),16)
    for j in range(i+1,min(i+6,len(lines))):
        mt=re.search(r'movt\s+'+re.escape(reg)+r', #0x([0-9a-f]+)',lines[j])
        if mt:
            constants.append(((int(mt.group(1),16)<<16)|lo,addr))
            break
must(not any(v==0xC136E704 for v,_ in constants), 'no direct MOVW/MOVT materialization of C136E704 in full disassembly')
root_refs=[(v,a) for v,a in constants if v==0xC136E6F0]
must(len(root_refs)>=20, 'full disassembly root-global xrefs enumerated')
# Stores through the address register in the same basic sequence: only E0276A86 publishes root pointer.
stores=[]
for i,line in enumerate(lines):
    m=re.search(r':\s+str(?:\.w)?\s+(r\d+), \[(r\d+)\]',line)
    if not m: continue
    src,dst=m.groups()
    if any(f'movt\t{dst}, #0xc136' in lines[k] or f'movt {dst}, #0xc136' in lines[k] for k in range(max(0,i-8),i)) and any(f'movw\t{dst}, #0xe6f0' in lines[k] or f'movw {dst}, #0xe6f0' in lines[k] for k in range(max(0,i-10),i)):
        stores.append(line.strip())
must(any('e0276a86:' in x for x in stores) and len(stores)==1, 'only direct store via C136E6F0 address register is constructor publication')

# Ensure no direct branch to known print-control implementation from alert area.
alert_area=asm[asm.find('e02753d8:'):asm.find('e02795e0:')]
for target in ['0xe07bdFA8','0xe07c1211','0xe07c1219','0xe0251788']:
    must(target.lower() not in alert_area.lower(), f'no direct literal branch to print control {target}')
# Also reject direct absolute address construction in alert code for those paths.
alert_lines=alert_area.splitlines(); built=[]
for i,line in enumerate(alert_lines):
    m=pat.search(line)
    if not m: continue
    addr=int(m.group(1),16); reg=m.group(2); lo=int(m.group(3),16)
    for j in range(i+1,min(i+6,len(alert_lines))):
        mt=re.search(r'movt\s+'+re.escape(reg)+r', #0x([0-9a-f]+)',alert_lines[j])
        if mt:
            built.append((int(mt.group(1),16)<<16)|lo); break
blocked={0xE07BDFA8,0xE07C1211,0xE07C1219,0xE0251788}
must(not (blocked & set(built)), 'no direct MOVW/MOVT absolute print-control address construction in alert code')

print('RESULT: all Part 22 Step 5 static checks passed')
