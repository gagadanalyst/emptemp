# Part 22 Step 5 evidence package

This archive supports Revision 92, Part 22 Step 5 of the HP DeskJet 2855e independent printing/scanning investigation. It contains the recovered disassembly excerpts, ROMFS table decoding, source hashes, a reproducible verifier and its output.

## Reproduce the static checks

Run `python verify_part22_step5.py` in an environment where the source inputs listed in `SOURCE_INPUTS.txt` are mounted under `/mnt/data/hp_fw_inputs/`. It does not access a printer, network or firmware update interface.

Expected result: `RESULT: all Part 22 Step 5 static checks passed`.

## Important scope boundary

The evidence identifies the `siriusInstance` singleton, alert-list interface contract and a separate four-slot dependency-registration table. It does not identify the code that assigns `0xC136E704`, the concrete vtable method behind its +0x14 call, or a path from the subscription alert to the known RTP/PE print-block implementation.

The full 107 MB disassembly and original firmware blob are not included in this compact ZIP. Their SHA-256 hashes are recorded in `SOURCE_INPUTS.txt`; the exact relevant excerpts are included.
