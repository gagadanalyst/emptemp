from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

src = Path('/mnt/data/hp_part22_step4/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision91_Part22_Step4_CdmAlerts_CdmPrint_Trace.docx')
out = Path('/mnt/data/hp_part22_step5/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision92_Part22_Step5_Sirius_Alert_Provider_Binding_Trace.docx')
out.parent.mkdir(parents=True, exist_ok=True)
doc = Document(src)

NAVY='17365D'; BLUE='21618C'; PALE='D9EAF7'; GRAY='666666'

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def cell_text(cell,text,bold=False,color=None,size=7.2):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers,rows,widths=None,font=7.1):
    t=doc.add_table(rows=1,cols=len(headers)); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    for i,h in enumerate(headers): cell_text(t.rows[0].cells[i],h,True,NAVY,font); shade(t.rows[0].cells[i],PALE)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row): cell_text(cells[i],v,size=font)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t

def body(text,size=8.4,before=0,after=4,bold_lead=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(before); p.paragraph_format.space_after=Pt(after); p.paragraph_format.line_spacing=1.02
    if bold_lead and text.startswith(bold_lead):
        r=p.add_run(bold_lead); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(size)
        r=p.add_run(text[len(bold_lead):]); r.font.name='Aptos'; r.font.size=Pt(size)
    else:
        r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size)
    return p

def h1(s):
    p=doc.add_paragraph(style='Heading 1'); p.paragraph_format.space_before=Pt(0); p.paragraph_format.space_after=Pt(5); p.add_run(s)

def h2(s):
    p=doc.add_paragraph(style='Heading 2'); p.paragraph_format.space_before=Pt(5); p.paragraph_format.space_after=Pt(3); p.add_run(s)

def code(s,size=7.3):
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(.14); p.paragraph_format.right_indent=Inches(.08); p.paragraph_format.space_before=Pt(1); p.paragraph_format.space_after=Pt(4); p.paragraph_format.line_spacing=1.0
    r=p.add_run(s); r.font.name='Consolas'; r.font.size=Pt(size); r.font.color.rgb=RGBColor.from_string('333333')

def label(page):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(f'REVISION 92 | PART 22 STEP 5 | PAGE {page}'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(7.5); r.font.color.rgb=RGBColor.from_string(GRAY)

# PAGE 174

doc.add_page_break(); label(174)
h1('siriusInstance lifecycle and alert-list interface')
h2('92.1 Global initialization and constructor')
body('The alert subsystem global at 0xC136E6F0 is a pointer to a singleton object whose storage begins at 0xC136E6F4. The initialization wrapper at 0xE0277070 supplies the ROMFS descriptor at 0xE09986CC and calls the constructor at 0xE02769C8. The wrapper then calls 0xE0981216 with a separate node pointer (0xC01DD864). The callee inserts that node into a global linked list whose head/tail words are at 0xC1D63BD4 and 0xC1D63BD8; the broader framework semantics of that list are not established.')
table(['Evidence point','Address / value','Static interpretation'],[
('Static storage','0xC136E6F4','Singleton object address passed as constructor this-pointer.'),
('Published global','0xC136E6F0','Constructor stores this-pointer here at 0xE0276A86.'),
('Primary vptr','0xE09989F4','Written at object offset +0x00.'),
('Secondary vptr','0xE0998A4C','Written at object offset +0x04.'),
('Nested interface field','0xC136E704 = object +0x10','Initialized to zero by constructor; later read by alert-list handler.'),
('Instance descriptor','0xE09986CC','ROMFS string begins siriusInstance.'),
('Service descriptor','0xE0998704','com.hp.cdm.service.alert.version.1.resource.alert.'),
],widths=[1.45,2.0,3.1],font=6.9)
body('At 0xE02769E4 the constructor writes the two vptrs and three zero words at object offsets +0x08, +0x0C and +0x10. It initializes further embedded containers, publishes the object pointer through 0xC136E6F0 at 0xE0276A86, initializes embedded state through 0xE0276DD0, and initializes the vector-like region at +0x14 through the veneer 0xE02795D8. Only one direct call to this constructor was found: the global-init wrapper.')
h2('92.2 What the alert-list handler expects')
code('0xE0277500:  root = *(0xC136E6F0)\n             list_interface = *(root + 0x10)\n             enumerate = *( *(list_interface) + 0x14 )\n             enumerate(list_interface, &begin_end, &capacity)')
body('The handler sets the capacity value to 8 at [sp], passes sp+8 as a two-word begin/end output pair in r1, and passes sp as r2. After the virtual call it reads [sp+8] and [sp+0xC], computes (end-begin)/4, and iterates the returned pointer range. The nested interface is therefore used as a record-range enumerator, not merely as a status getter. Its concrete vtable and implementation remain unknown.')
body('The constructor zeroes root+0x10, while the handler later dereferences that field. The investigation found no direct MOVW/MOVT materialization of 0xC136E704 in the full reconstructed .srtext disassembly. This supports an unresolved injection/indirect-binding boundary; it does not prove the field is never assigned through external code or runtime callbacks.')

# PAGE 175

doc.add_page_break(); label(175)
h1('Nested alert-list provider: candidate testing and external boundary')
h2('92.3 Nearby ROMFS candidate rejected by calling-convention evidence')
body('A ROMFS function-pointer block at 0xE09988EC contains a +0x14 entry pointing to Thumb address 0xE0276289 (implementation 0xE0276288). This initially looked like a possible match for the nested alert-list method. Its actual argument use does not fit the caller observed at 0xE0277500: the candidate treats r1 as a large request/response object, stores through offset +0x248, and allocates a 0x1F2E8-byte object. The alert-list caller instead passes r1 as a two-word begin/end output pair and r2 as a capacity pointer.')
table(['Candidate evidence','Observed fact','Assessment'],[
('ROMFS entry','0xE0998900 -> Thumb 0xE0276289','Candidate vtable slot +0x14 in this table only.'),
('Candidate body','0xE0276288 uses r1 as large context at +0x248','Does not match begin/end output-pair ABI.'),
('Allocation','0x1F2E8 bytes','Consistent with large request context, not the caller’s small range descriptor.'),
('Source metadata','CdmAlertsCapsProvider.cpp','Component association does not establish it as the list provider.'),
],widths=[1.45,3.0,2.2],font=7.0)
body('Conclusion: 0xE0276288 is not accepted as the concrete implementation behind root+0x10 virtual slot +0x14. No evidence puts this vptr into 0xC136E704. The address match alone is insufficient, and the call ABI is a substantive contradiction.')
h2('92.4 Serialization helper veneers leave the target outside the reconstructed sections')
code('0xE02795D8: ldr.w pc, [pc, #0]  ; literal at 0xE02795DC = 0x38100424\n0xE02795E0: ldr.w pc, [pc, #0]  ; literal at 0xE02795E4 = 0x381005A0')
body('The constructor’s vector initializer and the per-record serializer are veneers, not full local implementations. Their literal targets, 0x38100424 and 0x381005A0, lie outside the reconstructed .srtext and .romfs_objs regions examined in this step. The target may be provided by another firmware/runtime region; the available evidence does not identify its owner or implementation.')
body('This boundary prevents a complete static reconstruction of alert-record enumeration and serialization from the current LBI sections. It also means the external target must not be assigned a behavior based solely on the veneer name or call position.')

# PAGE 176

doc.add_page_break(); label(176)
h1('Secondary dependency-registration interface and Step 5 result')
h2('92.5 Secondary vtable routes into a four-slot registry')
body('The singleton has a secondary vtable at 0xE0998A4C. Its method entry at 0xE0998A60 points to adjustor thunk 0xE0277041. The thunk subtracts four from r0 and branches to registration method 0xE0277130. That method receives a selector in r1 and a pointer argument in r3, and conditionally stores the pointer into one of four global slots beginning at 0xC136E4A4.')
table(['Incoming selector','Registry destination','Observed consumer / use'],[
('0x0001234C','0xC136E4A8 (+4)','Read by 0xE02771B0; later null-checked and passed to helper 0xE0277CE8.'),
('0x00012A80','0xC136E4A4 (+0)','Read by methods including 0xE0276B90 and 0xE0277228.'),
('0x00012238','0xC136E4AC (+8)','Read by 0xE0275500 (virtual slot +0x28) and 0xE02771B0.'),
('0x00012D5D','0xC136E4B0 (+0xC)','Fourth registry slot; consumer not mapped in this step.'),
],widths=[1.35,1.5,3.8],font=7.0)
body('Selector decoding was recalculated from the Thumb instructions rather than copying compare immediates as though they were input values. For example, 0xE0277130 subtracts 0x12D5D, then compares the result with two’s-complement constants produced by MVN instructions. This yields the four input selectors shown above. Separate cases 0x0061862B, 0x003BEB01 and 0x00021E52 write to fields of the passed object at +0x10, +0x0C and +0x08; they are not entries in the four global slots.')
body('The clear method at 0xE0277100 zeroes all four registry words at 0xC136E4A4–0xC136E4B0. This establishes a local dependency-registration mechanism for the alert subsystem. The registry is distinct from the alert-list interface field at 0xC136E704; the registration method does not write that field.')
h2('92.6 What Step 5 establishes — and does not establish')
table(['Established by static evidence','Still unresolved'],[
('The singleton constructor, descriptor and global publication point.','Who assigns the nested alert-list pointer at 0xC136E704.'),
('The alert-list consumer ABI: virtual +0x14 receives begin/end and capacity pointers.','The concrete vtable and implementation behind that call.'),
('A secondary interface registers dependencies into four distinct global slots.','The upstream framework caller and semantic names for the four selectors.'),
('The generic serializer/initializer veneers jump to 0x38100424 and 0x381005A0.','The owning module and implementation at those targets.'),
],widths=[3.25,3.35],font=7.0)
body('No direct call or address materialization was found from the examined alert-provider path to the known RTP block helper 0xE07BDFA8, block/unblock wrappers 0xE07C1211 / 0xE07C1219, or PE blocked-state writer 0xE0251788. This is a bounded direct-edge result; indirect callbacks and code outside the reconstructed sections remain open.')
body('Step 5 conclusion: a local alert-subsystem dependency-registration interface is now mapped, but it is not the missing alert-list binding. The next bounded target should be the upstream framework path that invokes the secondary registration vtable and the runtime binding of 0xC136E704. The investigation does not yet connect alert 66,220 to RTP or PE print-block state.')
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(0)
r=p.add_run('PART 22 STEP 5 COMPLETE — WAIT FOR APPROVAL BEFORE STEP 6'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(8.4); r.font.color.rgb=RGBColor.from_string(NAVY)

props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing and Scanning Investigation — Revision 92'
props.subject='Part 22 Step 5: siriusInstance alert-list binding and secondary dependency-registration trace'
props.comments='Appended to Revision 91. Static-only analysis; no printer interaction, network access or firmware modification.'
doc.save(out)
print(out)
