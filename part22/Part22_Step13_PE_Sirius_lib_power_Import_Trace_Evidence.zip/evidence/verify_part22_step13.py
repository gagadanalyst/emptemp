#!/usr/bin/env python3
"""Verify Part 22 Step 13 PE/Sirius/lib_power findings against preserved bytes."""
from __future__ import annotations
import hashlib
import re
import struct
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ROM_BASE=0xE09919C0
SRT_BASE=0xE0246070
ROM=ROOT/'romfs_objs_rebuilt.bin'
SRT=ROOT/'srtext_rebuilt.bin'
CROM=ROOT/'cromsrtext.bin'
SETUP=ROOT/'setup_text.bin'
ROMSTART=ROOT/'romstartup_text.bin'
checks=[]

def check(name: str, condition: bool):
    checks.append((name, bool(condition)))

def u32(buf: bytes, base: int, address: int) -> int:
    off=address-base
    if off<0 or off+4>len(buf): raise ValueError(f'address outside buffer: {address:#x}')
    return struct.unpack_from('<I',buf,off)[0]

def bytes_at(buf: bytes, base: int, address: int, size: int) -> bytes:
    off=address-base
    if off<0 or off+size>len(buf): raise ValueError(f'address outside buffer: {address:#x}')
    return buf[off:off+size]

def cstr(buf: bytes, base: int, address: int) -> str:
    off=address-base
    if off<0 or off>=len(buf): raise ValueError('string outside buffer')
    end=buf.find(b'\0',off)
    if end<0: raise ValueError('unterminated string')
    return buf[off:end].decode('ascii')

def header(address: int):
    v=struct.unpack_from('<17I',rom.read_bytes(),address-ROM_BASE)
    return v

def record(buf: bytes, base: int, ptr: int, index: int):
    return struct.unpack_from('<6I',buf,ptr-base+index*24)

rom=ROM.read_bytes(); srt=SRT.read_bytes(); crom=CROM.read_bytes(); setup=SETUP.read_bytes(); romstart=ROMSTART.read_bytes()

# A. Source and section integrity (5 checks)
expected={
 'romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
 'srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
 'cromsrtext.bin':'203a68ecf7d8f3c3b4398b75ada83a31b48d1e51c0772cb569279a6a9402d97f',
 'setup_text.bin':'75389f468d5867ee35cbc767954def6d17719fb3191547cf346fe1f1b0f28ba7',
 'romstartup_text.bin':'f46553c0680c89a748dc8003d6a140b7e79e34551f928a18f9fe0aeb01767e31',
}
for name,digest in expected.items():
    p=ROOT/name
    check(f'SHA256 {name}',hashlib.sha256(p.read_bytes()).hexdigest()==digest)
check('ROMFS section byte length',len(rom)==4_459_788)
check('SR text section byte length',len(srt)==7_616_052)
check('CROM SR text section byte length',len(crom)==0x529E00)
check('setup_text section byte length',len(setup)==0x2BB8)
check('romstartup_text section byte length',len(romstart)==0x25C)

# B. Exact component header layout (5 headers x 5 checks = 25 checks)
component_specs={
 'pe':(0xE0B325E8,12,37,0xE070FBD1,0xE070AEC9,'pe'),
 'pe_events':(0xE0B33A98,6,4,0xE0712189,0xE0713E69,'pe_events'),
 'pen':(0xE0B4A91C,5,19,0xE072C8D1,0xE0746AE9,'pen'),
 'lib_power':(0xE0BC04F8,2,5,0xE093DF01,0xE093E291,'lib_power'),
 'lib_digital_sensor':(0xE0AA6A94,2,8,0xE058CD19,0xE058CD69,'lib_digital_sensor'),
}
parsed={}
for name,(addr,a_count,b_count,meta,accessor,label) in component_specs.items():
    v=struct.unpack_from('<17I',rom,addr-ROM_BASE)
    pA,cA,pB,cB,meta_got,flag,labelptr=v[:7]
    pC,cC,pD,cD,acc_got,extra=v[11:17]
    parsed[name]=(v,pA,cA,pB,cB)
    check(f'{name} label',cstr(rom,ROM_BASE,labelptr)==label)
    check(f'{name} A/B counts',cA==a_count and cB==b_count)
    check(f'{name} A->B boundary',pA+cA*24==pB)
    check(f'{name} B->label boundary',pB+cB*24==labelptr)
    check(f'{name} callback pointers',meta_got==meta and acc_got==accessor and (meta_got&1)==1 and (acc_got&1)==1)

# C. Component Table A / Table B service-key crosswalk (10 checks)
pe_v,pe_A,pe_ac,pe_B,pe_bc=parsed['pe']
pe_events_v,events_A,events_ac,events_B,events_bc=parsed['pe_events']
pen_v,pen_A,pen_ac,pen_B,pen_bc=parsed['pen']
pow_v,pow_A,pow_ac,pow_B,pow_bc=parsed['lib_power']
ds_v,ds_A,ds_ac,ds_B,ds_bc=parsed['lib_digital_sensor']
key1,key2=0x0001141F,0x00D68CDF
check('lib_power Table A key 0',record(rom,ROM_BASE,pow_A,0)[2]==key1)
check('lib_power Table A key 1',record(rom,ROM_BASE,pow_A,1)[2]==key2)
check('lib_power Table B dependency keys',[record(rom,ROM_BASE,pow_B,i)[2] for i in range(pow_bc)]==[0x10D49,0x10FD7,0x125AC,0x10FDB,0x11B6C])
check('PE Table B does not contain lib_power keys',all(record(rom,ROM_BASE,pe_B,i)[2] not in {key1,key2} for i in range(pe_bc)))
check('pe_events Table B does not contain lib_power keys',all(record(rom,ROM_BASE,events_B,i)[2] not in {key1,key2} for i in range(events_bc)))
check('pen Table B does not contain lib_power keys',all(record(rom,ROM_BASE,pen_B,i)[2] not in {key1,key2} for i in range(pen_bc)))
check('PE Table B retains RTP service key at index 36',record(rom,ROM_BASE,pe_B,36)[2]==0x0001229F)
check('lib_digital_sensor Table B[3] imports 0x1141F',record(rom,ROM_BASE,ds_B,3)[2]==key1)
check('lib_digital_sensor Table B does not contain 0xD68CDF',all(record(rom,ROM_BASE,ds_B,i)[2]!=key2 for i in range(ds_bc)))
check('lib_power advertised service keys differ from PE Table B',not any(record(rom,ROM_BASE,pe_B,i)[2] in {record(rom,ROM_BASE,pow_A,j)[2] for j in range(pow_ac)} for i in range(pe_bc)))

# D. Name-keyed Sirius provider / consumer structures (11 checks)
check('provider key string',cstr(rom,ROM_BASE,0xE0BC010C)=='siriusInstance')
check('lib_power descriptor key string',cstr(rom,ROM_BASE,0xE0BC0654)=='siriusInstance')
check('provider/consumer names byte-identical',bytes_at(rom,ROM_BASE,0xE0BC010C,15)==bytes_at(rom,ROM_BASE,0xE0BC0654,15))
check('provider initializer entry',u32(rom,ROM_BASE,0xE0DD26AC)==0xE093C781)
check('lib_power descriptor initializer entry',u32(rom,ROM_BASE,0xE0DD26B0)==0xE093E311)
check('provider-side accessor pointer in ROMFS',u32(rom,ROM_BASE,0xE0BC00CC)==0xE093C521)
check('lib_power descriptor accessor pointer in ROMFS',u32(rom,ROM_BASE,0xE0BC0534)==0xE093E291)
check('lib_power acquire pointer in ROMFS',u32(rom,ROM_BASE,0xE0BC05F4)==0xE093E2A1)
check('lib_power release pointer in ROMFS',u32(rom,ROM_BASE,0xE0BC05F8)==0xE093E2A9)
check('provider-side accessor target slot',0xC1D5E880+4==0xC1D5E884)
check('lib_power descriptor accessor target slot',0xC1D62B4C+4==0xC1D62B50)

# E. Raw code bytes and PE singleton calculation (7 checks)
code_checks={
 'PE instance accessor body':(0xE070AEC8,bytes.fromhex('46 f2 2c 61 cc f2 90 11 08 00 18 bf 01 f1 18 00 70 47')),
 'provider builder body':(0xE093C4E0,bytes.fromhex('40 f2 10 42 40 f2 80 4c ce f2 bc 02 ce f2 bc 0c 80 e8 04 10 41 64 70 47')),
 'provider accessor body':(0xE093C520,bytes.fromhex('4e f6 80 01 cc f2 d5 11 08 00 18 bf 08 1d 70 47')),
 'lib_power descriptor builder body':(0xE093E250,bytes.fromhex('40 f2 ec 52 40 f2 30 63 ce f2 bc 02 ce f2 bc 03 8c 46 80 e8 0c 10 70 47')),
 'lib_power descriptor accessor body':(0xE093E290,bytes.fromhex('42 f6 4c 31 cc f2 d6 11 08 00 18 bf 08 1d 70 47')),
 'lib_power descriptor initializer body':(0xE093E310,bytes.fromhex('40 f2 54 61 42 f6 4c 30 ce f2 bc 01 cc f2 d6 10 ff f7 96 bf')),
 'lib_power acquire wrapper body':(0xE093E2A0,bytes.fromhex('08 46 11 46 ff f7 d4 bc')),
}
for name,(addr,expected_bytes) in code_checks.items():
    check(name,bytes_at(srt,SRT_BASE,addr,len(expected_bytes))==expected_bytes)
check('PE accessor returned subobject offset',0xC190662C+0x18==0xC1906644)

# F. PE_POLICY mask and prior full-disassembly call audit (9 checks)
clients=(ROOT/'power_client_name_table.txt').read_text()
check('PE_POLICY client slot listed', 'slot 23 | bit 22' in clients and 'POWER_CLIENT_PE_POLICY' in clients)
check('PE_POLICY mask listed', 'mask 0x00400000 | POWER_CLIENT_PE_POLICY' in clients)
check('PE_POLICY mask arithmetic',1<<22==0x00400000)
xrefs=(ROOT/'direct_call_xref_audit.txt').read_text()
check('zero direct callers of provider accessor',re.search(r'E093C520 direct BL/B\.W refs: 0',xrefs) is not None)
check('zero direct callers of descriptor accessor',re.search(r'E093E290 direct BL/B\.W refs: 0',xrefs) is not None)
check('zero direct callers of lib_power acquire wrapper',re.search(r'E093E2A0 direct BL/B\.W refs: 0',xrefs) is not None)
check('zero direct callers of wrapper branch entry',re.search(r'E093E2A4 direct BL/B\.W refs: 0',xrefs) is not None)
check('14 direct acquire-helper references',re.search(r'E093DC50 direct BL/B\.W refs: 14',xrefs) is not None)
check('12 direct release-helper references',re.search(r'E093DC68 direct BL/B\.W refs: 12',xrefs) is not None)

# G. Direct-call mask examples and unresolved virtual candidate (6 checks)
power_audit=(ROOT/'power_acquire_callsite_audit.txt').read_text()
check('UDW callsite 0x10 recorded','e071447c' in power_audit.lower() and '2110' in power_audit.lower())
check('SCAN callsite 0x200 recorded','e0671b46' in power_audit.lower() and '0x200' in power_audit.lower())
check('PEN direct callsite 0x8 recorded','e0741712' in power_audit.lower() and '0x8' in power_audit.lower())
check('no fixed PE_POLICY mask in resolved callsite audit','0x00400000' not in power_audit.lower())
excerpts=(ROOT/'PE_Sirius_lib_power_disassembly.txt').read_text().lower()
check('unresolved virtual call excerpt preserved','e0837994:' in excerpts and 'blx\tr12' in excerpts)
check('stack literal 0x00400000 candidate preserved','e0837982:' in excerpts and '#0x400000' in excerpts)

# H. Secondary CROM reference scan (6 checks)
for value in [0xE093E2A1,0xE093DC50,0xC1D62B4C,0xC1D62B50,0xC1D5E884,0xC1906644,0xE0B325E8,0xE0BC04F8,0xE07BCF10,0x0001229F,0x0001141F,0x00D68CDF,0x00400000]:
    check(f'CROM no exact word {value:#010x}',struct.pack('<I',value) not in crom)
for token in [b'siriusInstance',b'lib_power',b'POWER_CLIENT',b'component',b'dependency',b'registry']:
    check(f'CROM no exact token {token.decode()}',token not in crom)

# I. Reproducible report/PDF integrity (4 checks)
docx=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision100_Part22_Step13_PE_Sirius_lib_power_Import_Trace_Addendum.docx'
pdf=ROOT/'Revision100_Addendum_QA.pdf'
check('Revision 100 DOCX present and nonempty',docx.exists() and docx.stat().st_size>0)
check('Revision 100 PDF present and nonempty',pdf.exists() and pdf.stat().st_size>0)
try:
    import fitz
    page_count=len(fitz.open(pdf))
except Exception:
    page_count=-1
check('Revision 100 PDF has 15 pages',page_count==15)
check('Revision 99 base addendum retained', (ROOT/'Previous_Revision99_Addendum.docx').exists())

failed=[x for x in checks if not x[1]]
for i,(name,passed) in enumerate(checks,1): print(f'{i:02d} {"PASS" if passed else "FAIL"} {name}')
print(f'\nRESULT: {len(checks)-len(failed)}/{len(checks)} PASS; {len(failed)} FAIL')
if failed: raise SystemExit(1)
