# Part 22 — Step 13 evidence package

**Scope:** PE component instance accessor, the two `siriusInstance` structures, component Table A/Table B imports, and the `lib_power` acquire/PE_POLICY caller path. Static analysis only.

## Principal results

1. The PE component instance accessor at `0xE070AEC8` returns `0xC1906644`, exactly `0xC190662C + 0x18`. This is a concrete address inside the previously identified Sirius singleton, not a string inference.
2. The rtpadapter ROMFS object contains two adjacent initializer entries which construct separate structures carrying the exact key `siriusInstance`:
   - provider-side named object: global `0xC1D5E880`, accessor returns slot address `0xC1D5E884`;
   - lib_power descriptor: global `0xC1D62B4C`, accessor returns slot address `0xC1D62B50`.
3. The PE instance accessor and these matching name-keyed structures are consistent with a PE/Sirius instance being exposed to the lib_power component through a generic named dependency resolver. **The resolver call and pointer transfer have not been recovered.**
4. The component import table provides a useful negative result. `lib_power` advertises Table A keys `0x1141F` and `0xD68CDF`. The `pe`, `pe_events` and `pen` Table B records do not contain either key. `lib_digital_sensor` Table B entry 3 does contain `0x1141F`.
5. The corrected power-client table still maps `POWER_CLIENT_PE_POLICY` to `0x00400000`. No reviewed direct call site to shared acquire helper `0xE093DC50` passes that fixed mask. The lib_power acquire wrapper `0xE093E2A0` has no direct BL/B.W callers in the retained `.srtext` image; indirect calls remain possible.
6. A separate CROM `.cromsrtext` image and small setup/startup sections were checked. They did not reveal the missing resolver. The main LBI `.startup_text` and `.load_text` sections remain a future target.

## What this does not prove

- It does not prove that the runtime resolver populates `0xC1D5E884` or `0xC1D62B50` with `0xC1906644`.
- It does not prove that PE directly imports the `lib_power` component through its numeric Table B records.
- It does not prove that PE requests `POWER_CLIENT_PE_POLICY`, or that the power path causes `rtp_manager.block_print`, `unblock_print`, or the PE blocked-state writer to execute.
- The unresolved indirect call near `0xE0837994` places `0x00400000` on the stack before a virtual call with different register arguments. It is not counted as a lib_power acquire call without resolving its vtable target and ABI.

## Evidence files

- `romfs_objs_rebuilt.bin`: complete reconstructed ROMFS object section used to parse exact component headers, Table A/B records, initializer pointers and string keys.
- `srtext_rebuilt.bin`: reconstructed executable section used to verify the PE accessor, registry constructors/accessors and lib_power wrapper instruction bytes.
- `cromsrtext.bin`, `setup_text.bin`, `romstartup_text.bin`: exact FHX sections examined in the secondary-image check.
- `component_dependency_crosswalk.txt`: decoded PE, pe_events, pen, lib_power and lib_digital_sensor component headers and table entries.
- `PE_Sirius_lib_power_disassembly.txt`: focused disassembly excerpts, including the unresolved `0x00400000` virtual-call setup.
- `direct_call_xref_audit.txt`, `power_acquire_callsite_audit.txt`, `power_client_name_table.txt`: prior full-disassembly audits and the corrected client name list.
- `SOURCE_INPUTS.txt`: sizes and SHA-256 identities of the upstream LBI, FHX, section and disassembly inputs.
- `verify_part22_step13.py`, `verification_output.txt`: reproducible structural and binary checks.
- `Previous_Revision99_Addendum.docx`, `Previous_Step12_Evidence_Package.zip`: prior addendum/evidence retained for continuity.
- `Revision100` DOCX and its QA PDF: current cumulative Steps 11–13 addendum.

## Verification

Run from the extracted package directory:

```bash
python verify_part22_step13.py
```

The verifier passed **102/102 checks**. It checks exact section hashes, component header/table boundaries, key relationships, function-pointer records, machine-code bytes, the PE singleton accessor calculation, CROM raw-reference scan, and preserved direct-call-audit counts. The complete original LBI and FHX source binaries remain separately identified by hash in `SOURCE_INPUTS.txt` and in the earlier Part 1 evidence package.

## Operational boundary

No printer connection, network request, firmware write, updater execution, debug activation, print/scan job or device-state change was performed in Step 13.
