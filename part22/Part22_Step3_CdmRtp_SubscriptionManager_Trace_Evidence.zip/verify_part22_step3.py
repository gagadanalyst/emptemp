#!/usr/bin/env python3
"""Verify selected Part 22 Step 3 firmware trace findings using immutable inputs.

Usage:
  python3 verify_part22_step3.py srtext_rebuilt.bin romfs_objs_rebuilt.bin hp_lbi_sections.elf srtext_disasm_all.txt

This is an offline structural verifier. It does not communicate with or modify a printer.
"""
from __future__ import annotations
import hashlib
import re
import struct
import sys
from pathlib import Path

SR_SHA = "10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7"
ROM_SHA = "227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3"
ELF_SHA = "25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7"
SR_BASE = 0xE0246070
ROM_BASE = 0xE09919C0


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def require(ok: bool, message: str) -> None:
    if not ok:
        raise SystemExit("FAIL: " + message)
    print("PASS: " + message)


def find_all(data: bytes, needle: bytes) -> list[int]:
    out = []
    pos = 0
    while True:
        pos = data.find(needle, pos)
        if pos < 0:
            return out
        out.append(pos)
        pos += 1


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit(__doc__)
    sr_path, rom_path, elf_path, dis_path = map(Path, sys.argv[1:])
    sr, rom, elf = sr_path.read_bytes(), rom_path.read_bytes(), elf_path.read_bytes()
    print(f"srtext bytes={len(sr)} sha256={sha(sr_path)}")
    print(f"romfs bytes={len(rom)} sha256={sha(rom_path)}")
    print(f"ELF bytes={len(elf)} sha256={sha(elf_path)}")
    require(len(sr) == 0x743634 and sha(sr_path) == SR_SHA, "verified .srtext size and SHA-256")
    require(len(rom) == 0x440D0C and sha(rom_path) == ROM_SHA, "verified .romfs_objs size and SHA-256")
    require(sha(elf_path) == ELF_SHA, "verified ELF SHA-256")
    require(elf[0x54:0x54 + len(sr)] == sr, "ELF embedded .srtext matches extracted section byte-for-byte")
    require(elf[0x743688:0x743688 + len(rom)] == rom, "ELF embedded .romfs_objs matches extracted section byte-for-byte")

    expected_sr = {
        b"/cdm/rtp/v1\0": 0xE02C2698,
        b"/cdm/rtp/v1/alerts\0": 0xE02C31E4,
        b"CdmRtpAlertProvider.cpp\0": 0xE02C322C,
        b"self\0": 0xE02C3244,
        b"/cdm/rtp/v1/alerts/\0": 0xE02C324C,
        b"%s%d\0": 0xE02C3260,
        b"com.hp.cdm.service.rtp.version.1.sharedTypes.alerts\0": 0xE02C3268,
        b"/cdm/rtp/v1/rtpAction\0": 0xE02C329C,
        b"/selectedAction\0": 0xE02C32B4,
        b"subscriptionManager.cpp\0": 0xE02E7EAC,
        b"devtelemetry.vcd.hp.com\0": 0xE02E7EC4,
        b"version\0": 0xE02E7EF0,
        b"deviceUuid\0": 0xE02E7EF8,
        b"productNumber\0": 0xE02E7F04,
        b"serialNumber\0": 0xE02E7F14,
        b"firmwareVersion\0": 0xE02E7F24,
        b"ink\0": 0xE02E7F34,
        b"engineType\0": 0xE02E7F38,
        b"currentDateTime\0": 0xE02E7F44,
        b"stemCellWaiting\0": 0xE02E7F54,
        b"e2eRtpRequired\0": 0xE02E7F64,
        b"flexRtpOptional\0": 0xE02E7F74,
        b"flexRtpOptionalDev\0": 0xE02E7F98,
        b"e2eRtpRequiredDev\0": 0xE02E7FAC,
        b"personaState\0": 0xE02E7FC0,
        b"serviceId\0": 0xE02E7FD8,
        b"originatorDetail\0": 0xE02E8054,
        b"ackToken\0": 0xE02E8074,
        b"metadata\0": 0xE02E8080,
        b"token\0": 0xE02E808C,
        b"subscriptionId\0": 0xE02E8094,
        b"/cdm/eventing/v1\0": 0xE02E80AC,
        b"%s/events/%s\0": 0xE02E80C0,
        b"eventsByCategory\0": 0xE02E80D0,
        b"rel\0": 0xE02E80E4,
        b"href\0": 0xE02E80E8,
        b"links\0": 0xE02E80F0,
        b"eventDetailType\0": 0xE02E80FC,
        b"vnd.hp.cdm.service.eventing.resource.\0": 0xE02E810C,
    }
    for s, vma in expected_sr.items():
        offsets = find_all(sr, s)
        require(any(SR_BASE + off == vma for off in offsets),
                f".srtext string {s.rstrip(bytes([0])).decode(errors='replace')} at {vma:#010x}")

    # CdmRtpAlertProvider callback in a ROMFS function-pointer block.
    fp = struct.unpack_from("<I", rom, 0xFCF8)[0]
    require(fp == 0xE02C34B1, "ROMFS pointer block at file offset 0xFCF8 contains Thumb pointer 0xE02C34B1")
    fp_words = struct.unpack_from("<15I", rom, 0xFCE4)
    require(fp_words[5] == 0xE02C34B1, "CdmRtpAlertProvider pointer occupies word 6 in 15-word function-pointer block")

    # RTP manager block/unblock registration records.
    for off, name_ptr_expected, fn_expected, label in [
        (0x1D16A8, 0xE0B633B8, 0xE07C1211, "rtp_manager.block_print"),
        (0x1D16B4, 0xE0B633D0, 0xE07C1219, "rtp_manager.unblock_print"),
    ]:
        name_ptr, fn_ptr, terminator = struct.unpack_from("<III", rom, off)
        require(name_ptr == name_ptr_expected and fn_ptr == fn_expected and terminator == 0,
                f"ROMFS registration record for {label} has expected name pointer/function pointer/terminator")
        name_off = name_ptr - ROM_BASE
        require(0 <= name_off < len(rom) and rom[name_off:name_off + len(label) + 1] == label.encode() + b"\0",
                f"ROMFS method name resolves to {label}")

    dis = dis_path.read_text(errors="replace")
    # Check reconstructed MOVW/MOVT global addresses in component-local code ranges.
    insn_re = re.compile(r"^\s*([0-9a-f]+):\s+.*?\b(movw|movt)\s+r(\d+),\s*#0x([0-9a-f]+)", re.I | re.M)
    insns = [(int(a, 16), op.lower(), int(reg), int(imm, 16)) for a, op, reg, imm in insn_re.findall(dis)]
    component_ranges = [(0xE02C2FC0, 0xE02C33A8), (0xE02C34B0, 0xE02C36B0),
                        (0xE02E2838, 0xE02E2840), (0xE02E6DB0, 0xE02E6E7A),
                        (0xE02E7080, 0xE02E73C4)]
    def has_constructed_address(target: int) -> bool:
        lo, hi = target & 0xFFFF, (target >> 16) & 0xFFFF
        for i, (addr, op, reg, imm) in enumerate(insns):
            if op != "movw" or imm != lo or not any(a <= addr < b for a, b in component_ranges):
                continue
            for a2, op2, reg2, imm2 in insns[i + 1:i + 6]:
                if a2 - addr > 0x20:
                    break
                if op2 == "movt" and reg2 == reg and imm2 == hi:
                    return True
        return False
    expected_globals = [
        (0xC13A6124, True, "CdmRtp core global root 0xC13A6124"),
        (0xC13A614C, True, "CdmRtp callback/resource global root 0xC13A614C"),
        (0xC13DA1B4, True, "subscriptionManager collection root 0xC13DA1B4"),
        (0xC13DA5A8, True, "subscriptionManager diagnostic global 0xC13DA5A8"),
        (0xC13DA470, True, "subscriptionManager callback global 0xC13DA470"),
        (0xC022A43C, True, "subscriptionManager guard global 0xC022A43C"),
        (0xC19FD498, False, "no constructed RTP provider slot table base 0xC19FD498 in examined component ranges"),
        (0xC19FD4C8, False, "no constructed RTP provider slot address 0xC19FD4C8 in examined component ranges"),
        (0xC15D6694, False, "no constructed IPP selector table base 0xC15D6694 in examined component ranges"),
    ]
    for target, wanted, label in expected_globals:
        require(has_constructed_address(target) is wanted, label)

    # Validate the four observed decrement-and-unsigned-bound checks in the manager worker.
    line_map = {}
    for line in dis.splitlines():
        m = re.match(r"^\s*([0-9a-f]+):\s*(.*)$", line, re.I)
        if m:
            line_map[int(m.group(1), 16)] = re.sub(r"\s+", " ", m.group(2).strip().lower())
    range_checks = {
        0xE02E7108: "subs r0, #0x1",
        0xE02E710A: "cmp.w r0, #0x12c",
        0xE02E711A: "subs r0, #0x1",
        0xE02E711C: "cmp.w r0, #0x12c",
        0xE02E712C: "subs r0, #0x1",
        0xE02E712E: "cmp r0, #0x5",
        0xE02E713C: "subs r0, #0x1",
        0xE02E713E: "cmp.w r0, #0x12c",
    }
    for site, expected_text in range_checks.items():
        require(expected_text in line_map.get(site, ""),
                f"subscriptionManager value check at {site:#010x}: {expected_text}")

    branch_re = re.compile(r"^\s*([0-9a-f]+):.*?\b(b(?:\.w)?|bl)\s+0x([0-9a-f]+)\b", re.I | re.M)
    refs: dict[int, list[int]] = {}
    for site_s, _mn, target_s in branch_re.findall(dis):
        refs.setdefault(int(target_s, 16), []).append(int(site_s, 16))
    expected_refs = {
        0xE02C2FC0: [0xE02C250A],
        0xE02C34B0: [],
        0xE02C35C8: [0xE02C34F4, 0xE02C3556],
        0xE02E7080: [0xE02E283A, 0xE02E6E44],
        0xE07BDFA8: [0xE07C1212, 0xE07C121A],
        0xE0251788: [0xE0251F7A, 0xE0251F8A],
        0xE07C1211: [],
        0xE07C1219: [],
    }
    for target, expected in expected_refs.items():
        actual = sorted(refs.get(target, []))
        actual_hex = [f"0x{x:08X}" for x in actual]
        require(actual == sorted(expected),
                f"full-disassembly direct branch/call refs to {target:#010x} are {actual_hex}")

    print("PASS: static trace verifier completed; indirect BLX targets remain outside this proof.")
    print("NO NETWORK OR PRINTER OPERATIONS WERE PERFORMED.")


if __name__ == "__main__":
    main()
