from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import hashlib

BASE = Path('/mnt/data/hp_part22/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision89_Part22_Step2_Alert_Key_Trace.docx')
OUT = Path('/mnt/data/hp_part22_step3/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision90_Part22_Step3_CdmRtp_SubscriptionManager_Trace.docx')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def shade(cell, fill='E8EEF5'):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd'); shd.set(qn('w:fill'), fill); tcPr.append(shd)

def set_cell(cell, text, bold=False, size=7.8, color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    r = p.add_run(str(text)); r.bold = bold; r.font.size = Pt(size)
    r.font.name = 'Aptos'
    r._element.get_or_add_rPr().rFonts.set(qn('w:ascii'), 'Aptos')
    r._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'), 'Aptos')
    if color: r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(doc, headers, rows, widths=None, size=7.7):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = 'Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.autofit = True
    for i, h in enumerate(headers): set_cell(t.rows[0].cells[i], h, True, size); shade(t.rows[0].cells[i])
    for row in rows:
        cells = t.add_row().cells
        for i, value in enumerate(row): set_cell(cells[i], value, False, size)
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths): row.cells[i].width = Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(1); p.paragraph_format.space_before=Pt(0)
    return t

def para(doc, text, bold_prefix=None, size=8.45, after=3.2):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    if bold_prefix and text.startswith(bold_prefix):
        r=p.add_run(bold_prefix); r.bold=True; r.font.size=Pt(size)
        r2=p.add_run(text[len(bold_prefix):]); r2.font.size=Pt(size)
    else:
        r=p.add_run(text); r.font.size=Pt(size)
    for rr in p.runs:
        rr.font.name='Aptos'; rr._element.get_or_add_rPr().rFonts.set(qn('w:ascii'),'Aptos'); rr._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'),'Aptos')
    return p

def heading(doc, text, level=2):
    p=doc.add_paragraph(text, style=f'Heading {level}')
    p.paragraph_format.keep_with_next=True
    p.paragraph_format.space_before=Pt(4 if level==2 else 6)
    p.paragraph_format.space_after=Pt(2)
    return p

def label(doc, text):
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(4)
    p.paragraph_format.space_before=Pt(0)
    r=p.add_run(text); r.bold=True; r.font.size=Pt(8.5); r.font.color.rgb=RGBColor(65,80,98)
    return p

doc=Document(str(BASE))

# PAGE 168
# Each page is deliberately bounded with a page break and compact tables to preserve one-page layout.
doc.add_page_break()
label(doc, 'REVISION 90 | PART 22 STEP 3 | PAGE 168')
heading(doc, 'CdmRtpAlertProvider: CDM alert resource and action path', 1)
para(doc, 'Scope: Continue the approved static-only trace in the package-verified 2629A LBI. This step follows the CdmRtpAlertProvider-labelled routines and subscriptionManager-labelled routines, compares their state/callback paths with the already recovered native print-block controls, and records direct-reference limits. The firmware inputs remained immutable. No printer access, network request, flash, reset, debug activation, or device-state change was performed.')
heading(doc, '90.1 Component role indicated by code and resources', 2)
para(doc, 'The CdmRtpAlertProvider.cpp source label is at 0xE02C322C. Nearby component-local strings define a CDM resource namespace: /cdm/rtp/v1/alerts (0xE02C31E4), /cdm/rtp/v1/alerts/ (0xE02C324C), the shared alert type com.hp.cdm.service.rtp.version.1.sharedTypes.alerts (0xE02C3268), /cdm/rtp/v1/rtpAction (0xE02C329C), and /selectedAction (0xE02C32B4). The code builds alert/resource objects and action/response metadata around these paths. This identifies a CDM REST/resource-provider role; it does not equate the provider with the separately registered rtp_manager print-block methods.')
table(doc, ['Routine / location', 'Observed operation', 'Evidence boundary'], [
    ('0xE02C2FC0; tail thunk 0xE02C2508-0xE02C250A', 'Obtains a collection through an object rooted at 0xC13A6124; loops through up to 25 records with 0x8C-byte stride; compares input fields against record offsets +0x04 and +0x10; constructs resource objects.', 'Direct native trace; exact C++ types and semantic field names remain unknown.'),
    ('0xE02C34B0; ROMFS pointer 0xE09A16B8', 'Handles a request/response path; calls 0xE02C35C8; dispatches success/failure callbacks through objects rooted at 0xC13A614C.', 'Function pointer is present in a ROMFS function-pointer block; table type/ownership is not proven.'),
    ('0xE02C35C8 / 0xE02C33A8', 'Builds callback payloads and invokes object vtable slots indirectly; event code 7 is passed in observed helper paths.', 'BLX targets are runtime-loaded and have not been resolved to print-control functions.'),
], widths=[1.55, 3.15, 2.0], size=7.45)
heading(doc, '90.2 Response and callback behavior', 2)
para(doc, 'The request handler compares the helper result with 0xC8 (HTTP 200). Its alternate response path forwards a non-200 status through an indirect callback; a separate no-result path passes 0x190 (HTTP 400). The code uses vtable offsets +0x10 and +0x18 from the 0xC13A614C object cluster. A second method pointer, 0xE02C34B1 (Thumb), is present at ROMFS file offset 0xFCF8 / VMA 0xE09A16B8 within a 15-word function-pointer block. It is not safe to call that block a C++ vtable without its type metadata.')
para(doc, 'Interpretation: the CdmRtpAlertProvider trace establishes a CDM alert-resource/action implementation and its internal callback plumbing. It does not reveal the source of subscribedPagesOutAccountProblem, nor prove that this provider calls rtp_manager.block_print, changes DSID_PRINT_ENGINE_BLOCKED, or owns the IPP job-admission state.')

# PAGE 169
doc.add_page_break()
label(doc, 'REVISION 90 | PART 22 STEP 3 | PAGE 170')
heading(doc, 'subscriptionManager: CDM eventing and telemetry context', 1)
heading(doc, '90.3 Component-local string context', 2)
para(doc, 'The subscriptionManager.cpp source label is at 0xE02E7EAC. Its adjacent string cluster describes generic device telemetry and CDM eventing: devtelemetry.vcd.hp.com, deviceUuid, productNumber, serialNumber, firmwareVersion, ink, engineType, currentDateTime, personaState, serviceId, subscriptionId, /cdm/eventing/v1, %s/events/%s, eventsByCategory, eventDetailType, and a vnd.hp.cdm.service.eventing.resource media-type prefix. Strings e2eRtpRequired and flexRtpOptional are also present, including Dev variants; their exact semantics are unresolved.')
table(doc, ['Address / routine', 'Observed behavior', 'Interpretation limit'], [
    ('0xE02E6DB0 orchestrator; 0xE02E6E44 worker call', 'Builds parsed data/context buffers, obtains a collection from 0xC13DA1B4 + 0x30, then calls worker 0xE02E7080.', 'The higher-level interface that dispatches the orchestrator is not fully resolved.'),
    ('0xE02E7080 worker', 'Accepts three pointer-like arguments in r0-r2; traverses a linked collection; compares/copies record fields and reconciles a record-like object.', 'Structure offsets are observed; business field names are not recovered.'),
    ('0xE02E2838-0xE02E283A', 'Adjustor thunk adds 0x88 to r0 and tail-branches to 0xE02E7080.', 'This is a second entry shim, not an independent worker implementation.'),
], widths=[1.55, 3.15, 2.0], size=7.45)
heading(doc, '90.4 Worker validation and state updates', 2)
para(doc, 'Worker 0xE02E7080 checks four presence/value pairs at offsets 0x700/0x704, 0x708/0x70C, 0x710/0x714, and 0x718/0x71C. Where each presence field is set, the corresponding value is decremented and range-checked: three values are constrained to 1-300 and one to 1-5. It also uses fields at +0x764 and +0x768 to record an internal flag/result state. The meanings of these structure fields cannot be assigned from the disassembly alone.')
para(doc, 'The worker updates/traverses records, builds a 0x18-byte event/service payload and calls 0xE06FEFF0 at 0xE02E7386 through global 0xC13DA470. It then uses helper 0xE02E5F78. Internal return/result values observed in r10 include 0, 1, 2 and 3; their external meaning is not decoded. Diagnostic source-location calls use global 0xC13DA5A8.')
heading(doc, '90.5 Separate global-state roots', 2)
table(doc, ['Code unit', 'Observed global roots', 'What the split means'], [
    ('CdmRtpAlertProvider', '0xC13A6124 and 0xC13A614C', 'Alert/resource collection and callback object cluster.'),
    ('subscriptionManager', '0xC13DA1B4, 0xC13DA5A8, 0xC13DA470; guard 0xC022A43C', 'Separate collection, diagnostic and event-service roots plus integrity/version guard.'),
], widths=[1.55, 2.6, 2.55], size=7.45)
para(doc, 'Conclusion: the filename subscriptionManager.cpp is not enough to label this the Instant Ink page-entitlement manager. Its surrounding vocabulary and observed callback path support a generic CDM eventing/telemetry subscription-management interpretation. This does not rule out another module handling commercial entitlement; it means this routine is not demonstrated to be that module.')

# PAGE 170
doc.add_page_break()
label(doc, 'REVISION 90 | PART 22 STEP 3 | PAGE 170')
heading(doc, 'Direct-edge audit against native print-block paths', 1)
heading(doc, '90.6 Existing print-block registrations', 2)
table(doc, ['ROMFS file offset / VMA', 'Registered name', 'Thumb entry'], [
    ('0x1D16A8 / 0xE0B63068', 'rtp_manager.block_print', '0xE07C1211'),
    ('0x1D16B4 / 0xE0B63074', 'rtp_manager.unblock_print', '0xE07C1219'),
], widths=[2.0, 2.75, 1.95], size=7.6)
para(doc, 'Both registered methods branch to shared helper 0xE07BDFA8. The helper obtains provider slot 12 from the table rooted at 0xC19FD498 (slot address 0xC19FD4C8) and calls the provider vtable method at +0xA0. This is the already-established RTP print-block dispatch; it is not the /cdm/rtp/v1 resource path described on page 169.')
heading(doc, '90.7 Full-disassembly direct-reference results', 2)
table(doc, ['Target', 'All direct branch/call sites in full .srtext disassembly', 'Result'], [
    ('CdmRtp body 0xE02C2FC0', '0xE02C250A (adjustor/tail thunk)', 'No direct call from subscriptionManager.'),
    ('CdmRtp callback 0xE02C34B0', 'No direct B/BL; Thumb pointer 0xE02C34B1 in ROMFS block.', 'Dynamically registered function pointer.'),
    ('CdmRtp helper 0xE02C35C8', '0xE02C34F4 and 0xE02C3556', 'Both calls originate within CdmRtp provider callback.'),
    ('subscriptionManager worker 0xE02E7080', '0xE02E283A (adjustor), 0xE02E6E44 (orchestrator)', 'No direct call from CdmRtp provider.'),
    ('RTP helper 0xE07BDFA8', '0xE07C1212 and 0xE07C121A only', 'Only block/unblock wrapper bodies.'),
    ('PE writer 0xE0251788', '0xE0251F7A and 0xE0251F8A only', 'Callers are outside both examined CDM routines.'),
], widths=[1.55, 2.7, 2.45], size=7.1)
para(doc, 'The examined CdmRtp and subscriptionManager ranges do not construct the RTP provider table base 0xC19FD498 / slot 0xC19FD4C8 or IPP selector table 0xC15D6694 by direct MOVW/MOVT address pairs. This is a static immediate-reference result, not a proof that an indirect callback cannot eventually reach those components.')
heading(doc, '90.8 Result, limits and next approval gate', 2)
para(doc, 'Step 3 establishes two distinct CDM-side implementations: CdmRtpAlertProvider is a REST alert/resource/action provider with indirect callback dispatch; subscriptionManager is surrounded by generic eventing/telemetry resources and reconciles record-like structures in the eventing/telemetry component. No direct branch/call path from either examined unit to rtp_manager.block_print/unblock_print or PE writer 0xE0251788 was found. No direct shared global root was identified. The remaining uncertainty is in runtime-bound callbacks and in the as-yet-untraced producer of the account/page-out alert.')
para(doc, 'Runtime context: the corrected local IPP Print-Job was accepted and created Job ID 1; the last status sample was processing, while the user reported that no physical page emerged. This is consistent with a later-stage block after IPP job creation, but does not identify the responsible firmware component.')
para(doc, 'Recommended next static increment (not started): trace CdmAlertsAlertProvider.cpp and CdmPrintAlertProvider.cpp to locate where alert 66220 / subscribedPagesOutAccountProblem is produced, and follow any direct data/control dependency into the RTP/PE paths. Stop after that bounded trace and request approval before further work.')
label(doc, 'PART 22 STEP 3 COMPLETE — WAIT FOR APPROVAL BEFORE STEP 4')

# Ensure the base remains intact through append-only editing; set output properties.
doc.core_properties.title = 'HP DeskJet 2855e Independent Printing and Scanning Investigation — Revision 90'
doc.core_properties.subject = 'Part 22 Step 3: CdmRtpAlertProvider and subscriptionManager static trace'
doc.core_properties.comments = 'Append-only update to Revision 89; static analysis only.'
OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUT)
print(f'OUTPUT={OUT}')
print(f'SIZE={OUT.stat().st_size}')
print(f'SHA256={sha(OUT)}')
print(f'BASE_SHA256={sha(BASE)}')
