# Part 22, Step 3 — CdmRtpAlertProvider and subscriptionManager static trace

## Scope and handling

This increment statically traces the `CdmRtpAlertProvider.cpp`-labelled routines and `subscriptionManager.cpp`-labelled routines in the package-verified 2629A `.srtext` image. It compares their direct call references and reconstructed global-object roots with the previously recovered `rtp_manager.block_print` / `unblock_print` dispatch, the PE blocked-state writer, and the IPP selector table.

The firmware inputs are treated as immutable. No printer access, network request, firmware write/flash, reset, debug activation, or device-state change was performed.

## Verified source corpus

The analysed sections are the extracted `.srtext` and `.romfs_objs` copies embedded in `hp_lbi_sections.elf`. Both embedded ranges match their extracted files byte-for-byte.

| Input | Size | SHA-256 |
|---|---:|---|
| `hp_lbi_sections.elf` | 12,076,084 B | `25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7` |
| `srtext_rebuilt.bin` | 7,616,052 B | `10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7` |
| `romfs_objs_rebuilt.bin` | 4,459,788 B | `227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3` |

`.srtext` VMA base is `0xE0246070`. `.romfs_objs` VMA base is `0xE09919C0`.

## Findings at a glance

1. **`CdmRtpAlertProvider` is a CDM resource/action provider.** Its compiled component-local strings include `/cdm/rtp/v1/alerts`, `/cdm/rtp/v1/alerts/`, the shared alert type `com.hp.cdm.service.rtp.version.1.sharedTypes.alerts`, `/cdm/rtp/v1/rtpAction`, and `/selectedAction`. Its code constructs alert/resource objects and performs response handling through indirect callbacks. This is not established to be the native `rtp_manager.block_print` API.
2. **`subscriptionManager.cpp` is surrounded by generic CDM eventing/telemetry vocabulary.** Its local string cluster includes `devtelemetry.vcd.hp.com`, device metadata fields, `subscriptionId`, `/cdm/eventing/v1`, `%s/events/%s`, `eventsByCategory`, and event-detail resource media types. The code reconciles record-like structures and calls a generic event/service callback. It is not proven to manage Instant Ink page entitlement.
3. **The two components use separate global-object clusters.** CdmRtp routines construct globals `0xC13A6124` and `0xC13A614C`; subscriptionManager uses `0xC13DA1B4`, `0xC13DA5A8`, `0xC13DA470`, and guard `0xC022A43C`. No shared global root or direct call edge between these code units was established.
4. **No direct branch/call from these routines reaches the native print-block path.** In the complete `.srtext` disassembly, direct references to helper `0xE07BDFA8` are the two branches from the native `block_print` / `unblock_print` wrappers. Direct references to PE writer `0xE0251788` are two callers at `0xE0251F7A` and `0xE0251F8A`, outside the examined CDM routines.
5. **The acronym overlap is not enough to equate the components.** `CdmRtpAlertProvider` exposes a `/cdm/rtp/v1` CDM resource, while `rtp_manager.block_print` / `unblock_print` are separately registered native methods. No static call/data edge links them in this step.

## CdmRtpAlertProvider trace

- Source filename literal: `CdmRtpAlertProvider.cpp` at `0xE02C322C`.
- Core method: `0xE02C2FC0`, reached from an adjustor/tail-call thunk at `0xE02C2508`–`0xE02C250A` which adds `0x50` to `r0`.
- The core obtains a collection through an object rooted at `0xC13A6124`, then iterates up to 25 records with stride `0x8C`. It compares input fields against record offsets `+0x04` and `+0x10`, constructs additional alert/resource objects, and fills resource metadata/links.
- Additional object/callback operations use global root `0xC13A614C` and virtual methods loaded from runtime objects.
- Method `0xE02C34B0` performs response/status handling. It calls helper `0xE02C35C8` at `0xE02C34F4` and `0xE02C3556`, compares the result with `0xC8` (HTTP 200), and routes success/failure through indirect callbacks at vtable offsets `+0x10` / `+0x18` on the `0xC13A614C` object cluster. A separate no-result path passes `0x190` (HTTP 400).
- `0xE02C34B1` is present as a Thumb function pointer at ROMFS file offset `0xFCF8` (VMA `0xE09A16B8`) inside a 15-word function-pointer block. The table's precise C++ type/ownership is not established; this evidence package calls it a function-pointer block, not a proven vtable.
- `0xE02C35C8` and `0xE02C33A8` perform payload/callback work through indirect methods. The destination methods are unresolved.

## subscriptionManager trace

- Source filename literal: `subscriptionManager.cpp` at `0xE02E7EAC`; observed source-location references at `0xE02E7242` and `0xE02E72AA` pass line values `0x121` and `0x13B` to diagnostic helpers.
- Orchestrator `0xE02E6DB0` creates parsed-data/context buffers, obtains a collection through `0xC13DA1B4 + 0x30`, and directly calls worker `0xE02E7080` at `0xE02E6E44`.
- Worker `0xE02E7080` accepts three pointer-like arguments in `r0`–`r2`, traverses a linked collection, validates four presence/value pairs at offsets `0x700/0x704`, `0x708/0x70C`, `0x710/0x714`, and `0x718/0x71C`. After decrementing each present value, the unsigned comparisons visibly accept 1–300, 1–300, 1–5, and 1–300 respectively (zero underflows and fails). Semantic field names are unknown.
- The worker reconciles record-like structures and calls event/service helper `0xE06FEFF0` at `0xE02E7386` with a 0x18-byte payload, using global `0xC13DA470`. It also uses helper `0xE02E5F78`, and returns internal values observed in `r10` of 0, 1, 2 or 3; their business meaning is not decoded.
- A second entry shim at `0xE02E2838` adds `0x88` to `r0` and tail-branches at `0xE02E283A` to `0xE02E7080`.
- The string context strongly supports a generic CDM eventing/telemetry interpretation. It does not prove the `e2eRtpRequired` or `flexRtpOptional` flags' exact meaning, and does not prove this component performs commercial print-page accounting.

## Print-block comparison

- ROMFS records at `0x1D16A8` and `0x1D16B4` map `rtp_manager.block_print` / `rtp_manager.unblock_print` to Thumb entries `0xE07C1211` / `0xE07C1219`.
- Both wrappers branch to shared helper `0xE07BDFA8`. The complete disassembly contains exactly two direct branch references to that helper: `0xE07C1212` and `0xE07C121A`.
- PE writer `0xE0251788` has two direct callers: `0xE0251F7A` and `0xE0251F8A`. Neither is in the inspected CdmRtp or subscriptionManager routines.
- The inspected ranges do not construct RTP provider table base `0xC19FD498` / slot `0xC19FD4C8` or IPP selector table `0xC15D6694` via direct MOVW/MOVT address pairs.
- No direct branch/call edge from the inspected CdmRtp or subscriptionManager routines to the native block/unblock wrappers, shared helper, or PE writer was found.

## Interpretation and limits

The static code establishes that CdmRtpAlertProvider is a CDM alert/resource/action provider and that subscriptionManager is embedded in a CDM eventing/telemetry context. The analysis does not establish that either code unit is the enforcement component for alert `66220` / `subscribedPagesOutAccountProblem`.

The firmware uses indirect BLX and runtime object/vtable dispatch. Without an authorized runtime trace, vendor symbols, or further static resolution of those callback targets, a callback could still lead to an unexamined component. Absence of a direct branch/call is not proof that no indirect path exists.

**Step 3 result:** no direct static connection from either examined component to `rtp_manager.block_print`, `rtp_manager.unblock_print`, or the PE blocked-state writer was established. The alert producer/enforcement edge remains unresolved.

**Next approval gate:** a separate static trace of `CdmAlertsAlertProvider.cpp` and `CdmPrintAlertProvider.cpp`, concentrating on where alert 66220 / `subscribedPagesOutAccountProblem` is produced and on any data/control dependency into RTP or PE. This is only a proposal; no Step 4 work is included here.

## Reproduction

Run the structural verifier against the previously preserved extracted section files and the full `.srtext` disassembly:

```bash
python3 verify_part22_step3.py srtext_rebuilt.bin romfs_objs_rebuilt.bin hp_lbi_sections.elf srtext_disasm_all.txt
```

The verifier checks section hashes/ELF identity, component-local string addresses, ROMFS method registration records, the CdmRtp function-pointer entry, known global address constructions, and full-disassembly immediate branch/call reference sets. It deliberately does not claim to resolve runtime-indirect BLX targets. The full disassembly input is not duplicated in this small evidence ZIP.
