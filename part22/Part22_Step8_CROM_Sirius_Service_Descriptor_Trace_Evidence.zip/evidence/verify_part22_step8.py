#!/usr/bin/env python3
"""Verify Part 22 Step 8 CROM strings, branch-skipped islands and raw-reference audit."""
from pathlib import Path
import hashlib, struct, csv, sys
ROOT = Path(__file__).resolve().parent
SECTION = ROOT / "CROM_SR_TEXT_SECTION.bin"
BASE = 0xE1A76480
EXPECTED_SIZE = 0x529E00
EXPECTED_SHA = "203a68ecf7d8f3c3b4398b75ada83a31b48d1e51c0772cb569279a6a9402d97f"

BRANCHES = [
    ("sirius_build_path", 0x724CA, 0xE092, 0x725F2, 0x724E5),
    ("sirius_memory_usb_fragment", 0x431C5A, 0xE1F4, 0x432046, 0x432036),
    ("sirius_mfg_service_mode_fragment", 0x444E5C, 0xE0FD, 0x44505A, 0x445016),
    ("provider_capabilities", 0x26BB2, 0xE161, 0x26E78, 0x26C45),
    ("provider_resource", 0x33E0C, 0xE340, 0x34490, 0x33E14),
    ("provider_diagnostic", 0x34B6C, 0xE06C, 0x34C48, 0x34BEE),
    ("provider_print_fragment", 0x4571A, 0xE04C, 0x457B6, 0x45745),
    ("service_system", 0x64694, 0xE061, 0x6475A, 0x646B5),
    ("service_ws_addressing", 0x148814, 0xE2BB, 0x148D8E, 0x1488B8),
    ("service_fault", 0x1491BC, 0xE356, 0x14986C, 0x1492EC),
    ("service_pe_data", 0x36B418, 0xE0FD, 0x36B616, 0x36B4CB),
    ("service_info_rtp", 0x3EEAA0, 0xE159, 0x3EED56, 0x3EEAD6),
    ("supply_service_provider", 0x62B7E, 0xE0FF, 0x62D80, 0x62BAF),
]

def calc_target(p, halfword):
    imm = halfword & 0x7FF
    if imm & 0x400:
        imm -= 0x800
    return p + 4 + (imm << 1)

def check(condition, label):
    global passed, failed
    if condition:
        passed += 1
        print(f"PASS {label}")
    else:
        failed += 1
        print(f"FAIL {label}")

passed = failed = 0
if not SECTION.exists():
    raise SystemExit(f"Missing {SECTION}")
s = SECTION.read_bytes()
check(len(s) == EXPECTED_SIZE, f"section size 0x{len(s):X}")
sha = hashlib.sha256(s).hexdigest()
check(sha == EXPECTED_SHA, f"section SHA256 {sha}")

# Raw exact occurrence inventory.
def occurrences(needle):
    found=[]; p=0
    while True:
        x=s.find(needle,p)
        if x < 0: break
        found.append(x); p=x+1
    return found
sirius = occurrences(b"sirius")
check(sirius == [0x724E5, 0x432036, 0x445016], f"three and only three lowercase sirius hits {list(map(hex,sirius))}")
check(len(occurrences(b"siriusInstance")) == 0, "no exact siriusInstance ASCII string")
check(len(occurrences(b"rtp_manager")) == 0, "no exact rtp_manager ASCII string")
check(len(occurrences(b"block_print")) == 0, "no exact block_print ASCII string")
check(len(occurrences(b"DSID_PRINT_ENGINE_BLOCKED")) == 0, "no exact DSID_PRINT_ENGINE_BLOCKED ASCII string")

# Every selected branch is a 16-bit Thumb unconditional forward B, verified against the actual bytes and target math.
for name,p,expected_hw,target,literal in BRANCHES:
    hw = struct.unpack_from("<H", s, p)[0]
    actual_target = calc_target(p, hw)
    check(hw == expected_hw, f"{name}: halfword 0x{hw:04X} == 0x{expected_hw:04X}")
    check(actual_target == target, f"{name}: decoded target 0x{actual_target:X} == 0x{target:X}")
    check(p + 2 <= literal < target, f"{name}: target literal 0x{literal:X} is in skipped interval [0x{p+2:X},0x{target:X})")

# Raw little-endian key/address values; absence is strictly a byte-scan result, not semantic proof.
raw_values = {
    "service_id_0x1229F": struct.pack("<I", 0x0001229F),
    "alert_list_selector_0x0061862B": struct.pack("<I", 0x0061862B),
    "alert_list_global_0xC136E704": struct.pack("<I", 0xC136E704),
    "alert_list_setter_0xE0277130": struct.pack("<I", 0xE0277130),
    "rtp_binder_0xE07BCF10": struct.pack("<I", 0xE07BCF10),
    "rtp_helper_0xE07BDFA8": struct.pack("<I", 0xE07BDFA8),
}
for label, needle in raw_values.items():
    check(len(occurrences(needle)) == 0, f"raw scan: no {label} literal")

# Descriptor/source vocabulary counts; not proof of runtime registration semantics.
counts = {
    "Provider": 5,
    "Service": 5,
    "service": 14,
    "register": 2,
    "Register": 1,
}
for term, expected in counts.items():
    got = len(occurrences(term.encode("ascii")))
    check(got == expected, f"raw source-text count {term}={got}")

print(f"SUMMARY passed={passed} failed={failed}")
sys.exit(0 if failed == 0 else 1)
