#!/usr/bin/env python3
"""Extract the FHX .cromsrtext section from the verified rebuilt FHX payload."""
from pathlib import Path
import argparse, hashlib

PAYLOAD_OFFSET = 0x71E640
SECTION_SIZE = 0x529E00
EXPECTED_SHA256 = "203a68ecf7d8f3c3b4398b75ada83a31b48d1e51c0772cb569279a6a9402d97f"

p = argparse.ArgumentParser()
p.add_argument("payload", type=Path, help="fhx_secure_payload_rebuilt.bin")
p.add_argument("output", type=Path, help="output section file")
a = p.parse_args()
payload = a.payload.read_bytes()
if len(payload) != 0xC4A900:
    raise SystemExit(f"Unexpected payload size: {len(payload)} (0x{len(payload):X})")
if PAYLOAD_OFFSET + SECTION_SIZE > len(payload):
    raise SystemExit("Section range exceeds payload")
section = payload[PAYLOAD_OFFSET:PAYLOAD_OFFSET + SECTION_SIZE]
digest = hashlib.sha256(section).hexdigest()
if digest != EXPECTED_SHA256:
    raise SystemExit(f"Section hash mismatch: {digest}")
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_bytes(section)
print(f"PASS .cromsrtext: VMA=0xE1A76480 offset=0x{PAYLOAD_OFFSET:X} size=0x{SECTION_SIZE:X}")
print(f"PASS SHA256 {digest}")
