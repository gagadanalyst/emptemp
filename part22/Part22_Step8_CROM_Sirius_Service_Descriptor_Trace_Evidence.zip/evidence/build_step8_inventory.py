from pathlib import Path
import csv, re, hashlib
root=Path(__file__).resolve().parent
s=(root/'CROM_SR_TEXT_SECTION.bin').read_bytes(); base=0xE1A76480
rows=[]
for term in [b'sirius',b'Provider',b'Service',b'service',b'register',b'Register']:
    p=0
    while True:
        x=s.find(term,p)
        if x<0: break
        rows.append((term.decode(),f'0x{x:X}',f'0x{base+x:X}'))
        p=x+1
with (root/'CROM_TERM_OCCURRENCES.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['term','section_offset','projected_vma']); w.writerows(rows)
# Carefully authored context summaries, retaining non-ASCII interruptions as fragments.
text='''PART 22 STEP 8 - CROM STRING / DATA-ISLAND CONTEXTS

Source section: .cromsrtext, VMA 0xE1A76480, payload offset 0x71E640, size 0x529E00.
The fragments below are literal byte-context descriptions. Non-ASCII bytes (including 0xFF and other values) interrupt
some strings, so punctuation and full normalized path names are not inferred where the bytes do not support them.

SIRIUS OCCURRENCES
1) Section offset 0x724E5, VMA 0xE1AE8965.
   Surrounding readable fragments include "/work/ab3/autobuild/sirius_hub_release/tassel_box_pp1/ram_na..."
   and a later "01.2629A..." fragment. The 0xFF/non-ASCII separators make this a fragment, not a complete path.
   A Thumb B at section offset 0x724CA (VMA 0xE1AE894A; bytes 92 E0; halfword 0xE092) branches to
   offset 0x725F2 (VMA 0xE1AE8A72). The literal falls in [0x724CC,0x725F2), length 0x126 bytes.

2) Section offset 0x432036, VMA 0xE1EA84B6.
   The literal begins "sirius_". The surrounding skipped bytes contain diagnostic fragments including
   "total ... of memory ... free" and file/USB-related text such as "/fs" and "/usba/". No source class or
   function identifier can be safely assigned to this isolated fragment.
   A Thumb B at offset 0x431C5A (VMA 0xE1EA80DA; bytes F4 E1; halfword 0xE1F4) branches to
   offset 0x432046 (VMA 0xE1EA84C6). The literal falls in [0x431C5C,0x432046), length 0x3EA bytes.

3) Section offset 0x445016, VMA 0xE1EBB496.
   The surrounding data begins with a fragment resembling "FsiriusInG" and includes readable command/diagnostic
   fragments "MFG_MODE_SET", "Service", "Mod", "SOFT" and "CNX/". These are manufacturer/service-mode
   data fragments, not proof of an active service-binding symbol.
   A Thumb B at offset 0x444E5C (VMA 0xE1EBB2DC; bytes FD E0; halfword 0xE0FD) branches to
   offset 0x44505A (VMA 0xE1EBB4DA). The literal falls in [0x444E5E,0x44505A), length 0x1FC bytes.

RELATED PROVIDER / SERVICE LABEL FRAGMENTS
- Provider at 0x26C45 (VMA 0xE1A9D0C5): nearby "/capabilities", resource-like text and Provider; local B at
  0x26BB2 -> 0x26E78 skips the literal.
- Provider at 0x33E14 (VMA 0xE1AAA294): .resource-like text and "Provider.cpp"; local B at
  0x33E0C -> 0x34490 skips the literal.
- Provider at 0x34BEE (VMA 0xE1AAB06E): diagnostic/v1, telemetry/type/version fragments and
  "CdmE...Provider.cpp"; local B at 0x34B6C -> 0x34C48 skips the literal.
- Provider at 0x45745 (VMA 0xE1ABBBC5): print-like fragment, resource fragment and Provider; local B at
  0x4571A -> 0x457B6 skips the literal.
- Provider at 0x61A39 (VMA 0xE1AD7EB9): adjacent fragments include "/cartridgeSetup", "/cdm/.../service/v1",
  resource text and a "CdmS...Provider.cpp" label. The nearby 16-bit candidate at 0x6126C is not a valid
  independent branch start in the local linear decode; no branch-skipped boundary is asserted here.
- lowercase service at 0x62BAF (VMA 0xE1AD902F): a regionReset fragment, "/cdm/supply/v1", service/version/resource
  fragments and "CdmS...Provider.cpp"; local B at 0x62B7E -> 0x62D80 skips the block.
- Service at 0x646B5 (VMA 0xE1ADAB35): "/cdm/system/v1" and "Service.cpp" fragments; local B at
  0x64694 -> 0x6475A skips the block.
- Service at 0x36B4CB (VMA 0xE1DE194B): "PE SERVICE DATA" and "ServiceData" fragments; local B at
  0x36B418 -> 0x36B616 skips the block.
- ServiceInfo at 0x3EEAD6 (VMA 0xE1E64F56): includes "RTP St...", "counters", "total_impr...", "report",
  "subscrip..." and other diagnostic fragments; local B at 0x3EEAA0 -> 0x3EED56 skips the block.
- Other uppercase Service occurrences at 0x1488B8 and 0x1492EC occur within SOAP/WS-Addressing and
  ServiceFaultValues-like resource text respectively; their local branch sites are recorded in the branch inventory.

Counts in the full section: sirius=3, Provider=5, Service=5, service=14, register=2, Register=1.
These are raw literal counts, not counts of executable methods, component registrations or live services.
'''
(root/'CROM_LITERAL_CONTEXTS.txt').write_text(text)
