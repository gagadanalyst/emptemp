# Part 22 Step 8 - branch-aware CROM `sirius` and service-string trace

## Scope

Static-only analysis of the FHX `.cromsrtext` section around its three lowercase `sirius` byte strings and relevant nearby `Provider`, `Service`, `service`, and `register` fragments. This step does not access the printer, submit network requests, change configuration, or modify firmware.

## Provenance and section mapping

The rebuilt FHX secure payload has size 12,888,320 bytes (`0xC4A900`) and SHA-256:

`aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858`

The 125-entry FHX directory maps `.cromsrtext` to VMA `0xE1A76480`, size `0x529E00` (5,414,400 bytes), payload offset `0x71E640`. The section ends at payload offset `0xC48440`. Its SHA-256 is:

`203a68ecf7d8f3c3b4398b75ada83a31b48d1e51c0772cb569279a6a9402d97f`

`CROM_SR_TEXT_SECTION.bin` is the exact extracted section. `extract_crom_section.py` reproduces it from the full rebuilt FHX payload. `FHX_DIRECTORY_125.csv` and `FHX_RELEVANT_DESCRIPTORS.txt` preserve the descriptor evidence.

The section has 256 distinct byte values, 154,254 zero bytes, 176,315 `0xFF` bytes, and Shannon entropy 7.5660934245 bits/byte, consistent with the previously reported inventory.

## Main findings

The three `sirius` hits are at section offsets `0x724E5`, `0x432036`, and `0x445016` (VMAs `0xE1AE8965`, `0xE1EA84B6`, and `0xE1EBB496`). Each lies inside a directly decoded 16-bit Thumb unconditional-branch skipped interval. The branch instruction bytes, target arithmetic and containment checks are retained in `BRANCH_BOUNDARY_INVENTORY.csv` and `LLVM_BRANCH_VERIFICATION.txt`.

The local data contexts differ:

1. A build-path fragment contains `autobuild/sirius_hub_release`, a `tassel_box_pp1` fragment, and a later `01.2629A` fragment.
2. A diagnostics/resource fragment contains `sirius_`, memory-usage text and filesystem/USB fragments.
3. A manufacturer/service-mode fragment contains `MFG_MODE_SET`, `Service`, `Mod`, `SOFT` and `CNX/` fragments.

The same CROM image contains multiple `Provider.cpp`, `Service.cpp`, `/cdm/supply/v1`, `/cdm/system/v1`, `PE SERVICE DATA`, and `ServiceInfo`/`RTP`/subscription/counter fragments. Several of these are also inside local branch-skipped regions. They are source/resource/diagnostic text fragments, not recovered runtime dispatcher methods or pointer registrations.

There is no exact `siriusInstance` string or `rtp_manager` string in this section. Raw little-endian scans also do not find the specific alert-list selector `0x0061862B`, alert-list field `0xC136E704`, setter `0xE0277130`, RTP service ID `0x0001229F`, RTP binder `0xE07BCF10`, or RTP helper `0xE07BDFA8`. These are raw byte-scan negatives only; they do not prove semantic absence if values are encoded, relocated, or supplied indirectly.

## Limits

- The full `.cromsrtext` image still has no complete entry-point map, mapping-symbol table, or global code/data boundary map.
- A forward branch proves that its individual skipped bytes are not executed along that branch path. It does not prove that no other branch or entry point reaches any byte within the interval.
- Some strings are interrupted by non-ASCII bytes. Descriptions preserve visible fragments rather than inventing complete normalized path names.
- The CROM provider/service vocabulary does not identify the caller of the Part 22 alert-list setter or the concrete pointer passed in `r3`.
- No causal connection from these strings to RTP print blocking or the PE blocked-state writer is established.

## Reproduction

```bash
python extract_crom_section.py /path/to/fhx_secure_payload_rebuilt.bin /tmp/CROM_SR_TEXT_SECTION.bin
python verify_part22_step8.py
python build_step8_inventory.py
```

`verify_part22_step8.py` checks section size/hash, all three `sirius` occurrences, all 13 selected branch encodings/targets/interval-containment facts, exact source-term counts, and raw literal absence for the key addresses/selectors. It does not rely on text extracted from the findings document.
