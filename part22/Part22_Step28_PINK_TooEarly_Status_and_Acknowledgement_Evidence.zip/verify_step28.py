#!/usr/bin/env python3
from pathlib import Path
import hashlib, struct, zipfile
import fitz
ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence'
DOCX=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision114_Part22_Step28_PINK_TooEarly_Status_and_Acknowledgement_Path_Addendum.docx'
PDF=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision114_Part22_Step28_PINK_TooEarly_Status_and_Acknowledgement_Path_Addendum.pdf'
checks=[]
def ck(name, ok): checks.append((name,bool(ok)))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
elf=E/'hp_lbi_sections.elf'; sr=E/'srtext_rebuilt.bin'; rom=E/'romfs_objs_rebuilt.bin'
for p in (elf,sr,rom): ck('source present '+p.name,p.is_file() and p.stat().st_size>0)
rom_b=rom.read_bytes(); sr_b=sr.read_bytes()
for v in (0x00012FB0,0x00012FC2,0x00012FC6): ck(f'ROMFS DSID value {v:08X}',struct.pack('<I',v) in rom_b)
for s in (b'DSID_CONSTAT_INK_SUBSCRIPTION_LEVEL',b'DSID_CONSTAT_USER_ACK_BITS_K',b'DSID_CONSTAT_USER_ACK_BITS_CMY'):
 ck('ROMFS DSID string '+s.decode(),s in rom_b)
# Service-key values are derived from the setter's successive compare constants.
service_1ff211=(0x00223EE5 - (0x100000000-0xFFFD_B32C)) & 0xFFFFFFFF
service_deed54=(0x00223EE5+0x0044059E+0x0078A8D1) & 0xFFFFFFFF
service_f8ae47=(service_deed54+0x00125DAB+0x00076348) & 0xFFFFFFFF
ck('setter maps C1443000+0x20 to service 0x001FF211',service_1ff211==0x001FF211)
ck('setter maps C1443000+0x1C to service 0x00DEED54',service_deed54==0x00DEED54)
ck('setter maps C1443000+0x30 to service 0x00F8AE47',service_f8ae47==0x00F8AE47)
setter=(E/'disassembly/service_dependency_setter_E0308D90.dis').read_text(errors='replace').lower()
reader=(E/'disassembly/constat_helper_mask_status_reader_E030B2A8.dis').read_text(errors='replace').lower()
updater=(E/'disassembly/constat_helper_pink_mask_updater_E030B478.dis').read_text(errors='replace').lower()
reason=(E/'disassembly/constat_reason_writer_E03076C0.dis').read_text(errors='replace').lower()
defnot=(E/'disassembly/def_not_candidate_method_family_E031E440_E031E8D0.dis').read_text(errors='replace').lower()
for label,txt,needle in [
 ('setter encodes service comparison with MOVW 0x6348 / MOVT 0x7',setter,'movw\tr2, #0x6348'),
 ('mask reader is E030B2A8',reader,'e030b2a8'),
 ('mask reader uses event 0x6C',reader,'#0x6c'),
 ('mask reader uses event 0x6D',reader,'#0x6d'),
 ('mask reader queries DSID 0x12FC2',reader,'#0x2fc2'),
 ('mask reader queries DSID 0x12FC6',reader,'#0x2fc6'),
 ('mask reader extracts bit 17',reader,'#0x11'),
 ('mask updater uses service slot +0x54',updater,'#0x54'),
 ('mask updater contains TooEarly bit 0x20000',updater,'0x20000'),
 ('reason writer accesses supply table +0x1AC8',reason,'0x1ac8'),
 ('reason writer uses group array +0x8F4',reason,'0x8f4'),
 ('reason writer updates can_print +0x2F8',reason,'0x2f8'),
 ('reason writer preserves exception 0x25',reason,'#0x25'),
 ('def_not candidate includes notification registration helper',defnot,'e031e558'),
 ('def_not candidate uses lock release helper',defnot,'e06ff618'),
]: ck(label,needle in txt)
ck('setter high half is MOVT 0x7', 'movt\tr2, #0x7' in setter)
# Ensure focused disassembly set complete.
dis_files=list((E/'disassembly').glob('*.dis'))
ck('focused disassembly files >= 8',len(dis_files)>=8)
ck('README/findings present',(E/'STEP28_FINDINGS.txt').is_file())
ck('DOCX exists',DOCX.is_file() and DOCX.stat().st_size>30000)
ck('PDF exists',PDF.is_file() and PDF.stat().st_size>10000)
if DOCX.is_file():
 try:
  with zipfile.ZipFile(DOCX) as z: ck('DOCX zip integrity',z.testzip() is None)
 except Exception: ck('DOCX zip integrity',False)
if PDF.is_file():
 try:
  d=fitz.open(PDF); ck('PDF page count is 3',len(d)==3); ck('PDF pages US Letter',all(abs(pg.rect.width-612)<1 and abs(pg.rect.height-792)<1 for pg in d))
 except Exception: ck('PDF opens',False)
# Save source hash record.
with (E/'SOURCE_INPUTS.txt').open('w') as f:
 for p in (elf,sr,rom): f.write(f'{sha(p)}  {p.name}  {p.stat().st_size} bytes\n')
# Save verifier output.
out='Step 28 focused verification: %d/%d PASS\n\n'%(sum(ok for _,ok in checks),len(checks))
for name,ok in checks: out+=('PASS' if ok else 'FAIL')+' | '+name+'\n'
(E/'verification_output.txt').write_text(out)
print(out)
if not all(ok for _,ok in checks): raise SystemExit(1)
