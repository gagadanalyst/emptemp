from pathlib import Path
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = Path('/mnt/data/hp_part22_step28')
DOCX = OUT / 'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision114_Part22_Step28_PINK_TooEarly_Status_and_Acknowledgement_Path_Addendum.docx'
doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.60); sec.bottom_margin = Inches(0.58); sec.left_margin = Inches(0.68); sec.right_margin = Inches(0.68)
styles = doc.styles
styles['Normal'].font.name='Aptos'; styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'),'Aptos'); styles['Normal'].font.size=Pt(9.0); styles['Normal'].font.color.rgb=RGBColor(44,55,66); styles['Normal'].paragraph_format.space_after=Pt(3)
for name,size,color in [('Title',23,'17365D'),('Heading 1',15,'17365D'),('Heading 2',10.5,'1F4E79')]:
 s=styles[name]; s.font.name='Aptos Display' if name=='Title' else 'Aptos'; s._element.rPr.rFonts.set(qn('w:eastAsia'),s.font.name); s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor.from_string(color); s.paragraph_format.space_before=Pt(4); s.paragraph_format.space_after=Pt(3)
header=sec.header.paragraphs[0]; header.text='HP DESKJET 2855e  |  INDEPENDENT PRINTING / SCANNING INVESTIGATION'; header.style='Caption'; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
for r in header.runs: r.font.name='Aptos'; r.font.size=Pt(7); r.font.bold=True; r.font.color.rgb=RGBColor(95,112,130)
footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('Revision 114  |  Part 22, Step 28  |  Static firmware analysis  |  Page '); r.font.size=Pt(7); r.font.color.rgb=RGBColor(100,110,120)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

def shade(cell, fill):
 tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)
def set_cell(cell,text,bold=False,color=None,size=7.8):
 cell.text=''; p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.keep_together=True
 r=p.add_run(str(text)); r.bold=bold; r.font.name='Aptos'; r.font.size=Pt(size)
 if color: r.font.color.rgb=RGBColor.from_string(color)
 cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def table(headers,rows,widths=None):
 t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'
 for i,h in enumerate(headers): set_cell(t.rows[0].cells[i],h,True,'FFFFFF',7.7); shade(t.rows[0].cells[i],'17365D')
 for n,row in enumerate(rows):
  cells=t.add_row().cells
  for i,v in enumerate(row):
   set_cell(cells[i],v,size=7.5)
   if n%2: shade(cells[i],'F1F5F9')
 if widths:
  for row in t.rows:
   for i,w in enumerate(widths): row.cells[i].width=Inches(w)
 p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
 return t
def para(text='', bold_prefix=None, italic=False):
 p=doc.add_paragraph(); p.paragraph_format.keep_together=True
 if bold_prefix and text.startswith(bold_prefix): p.add_run(bold_prefix).bold=True; p.add_run(text[len(bold_prefix):])
 else:
  r=p.add_run(text); r.italic=italic
 return p
def bullet(text):
 p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(1.5); p.paragraph_format.keep_together=True; p.add_run(text); return p

# Page 1
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('FIRMWARE INVESTIGATION ADDENDUM'); r.bold=True; r.font.size=Pt(8.5); r.font.color.rgb=RGBColor(31,78,121)
p=doc.add_paragraph(style='Title'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.add_run('PINK TooEarly Mask: Status and\nAcknowledgement Path')
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Revision 114  |  Part 22, Step 28  |  20 November 2026'); r.font.size=Pt(8.5); r.font.color.rgb=RGBColor(90,105,120)

p=doc.add_paragraph(); p.paragraph_format.keep_together=True
r=p.add_run('Primary finding: '); r.bold=True; r.font.color.rgb=RGBColor(31,78,121)
p.add_run('The firmware now provides an executable write-and-read path for the exact PINK supplyInksubTooEarly flag (0x00020000). A ConStat helper updater sets bit 17 in a per-supply mask; a separate status decoder reads the mask, extracts bit 17, and writes a caller-supplied status byte. The examined reader routes through user-acknowledgement DSIDs, not the ConStat reason insertion API.')

p=doc.add_paragraph(style='Heading 1'); p.add_run('1. The three service dependencies are distinct')
para('The setter 0xE0308D90 maps service IDs to three separate fields on the object returned by 0xE0308F10 (C1443000). The keys are reconstructed from the complete subtraction path and checked against the ROMFS descriptor records.')
table(['Object field','Service ID','Observed role in this step'],[
 ('C1443000 + 0x20','0x001FF211','PINK per-supply mask update (+0x54) and read (+0x50) interface'),
 ('C1443000 + 0x1C','0x00DEED54','DSID access used for user-acknowledgement fields'),
 ('C1443000 + 0x30','0x00F8AE47','Notification / reason-ingress dependency from Step 27; concrete provider unresolved'),
],[1.45,1.25,3.35])
para('These fields must not be treated as one generic service: the PINK mask data, DSID acknowledgements, and notification/reason-ingress callbacks enter through different providers.')

p=doc.add_paragraph(style='Heading 1'); p.add_run('2. Executable TooEarly mask update')
para('Function 0xE030B478 derives a per-supply index from the incoming supply key, builds a mask according to selector r4 and state r6, and invokes the injected provider at C1443000 + 0x20 through virtual slot +0x54. The selector/state case that creates the TooEarly bit is:')
table(['Selector r4','State r6','Mask bits written','Interpretation'],[
 ('1','1','0x00020000 | 0x00000040','Includes supplyInksubTooEarly'),
 ('1','2','0x00020000','TooEarly bit only'),
 ('1','3','0x00000040','Other status bit only'),
],[1.05,0.85,1.9,2.25])
para('The 0x00020000 bit is therefore produced by an executable state transition, not only named in PINK_supply_errors_t metadata.')

# Page 2
doc.add_page_break()
p=doc.add_paragraph(style='Heading 1'); p.add_run('3. The exact bit is read by a status decoder')
para('Function 0xE030B2A8 is a separate status-decoding method. It selects a DSID context based on its event selector and then obtains a per-supply mask through the provider field C1443000 + 0x20, virtual slot +0x50. It keeps the returned mask in r5.')
table(['Event selector','DSID queried','ROMFS DSID label'],[
 ('0x6C','0x00012FC2','DSID_CONSTAT_USER_ACK_BITS_K'),
 ('0x6D','0x00012FC6','DSID_CONSTAT_USER_ACK_BITS_CMY'),
],[1.2,1.4,3.35])
para('The DSID labels and numbers are paired in the ROMFS metadata table. They are user-acknowledgement bit fields, not the Ink Subscription consumable-error reasons.')

p=doc.add_paragraph(style='Heading 2'); p.add_run('Bit-17 extraction')
para('In the r8 = 1 selector branch, the decoder extracts bit 17 from the mask with `UBFX r0, r5, #0x11, #1` and writes the result to the caller-provided byte pointer. The r4 = 2 branch leaves that value as the output; when r4 = 1, a later bit-6 assignment overwrites the same byte. This is a concrete read of the TooEarly flag in an acknowledgement/status calculation.')

p=doc.add_paragraph(style='Heading 1'); p.add_run('4. Why this is not yet the print-block conversion')
bullet('The status decoder 0xE030B2A8 does not call 0xE03076C0, does not insert a ConStat consumable-error reason, and does not write DSID_PRINT_ENGINE_BLOCKED.')
bullet('The separate ConStat reason writer 0xE03076C0 stores reasons in groups at this +0x8F4 (0x40-byte stride), updates can_print at this +0x2F8, and accesses a per-supply record at this +0x1AC8 (8-byte stride).')
bullet('Its special switch branches use decimal values 11, 12, and 13 and update mask bits 0x01000000, 0x02000000, and 0x00800000. Those are not PINK InkSub bits 0x00010000/0x00020000/0x00040000, and are not ConStat InkSub reason codes 0x12/0x13/0x14 (decimal 18/19/20).')
para('The PINK functions and the ConStat reason writer use the same object-relative per-supply record layout and supply-index helper, but the runtime identity of their `this` pointers is not proven. This is a structural link, not evidence that the TooEarly flag is converted into reason 0x13.')

# Page 3
doc.add_page_break()
p=doc.add_paragraph(style='Heading 1'); p.add_run('5. Correction to the Step 27 provider assumption')
para('The Step 27 report identified service 0x00F8AE47 at C1443000 + 0x30 and followed it into the ConStat reason-ingress callback family. The separate ROMFS descriptor at 0xE09B3AC0 associates that same key with the label `def_not` and five method pointers.')
para("Inspection of the candidate method family shows that its +0x18 thunk reaches 0xE031E558, which registers a notification key and callback pointer in a global table. Its return is a lock-release status (0 on success, -1 on release failure), not a demonstrated PINK/ConStat reason value. The ConStat callback's argument preparation also does not match a clean direct reason-value getter contract. Consequently, `def_not` is not accepted as the confirmed implementation of the service at C1443000 + 0x30. The actual provider remains unresolved, and Step 27's description of +0x18 as a confirmed reason-value source is withdrawn.")

p=doc.add_paragraph(style='Heading 1'); p.add_run('6. Current causal model')
table(['Path','What is established','What remains open'],[
 ('PINK mask update','0xE030B478 writes the 0x00020000 TooEarly bit through service 0x1FF211.','Runtime provider pointer and the upstream event/state source.'),
 ('PINK mask status','0xE030B2A8 reads the mask and exports bit 17 into a user-ack/status output.','The caller and final destination of the output byte.'),
 ('ConStat reason insertion','0xE03076C0 updates reason groups and can_print.','Which caller inserts reason 19 (0x13) in response to TooEarly.'),
 ('Service 0xF8AE47','Dependency field and reason-ingress callbacks are confirmed.','Concrete implementation and its actual return semantics.'),
],[1.35,2.55,2.1])

p=doc.add_paragraph(style='Heading 1'); p.add_run('7. Next target and limitations')
para('The next most useful trace is the caller and destination of the status byte produced by 0xE030B2A8. In parallel, identify the dynamic implementation behind C1443000 + 0x30 and find any direct or indirect caller that inserts decimal reason 19 (0x13) from the TooEarly supply state. The separate DSID_CONSTAT_INK_SUBSCRIPTION_LEVEL (0x12FB0) getter remains another input to inspect, but no connection from that value to reason 0x13 is established here.')
para('Static firmware analysis does not establish which flag was active on the printer during the failed Print-Job. No live device request, physical print/scan, firmware write, or device modification was performed.')

p=doc.add_paragraph(style='Heading 2'); p.add_run('Evidence package and QA')
para('The evidence ZIP contains the ELF and rebuilt source binaries, focused Thumb disassembly, ROMFS DSID/service crosswalks, Step 27 and Step 24 baselines, the verifier, hashes, and this report. The report is a standalone Step 28 addendum, not a replacement for the full investigation archive.')

for t in doc.tables:
 for row in t.rows:
  for cell in row.cells:
   for p in cell.paragraphs: p.paragraph_format.keep_together=True
props=doc.core_properties; props.title='HP DeskJet 2855e Investigation - Revision 114 Step 28'; props.subject='PINK TooEarly mask status and acknowledgement path'; props.author='OpenAI'; props.keywords='HP DeskJet 2855e, PINK, TooEarly, ConStat, user acknowledgement, firmware'
doc.save(DOCX)
print(DOCX)
