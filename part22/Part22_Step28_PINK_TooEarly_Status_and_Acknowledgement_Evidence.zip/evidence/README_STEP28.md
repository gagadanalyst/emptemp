# Part 22 — Step 28 evidence

This package preserves the direct PINK TooEarly update/read path and keeps the user-acknowledgement status flow separate from ConStat print-block reason insertion.

## Primary addresses

- `0xE030B478`: `constat_helper` mask updater; service `0x001FF211` at `C1443000 + 0x20`, virtual slot `+0x54`.
- `0xE030B2A8`: status decoder; chooses DSID `0x12FC2` or `0x12FC6`, reads mask through service `0x001FF211` slot `+0x50`, extracts bit 17 (`0x00020000`) to an output byte.
- `0xE03076C0`: ConStat reason-group writer; modifies separate reason groups and `can_print`, while also touching the same object-relative per-supply record layout. No direct `0x20000 -> 0x13` conversion is established.
- `0xE0308D90`: service dependency setter mapping `C1443000 + 0x20`, `+0x1C`, and `+0x30` to IDs `0x1FF211`, `0xDEED54`, and `0xF8AE47`.

## Contents

- `hp_lbi_sections.elf`, `srtext_rebuilt.bin`, `romfs_objs_rebuilt.bin`: exact static inputs used for this step.
- `disassembly/`: focused Thumb disassembly for the updater, status reader, reason writer, service setter, subscription-level getter, and the candidate `def_not` method family.
- `crosswalks/`: service-field, PINK-to-status, and ConStat-reason namespace crosswalks.
- `baselines/`: Step 24/27 evidence and Part 8 component-registry crosswalk baseline.
- `STEP28_FINDINGS.txt`, `verification_output.txt`, and `SOURCE_INPUTS.txt`: findings, test output, and source hashes.

All conclusions are static. No printer communication, printing, scanning, or firmware modification occurred.
