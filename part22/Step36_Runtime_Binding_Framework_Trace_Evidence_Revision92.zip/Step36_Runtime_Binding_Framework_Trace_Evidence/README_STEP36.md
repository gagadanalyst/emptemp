# Step 36 - Runtime Binding Framework Trace

Scope: offline static analysis of the HP DeskJet 2855e firmware; no printer interaction, live execution, or firmware modification.

## Result

Two potential framework routes are now distinguished. First, `0xE0303558` can dispatch through vtable `+0x268`, the `siriusInstance` setter slot, but obtains its receiver from globals `0xC143E904/0xC143E908`; identity with singleton `0xC193B3C0` is unproven.

Second, the constructor wrapper `0xE0747088` inserts node `0xC020EC30` into a shared singly linked list rooted at `0xC1D63BD4`. The same root receives nodes `0xC01E05E8` and `0xC01E05F4` from `0xE0308B70`. The list consumer `0xE09811E4` removes nodes and invokes each callback at node `+0x08`, passing `2` when node `+0x04` is nonzero. This proves callback execution exists, but the mode and callback fields for the Sirius node are outside the retained ELF sections and remain unresolved.

The drain is reached through `0xE0981500` from `0xE0983DC2`, itself reached by a tail branch from `0xE093E746`. The static evidence does not establish this as a boot-wide initializer or show that the Sirius node callback calls `0xE0747130`.

The `lib_handle` ROMFS metadata contains selector `0x00DFB904`, `lib_hda`, and adjacent `siriusInstance` text; this remains an association, not a proven pointer handoff. A separate ROMFS occurrence of function pointer `0xE0747089` is in an address-sorted function index, not evidence of constructor invocation.

## Files

- `step36_verified_disassembly.txt`: exact recovered disassembly excerpts for constructor, setter, dispatcher, linked-list insertion/walker, and relevant callers.
- `step36_romfs_records.txt`: decoded ROMFS words/strings and the function-address-index cross-check.
- `step36_cross_reference_report.txt`: call paths, counts, limitations and corrected interpretation.
- `step36_source_hashes.txt`: SHA-256 fingerprints of the disassembly, ELF, reconstructed sections and payload.
- `verify_step36.py`: focused reproducibility verifier.
- `verification_output.txt`: verifier run result.
- `hash_manifest.sha256`: hashes of package files (excluding itself).

## Important constraints

Do not treat the list insertion call as the setter call. The list is a real callback-execution mechanism, but the Sirius node's callback pointer is not recovered from the available ELF. Do not conflate this Part22 trace with older Part5 traces using different `siriusInstance` addresses/layouts.
