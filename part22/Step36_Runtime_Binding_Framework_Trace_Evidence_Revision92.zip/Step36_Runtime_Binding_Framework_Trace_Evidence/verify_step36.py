#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, struct, sys
ROOT=Path('/mnt/data/firmware_recovery')
DIS=ROOT/'srtext_full.dis'
BASE=ROOT/'extracted/Part1_RTP_Provider_Trace_Evidence_Package/part1_rtp_provider_trace'
ROM=BASE/'romfs_objs_rebuilt.bin'
D=DIS.read_text(errors='replace')
B=ROM.read_bytes(); ROM_BASE=0xE09919C0
checks=[]
def check(name, cond): checks.append((name,bool(cond)))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def word(addr): return struct.unpack_from('<I',B,addr-ROM_BASE)[0]
def string(addr): return B[addr-ROM_BASE:addr-ROM_BASE+80].split(b'\0',1)[0].decode('ascii','replace')
check('constructor zeroes +0x1C..+0x28', 'e0746a48:' in D and 'stm.w	lr, {r0, r2, r3, r12}' in D)
check('constructor publishes at C193B3C0', 'e0746a72:' in D and 'e0746a7a:' in D)
check('setter writes +0x20', 'e074725e:' in D and 'str	r3, [r0, #0x20]' in D)
check('setter writes +0x24', 'e0747262:' in D and 'str	r3, [r0, #0x24]' in D)
check('no direct BL to setter', not re.search(r'bl\w*\s+0x[eE]0747130',D))
check('generic helper has vtable +0x268 indirect dispatch', 'e03035c4:' in D and 'ldr.w	r3, [r0, #0x268]' in D and 'e03035cc:' in D and 'blx	r3' in D)
check('generic wrapper obtains receiver through E0308C48', 'bl	0xe0308c48' in D and 'bl	0xe0303558' in D)
check('receiver selection checks second object vtable +0x298', 'e0308c58:' in D and 'ldr.w	r1, [r0, #0x298]' in D)
check('receiver globals are C143E904/C143E908', 'movw	r5, #0xe904' in D and 'movt	r5, #0xc143' in D)
check('Sirius wrapper inserts C020EC30', 'e074709e:' in D and 'movw	r0, #0xec30' in D and 'movt	r0, #0xc020' in D and 'bl	0xe0981216' in D)
check('list insertion root is C1D63BD4', 'e098121a:' in D and 'movt	r1, #0xc1d6' in D and 'e0981230:' in D and 'str	r0, [r1]' in D)
check('list insert is head-prepend and singly linked', 'e098122e:' in D and 'str	r2, [r0]' in D and 'e0981230:' in D)
check('shared initializer inserts C01E05E8 and C01E05F4', 'movw	r0, #0x5e8' in D and 'movw	r0, #0x5f4' in D and 'movt	r0, #0xc01e' in D)
check('callback walker reads next/mode/callback fields', 'e09811ea:' in D and 'ldr	r0, [r1]' in D and 'e09811ee:' in D and 'ldr	r0, [r1, #0x4]' in D and 'e09811f0:' in D and 'ldr	r1, [r1, #0x8]' in D)
check('callback walker passes mode argument 2', 'e09811f6:' in D and 'movs	r1, #0x2' in D and 'e09811f8:' in D and 'blx	r2' in D)
check('callback drain wrapper uses C1D63BD4', 'e0981208:' in D and 'movt	r0, #0xc1d6' in D and 'e0981210:' in D)
check('E0981500 drains both lists', 'e0981502:' in D and 'bl	0xe0981470' in D and 'e0981506:' in D and 'bl	0xe0981206' in D)
check('only one direct call to E0981500', sum('bl	0xe0981500' in line for line in D.splitlines())==1)
check('only one direct callback-list drain call', sum('bl	0xe0981206' in line for line in D.splitlines())==1)
check('parser/registration tail path reaches E0983DC2', 'e093e746:' in D and 'b.w	0xe0983dc2' in D and 'e0983dd2:' in D and 'bl	0xe0981500' in D)
check('ROMFS lib_handle selector 0x00DFB904', word(0xE0AB0CDC)==0x00DFB904)
check('ROMFS lib_hda and siriusInstance strings', string(0xE0AB0D34)=='lib_hda' and string(0xE0AB0D3C)=='siriusInstance')
check('metadata callback table first pointer', word(0xE0AB0C5C)==0xE05996B1)
idx=[word(a) for a in range(0xE0DD2400,0xE0DD26C0,4)]
check('176-word code-address index strictly ascending', len(idx)==176 and all(a<b for a,b in zip(idx,idx[1:])))
check('E0747089 is indexed, not a 22-entry execution-table member', word(0xE0DD24E8)==0xE0747089 and 0xE0747089 not in [word(a) for a in range(0xE0DD2014,0xE0DD2014+22*4,4)])
check('callback execution table at E0DD26C8 is empty', word(0xE0DD26C8)==0)
check('Sirius initializer pairs MOVW #0xEC30 with MOVT #0xC020', 'e074709e:' in D and 'movw	r0, #0xec30' in D and 'e07470a2:' in D and 'movt	r0, #0xc020' in D)
check('source disassembly SHA unchanged', sha(DIS)=='33da87a4babddaa1c6407d69e9a6a190781f0503a653b89b52f682e3fb015956')
for name,ok in checks: print(('PASS' if ok else 'FAIL')+'  '+name)
print(f'RESULT: {sum(ok for _,ok in checks)}/{len(checks)} checks passed')
sys.exit(0 if all(ok for _,ok in checks) else 1)
