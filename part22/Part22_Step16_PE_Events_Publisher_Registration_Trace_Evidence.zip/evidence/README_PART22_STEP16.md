# Part 22 Step 16 — PE events publisher registration trace

## Scope

Offline static trace of the `pe_events` component metadata, the registered callback setter, the PE event relay, the `pe_events.list` / `DSID_PE_EVENT_ID_NOTIFY` metadata, and the seven subscriber registrations for event ID `0x0001347F`.

## Main result

A ROMFS pointer at `0xE0B33A6C` stores Thumb pointer `0xE0712199`. Its target, `0xE0712198`, stores its incoming `r1` into global callback slot `0xC190A144`. The PE relay at `0xE07126B8` reads that same global and, if non-null, calls it with event ID `0x0001347F` and a stack event envelope.

The `pe_events` component header at `0xE0B33A98` carries one Array C record `(0x0000052C, 0x0001347F)` and no Array D records. The adjacent ROMFS metadata names `pe_events.list`, key `0x00011570`, and `DSID_PE_EVENT_ID_NOTIFY`. The component also exposes metadata callback `0xE0712189` and instance accessor `0xE0713E69`.

Seven other components have D callbacks for the same event ID, all using context `0xE09680D9`.

## Limits

The runtime caller of setter `0xE0712198`, the concrete publisher pointer supplied in `r1`, and the runtime resolver invocation are not recovered. This finding does not connect the event to alert 66220, the PE blocked-state DSID, or native RTP block/unblock methods.

## Reproduction

Run:

```bash
python verify_part22_step16.py
```

The verifier checks source hashes, ROMFS structures, function-pointer and instruction bytes, component metadata, the service label, the event ID, subscriber tuples, and bounded direct-reference evidence.
