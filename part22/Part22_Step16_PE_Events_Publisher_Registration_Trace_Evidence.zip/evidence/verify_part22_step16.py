#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, re, struct, sys
ROOT = Path(__file__).resolve().parent
checks = []
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def u32(buf, base, address):
    return struct.unpack_from('<I', buf, address-base)[0]

def contains(buf, base, address, expected):
    off=address-base
    return buf[off:off+len(expected)] == expected

# Immutable source identities (from the verified Part 1 / Step 15 corpus).
sr_path = ROOT/'source_srtext_rebuilt.bin'
rom_path = ROOT/'source_romfs_objs_rebuilt.bin'
expected_hashes = {
    'source_srtext_rebuilt.bin': '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
    'source_romfs_objs_rebuilt.bin': '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
}
for fn, expected in expected_hashes.items():
    p=ROOT/fn
    check(f'{fn} exists', p.exists(), str(p))
    check(f'{fn} sha256', p.exists() and sha(p)==expected, sha(p) if p.exists() else 'missing')

sr=sr_path.read_bytes(); rom=rom_path.read_bytes()
sbase=0xE0246070; rbase=0xE09919C0
check('srtext size', len(sr)==7616052, f'{len(sr)} bytes')
check('romfs size', len(rom)==4459788, f'{len(rom)} bytes')

# pe_events standard component header and C-record.
header=0xE0B33A98
header_words=[u32(rom,rbase,header+i*4) for i in range(17)]
expected_header=[0xE0B33AD8,6,0xE0B33B68,4,0xE0712189,1,0xE0B33BC8,0,0,0,0,0xE0B33BD4,1,0,0,0xE0713E69,0]
check('pe_events header fields', header_words==expected_header, ' '.join(f'{v:08X}' for v in header_words))
check('pe_events component label', rom[0xE0B33BC8-rbase:0xE0B33BC8-rbase+10]==b'pe_events\x00')
check('pe_events metadata callback pointer', u32(rom,rbase,0xE0B33AA8)==0xE0712189)
check('pe_events instance accessor pointer', u32(rom,rbase,0xE0B33AD4)==0xE0713E69)
check('pe_events Array C record word0', u32(rom,rbase,0xE0B33BD4)==0x0000052C)
check('pe_events Array C record event ID', u32(rom,rbase,0xE0B33BD8)==0x0001347F)
check('pe_events Array D count zero', u32(rom,rbase,0xE0B33AD0)==0)

# The callback setter pointer is physically present in the adjacent ROMFS object block.
setter_ptr=struct.pack('<I',0xE0712199)
ptr_offsets=[]; cursor=0
while True:
    i=rom.find(setter_ptr,cursor)
    if i<0: break
    ptr_offsets.append(i); cursor=i+1
check('setter Thumb pointer appears once in ROMFS', ptr_offsets==[0xE0B33A6C-rbase], str([hex(rbase+x) for x in ptr_offsets]))
check('setter pointer at ROMFS 0xE0B33A6C', u32(rom,rbase,0xE0B33A6C)==0xE0712199)

# Named pe_events.list / DSID_PE_EVENT_ID_NOTIFY metadata.
check('pe_events.list string', rom[0xE0B33FC8-rbase:0xE0B33FD7-rbase]==b'pe_events.list\x00')
check('pe_events.list key', u32(rom,rbase,0xE0B33FD8)==0x00011570)
check('pe_events.list DSID pointer', u32(rom,rbase,0xE0B33FDC)==0xE0B33FF0)
check('DSID_PE_EVENT_ID_NOTIFY label', rom[0xE0B33FF0-rbase:0xE0B34008-rbase]==b'DSID_PE_EVENT_ID_NOTIFY\x00')

# Native metadata accessor, setter, and instance-accessor instruction bytes.
check('metadata accessor E0712188 bytes', contains(sr,sbase,0xE0712188,bytes.fromhex('43 f6 3c 20 ce f2 b3 00 70 47')))
check('publisher setter E0712198 bytes', contains(sr,sbase,0xE0712198,bytes.fromhex('4a f2 44 10 cc f2 90 10 01 60 70 47')))
check('instance accessor E0713E68 bytes', contains(sr,sbase,0xE0713E68,bytes.fromhex('45 f6 6c 20 cc f2 91 10 01 1d 01 60 14 bf 01 f1 0c 00 00 20 70 47')))

# Event relay: C1915A6C root, C190A144 callback slot, resolver key, and published event ID.
check('relay loads C1915A6C root', contains(sr,sbase,0xE071271A,bytes.fromhex('45 f6 6c 26 cc f2 91 16 30 68 00 69 01 68')))
check('relay loads C190A144 callback slot', contains(sr,sbase,0xE0712728,bytes.fromhex('4a f2 44 17 cc f2 90 17 4b 69')))
check('relay resolver key 0x01011570', contains(sr,sbase,0xE0712732,bytes.fromhex('41 f2 70 51 c0 f2 01 01 98 47')))
check('relay tests callback slot for null', contains(sr,sbase,0xE071274E,bytes.fromhex('38 68 68 b1')))
check('relay publishes event ID 0x0001347F', contains(sr,sbase,0xE0712762,bytes.fromhex('43 f2 7f 40 02 a9 c0 f2 01 00 90 47')))

# The ROMFS key matches the low 24 bits of the runtime resolver key.
resolver_key=0x01011570
romfs_key=u32(rom,rbase,0xE0B33FD8)
check('resolver/service low-key agreement', (resolver_key & 0x00FFFFFF)==romfs_key, f'{resolver_key:08X} vs {romfs_key:08X}')

# Subscriber D records: seven component-specific callbacks, common ID/context.
sub_path=ROOT/'shared_pe_event_0x1347f_d_subscribers.csv'
rows=list(csv.DictReader(sub_path.open()))
expected={
 'jm_copy':('0xE09EE21C','0xE0510589'),
 'job_tracker':('0xE0A99DA8','0xE054D5C1'),
 'pe':('0xE0B32AD4','0xE070E981'),
 'quiet_mode_cntrl':('0xE0B5BC04','0xE0788A11'),
 'rest_fw_update':('0xE0B5F6E4','0xE07B4401'),
 'rtp_manager':('0xE0B624C0','0xE07BCBE1'),
 'smpw':('0xE0B82058','0xE083C351'),
}
check('seven event subscribers',len(rows)==7,f'rows={len(rows)}')
check('all subscribers use event 0x1347F',len(rows)==7 and {r['id'] for r in rows}=={'0x0001347F'})
check('all subscribers share context E09680D9',len(rows)==7 and {r['context'] for r in rows}=={'0xE09680D9'})
check('subscriber component set', {r['component'] for r in rows}==set(expected))
for r in rows:
    exp=expected.get(r['component'])
    ok=exp is not None and (r['record_address'],r['callback'])==exp
    check(f"subscriber tuple {r['component']}",ok,str((r['record_address'],r['callback'])))

# Full disassembly direct-reference audit, supplied by the retained Step 14 disassembly.
dis_path=Path('/mnt/data/hp_part22_step14/srtext_full_step14.dis')
if dis_path.exists():
    dis=dis_path.read_text(errors='replace')
    direct_calls=[line for line in dis.splitlines() if '0xe0712198' in line.lower() and re.search(r'\b(bl|blx|b\.w)\b',line.lower())]
    check('no direct BL/BLX/B.W call to setter',len(direct_calls)==0,str(direct_calls))
    hits=[]
    for line in dis.splitlines():
        if re.search(r'movw\s+r\d+,\s*#0xa144',line.lower()):
            hits.append(line.split(':',1)[0].strip())
    check('C190A144 direct constructions are setter and relay only',set(hits)=={'e0712198','e0712728'},str(hits))
    check('full disassembly hash matches recorded source',sha(dis_path)=='e0d75046a32c7c69a6b238662708d4519a4e2527c414810ed0dceb360015ee3c')
else:
    audit=(ROOT/'XREF_AUDIT.txt').read_text()
    check('recorded xref audit states zero direct setter calls','Direct BL / BLX / B.W references targeting 0xE0712198: zero.' in audit)
    check('recorded xref audit identifies unique ROMFS pointer','ROMFS occurrences of Thumb pointer 0xE0712199: one, at VMA 0xE0B33A6C.' in audit)
    check('recorded xref audit hash is anchored','e0d75046a32c7c69a6b238662708d4519a4e2527c414810ed0dceb360015ee3c' in audit)

# Guardrails in the findings summary.
findings=(ROOT/'STEP16_FINDINGS.txt').read_text() if (ROOT/'STEP16_FINDINGS.txt').exists() else ''
for term in ['runtime caller','r1','not recovered','alert 66220','block_print']:
    check(f'interpretation guardrail {term}',term in findings.lower())

passed=sum(1 for _,ok,_ in checks if ok); failed=len(checks)-passed
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
print(f'\nRESULT: {passed}/{len(checks)} PASS; {failed} FAIL')
if failed: sys.exit(1)
