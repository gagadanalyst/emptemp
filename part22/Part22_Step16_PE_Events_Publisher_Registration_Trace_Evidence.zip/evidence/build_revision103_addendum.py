from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path('/mnt/data/hp_part22_step16')
BASE=Path('/mnt/data/hp_part22_step15/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision102_Part22_Step15_PE_Event_Producer_and_Client_Audit_Addendum.docx')
OUT=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision103_Part22_Step16_PE_Events_Publisher_Registration_Trace_Addendum.docx'
doc=Document(BASE)
sec=doc.add_section(WD_SECTION.NEW_PAGE)
sec.top_margin=Inches(0.62); sec.bottom_margin=Inches(0.62)
sec.left_margin=Inches(0.68); sec.right_margin=Inches(0.68)
sec.header_distance=Inches(0.28); sec.footer_distance=Inches(0.28)
sec.header.is_linked_to_previous=False; sec.footer.is_linked_to_previous=False
NAVY='17365D'; BLUE='1F4E79'; CYAN='00A6C7'; LIGHT='D9EAF7'; PALE='EEF5FA'; GRAY='595959'; MID='7F8C8D'; WHITE='FFFFFF'; WARN='FFF2CC'; GREEN='E2F0D9'; RED='FCE4D6'
header=sec.header.paragraphs[0]; header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=header.add_run('HP DESKJET 2855e  |  INDEPENDENT PRINTING / SCANNING INVESTIGATION')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(MID)
footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('Revision 103 - Part 22, Step 16 addendum  |  19 November 2026  |  Page ')
r.font.name='Aptos'; r.font.size=Pt(7); r.font.color.rgb=RGBColor.from_string(MID)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)
def celltxt(cell,text,bold=False,color=None,size=7.6):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color:r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
def table(headers,rows,widths=None,font=7.3):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; t.style='Table Grid'
    for i,h in enumerate(headers): celltxt(t.rows[0].cells[i],h,True,WHITE,font); shade(t.rows[0].cells[i],BLUE)
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            celltxt(cells[i],val,False,None,font)
            if ri%2: shade(cells[i],PALE)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t
def para(text='',style=None,boldlead=None,color=None,italic=False,size=None,after=Pt(3)):
    p=doc.add_paragraph(style=style); p.paragraph_format.space_after=after
    if boldlead and text.startswith(boldlead):
        runs=[p.add_run(boldlead),p.add_run(text[len(boldlead):])]; runs[0].bold=True
    else:runs=[p.add_run(text)]
    for r in runs:
        r.font.name='Aptos'
        if color:r.font.color.rgb=RGBColor.from_string(color)
        if italic:r.italic=True
        if size:r.font.size=Pt(size)
    return p
def bullet(text,size=7.9):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(1.5)
    r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size); return p
def callout(title,body,fill=LIGHT):
    t=doc.add_table(rows=1,cols=1); t.autofit=False; t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0); shade(c,fill); c.text=''
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(title); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9.1); r.font.color.rgb=RGBColor.from_string(NAVY)
    p2=c.add_paragraph(body); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.02
    for r in p2.runs:r.font.name='Aptos'; r.font.size=Pt(7.8)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
def newpage(kicker,title,subtitle=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(14); p.paragraph_format.space_after=Pt(4)
    r=p.add_run(kicker); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9.5); r.font.color.rgb=RGBColor.from_string(CYAN)
    p=doc.add_paragraph(style='Title'); p.paragraph_format.space_after=Pt(4); p.add_run(title)
    if subtitle: para(subtitle,color=GRAY,size=8.2,after=Pt(7))

# PAGE 27
newpage('PART 22  /  STEP 16','The pe_events component declares event ID 0x1347F in metadata',
        'Revision 103 addendum extending Revision 102  |  Static firmware analysis  |  19 November 2026')
callout('Step 16 result at a glance',
        'The event-publisher path is now tied to a named component. The pe_events component header at 0xE0B33A98 has a single Array C record at 0xE0B33BD4: (0x0000052C, 0x0001347F), and an Array D count of zero in its component header. Seven other components have D-record callbacks registered for the same event ID. A ROMFS callback pointer at 0xE0B33A6C targets setter 0xE0712198, which stores a supplied function pointer in global 0xC190A144. The PE event relay at 0xE07126B8 reads that same global and calls the pointer with event ID 0x1347F. This closes the static registration-to-emission edge, although the runtime value supplied to the setter remains unknown.',GREEN)
para('This is a stronger result than the earlier shared-context finding. Step 15 identified the seven subscribers and their common IpcEvtProdPeEvent envelope. Step 16 identifies the separate pe_events component record, the callback setter that populates the exact publisher slot, and the emitter that consumes that slot.',size=8.1)
table(['pe_events metadata field','Observed value','Interpretation'],[
('Component header','0xE0B33A98','Standard component metadata header'),
('Component label','pe_events','Label pointer 0xE0B33BC8'),
('Metadata callback','0xE0712189 -> 0xE0712188','Returns metadata pointer 0xE0B33A3C'),
('Instance accessor','0xE0713E69 -> 0xE0713E68','Initializes/returns pe_events instance subobject'),
('Array C pointer/count','0xE0B33BD4 / 1','One two-word record'),
('Array C record','(0x0000052C, 0x0001347F)','Contains the exact event ID emitted by PE relay'),
('Array D count','0','No D-record subscribers on pe_events itself'),
],[1.65,2.0,2.5],7.1)
callout('Why this matters',
        'The exact same ID is present in the pe_events component metadata, in seven consumer D records, and in the native event-emission call. This is now a coherent component-to-emitter-to-subscriber path rather than a string-only or two-component association.',LIGHT)

# PAGE 28
p=doc.add_page_break()
newpage('PART 22  /  STEP 16','The ROMFS object block exposes the publisher callback setter',
        'A Thumb-tagged callback pointer resolves directly to a three-instruction global-slot setter.')
para('The ROMFS object block immediately preceding the pe_events header contains a Thumb-tagged pointer at 0xE0B33A6C:',size=8.2)
table(['ROMFS address','Stored word','Resolved target'],[
('0xE0B33A6C','0xE0712199','Thumb entry -> code 0xE0712198'),
('0xE0B33AA8','0xE0712189','Metadata callback -> 0xE0712188'),
('0xE0B33AD4','0xE0713E69','Instance accessor -> 0xE0713E68'),
],[1.45,1.55,3.15],7.2)
para('The target at 0xE0712198 is unambiguous:',size=8.2)
table(['Address','Instruction','Effect'],[
('0xE0712198','movw r0, #0xA144','Load low half of global address'),
('0xE071219C','movt r0, #0xC190','Complete r0 = 0xC190A144'),
('0xE07121A0','str r1, [r0]','Store caller-supplied r1 into global callback slot'),
('0xE07121A2','bx lr','Return'),
],[1.25,2.25,2.7],7.1)
callout('Confirmed edge',
        'The ROMFS block contains the Thumb pointer 0xE0712199, and its target writes r1 to C190A144. The event relay later reads C190A144 and calls the stored pointer. This is a concrete setter/consumer match. Static firmware evidence does not yet reveal which runtime component calls the setter or which function address it supplies in r1.',GREEN)
para('The function-pointer value occurs once in the reconstructed ROMFS image, at 0xE0B33A6C. The retained full .srtext disassembly has no direct BL/BLX caller for 0xE0712198; the available route is therefore through the ROMFS-registered indirect interface rather than a direct static branch.',size=7.9,color=GRAY)

# PAGE 29
p=doc.add_page_break()
newpage('PART 22  /  STEP 16','The PE relay resolves pe_events.list and emits 0x1347F',
        'The setter and emitter operate on the same callback global; the event ID is passed as the first argument.')
para('The event relay begins at 0xE07126B8. Its relevant sequence has three stages:',size=8.2)
table(['Stage','Code behavior','Address / value'],[
('1. Resolve event-list service','Loads the pe_events instance root through C1915A6C, gets a virtual method at +0x14, and passes lookup key 0x01011570.','0xE071271A-0xE071273A'),
('2. Update event-list state','Loads another pe_events subobject and calls its virtual method at +0x18 with operation 1 and a pair containing the source object and result.','0xE071273C-0xE071274C'),
('3. Publish event','Reads C190A144, skips if null, builds the event envelope, loads event ID 0x0001347F, and calls the stored function pointer.','0xE071274E-0xE071276C'),
],[1.1,3.3,1.8],7.0)
para('The adjacent ROMFS metadata contains:',size=8.2)
table(['Address','Observed bytes / label','Meaning supported by location'],[
('0xE0B33FC8','pe_events.list','Named event-list resource'),
('0xE0B33FD8','0x00011570','ROMFS key; matches runtime low 24 bits'),
('0xE0B33FDC','0xE0B33FF0','Pointer to label text'),
('0xE0B33FF0','DSID_PE_EVENT_ID_NOTIFY','Named event-notification data item'),
],[1.25,2.1,2.85],7.1)
callout('Key match, with an encoding caveat',
        'The relay supplies 0x01011570 to the runtime resolver. The ROMFS descriptor names pe_events.list and carries key 0x00011570 next to DSID_PE_EVENT_ID_NOTIFY. The low 24 bits of the runtime key match the ROMFS value. The leading 0x01 byte is an additional runtime qualifier; its semantics have not been independently decoded.',WARN)
para('The relay constructs a 24-byte stack envelope from the ROMFS base descriptor at 0xE0D421C8, then stores a flag and the original typed event object pointer. It invokes the registered publisher with r0=0x0001347F and r1 pointing to that envelope. This is the first direct static publication site recovered for this event ID.',size=8.0)

# PAGE 30
p=doc.add_page_break()
newpage('PART 22  /  STEP 16','The complete static event registration chain',
        'The pe_events component metadata, setter, publisher relay and seven subscriber D-records all carry or use the same ID.')
# compact monospaced flow, presented in a table for renderer stability
table_data=[
 ('ROMFS pe_events block','0xE0B33A6C stores Thumb pointer 0xE0712199'),
 ('Callback setter','0xE0712198: C190A144 = r1'),
 ('PE event relay','0xE07126B8 reads C190A144 and invokes it'),
 ('Event envelope','event_id=0x0001347F; payload pointer at stack envelope'),
 ('Subscribers','Seven D-record callbacks share context 0xE09680D9'),
]
table(['Layer','Verified connection'],table_data,[1.55,4.45],7.1)
table(['Subscriber','Callback code','D record'],[
('jm_copy','0xE0510588','0xE09EE21C'),
('job_tracker','0xE054D5C0','0xE0A99DA8'),
('pe','0xE070E980','0xE0B32AD4'),
('quiet_mode_cntrl','0xE0788A10','0xE0B5BC04'),
('rest_fw_update','0xE07B4400','0xE0B5F6E4'),
('rtp_manager','0xE07BCBE0','0xE0B624C0'),
('smpw','0xE083C350','0xE0B82058'),
],[1.6,2.0,2.4],7.0)
callout('What is now confirmed',
        'The PE event relay publishes event ID 0x1347F through a callback slot whose setter is registered in ROMFS near the pe_events component header. The pe_events header carries one C-array record containing the same ID, and seven other components register D callbacks for it. This is a high-confidence static publisher/subscriber chain.',GREEN)

# PAGE 31
p=doc.add_page_break()
newpage('PART 22  /  STEP 16','What this changes - and what is still not proven',
        'This is a golden architectural finding, but it is not yet the root cause of the printer block.')
para('The investigation has now moved past a generic shared-event hypothesis. We know:',size=8.2)
bullet('Which component metadata carries event ID 0x1347F: pe_events, with its single C-array record at 0xE0B33BD4.',7.8)
bullet('Which ROMFS pointer exposes the publisher-callback setter: 0xE0B33A6C -> 0xE0712199.',7.8)
bullet('What the setter changes: global function-pointer slot C190A144.',7.8)
bullet('Which code consumes that slot: PE event relay 0xE07126B8.',7.8)
bullet('What the relay emits: event ID 0x1347F plus a structured event envelope.',7.8)
bullet('Which seven components register as consumers of that event ID.',7.8)
callout('Limits retained',
        'The runtime caller of setter 0xE0712198 and the function pointer passed in r1 are not recovered. Runtime delivery to each subscriber is not observed. No payload subtype has yet been tied to subscribedPagesOutAccountProblem (alert 66220), DSID_PRINT_ENGINE_BLOCKED (0x12196), rtp_manager.block_print, or unblock_print. The event bus may carry ordinary PE object/list lifecycle changes as well as other state.',WARN)
para('No printer interaction, network request, firmware write, reset, flash, print job, or scan job was performed. All findings are from the verified firmware binaries and ROMFS/component metadata.',size=8.0)
para('Next focused trace',style='Heading 2')
para('Trace the registration method pointer at 0xE0B33A6C through its parent pe_events interface/constructor to identify the caller and runtime r1 value. Then follow the registered publisher callback into the event hub and inspect whether the event payloads that reach PE and RTP include a print-admission, blocked-state, or subscription-entitlement transition. Preserve the distinction between the confirmed event publisher and the still-unproven print-block cause.',size=8.0)
callout('Step 16 stop point',
        'The publisher registration edge is now established statically. The next unresolved edge is the source of r1 at the setter and the semantic mapping of emitted subtypes. Stop here until the next bounded trace is approved.',LIGHT)

props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 103 Part 22 Step 16 Addendum'
props.subject='PE events publisher registration, pe_events component, C190A144 callback setter and event 0x1347F emission path'
props.author='OpenAI'
props.keywords='HP DeskJet 2855e, firmware, pe_events, DSID_PE_EVENT_ID_NOTIFY, 0x1347F, C190A144, publisher callback'
doc.save(OUT)
print(OUT)
