from pathlib import Path
import re, struct, hashlib
root=Path('/mnt/data/hp_part22_step20')
source=Path('/mnt/data/hp_part22_step19/srtext_thumb.dis')
lines=source.read_text(errors='ignore').splitlines()
addr_re=re.compile(r'^([0-9a-fA-F]{8}):')
parsed=[]
for line in lines:
    m=addr_re.match(line)
    if m:
        parsed.append((int(m.group(1),16), line))

def extract_ranges(name, ranges):
    out=[]
    for lo,hi in ranges:
        out.append(f'===== VMA RANGE 0x{lo:08X}-0x{hi:08X} =====')
        selected=[line for addr,line in parsed if lo<=addr<=hi]
        out.extend(selected)
    (root/'evidence'/'disassembly'/name).write_text('\n'.join(out)+'\n')

extract_ranges('pe_wait_canprint_query_subscription_callback.dis', [
    (0xE0726768,0xE072689C),
    (0xE07268A8,0xE07268E2),
    (0xE07269B0,0xE07269F0),
])
extract_ranges('service_5742e_and_other_injection_setters.dis', [
    (0xE07140D0,0xE07140FE),
    (0xE0715950,0xE0715980),
    (0xE07269B0,0xE07269F0),
])
extract_ranges('sirius_aggregate_and_context_cleanup_api.dis', [
    (0xE0712378,0xE07123D2),
    (0xE07127D0,0xE0712808),
    (0xE0712B10,0xE0712B5C),
    (0xE0712BA8,0xE0712C30),
])

romfs=Path(root/'evidence/romfs/../romfs_objs_rebuilt.bin').read_bytes()
base=0xE09919C0

def dump_words(addr, length):
    off=addr-base
    out=[f'VMA 0x{addr:08X} / ROMFS file offset 0x{off:X} / length 0x{length:X}']
    for i in range(0,length,4):
        w=struct.unpack_from('<I',romfs,off+i)[0]
        raw=romfs[off+i:off+i+4]
        text=''.join(chr(c) if 32<=c<127 else '.' for c in raw)
        out.append(f'0x{addr+i:08X}: 0x{w:08X}  {text}')
    return '\n'.join(out)

cross=[]
cross.append('pe_iev_job record / method table')
cross.append(dump_words(0xE0B35770,0x110))
cross.append('\npe_jobdb adjacent record / name vicinity')
cross.append(dump_words(0xE0B35910,0x60))
cross.append('\npe_wait_for_canprint record / method table')
cross.append(dump_words(0xE0B39640,0x120))
(root/'evidence'/'romfs'/'STEP20_ROMFS_RECORD_WORDS.txt').write_text('\n'.join(cross)+'\n')

# Store raw-word counts for service IDs, to ground the negative cross-check.
ids=[0x000A701E,0x0005742E,0x0038948E,0x0096BF7A,0x00490F3E]
with open(root/'evidence'/'romfs'/'STEP20_ROMFS_SERVICE_ID_COUNTS.csv','w') as f:
    f.write('service_id,raw_32bit_occurrences\n')
    for value in ids:
        pattern=struct.pack('<I',value)
        count=romfs.count(pattern)
        f.write(f'0x{value:08X},{count}\n')

# source provenance summary
files=[root/'evidence/hp_lbi_sections.elf',root/'evidence/srtext_rebuilt.bin',root/'evidence/romfs_objs_rebuilt.bin']
with open(root/'evidence/SOURCE_INPUTS.txt','w') as f:
    f.write('Step 20 source inputs restored from Part 1 Library evidence and carried forward unchanged from Step 19.\n')
    for p in files:
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        f.write(f'{h}  {p.name}\n')
    f.write('\nOriginal Part 1 evidence archive SHA-256: 511fc8ac874b67a6caf0a52888e0a7c6ea1ab14f43c0c45902fd3fb0c55b21ee\n')
print('extracted focused disassembly and ROMFS crosswalk')
