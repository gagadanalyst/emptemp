from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

root = Path('/mnt/data/hp_part22_step20')
src = root / 'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision106_Part22_Step19_PE_Wait_For_CanPrint_Nonzero_Condition_Registration_Addendum.docx'
out = root / 'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision107_Part22_Step20_PE_Wait_For_CanPrint_Readiness_State_Machine_Addendum.docx'
doc = Document(src)

# Add a new section so the inherited Revision 106 pages keep their exact footer.
sec = doc.add_section(WD_SECTION.NEW_PAGE)
sec.header.is_linked_to_previous = False
sec.footer.is_linked_to_previous = False
for p in sec.footer.paragraphs:
    p._element.getparent().remove(p._element)
fp = sec.footer.add_paragraph()
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = fp.add_run('PART 22 / STEP 20  •  STATIC FIRMWARE ANALYSIS  •  REVISION 107 ADDENDUM')
r.font.name = 'Aptos'; r.font.size = Pt(8); r.font.color.rgb = RGBColor(96, 110, 125)

# Helpers consistent with prior addenda.
def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)

def set_cell_text(cell, text, bold=False, color=None, size=8.3):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.line_spacing = 1.0
    r = p.add_run(str(text))
    r.bold = bold
    r.font.name = 'Aptos'
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_heading(text, level=1):
    p = doc.add_paragraph(style=f'Heading {level}')
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(6 if level == 1 else 4)
    p.paragraph_format.space_after = Pt(4)
    p.add_run(text)
    return p

def add_body(text, bold_prefix=None):
    p = doc.add_paragraph(style='Normal')
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.line_spacing = 1.04
    if bold_prefix and text.startswith(bold_prefix):
        rr = p.add_run(bold_prefix); rr.bold = True
        p.add_run(text[len(bold_prefix):])
    else:
        p.add_run(text)
    for rr in p.runs:
        if rr.font.name is None: rr.font.name = 'Aptos'
        if rr.font.size is None: rr.font.size = Pt(9)
    return p

def add_bullets(items):
    for s in items:
        p = doc.add_paragraph(style='List Bullet')
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.line_spacing = 1.0
        p.add_run(s)

def add_table(headers, rows, widths=None, font_size=8.2):
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = 'Table Grid'
    t.autofit = False
    hdr = t.rows[0]
    trPr = hdr._tr.get_or_add_trPr()
    repeat = OxmlElement('w:tblHeader'); repeat.set(qn('w:val'), 'true'); trPr.append(repeat)
    for i,h in enumerate(headers):
        set_cell_text(hdr.cells[i], h, bold=True, color=(255,255,255), size=font_size)
        shade(hdr.cells[i], '174A6E')
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,v in enumerate(row):
            set_cell_text(cells[i], v, size=font_size)
            if ri%2==0: shade(cells[i], 'EAF1F6')
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(1); p.paragraph_format.space_before=Pt(0)
    return t

def page_title(kicker, title, subtitle):
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(3)
    r=p.add_run(kicker.upper()); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(9); r.font.color.rgb=RGBColor(24,107,153)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(3)
    r=p.add_run(title); r.bold=True; r.font.name='Aptos Display'; r.font.size=Pt(21); r.font.color.rgb=RGBColor(28,65,96)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(10)
    r=p.add_run(subtitle); r.font.name='Aptos'; r.font.size=Pt(9); r.font.color.rgb=RGBColor(95,110,125)

# Page 10
page_title('Part 22 / Step 20', 'The CanPrint readiness state machine', 'Revision 107 addendum | 19 November 2026')
add_heading('Four injected service slots in pe_wait_for_canprint', 1)
add_body('The setter at 0xE07269B0 accepts four service IDs and stores the supplied pointer into separate fields of the component object. Direct call-site tracing shows that two of these services have distinct roles in the wait-for-canprint path: one provides a status query, while another provides keyed subscription and unsubscription.')
add_table(['Service ID','Object field','Observed use in this trace'], [
    ['0x0038948E','+0x04','Status query via provider vtable +0x08; receives a 0xD0-byte output area'],
    ['0x0096BF7A','+0x08','Accepted by setter; direct use not established in the traced callback path'],
    ['0x000A701E','+0x0C','siriusInstance; registers condition token 1 and uses lifecycle methods'],
    ['0x0005742E','+0x10','Keyed subscription to "wait_for_canprint" via +0x08; unregister via +0x10'],
], [1.35,0.95,4.25], 8.0)
add_heading('Status-query predicate at 0xE07267B8', 2)
add_body('The helper first checks the latch at 0xC192F068. If that word is zero, it returns 0 without calling service 0x0038948E. If the latch is nonzero, it calls the provider object at component +0x04 through vtable +0x08, passing a 0xD0-byte result buffer. It then reads the word at result offset +0x8C.')
add_table(['Condition after provider call','Helper result'], [
    ['Latch 0xC192F068 == 0','0; provider is not queried'],
    ['Latch nonzero; result[+0x8C] == 0','0'],
    ['Latch nonzero; provider return != 0','0'],
    ['Latch nonzero; result[+0x8C] != 0 AND provider return == 0','1'],
], [3.8,2.75], 8.0)
add_body('This result is a branch predicate used by the callback; the product meaning of response field +0x8C and the provider return convention remain unknown. It is not an identified Instant Ink entitlement field.')

# Page 11
p=doc.add_paragraph(); p.paragraph_format.page_break_before=True
page_title('Step 20 evidence', 'Callback and subscription lifecycle', 'Control flow in 0xE0726850 and helper calls')
add_heading('Callback selectors and actions', 1)
add_table(['Callback value','Actions visible in code','Return'], [
    ['0x10','Run 0xE07267B8. If predicate is 0, subscribe to "wait_for_canprint" through 0xE0726768; if predicate is 1, do not subscribe.','2 when it subscribes; otherwise 1'],
    ['0x1A','Write 1 to 0xC192F068; call unregister 0xE0726798; only if unsubscribe returns nonzero, re-run predicate and invoke cleanup 0xE0726808 when it is true.','1'],
    ['0x87','Unregister; only if unsubscribe returns nonzero, re-run status predicate; if true, invoke cleanup 0xE0726808.','1'],
    ['0x90','Unregister; only if unsubscribe returns nonzero, re-run status predicate; if true, invoke cleanup 0xE0726808.','1'],
    ['Other values','Return without the subscribe/unsubscribe branches above.','1'],
], [1.0,4.55,1.0], 7.8)
add_heading('Subscription API details', 2)
add_table(['Function','Provider call','Arguments / effect'], [
    ['0xE0726768','component +0x10; vtable +0x08','Key "wait_for_canprint"; r2=0; r3=0x3C; stack values 1,1; return handle saved at 0xC192F064'],
    ['0xE0726798','component +0x10; vtable +0x10','Passes saved handle 0xC192F064 to unregister'],
], [1.0,2.0,3.55], 7.9)
add_heading('Cleanup sequence at 0xE0726808', 2)
add_bullets([
    'Call siriusInstance vtable +0x34.',
    'Call service 0x0005742E vtable +0x10 with handle 0xC192F064.',
    'If that call returns nonzero, call the same provider vtable +0x40 with the handle.',
    'Call siriusInstance vtable +0x38.'
])
add_body('The selector numbers and vtable slot names are left numeric because no matching named enum or implementation-class descriptor was found. The code proves the transition structure, not the user-facing meaning of each selector.')

# Page 12
p=doc.add_paragraph(); p.paragraph_format.page_break_before=True
page_title('Step 20 results', 'Shared service ID and remaining gap', 'Provider consumers, ROMFS cross-check, and next target')
add_heading('Service ID 0x0005742E is accepted by three PE objects', 1)
add_table(['Consumer','Setter','Destination field','Use established here'], [
    ['siriusInstance','0xE07140D0','+0x18','Aggregate reads this provider and calls vtable +0x54 / +0x58 with token'],
    ['pe_wait_for_canprint','0xE07269B0','+0x10','Subscribes/unsubscribes to "wait_for_canprint"'],
    ['pe_iev_job','0xE0715950','+0x10','Setter accepts the same service ID; direct use of field not established'],
], [1.55,1.2,1.0,2.8], 7.7)
add_body('The ROMFS pointer at 0xE0B3584C is 0xE0715951 and the containing component descriptor names pe_iev_job at 0xE0B35798. The adjacent pe_jobdb string at 0xE0B35928 belongs to a separate record; pe_jobdb is not the owner of setter 0xE0715950.')
add_heading('Why the concrete provider is still unresolved', 2)
add_body('The rebuilt ROMFS image contains 19 raw words equal to 0x000A701E (siriusInstance dependency ID), but no raw 32-bit occurrences of 0x0005742E, 0x0038948E, 0x0096BF7A, or 0x00490F3E. These latter values are assembled as immediates in setter code. The current ROMFS crosswalk therefore supplies no concrete provider class/name for the dynamically injected interfaces. This does not mean the runtime providers do not exist.')
add_heading('Established versus unresolved', 2)
add_bullets([
    'Established: the token-1 callback belongs to a PE wait-for-canprint state machine with separate status-query and event-subscription dependencies.',
    'Established: service 0x0005742E is used by the aggregate at siriusInstance +0x18 and by the wait component at +0x10; a third setter in pe_iev_job accepts the same service ID.',
    'Unresolved: the concrete providers behind 0x0038948E and 0x0005742E, the +0x8C result field semantics, and whether the runtime injected pointers are the same instance.',
    'Unresolved: whether token 1 was active on the the printer during the failed Print-Job, or whether any of this is caused by account/Instant Ink policy.'
])
add_body('Next target: identify the concrete implementation of service 0x0038948E and the status structure written at +0x8C, then resolve service 0x0005742E and its token-state methods. Runtime memory would still be needed to confirm which provider state was live on the printer.')
add_heading('Scope', 2)
add_body('Static firmware analysis only. No printer communication, runtime memory capture, firmware modification, print attempt, or scan attempt was performed.')

# Document properties.
doc.core_properties.title = 'HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 107'
doc.core_properties.subject = 'Part 22 Step 20 - PE Wait-for-CanPrint readiness state machine and service dependency trace'
doc.core_properties.comments = 'Revision 107 appends Step 20 to Revision 106. Adds the dual-provider status-query/subscription path, callback lifecycle, service ID 0x5742E consumers, and corrects pe_iev_job naming.'
doc.save(out)
print(out)
