from pathlib import Path
import hashlib, struct, re, fitz, zipfile, sys

root = Path('/mnt/data/hp_part22_step20')
ev = root/'evidence'
checks=[]
def check(name, cond, detail=''):
    checks.append((name, bool(cond), detail))

# Source provenance
expected = {
    'hp_lbi_sections.elf':'25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
    'srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
    'romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
}
for name,want in expected.items():
    got=hashlib.sha256((ev/name).read_bytes()).hexdigest()
    check(f'source hash {name}',got==want,got)

waitdis=(ev/'disassembly/pe_wait_canprint_query_subscription_callback.dis').read_text()
setdis=(ev/'disassembly/service_5742e_and_other_injection_setters.dis').read_text()
agdis=(ev/'disassembly/sirius_aggregate_and_context_cleanup_api.dis').read_text()
romtxt=(ev/'romfs/STEP20_ROMFS_RECORD_WORDS.txt').read_text()
findings=(ev/'STEP20_FINDINGS.txt').read_text()
svc_csv=(ev/'romfs/STEP20_SERVICE_DEPENDENCY_MAP.csv').read_text()
flow_csv=(ev/'romfs/STEP20_CALLBACK_STATE_FLOW.csv').read_text()

# Four service bindings on pe_wait_for_canprint
check('pe_wait setter service 0xA701E -> +0x0C','0xe07269ea' in setdis.lower() and '0x701e' in setdis.lower())
check('pe_wait setter service 0x5742E -> +0x10','0xe07269ee' in setdis.lower() and '0x742e' in setdis.lower())
check('pe_wait setter service 0x38948E -> +0x04','0xe07269e6' in setdis.lower() and '0x498e' in setdis.lower() and '0x38' in setdis.lower())
check('pe_wait setter service 0x96BF7A -> +0x08','e07269e2:' in setdis.lower() and '0xbf7a' in setdis.lower() and '0x96' in setdis.lower())

# Status query semantics
check('status query checks C192F068','0xc192' in waitdis.lower() and '0xf068' in waitdis.lower())
check('status query vtable slot +0x08','e07267d8' in waitdis.lower() and 'e07267da' in waitdis.lower() and 'e07267dc' in waitdis.lower())
check('status output offset +0x8C','ldr\tr1, [sp, #0x8c]' in waitdis.lower() or '[sp, #0x8c]' in waitdis.lower())
check('status predicate requires output nonzero','e07267e4' in waitdis.lower() and 'cbz\tr1' in waitdis.lower())
check('status predicate requires provider return zero','e07267e6' in waitdis.lower() and 'cbz\tr0' in waitdis.lower())
check('query result 1 only on combined condition','movs\tr4, #0x1' in waitdis.lower())

# Subscription details
check('wait_for_canprint key present in rebuilt disassembly', 'wait_for_canprint' in (root/'evidence'/'disassembly'/'pe_wait_canprint_query_subscription_callback.dis').read_text().lower() or 'wait_for_canprint' in findings.lower())
check('subscription event/type 0x3C','movs\tr3, #0x3c' in waitdis.lower())
check('subscription provider slot +0x08','ldr\tr4, [r1, #0x8]' in waitdis.lower() or 'ldr\tr4, [r1, #0x8]' in waitdis.lower())
check('subscription handle 0xC192F064','0xf064' in waitdis.lower() and 'str\tr0, [r4]' in waitdis.lower())
check('unsubscribe provider slot +0x10','ldr\tr2, [r1, #0x10]' in waitdis.lower())

# Callback transitions
for code in ['#0x10','#0xa','#0x6d','#0x9']:
    check(f'callback compares {code}',code in waitdis.lower())
check('callback selector 0x1A sets C192F068','str\tr0, [r1]' in waitdis.lower() and '#0xf068' in waitdis.lower())
check('unsubscribe result gates re-query','cbz\tr0, 0xe0726896' in waitdis.lower())
check('callback only returns 2 on subscription','movs\tr0, #0x2' in waitdis.lower())
check('callback other path returns 1','movs\tr0, #0x1' in waitdis.lower())

# Cleanup sequence
check('cleanup SiriusInstance slot +0x34','ldr\tr1, [r1, #0x34]' in waitdis.lower())
check('cleanup service slot +0x10','ldr\tr2, [r1, #0x10]' in waitdis.lower())
check('cleanup service slot +0x40','ldr\tr2, [r1, #0x40]' in waitdis.lower())
check('cleanup SiriusInstance slot +0x38','ldr\tr1, [r1, #0x38]' in waitdis.lower())

# Shared service ID and aggregate
check('siriusInstance setter accepts 0x5742E','0xe07140fc' in setdis.lower() and '0x742e' in setdis.lower())
check('siriusInstance stores 0x5742E at +0x18','str\tr3, [r0, #0x18]' in setdis.lower())
check('pe_iev_job setter accepts 0x5742E','0xe071597e' in setdis.lower() and '0x742e' in setdis.lower())
check('aggregate reads registry +0x5B8','[r6, #0x5b8]' in agdis.lower())
check('aggregate reads siriusInstance +0x18','[r0, #0x18]' in agdis.lower())
check('aggregate queries provider +0x54','[r2, #0x54]' in agdis.lower())
check('aggregate queries provider +0x58','[r2, #0x58]' in agdis.lower())

# ROMFS crosswalk and naming correction
check('pe_iev_job component name in ROMFS', 'pe_iev_job' in romtxt)
check('pe_iev_job method table contains E0715951','0xE0B3584C: 0xE0715951' in romtxt)
check('pe_jobdb is a separate neighboring record','0xE0B35928' in romtxt and 'pe_jobdb' in findings)
check('findings identify pe_iev_job not pe_jobdb','third consumer is named pe_iev_job' in findings.lower())

# ROMFS count check
romfs=(ev/'romfs_objs_rebuilt.bin').read_bytes()
counts={0x000A701E:19,0x0005742E:0,0x0038948E:0,0x0096BF7A:0,0x00490F3E:0}
for v,n in counts.items():
    actual=romfs.count(struct.pack('<I',v))
    check(f'ROMFS raw word count 0x{v:08X}',actual==n,str(actual))

# Document outputs and page count
outdocx=root/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision107_Part22_Step20_PE_Wait_For_CanPrint_Readiness_State_Machine_Addendum.docx'
outpdf=root/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision107_Part22_Step20_PE_Wait_For_CanPrint_Readiness_State_Machine_Addendum.pdf'
check('Revision 107 DOCX exists',outdocx.exists())
check('Revision 107 PDF exists',outpdf.exists())
if outdocx.exists():
    with zipfile.ZipFile(outdocx) as z: check('DOCX ZIP integrity',z.testzip() is None)
if outpdf.exists():
    pdf=fitz.open(outpdf)
    check('PDF page count 12',len(pdf)==12,str(len(pdf)))
    check('PDF page size US Letter',abs(pdf[0].rect.width-612)<1 and abs(pdf[0].rect.height-792)<1,str(pdf[0].rect))

# Report scope and limitations
check('findings distinguish dynamic provider limitation','concrete provider implementation/class behind service 0x0005742e' in findings.lower())
check('findings do not claim runtime state on the printer','whether token 1 was active' in findings.lower())
check('findings explicitly rule out unproven Instant Ink attribution','not yet proof' in findings.lower() or 'not proof' in findings.lower())

passed=sum(p for _,p,_ in checks)
lines=[f'Step 20 focused verification: {passed}/{len(checks)} PASS', '']
for name,ok,detail in checks:
    lines.append(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
(ev/'verification_output.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[:6]))
print('FAILURES:',[n for n,ok,_ in checks if not ok])
if passed!=len(checks): sys.exit(1)
