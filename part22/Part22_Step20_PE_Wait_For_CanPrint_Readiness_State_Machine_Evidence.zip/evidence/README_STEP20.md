# Part 22 / Step 20 — PE Wait-for-CanPrint readiness state machine

## Golden result

The `pe_wait_for_canprint` component has two distinct service dependencies in the analyzed path:

- Service `0x0038948E` at object offset `+0x04` supplies a status query. The component passes a `0xD0`-byte result area and examines the word at offset `+0x8C` together with the provider's return value.
- Service `0x0005742E` at object offset `+0x10` provides keyed subscription/unsubscription for the literal key `wait_for_canprint` (subscription argument `0x3C`, handle at `0xC192F064`).

The token-1 callback `0xE0726850` orchestrates that state machine. Selector `0x10` runs the status predicate and subscribes when it returns false. Selectors `0x1A`, `0x87`, and `0x90` call unsubscribe; the status predicate is re-run only if unsubscribe returns nonzero. Selector `0x1A` also sets `0xC192F068` to `1` before that path.

The same service ID `0x0005742E` is accepted by setters for `siriusInstance`, `pe_wait_for_canprint`, and `pe_iev_job`. `siriusInstance` stores it at `+0x18`; the aggregate queries that provider at vtable `+0x54` and `+0x58` with the condition token. `pe_wait_for_canprint` stores it at `+0x10` and uses subscribe/unsubscribe methods. The `pe_iev_job` setter accepts the same ID, though direct use of that field was not established in this step.

## Important limits

The concrete provider implementations behind `0x0038948E` and `0x0005742E` remain unresolved. The ROMFS object image contains no raw 32-bit occurrences of these IDs; the values are assembled in setter instructions, so the current static ROMFS crosswalk does not give provider class names. The `+0x8C` status-field meaning is unknown. We do not know whether token `1` was active on the user's printer at the time of the failed print job, and this is not proof of an Instant Ink/account-policy cause.

The adjacent `pe_jobdb` record is separate. The component owning setter `0xE0715950` is `pe_iev_job`.

## Verification

- Focused verifier: 54/54 checks passed.
- Source binary hashes match the Step 19 baseline.
- DOCX contains 12 pages; PDF contains 12 US Letter pages.
- The 9 inherited pages from Revision 106 are pixel-identical (9/9).
- New pages 10–12 were inspected in DOCX and at 200 dpi in the PDF.
- DOCX ZIP integrity and evidence ZIP integrity passed.

## Scope

Static firmware analysis only. No printer communication, runtime memory capture, firmware modification, print attempt, or scan attempt was performed.
