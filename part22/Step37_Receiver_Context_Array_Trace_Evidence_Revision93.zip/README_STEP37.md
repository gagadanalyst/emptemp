# Step 37 - Receiver Context Array Trace

Scope: offline static analysis of the HP DeskJet 2855e firmware; no printer interaction, runtime execution, device modification, or firmware flashing.

## Result

The complete reconstructed `.srtext` disassembly confirms that `0xC143E904` is the base of a three-pointer runtime context array, distinct from the `siriusInstance` singleton global `0xC193B3C0`. Initializer `0xE0308B70`, called by wrapper `0xE0308C70`, zeroes all three entries. Selector `0xE0308C48` checks slot `+0x04` with a vtable `+0x298` predicate and returns that pointer only when the predicate is nonzero; otherwise it returns slot `+0x00`. The selector does not examine slot `+0x08`.

The complete `.srtext` disassembly contains 264 direct BL callsites to `0xE0308C48`. The generic property dispatcher `0xE0303558` has two direct callers in the recovered image (`0xE03041EE` and `0xE030971E`); each wrapper first calls the selector and then calls the dispatcher. The dispatcher performs indirect calls through the chosen receiver's vtable, including offsets `+0x264` and `+0x268`. This is a genuine generic receiver-dispatch path, but it does not identify the selected receiver as `siriusInstance`.

The three array entries are also used by lifecycle helpers: `0xE0308BF0` conditionally clears slots `+0x04` and `+0x08`, then calls non-null entries at vtable `+0x20C`; `0xE0308C18` calls non-null entries at vtable `+0x210`. Two other functions (`0xE0306790`, `0xE03067BE`) read slot `+0x00` and pass/store it into a separate consumer object. These operations consume the context; they do not establish who populates it.

The direct-reference paths recovered in `.srtext` show zero-initialization, conditional clearing, reads, predicate selection, lifecycle notification, and forwarding. No explicit nonzero pointer store into the three array entries was found in these paths. The supplier remains unresolved.

## Callback-node continuity

The same `0xE0308B70` initializer inserts `0xC01E05E8` and `0xC01E05F4` into the shared callback list rooted at `0xC1D63BD4`. Sirius wrapper `0xE0747088` inserts node `0xC020EC30` into that same list after constructing `siriusInstance`. These nodes' RAM-backed fields are not contained in the retained ELF.

`hp_lbi_sections.elf` has zero program headers and only `.srtext` and `.romfs_objs` sections. It has no mapped RAM data section covering the pointer array or the callback-node addresses. Therefore the node `+0x04` mode and `+0x08` callback, and the non-null runtime values of `0xC143E904/0xC143E908/0xC143E90C`, cannot be recovered from this ELF alone. This is a source-coverage limit, not evidence that the runtime values are always null.

## Important interpretation limits

- Do not equate `0xC143E904` with singleton `0xC193B3C0`; they are separate globals with different roles in this trace.
- Do not treat the shared `+0x268` virtual slot as class identity. The dispatcher calls the receiver's own implementation; the selected receiver's vtable pointer is not recovered.
- A nearby ROMFS method-pointer window is included as raw evidence only. Its address point is not tied to the runtime receiver by available references.
- Step 37 does not prove that the shared-list drain runs before Pen initialization, or that any callback writes `siriusInstance +0x20/+0x24`.

## Files

- `step37_verified_disassembly.txt`: reviewed address-bounded disassembly excerpts.
- `step37_cross_reference_report.txt`: complete-code call counts, direct-reference census, and interpretation limits.
- `step37_romfs_method_pointer_window.txt`: raw ROMFS word windows near candidate method pointers; no receiver-table identity is asserted.
- `step37_elf_coverage.txt`: ELF headers and section map confirming lack of program headers/RAM section.
- `step37_source_hashes.txt`: SHA-256 fingerprints for input ELF, reconstructed sections, FHX payload, and generated full disassembly.
- `step36_baseline_cross_reference.txt`: prior-step continuity evidence.
- `verify_step37.py`, `verification_output.txt`, `QA_SUMMARY.txt`, `hash_manifest.sha256`.

## Reproduction

The full disassembly was regenerated from the retained ELF with `llvm-objdump -d --triple=thumbv7m-none-eabi hp_lbi_sections.elf`. The focused verifier rechecks the important instructions, full-code call counts, global references, source layout, and package integrity markers.
