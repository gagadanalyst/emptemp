from pathlib import Path
import re, hashlib, struct, subprocess
ROOT = Path(__file__).resolve().parent
WORK = Path('/mnt/data/firmware_recovery/step37_work')
SRC = WORK/'base/part1_rtp_provider_trace'
DIS = WORK/'full_srtext.dis'
lines = DIS.read_text(errors='replace').splitlines()
all_text = '\n'.join(lines)
checks=[]
def check(name, ok): checks.append((name,bool(ok)))
def line_at(addr):
    prefix=f'{addr:08x}:'
    return next((x for x in lines if x.startswith(prefix)), '')
def direct_call_count(target):
    return sum(1 for x in lines if target in x and re.search(r'\bbl\b',x))

check('complete .srtext disassembly exists', DIS.exists() and len(lines)>2_000_000)
check('context initializer zeros three slots with indexed STR', 'str.w\tr2, [r4, r1, lsl #2]' in all_text)
check('context initializer bounds loop at three entries', 'cmp\tr0, #0x3' in all_text and 'cmp\tr5, #0x3' in all_text)
check('initializer wrapper targets context global', 'movt\tr0, #0xc143' in all_text and '0xe0308b70' in all_text)
check('selector reads second entry at +4', 'ldr\tr4, [r5, #0x4]' in all_text)
check("selector calls selected object vtable +0x298", '[r0, #0x298]' in all_text)
check('selector falls back to slot zero', '0xe0308c66' in all_text and 'ldr\tr0, [r5]' in all_text)
check('cleanup may clear slot +4', 'str\tr0, [r4, #0x4]' in all_text)
check('cleanup may clear slot +8', 'str\tr0, [r4, #0x8]' in all_text)
check('cleanup iterates three slots', 'ldr.w\tr0, [r4, r5, lsl #2]' in all_text)
check('cleanup dispatches vtable +0x20c', '[r1, #0x20c]' in all_text)
check('notification iterates three slots', 'ldr.w\tr0, [r5, r4, lsl #2]' in all_text)
check('notification dispatches vtable +0x210', '[r1, #0x210]' in all_text)
check('slot zero consumer reads global', line_at(0xE0306790)!='' and line_at(0xE03067BE)!='')
check('slot zero consumer passes object method +0x294', '[r0, #0x294]' in all_text)
check('slot zero consumer stores into separate object +0x220', '[r0, #0x220]' in all_text)
check('generic dispatcher loads receiver vtable +0x264', '[r0, #0x264]' in all_text)
check('generic dispatcher loads receiver vtable +0x268', '[r0, #0x268]' in all_text)
check('context selector has 264 direct BL callsites', direct_call_count('0xe0308c48')==264)
check('generic dispatcher has exactly two direct BL callers', direct_call_count('0xe0303558')==2)
check('first call path selects receiver then dispatches', 'e03041e0:' in all_text and 'e03041ee:' in all_text)
check('second call path selects receiver then dispatches', 'e0309710:' in all_text and 'e030971e:' in all_text)
check('secondary-slot accessor reads +4', 'e030feb8:' in all_text and 'ldr\tr0, [r1, #0x4]' in all_text)
check('Sirius wrapper builds C020EC30 node', 'e074709e:' in all_text and 'movt\tr0, #0xc020' in all_text)
check('Sirius wrapper calls shared list inserter', 'e07470a6:' in all_text and '0xe0981216' in all_text)
check('shared initializer registers C01E05E8 node', 'e0308ba2:' in all_text and 'movt\tr0, #0xc01e' in all_text)
check('shared initializer registers C01E05F4 node', 'e0308bce:' in all_text and 'movt\tr0, #0xc01e' in all_text)
elf = subprocess.run(['readelf','-h','-l','-S',str(SRC/'hp_lbi_sections.elf')],capture_output=True,text=True,check=True).stdout
check('ELF reports zero program headers', bool(__import__('re').search(r'Number of program headers:\s+0', elf)))
check('ELF exposes .srtext and .romfs_objs sections', '.srtext' in elf and '.romfs_objs' in elf)
check('ELF lacks RAM section naming', '.data' not in elf and '.bss' not in elf)
check('evidence package contains core report files', all((ROOT/n).exists() for n in ['README_STEP37.md','step37_verified_disassembly.txt','step37_cross_reference_report.txt','step37_elf_coverage.txt','step37_source_hashes.txt']))
print(f'RESULT: {sum(ok for _,ok in checks)}/{len(checks)} checks passed')
for name,ok in checks: print(('PASS' if ok else 'FAIL')+'  '+name)
if not all(ok for _,ok in checks): raise SystemExit(1)
