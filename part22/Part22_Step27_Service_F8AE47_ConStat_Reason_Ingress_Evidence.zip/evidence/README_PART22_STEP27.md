# Part 22, Step 27 evidence package

## Objective
Resolve the service dependency used by the ConStat reason-ingress callback family and establish how its returned values reach ConStat reason insertion.

## Key finding
The service setter at `0xE0308D90` maps service `0x00F8AE47` to `C1443000 + 0x30`. The callback family at ROMFS slots `0xE09AE544`, `0xE09AE550`, and `0xE09AE55C` uses that dependency. The first callback `0xE030FB40` obtains a 20-byte record through provider vtable `+0x24`, classifies a reason group, obtains a candidate reason value through `+0x18`, then calls selected-object slot `+0x2C0`. On the recovered secondary-object vtable at `0xE09AEA54`, that slot is `0xE03076B0`, forwarding to the actual reason insertion routine `0xE03076C0`.

## Limits
The concrete implementation returned for service `0x00F8AE47` remains unidentified. The Step 8 crosswalk records 32 Array B dependencies and no Array A provider among 59 standard component headers. The special `constat` descriptor independently lists `0x00F8AE47` as one of its nine Array B dependencies. This is consistent with a system/alternate provider, but does not prove where it is registered.

The evidence does not establish that the provider returns reason `0x13` for PINK mask `0x00020000`. No runtime call execution or printer-side state was captured.

## Contents
- `STEP27_FINDINGS.txt` — concise finding, exact chain, limits.
- `crosswalks/constat_array_A_six_records.csv` — six 24-byte Array A records.
- `crosswalks/constat_array_B_nine_records.csv` — nine 24-byte Array B records, including `0x00F8AE47`.
- `crosswalks/service_F8AE47_cumulative_arithmetic.csv` — exact setter subtraction sequence.
- `crosswalks/service_F8AE47_standard_component_usage.csv` — all 32 matching Part 8 records.
- `crosswalks/reason_callback_method_table.csv` — three descriptor/method entries.
- `disassembly/` — exact Thumb disassembly extracts.
- `romfs/` — relevant raw descriptor records.
- `baseline/` — complete Step 26 and Part 8 evidence archives.
- `scripts/verify_step27.py` — focused verifier.
- `SOURCE_INPUTS.txt` — source hashes and addresses.

## Reproduction
Run:

```bash
python scripts/verify_step27.py
```

The script uses only the preserved evidence from the Step 26 source package and the Step 8 component-registry crosswalk. It does not communicate with the printer.
