from __future__ import annotations
import csv
import hashlib
import struct
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE_ZIP = ROOT / 'baseline' / 'Part22_Step26_ConStat_Vtable_and_Reason_Path_Correction_Evidence.zip'

def check(cond: bool, label: str, checks: list[str]) -> None:
    checks.append(('PASS' if cond else 'FAIL') + ' | ' + label)

def read_u32(data: bytes, base: int, address: int) -> int:
    return struct.unpack_from('<I', data, address - base)[0]

checks: list[str] = []
with tempfile.TemporaryDirectory(prefix='hp-step27-verify-') as temp:
    tmp = Path(temp)
    with zipfile.ZipFile(BASELINE_ZIP) as zf:
        zf.extractall(tmp)
    src = tmp / 'evidence'
    romfs = (src / 'romfs_objs_rebuilt.bin').read_bytes()
    srtext = (src / 'srtext_rebuilt.bin').read_bytes()
    elf = src / 'hp_lbi_sections.elf'
    base = 0xE09919C0

    # Source hashes from the preserved Step 26 baseline.
    expected_hashes = {
        'hp_lbi_sections.elf': '25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
        'srtext_rebuilt.bin': '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
        'romfs_objs_rebuilt.bin': '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
    }
    for name, digest in expected_hashes.items():
        path = src / name
        observed = hashlib.sha256(path.read_bytes()).hexdigest()
        check(observed == digest, f'Step 26 source hash {name}: {observed}', checks)

    # Setter arithmetic: input F8AE47 maps to +0x30.
    value = 0x00F8AE47
    for subtract, expected_value, label in [
        (0x00223EE5, 0x00D66F62, 'after subtract 0x00223EE5'),
        (0x0044059E, 0x009269C4, 'after subtract 0x0044059E'),
        (0x0078A8D1, 0x0019C0F3, 'after subtract 0x0078A8D1'),
        (0x00125DAB, 0x00076348, 'after subtract 0x00125DAB'),
    ]:
        value = (value - subtract) & 0xFFFFFFFF
        check(value == expected_value, f'service arithmetic {label}: 0x{value:08X}', checks)
    check(value == 0x00076348, 'terminal comparison is 0x00076348', checks)

    # Special ConStat descriptor records.
    expected_a = [0x00013056, 0x006CF0E4, 0x00013218, 0x00C7F89A, 0x00014852, 0x000E4B0C]
    observed_a = [read_u32(romfs, base, 0xE09A8E40 + i*24 + 8) for i in range(6)]
    check(observed_a == expected_a, 'constat Array A six service IDs match ROMFS', checks)
    expected_b = [0x00DEED54, 0x001FF211, 0x00F14AFF, 0x000A701E, 0x00223EE5, 0x00F8AE47, 0x00014DC4, 0x00664483, 0x0017C9AC]
    observed_b = [read_u32(romfs, base, 0xE09A8ED0 + i*24 + 8) for i in range(9)]
    check(observed_b == expected_b, 'constat Array B nine service IDs match ROMFS', checks)
    check(read_u32(romfs, base, 0xE09A8F50) == 0x00F8AE47, 'service 0x00F8AE47 in ConStat Array B record 0xE09A8F48', checks)
    check(romfs[0xE09A8FA8-base:0xE09A8FAF-base] == b'constat', 'component label is constat', checks)
    check(read_u32(romfs, base, 0xE09A8FB0) == 0xE09A8FB4, 'constat method-table pointer', checks)

    # Standard-header crosswalk counts.
    rows = list(csv.DictReader((ROOT / 'crosswalks' / 'service_F8AE47_standard_component_usage.csv').open(encoding='utf-8')))
    check(len(rows) == 32, '0xF8AE47 appears in 32 standard component dependency records', checks)
    check(all(r['array'] == 'B' for r in rows), 'all 32 matches are Array B dependencies', checks)
    check(not any(r['array'] == 'A' for r in rows), 'no Array A provider among 59 standard headers', checks)

    # Adjacent ROMFS descriptor/method pairs.
    callback_rows = list(csv.DictReader((ROOT / 'crosswalks' / 'reason_callback_method_table.csv').open(encoding='utf-8')))
    expected_callbacks = [
        ('0xE09AE544', '0xE030FB41', '0xE030FB40'),
        ('0xE09AE550', '0xE030FC19', '0xE030FC18'),
        ('0xE09AE55C', '0xE030FD19', '0xE030FD18'),
    ]
    observed = [(r['method_pointer_slot'], r['thumb_method_pointer'], r['code_address']) for r in callback_rows]
    check(observed == expected_callbacks, 'three adjacent ROMFS method/descriptor pairs match callback family', checks)
    for slot, pointer in [(0xE09AE544,0xE030FB41),(0xE09AE550,0xE030FC19),(0xE09AE55C,0xE030FD19)]:
        check(read_u32(romfs, base, slot) == pointer, f'ROMFS method pointer at 0x{slot:08X} is 0x{pointer:08X}', checks)

    # Selected secondary ConStat object vtable address point.
    check(read_u32(romfs, base, 0xE09AEA54 + 0x2C0) == 0xE03076B1, 'selected-object +0x2C0 -> Thumb 0xE03076B0', checks)
    check(read_u32(romfs, base, 0xE09AEA54 + 0x2C4) == 0xE03076C1, 'selected-object +0x2C4 -> Thumb 0xE03076C0', checks)
    check(read_u32(romfs, base, 0xE09AEA54 + 0x2C8) == 0xE03077F1, 'selected-object +0x2C8 -> Thumb 0xE03077F0', checks)
    check(read_u32(romfs, base, 0xE09AEA54 + 0x2CC) == 0xE0307829, 'selected-object +0x2CC -> Thumb 0xE0307828', checks)

    # Disassembly contracts.
    setter_dis = (ROOT / 'disassembly' / 'C1443000_service_setter_E0308D90.dis').read_text()
    callback_dis = (ROOT / 'disassembly' / 'ConStat_reason_callback_family_FB40_FD18.dis').read_text().lower()
    reason_dis = (ROOT / 'disassembly' / 'ConStat_reason_group_methods_76B0_7828.dis').read_text().lower()
    check('#0x6348' in setter_dis and '#0x7' in setter_dis and '[r0, #0x30]' in setter_dis, 'setter terminal compare and +0x30 store present', checks)
    check('[r1, #0x2c0]' in callback_dis and '[r1, #0x2c8]' in callback_dis and '[r1, #0x2cc]' in callback_dis, 'callback family uses selected-object slots +0x2C0/+0x2C8/+0x2CC', checks)
    check('[r1, #0x24]' in callback_dis and '[r1, #0x18]' in callback_dis and '#0x14' in callback_dis, 'callback family queries provider +0x24/+0x18 with 20-byte record', checks)
    check('[r0, #0x224]' in reason_dis and '[r5, #0x2f8]' in reason_dis, 'reason-group code includes active-state and can_print writes', checks)

out = '\n'.join(checks) + f'\n\nTotal: {sum(x.startswith("PASS") for x in checks)}/{len(checks)} PASS\n'
(ROOT / 'verification_output.txt').write_text(out, encoding='utf-8')
print(out)
if any(x.startswith('FAIL') for x in checks):
    raise SystemExit(1)
