from __future__ import annotations
import csv, hashlib, struct, zipfile
from pathlib import Path

ROOT = Path('/mnt/data/hp_part22_step27/evidence')
ROMFS = Path('/mnt/data/hp_part22_step26/evidence/romfs_objs_rebuilt.bin').read_bytes()
ROMFS_BASE = 0xE09919C0
PART8 = Path('/mnt/data/step27_part8/evidence/part8_service_descriptor_crosswalk_A_B.csv')

def u32(addr: int) -> int:
    return struct.unpack_from('<I', ROMFS, addr - ROMFS_BASE)[0]

def record_csv(name: str, start: int, count: int, arr: str) -> None:
    path = ROOT / 'crosswalks' / name
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['array', 'index', 'record_address', 'word0_flags', 'word1_namespace', 'word2_service_id', 'word3', 'word4_local_field', 'word5_sentinel'])
        for i in range(count):
            addr = start + i * 24
            words = [u32(addr + j*4) for j in range(6)]
            w.writerow([arr, i, f'0x{addr:08X}', *(f'0x{x:08X}' for x in words)])

# The special constat descriptor is a pair of contiguous 24-byte record arrays.
record_csv('constat_array_A_six_records.csv', 0xE09A8E40, 6, 'A')
record_csv('constat_array_B_nine_records.csv', 0xE09A8ED0, 9, 'B')
(ROOT / 'romfs' / 'constat_service_arrays_A_B.bin').write_bytes(
    ROMFS[0xE09A8E40-ROMFS_BASE:0xE09A8E40-ROMFS_BASE + 6*24]
    + ROMFS[0xE09A8ED0-ROMFS_BASE:0xE09A8ED0-ROMFS_BASE + 9*24]
)

# Preserve the exact vtable callback descriptor triples from ROMFS.
with (ROOT / 'crosswalks' / 'reason_callback_method_table.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['descriptor_pointer_slot', 'descriptor_pointer', 'method_pointer_slot', 'thumb_method_pointer', 'code_address', 'downstream_selected_object_slot', 'downstream_behavior'])
    rows = [
        (0xE09AE540, 0xE09AE674, 0xE09AE544, 0xE030FB41, 0xE030FB40, '+0x2C0', 'single reason insertion into ConStat reason group'),
        (0xE09AE54C, 0xE09AE698, 0xE09AE550, 0xE030FC19, 0xE030FC18, '+0x2C8', 'collects four scalar values; stores a 16-byte record'),
        (0xE09AE558, 0xE09AE6B4, 0xE09AE55C, 0xE030FD19, 0xE030FD18, '+0x2CC', 'collects three scalar values; updates selected-object state and queries follow-on provider'),
    ]
    for row in rows:
        w.writerow([f'0x{row[0]:08X}', f'0x{row[1]:08X}', f'0x{row[2]:08X}', f'0x{row[3]:08X}', f'0x{row[4]:08X}', row[5], row[6]])

# Exact service-ID subtraction sequence for C1443000+0x30.
steps = [
    ('input service ID', None, 0x00F8AE47),
    ('subtract first base', 0x00223EE5, 0x00D66F62),
    ('subtract second base', 0x0044059E, 0x009269C4),
    ('subtract third base', 0x0078A8D1, 0x0019C0F3),
    ('subtract fourth base', 0x00125DAB, 0x00076348),
    ('compare terminal value', 0x00076348, 0x00076348),
]
with (ROOT / 'crosswalks' / 'service_F8AE47_cumulative_arithmetic.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['step', 'operation_value', 'resulting_r1'])
    for label, op, result in steps:
        w.writerow([label, '' if op is None else f'0x{op:08X}', f'0x{result:08X}'])

# Cross-component service usage from Part 8 (59 standard headers).
rows = list(csv.DictReader(PART8.open(encoding='utf-8')))
key = '0x00F8AE47'
match = [r for r in rows if r['word2'].lower() == key.lower()]
with (ROOT / 'crosswalks' / 'service_F8AE47_standard_component_usage.csv').open('w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(match)
counts = {
    'total_records': len(match),
    'array_A_records': sum(r['array'] == 'A' for r in match),
    'array_B_records': sum(r['array'] == 'B' for r in match),
    'unique_components': len({r['component'] for r in match}),
}
(ROOT / 'crosswalks' / 'service_F8AE47_standard_component_summary.txt').write_text(
    '\n'.join(f'{k}: {v}' for k, v in counts.items()) + '\n', encoding='utf-8'
)

# Raw relevant structures for independent re-parsing.
(ROOT / 'romfs' / 'constat_name_and_method_table.bin').write_bytes(
    ROMFS[0xE09A8FA8-ROMFS_BASE:0xE09A8FB4-ROMFS_BASE+4*20]
)
(ROOT / 'romfs' / 'F8AE47_B_record.bin').write_bytes(
    ROMFS[0xE09A8F48-ROMFS_BASE:0xE09A8F48-ROMFS_BASE+24]
)

# Build a findings summary.
findings = f'''Part 22, Step 27 — Service 0x00F8AE47 and the ConStat reason-ingress callback family

Confirmed service mapping
- Setter: 0xE0308D90.
- Service key: 0x00F8AE47.
- Stored field: C1443000 + 0x30 (C1443030).
- Arithmetic: 0x00F8AE47 - 0x00223EE5 = 0x00D66F62; - 0x0044059E = 0x009269C4; - 0x0078A8D1 = 0x0019C0F3; - 0x00125DAB = 0x00076348; terminal comparison is 0x00076348; equal branch stores r3 at +0x30.

ConStat descriptor crosswalk
- Special ROMFS component name string: 0xE09A8FA8, "constat".
- Method table pointer at 0xE09A8FB0 -> 0xE09A8FB4.
- Its nearby service arrays decode as Array A: six records beginning 0xE09A8E40; Array B: nine records beginning 0xE09A8ED0.
- Array B includes service 0x00F8AE47 at record 0xE09A8F48. The component's Array A list does not include 0x00F8AE47.
- In the independent Part 8 crosswalk across 59 standard headers, 0x00F8AE47 occurs in 32 Array B dependency records, across 32 components, and zero Array A records. Therefore its provider is not identified among the 59 standard advertised-service records; it may be supplied by a global/system or alternate registration path, but that is not proven.

Reason-ingress callback family
- ROMFS pair at descriptor pointer slot 0xE09AE540 / method pointer slot 0xE09AE544: descriptor 0xE09AE674, callback 0xE030FB41 -> code 0xE030FB40.
- 0xE030FB40 queries the injected provider at C1443030 through vtable +0x24 with a 20-byte local record (r1=sp+0x18, r2=0x14), parses the record via 0xE03053F8 to obtain a group identifier, then invokes provider vtable +0x18 to obtain a candidate reason value. It resolves the selected ConStat object through 0xE030FEB8 and calls selected-object slot +0x2C0. In the selected object's vtable, +0x2C0 is 0xE03076B0, which forwards to +0x2C4 / 0xE03076C0, the actual reason inserter.
- Adjacent ROMFS pair 0xE09AE54C/0xE09AE550 maps to descriptor 0xE09AE698 and callback 0xE030FC18. It queries four scalar values from provider +0x18 and calls selected-object +0x2C8 (0xE03077F0), which stores a 16-byte record in the object's auxiliary table.
- Adjacent pair 0xE09AE558/0xE09AE55C maps to descriptor 0xE09AE6B4 and callback 0xE030FD18. It queries three scalar values and calls selected-object +0x2CC (0xE0307828), which stores them and invokes a further provider operation.
- These are adjacent table entries and share dependency 0xF8AE47. The descriptor bytes are retained as raw data; their semantic names are not decoded.

Limits / correction
- The concrete implementation behind service 0x00F8AE47 is still unresolved. The same service is widely requested but no provider appears in the 59 standard Array A records inspected.
- The call chain proves how 0xF8AE47's returned values can reach ConStat reason insertion; it does not prove that the value returned for any particular PINK error is 0x13.
- The PINK TooEarly mask 0x00020000 -> ConStat INKSUB_REPLACED_EARLY reason 0x13 conversion remains unproven.
- No runtime call execution, printer state capture, or device-side pointer identity has been observed. These are static paths only.
'''
(ROOT / 'STEP27_FINDINGS.txt').write_text(findings, encoding='utf-8')

print('created crosswalks')
print(counts)
