#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, struct, re, sys

ROOT=Path('/mnt/data/hp_part22_step9')
E=ROOT/'evidence'
PAYLOAD=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/fhx_secure_payload_rebuilt.bin')
ROMFS=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/romfs_objs_rebuilt.bin')
SR=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/srtext_rebuilt.bin')
DIS=Path('/mnt/data/hp_fw_inputs/srtext_disasm_all.txt')
META=Path('/mnt/data/hp_fw_inputs/extracted/part7_component_metadata_header_inventory.csv')

checks=[]
def check(name,condition,detail=''):
    checks.append((name,bool(condition),detail))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def findall(b,pat):
    out=[]; p=0
    while True:
        i=b.find(pat,p)
        if i<0: return out
        out.append(i); p=i+1

payload=PAYLOAD.read_bytes(); rom=ROMFS.read_bytes(); sr=SR.read_bytes(); dis=DIS.read_text(errors='replace')
base=0xE09919C0; srbase=0xE0246070
specs={'cromtext':(0xC48440,0xE1FA0280,0x6E3),'crommodule':(0xC48B24,0xE1FA0964,0x48A),'cromfs':(0xC48FB0,0xE1FA0DF0,0xB4C)}
expected_hashes={'cromtext':'f4677e4c79bed2455397976c43491f4ad3d6cb20500144bcc8c6a32362e819af','crommodule':'345156ea257f140cbe9e46ab619c24d4128fb68ab63af4d826192a981d068be6','cromfs':'6a65a9d29a2b18142692cfb841899008579eaf3d63362e0f1002628bd1a1c188'}
sections={}
for n,(off,va,size) in specs.items():
    b=payload[off:off+size]; p=ROOT/'extract'/f'{n}.bin'
    check(f'{n} descriptor size',len(b)==size,f'{len(b)} / {size}')
    check(f'{n} workfile matches payload',p.exists() and p.read_bytes()==b)
    check(f'{n} SHA256',hashlib.sha256(b).hexdigest()==expected_hashes[n],hashlib.sha256(b).hexdigest())
    sections[n]=b
check('payload byte size',len(payload)==0xC4A900,str(len(payload)))
check('payload SHA256',sha(PAYLOAD)=='aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858',sha(PAYLOAD))
check('romfs image size',len(rom)==0x440D0C,str(len(rom)))
check('srtext image size',len(sr)==0x743634,str(len(sr)))
check('cromtext-to-module one-byte gap',specs['cromtext'][0]+specs['cromtext'][2]+1==specs['crommodule'][0] and payload[0xC48B23:0xC48B24]==b'\xB9',payload[0xC48B23:0xC48B24].hex())
check('module-to-fs padding exact',payload[0xC48FAE:0xC48FB0]==bytes.fromhex('e038'),payload[0xC48FAE:0xC48FB0].hex())
check('module end and fs VMA gap',specs['crommodule'][1]+specs['crommodule'][2]==0xE1FA0DEE and specs['cromfs'][1]==0xE1FA0DF0)

# component record header-minus-0xC crosswalk from known Part7 inventory
rows=list(csv.DictReader(META.open()))
byhead={int(r['header']):r for r in rows}
counts={n:0 for n in specs}; allhits=[]
for n,b in sections.items():
    for off in range(len(b)-3):
        val=struct.unpack_from('<I',b,off)[0]
        if val+0xC in byhead:
            allhits.append((n,off,val+0xC,byhead[val+0xC]['label']))
            counts[n]+=1
check('component prefix matches total',len(allhits)==22,str(len(allhits)))
check('component prefix matches crommodule',counts['crommodule']==10,str(counts))
check('component prefix matches cromfs',counts['cromfs']==12,str(counts))
check('component prefix matches cromtext',counts['cromtext']==0,str(counts))
check('no direct metadata header matches',not any(struct.unpack_from('<I',b,o)[0] in byhead for n,b in sections.items() for o in range(len(b)-3)))
expected_labels={
 'crommodule':{'firm','hw_clock_sys','jm_echo','jm_jpeg_print','jm_pjl','jm_reports','job_tracker','jpeg','ldx','lib_digital_sensor'},
 'cromfs':{'localization','pe','pe_digital_sensor','product_prop','reports_manager','rest_helper','scan_hw_mgr','scan','sense_deriv_proxy','smgr_init','smpw','ews_ctrl'},
 'cromtext':set()
}
for n,want in expected_labels.items():
    got={x[3] for x in allhits if x[0]==n}
    check(f'{n} component label set',got==want,f'got {sorted(got)}')

# Exact named references and count uniqueness
for n,off,target in [('crommodule',0x152,0xE099FF48),('cromfs',0x36A,0xE0BC0084)]:
    b=sections[n]
    check(f'{n} key value at candidate offset',struct.unpack_from('<I',b,off)[0]==target,hex(struct.unpack_from('<I',b,off)[0]))
    check(f'{n} key value unique',len(findall(b,struct.pack('<I',target)))==1,str(findall(b,struct.pack('<I',target))))
check('no exact rtp_manager prefix in tail',sum(len(findall(b,struct.pack('<I',v))) for b in sections.values() for v in [0xE0B621E0,0xE0B621EC,0xE0B6242C])==0)

# ROMFS data targets and strings
rtp_off=0xE0BC0084-base; print_off=0xE099FF48-base
check('rtpadapter target inside ROMFS',0<=rtp_off<len(rom))
check('print resource target inside ROMFS',0<=print_off<len(rom))
for s,va in [(b'rtpadapter',0xE0BC0100),(b'siriusInstance',0xE0BC010C),(b'/eventfifo/rtp_secure_pipe',0xE0BC01F1),(b'/eventfifo/rtp_secure_pipe',0xE0BC020D),(b'/eventfifo/rtp_secure_pipe',0xE0BC0229),(b'hp.cdm.service.print.version.2.resource.configuration',0xE099FF48),(b'com.hp.cdm.service.print.version.2.resource.setupStatus',0xE099FF84)]:
    off=va-base
    check(f'string {s.decode()} at {va:#x}',rom[off:off+len(s)]==s,rom[off:off+len(s)].decode('ascii','replace'))
check('internal Print setupStatus pointer at FF80',struct.unpack_from('<I',rom,0xE099FF80-base)[0]==0xE099FF84)

# Code pointers from ROMFS adapter object table
ptr_table={
 0xE0BC024C:0xE093A959,0xE0BC0258:0xE093CD69,0xE0BC025C:0xE0590AA1,0xE0BC0260:0xE0590AC1,
 0xE0BC0264:0xE093C819,0xE0BC0268:0xE093CE19,0xE0BC026C:0xE093CF09,0xE0BC0270:0xE093D2F1,
 0xE0BC0274:0xE093D349,0xE0BC0278:0xE093D3A1,0xE0BC027C:0xE093D421}
for src,val in ptr_table.items():
    actual=struct.unpack_from('<I',rom,src-base)[0]
    target=val&~1
    check(f'code pointer {src:#x} stored',actual==val,hex(actual))
    check(f'code pointer target label {target:#x}',re.search(rf'^{target:08x}:',dis,re.M) is not None)
# Additional pointer and instruction targets
check('callback pointer at E0BC00CC',struct.unpack_from('<I',rom,0xE0BC00CC-base)[0]==0xE093C521)
check('callback target E093C520 label',re.search(r'^e093c520:',dis,re.M) is not None)
check('repeated helper pointer at E0BC0124',struct.unpack_from('<I',rom,0xE0BC0124-base)[0]==0xE0981339)
check('repeated helper target E0981338 label',re.search(r'^e0981338:',dis,re.M) is not None)
# method at CD68 stores E0BC0250 into this
cd=dis[dis.find('e093cd68:'):dis.find('e093cdb0:')]
check('constructor/cleanup candidate stores E0BC0250', 'movw\tr0, #0x250' in cd and 'movt\tr0, #0xe0bc' in cd)

# no direct alert/print-block address patterns in tail sections
negative=[0xC136E704,0xE0277130,0x0061862B,0x0001229F,0xE07BCF10,0xE07BDFA8,0xE0251788,0x00012196]
for v in negative:
    count=sum(len(findall(b,struct.pack('<I',v))) for b in sections.values())
    check(f'no exact raw {v:#x} in CROM tail',count==0,str(count))

# all evidence outputs present
required=['CROM_TAIL_SECTIONS.csv','CROM_TAIL_COMPONENT_RECORD_CANDIDATES.csv','CROM_TAIL_KEY_REFERENCE_CANDIDATES.csv','CROM_TAIL_EXACT_ADDRESS_SCAN.csv','CROSS_SECTION_ROMFS_CONTEXTS.txt','RTPADAPTER_CODE_POINTER_CANDIDATES.csv','RTPADAPTER_CODE_POINTER_DISASSEMBLY.txt','CROSS_SECTION_TARGET_REFERENCE_COUNTS.csv','FHX_TAIL_DESCRIPTOR_CONTEXT.txt','CROM_TAIL_GAPS.txt','RTPADAPTER_HEX_CONTEXTS.txt','RTPADAPTER_METHOD_BEHAVIOR_NOTES.txt','CROMFS_COMPONENT_REFERENCE_INTERPRETATION.txt','README_PART22_STEP9.md','DOCUMENT_QA.txt','SOURCE_INPUTS.txt']
for name in required: check(f'evidence file {name}',(E/name).exists() and (E/name).stat().st_size>0)

passed=sum(ok for _,ok,_ in checks)
lines=[f'Part 22 Step 9 verification: {passed}/{len(checks)} PASS']
for name,ok,detail in checks:
    lines.append(f"{'PASS' if ok else 'FAIL'} | {name}"+(f' | {detail}' if detail else ''))
(E/'verification_output.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
if passed!=len(checks): sys.exit(1)
