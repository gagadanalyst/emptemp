from pathlib import Path
import csv, hashlib, struct, re, json

ROOT=Path('/mnt/data/hp_part22_step9')
OUT=ROOT/'evidence'; OUT.mkdir(exist_ok=True)
PAYLOAD=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/fhx_secure_payload_rebuilt.bin')
ROMFS=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/romfs_objs_rebuilt.bin')
SR=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/srtext_rebuilt.bin')
DIS=Path('/mnt/data/hp_fw_inputs/srtext_disasm_all.txt')
META=Path('/mnt/data/hp_fw_inputs/extracted/part7_component_metadata_header_inventory.csv')
FHXCSV=Path('/mnt/data/hp_part22_step8/evidence/FHX_DIRECTORY_125.csv')

payload=PAYLOAD.read_bytes(); rom=ROMFS.read_bytes(); sr=SR.read_bytes(); dis=DIS.read_text(errors='replace')
rom_base=0xE09919C0; sr_base=0xE0246070
section_specs={
 'cromtext':(0xC48440,0xE1FA0280,0x6E3,0x2),
 'crommodule':(0xC48B24,0xE1FA0964,0x48A,0x2),
 'cromfs':(0xC48FB0,0xE1FA0DF0,0xB4C,0x2),
}
sections={}
for name,(off,va,size,flags) in section_specs.items():
    data=payload[off:off+size]
    if len(data)!=size: raise SystemExit(f'{name}: short extraction')
    out=ROOT/'extract'/f'{name}.bin'
    out.parent.mkdir(exist_ok=True)
    out.write_bytes(data)
    sections[name]=data

def sha(b): return hashlib.sha256(b).hexdigest()
def find_all(data,pat):
    out=[]; p=0
    while True:
        i=data.find(pat,p)
        if i<0: return out
        out.append(i); p=i+1

# Section map and FHX descriptors
with (OUT/'CROM_TAIL_SECTIONS.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['section','payload_offset','vma','size_bytes','flags_numeric','sha256','end_vma_exclusive','next_payload_offset'])
    ordered=list(section_specs.items())
    for idx,(name,(off,va,size,flags)) in enumerate(ordered):
        nxt=ordered[idx+1][1][0] if idx+1<len(ordered) else None
        w.writerow([name,hex(off),hex(va),size,hex(flags),sha(sections[name]),hex(va+size),hex(nxt) if nxt is not None else ''])

# exact component record prefix pattern hits
metadata=list(csv.DictReader(META.open()))
by_header={int(r['header']):r for r in metadata}
component_hits=[]
for name,data in sections.items():
    va=section_specs[name][1]
    for off in range(max(0,len(data)-3)):
        val=struct.unpack_from('<I',data,off)[0]
        row=by_header.get(val+0xC)
        if row:
            component_hits.append({
                'section':name,'section_offset':off,'section_vma':va+off,
                'reference_value':val,'component':row['label'],'metadata_header':val+0xC,
                'header_prefix_address':val,
                'offset_mod4':off%4,
                'exact_header_match':False,
            })
        direct=by_header.get(val)
        if direct:
            component_hits.append({
                'section':name,'section_offset':off,'section_vma':va+off,
                'reference_value':val,'component':direct['label'],'metadata_header':val,
                'header_prefix_address':val,
                'offset_mod4':off%4,
                'exact_header_match':True,
            })
with (OUT/'CROM_TAIL_COMPONENT_RECORD_CANDIDATES.csv').open('w',newline='') as f:
    fields=['section','section_offset','section_vma','reference_value','component','metadata_header','header_prefix_address','offset_mod4','exact_header_match']
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
    for r in component_hits: w.writerow({k:(hex(r[k]) if k in {'section_offset','section_vma','reference_value','metadata_header','header_prefix_address'} else r[k]) for k in fields})

# named cross-section pointer candidates
key_targets=[
 ('crommodule',0x152,0xE099FF48,'CDM Print v2 configuration resource'),
 ('cromfs',0x36A,0xE0BC0084,'rtpadapter / siriusInstance / RTP secure event-pipe resource block'),
]
key_rows=[]
for sect,off,target,meaning in key_targets:
    data=sections[sect]; val=struct.unpack_from('<I',data,off)[0]
    key_rows.append([sect,hex(off),hex(section_specs[sect][1]+off),hex(val),meaning,find_all(data,struct.pack('<I',target))])
with (OUT/'CROM_TAIL_KEY_REFERENCE_CANDIDATES.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['section','section_offset','section_vma','decoded_little_endian_value','target_context','occurrences_in_section'])
    for r in key_rows: w.writerow([*r[:5],';'.join(hex(x) for x in r[5])])

# Exact address scan in tail sections
scan_values=[0xE0BC0084,0xE099FF48,0xE099FF84,0xE0B621E0,0xE0B621EC,0xE0B6242C,0xC136E704,0xE0277130,0x0061862B,0x0001229F,0xE07BCF10,0xE07BDFA8]
with (OUT/'CROM_TAIL_EXACT_ADDRESS_SCAN.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['value','cromtext_offsets','crommodule_offsets','cromfs_offsets'])
    for val in scan_values:
        pat=struct.pack('<I',val)
        hits=[]
        for name in ['cromtext','crommodule','cromfs']:
            hits.append(';'.join(hex(x) for x in find_all(sections[name],pat)))
        w.writerow([hex(val),*hits])

# ROMFS blocks and exact context text
blocks={
 'rtpadapter':(0xE0BC0084,0x300),
 'cdm_print_v2_configuration':(0xE099FF48,0x300),
}
with (OUT/'CROSS_SECTION_ROMFS_CONTEXTS.txt').open('w') as f:
    for label,(va,size) in blocks.items():
        off=va-rom_base; b=rom[off:off+size]
        f.write(f'[{label}] VMA={va:#010x} romfs_offset={off:#x} requested_size={size:#x} actual_size={len(b):#x}\n')
        f.write(f'SHA256={sha(b)}\n')
        for m in re.finditer(rb'[\x20-\x7e]{4,}',b):
            f.write(f'  {va+m.start():#010x}: {m.group().decode("ascii","replace")}\n')
        f.write('\n')

# aligned words in adapter block and function pointer candidates
adapter_va=0xE0BC0084; adapter_off=adapter_va-rom_base
pointer_rows=[]
for off in range(adapter_off,adapter_off+0x240,4):
    val=struct.unpack_from('<I',rom,off)[0]
    if sr_base <= (val & ~1) < sr_base+len(sr):
        pointer_rows.append([hex(rom_base+off),hex(val),hex(val&~1),'Thumb' if val&1 else 'ARM', 'function pointer candidate'])
with (OUT/'RTPADAPTER_CODE_POINTER_CANDIDATES.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['romfs_vma','stored_value','target_even_address','mode_hint','basis'])
    w.writerows(pointer_rows)

# extract instruction excerpts for selected code pointer targets
func_targets=[0xE093C520,0xE0981338,0xE093A958,0xE093CD68,0xE0590AA0,0xE0590AC0,0xE093C818,0xE093CE18,0xE093CF08,0xE093D2F0,0xE093D348,0xE093D3A0,0xE093D420]
lines=dis.splitlines()
with (OUT/'RTPADAPTER_CODE_POINTER_DISASSEMBLY.txt').open('w') as f:
    f.write('Selected code targets from the aligned pointer-like words in ROMFS object block E0BC0084.\n')
    f.write('These are exact target labels in the full SRtext disassembly. Semantic names/ownership are not inferred.\n\n')
    for target in func_targets:
        needle=f'{target:08x}:'
        idx=next((i for i,l in enumerate(lines) if l.startswith(needle)),None)
        f.write(f'[{target:#010x}]\n')
        if idx is None:
            f.write('NOT FOUND AS EXACT DISASSEMBLY LABEL\n\n'); continue
        for line in lines[idx:idx+18]: f.write(line+'\n')
        f.write('\n')

# Target references elsewhere; exact aligned 32-bit byte pattern only
with (OUT/'CROSS_SECTION_TARGET_REFERENCE_COUNTS.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['target','cromtext_hits','crommodule_hits','cromfs_hits','romfs_objs_hits','srtext_raw_hits'])
    for target in [0xE0BC0084,0xE099FF48,0xE099FF84,0xE0B621E0,0xE0B621EC,0xE0B6242C]:
        pat=struct.pack('<I',target)
        w.writerow([hex(target),*[len(find_all(sections[n],pat)) for n in ['cromtext','crommodule','cromfs']],len(find_all(rom,pat)),len(find_all(sr,pat))])

# FHX descriptor context
with (OUT/'FHX_TAIL_DESCRIPTOR_CONTEXT.txt').open('w') as f:
    f.write('Source FHX descriptor rows (125-entry table, CSV carried forward from Step 8).\n')
    for row in csv.reader(FHXCSV.open()):
        if len(row)>2 and row[2] in {'.cromtext','.crommodule','.cromfs','.cromfs_objs'}:
            f.write(','.join(row)+'\n')
    f.write('\nAssociated metadata VA -> payload offset mapping (payload base 0xE1357E40):\n')
    vals=[0xE135934C,0xE1359340,0xE1358918,0xE135936C,0xE1359364,0xE1358938,0xE1359394,0xE1359384,0xE1358958]
    for v in vals:
        po=v-0xE1357E40
        chunk=payload[po:po+32]
        f.write(f'{v:#010x} -> payload {po:#x}; bytes={chunk.hex(" ")}\n')
    f.write(f'Gap between .crommodule end and .cromfs start: payload [0xC48FAE,0xC48FB0) = {payload[0xC48FAE:0xC48FB0].hex()}\n')


with (OUT/'CROM_TAIL_GAPS.txt').open('w') as f:
    for name,off,data in [('.cromtext to .crommodule',0xC48B23,payload[0xC48B23:0xC48B24]),('.crommodule to .cromfs',0xC48FAE,payload[0xC48FAE:0xC48FB0])]:
        f.write(f'{name}: payload offset {off:#x}, bytes {data.hex()} ({len(data)} byte(s))\n')
        f.write('  First section end is exclusive; next section begins after these gap bytes.\n')

# Source input inventory
inputs=[PAYLOAD,ROMFS,SR,DIS,META,FHXCSV,Path('/mnt/data/hp_fw_inputs/tassel_LBI_verified.bin'),Path('/mnt/data/hp_fw_inputs/dump.bin'),Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/hp_lbi_sections.elf')]
with (OUT/'SOURCE_INPUTS.txt').open('w') as f:
    for p in inputs:
        b=p.read_bytes()
        f.write(f'{p}\n  size={len(b)} sha256={sha(b)}\n')

print('STEP9 evidence built')
for n,b in sections.items(): print(n,len(b),sha(b))
print('component records',len(component_hits),'module',sum(x['section']=='crommodule' for x in component_hits),'fs',sum(x['section']=='cromfs' for x in component_hits),'text',sum(x['section']=='cromtext' for x in component_hits))
print('adapter ptr candidates',len(pointer_rows),pointer_rows)
print('key refs',key_rows)
