# Part 22 Step 9 — CROM tail / module-resource trace

## Scope
Static-only offline inspection of the exact FHX `.cromtext`, `.crommodule`, and `.cromfs` descriptor ranges. No printer commands, network requests, flash writes, firmware patching, or state changes.

## Main findings
- Three tail sections extracted byte-for-byte from the rebuilt FHX secure payload. `.cromtext` is 1,763 bytes, `.crommodule` 1,162 bytes, `.cromfs` 2,892 bytes. Numeric descriptor flags are preserved but not interpreted.
- The tail is not contiguous: one gap byte `B9` separates `.cromtext` and `.crommodule`; bytes `E0 38` separate `.crommodule` and `.cromfs`.
- A byte-window crosswalk found 22 address patterns equal to known component metadata header minus 0x0C: 10 in `.crommodule`, 12 in `.cromfs`, none in `.cromtext`. These are not uniformly aligned, so the packed reference format is not yet proven.
- `.crommodule` section offset `0x152` contains unique little-endian value `0xE099FF48`, pointing into a CDM Print v2 configuration resource. The resource contains a pointer at `0xE099FF80` to `setupStatus` at `0xE099FF84`. It is not the separate alert/printAction resource provider.
- `.cromfs` section offset `0x36A` contains unique little-endian value `0xE0BC0084`, pointing to a ROMFS data block with the unique `rtpadapter` label, a `siriusInstance` text field, and three `/eventfifo/rtp_secure_pipe` strings. The `siriusInstance` text occurs 233 times in the full ROMFS image, so this is context, not proof of a live singleton pointer.
- The `rtpadapter` block stores Thumb-tagged code-pointer candidates at `0xE0BC024C`–`0xE0BC027C`. Eleven selected values resolve to exact instruction labels in the full `.srtext` disassembly. Several routines use indirect `BLX` callbacks whose runtime targets remain unknown. The observed instructions are preserved without inventing method names or a complete ABI.
- A separate `.crommodule` pointer leads to `hp.cdm.service.print.version.2.resource.configuration` and its linked `setupStatus` resource. This is not the separate `/cdm/print/v2/alerts` or `/cdm/print/v2/printAction` provider.
- The `.crommodule`/`.cromfs` byte-window matches are 22 candidate component-record-prefix references, not a proven parser/relocation table. The native `rtp_manager` metadata prefix, component header, and `0x1229F` service record do not appear as exact values in these three tail sections.
- This is not proof that `rtpadapter` is the `rtp_manager` provider, that the three event-pipe strings are actively used, or that this object sets the alert-list dependency or enforces a print restriction. No direct relation to the alert-list setter/selector or print-block routines is established.

## Reproduction
- `build_step9_evidence.py` extracts sections and regenerates inventories/context excerpts from the recorded source files.
- `verify_part22_step9.py` checks section sizes/hashes, gaps, all 22 component-prefix matches, target words, ROMFS string addresses, selected Thumb code-pointer labels, and negative raw address scans.
- `build_revision96.py` appends the Step 9 findings to Revision 95.
- `RAW_SECTIONS/` contains the three exact FHX tail-section byte ranges. `ROMFS_TARGET_BLOCKS/` contains exact 0x300-byte windows at the two resolved cross-section targets. `SOURCE_FILES/` preserves the component-header inventory and 125-entry FHX directory used by the crosswalk.
- `DIAGNOSTIC_DISASSEMBLY/` contains flat disassemblies of the three short tail sections only for reference; they are not trusted global code maps and are not used to claim function boundaries.

The verifier result is in `verification_output.txt`; inputs and hashes are in `SOURCE_INPUTS.txt`. The complete source LBI, full `.srtext` disassembly, and 16 MiB `dump.bin` are not duplicated. `dump.bin` is listed in the source inventory for provenance continuity only; this Step 9 analysis did not use its contents.
