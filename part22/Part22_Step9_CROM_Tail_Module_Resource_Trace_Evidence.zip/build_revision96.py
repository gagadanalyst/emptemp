from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path
import csv

BASE=Path('/mnt/data/hp_part22_step8/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision95_Part22_Step8_CROM_Sirius_Service_Descriptor_Trace.docx')
OUT=Path('/mnt/data/hp_part22_step9/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision96_Part22_Step9_CROM_Tail_Module_Resource_Trace.docx')
E=Path('/mnt/data/hp_part22_step9/evidence')
doc=Document(BASE)
NAVY='17365D'; BLUE='21618C'; PALE='D9EAF7'; GRAY='666666'; WARN='9C5700'; PALE2='EAF2F8'

def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def cell_text(cell,text,bold=False,color=None,size=6.7):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers,rows,widths=None,font=6.7):
    t=doc.add_table(rows=1,cols=len(headers)); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    for i,h in enumerate(headers): cell_text(t.rows[0].cells[i],h,True,NAVY,font); shade(t.rows[0].cells[i],PALE)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row): cell_text(cells[i],v,size=font)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t

def body(text,size=7.8,before=0,after=4,bold_lead=None,color=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(before); p.paragraph_format.space_after=Pt(after); p.paragraph_format.line_spacing=1.0
    if bold_lead and text.startswith(bold_lead):
        r=p.add_run(bold_lead); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(size)
        r=p.add_run(text[len(bold_lead):]); r.font.name='Aptos'; r.font.size=Pt(size)
    else:
        r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size)
        if color: r.font.color.rgb=RGBColor.from_string(color)
    return p

def h1(s):
    p=doc.add_paragraph(style='Heading 1'); p.paragraph_format.space_before=Pt(0); p.paragraph_format.space_after=Pt(5); p.add_run(s)
def h2(s):
    p=doc.add_paragraph(style='Heading 2'); p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(2); p.add_run(s)
def code(s,size=6.7):
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(.12); p.paragraph_format.right_indent=Inches(.05); p.paragraph_format.space_before=Pt(1); p.paragraph_format.space_after=Pt(3); p.paragraph_format.line_spacing=1.0
    r=p.add_run(s); r.font.name='Consolas'; r.font.size=Pt(size); r.font.color.rgb=RGBColor.from_string('333333')
def label(page):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(f'REVISION 96 | PART 22 STEP 9 | PAGE {page}'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(7.2); r.font.color.rgb=RGBColor.from_string(GRAY)

# Load generated inventories
sections=list(csv.DictReader((E/'CROM_TAIL_SECTIONS.csv').open()))
hits=list(csv.DictReader((E/'CROM_TAIL_COMPONENT_RECORD_CANDIDATES.csv').open()))
module_hits=[r for r in hits if r['section']=='crommodule']
fs_hits=[r for r in hits if r['section']=='cromfs']

# PAGE 186
doc.add_page_break(); label(186)
h1('Part 22 Step 9 — mapped CROM tail sections and boundaries')
h2('96.1 Exact FHX extraction and section identity')
body('The 125-entry FHX directory maps three small tail regions after `.cromsrtext`. They were extracted from the rebuilt FHX secure payload using each descriptor’s exact payload offset and byte size. All three extracted files byte-match the corresponding payload ranges and their SHA-256 digests are recorded below. Descriptor flag values are retained numerically; no execution or compression semantics are inferred from flag `0x2`.')
rows=[]
for r in sections:
    rows.append((f".{r['section']}",r['payload_offset'],r['vma'],r['size_bytes'],r['flags_numeric'],r['sha256'][:16]+'…'))
table(['Section','Payload offset','VMA','Size','Flags','SHA-256 prefix'],rows,widths=[1.0,1.05,1.15,.55,.48,2.0],font=6.15)
body('Source payload: 12,888,320 bytes, SHA-256 `aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858`. The three section hashes are: `.cromtext` `f4677e4c79bed2455397976c43491f4ad3d6cb20500144bcc8c6a32362e819af`; `.crommodule` `345156ea257f140cbe9e46ab619c24d4128fb68ab63af4d826192a981d068be6`; `.cromfs` `6a65a9d29a2b18142692cfb841899008579eaf3d63362e0f1002628bd1a1c188`.')
h2('96.2 Section gaps are preserved, not assumed contiguous')
table(['Boundary','End-exclusive / next VMA','Gap byte(s)','Observation'],[
('.cromtext → .crommodule','end `0xE1FA0963`; next `0xE1FA0964`','`B9` at payload `0xC48B23`','One-byte gap.'),
('.crommodule → .cromfs','end `0xE1FA0DEE`; next `0xE1FA0DF0`','`E0 38` at payload `0xC48FAE–0xC48FAF`','Two-byte gap.'),
],widths=[1.35,1.75,1.55,1.55],font=6.45)
body('The tail sections were inspected independently. Straight-line Thumb decoding from each section start did not yield a reliable global function map. The byte-level address matches described in this step are therefore treated as address-pattern references, not proof that every match is an aligned pointer or a parsed relocation entry.')
h2('96.3 Descriptor metadata remains raw')
body('The FHX entries also carry metadata pointers into the startup/header portion of the payload (including `0xE135934C/0xE1359340`, `0xE135936C/0xE1359364`, and `0xE1359394/0xE1359384`) and extra-field addresses (`0xE1358918`, `0xE1358938`, `0xE1358958`). Their associated bytes and offsets are preserved in `FHX_TAIL_DESCRIPTOR_CONTEXT.txt`; their undocumented fields are not assigned guessed meanings.')

# PAGE 187
doc.add_page_break(); label(187)
h1('CROM module records correlate with component metadata')
h2('96.4 Ten `.crommodule` address-pattern matches')
body('A byte-window scan of `.crommodule` found ten little-endian 32-bit values that exactly equal the address 0x0C bytes before a known component metadata header from the previously verified Part 7 inventory. They occur at the offsets below. These are candidate references to component-record prefixes; because the matches are not all four-byte aligned relative to the section start, the surrounding packed layout remains to be parsed.')
rows=[]
for r in module_hits:
    rows.append((r['section_offset'],r['section_vma'],r['reference_value'],r['component'],r['metadata_header'],r['offset_mod4']))
table(['Section offset','Section VMA','Value (header−0x0C)','Component','Header','Off mod 4'],rows,widths=[.85,1.0,1.45,1.35,1.15,.55],font=6.2)
body('The ten labels are `firm`, `hw_clock_sys`, `jm_echo`, `jm_jpeg_print`, `jm_pjl`, `jm_reports`, `job_tracker`, `jpeg`, `ldx`, and `lib_digital_sensor`. The `jm_jpeg_print` and `jm_reports` entries are print-related module records, but no exact alert endpoint or print-block method is identified by these matches.')
h2('96.5 A Print v2 resource reference is present in the same module region')
body('At `.crommodule` section offset `0x152` (VMA `0xE1FA0AB6`), the little-endian word is `0xE099FF48`. This is the unique occurrence of that exact word in `.crommodule`; the target falls inside `.romfs_objs`.')
code('0xE099FF48  hp.cdm.service.print.version.2.resource.configuration')
body('At ROMFS address `0xE099FF80`, a 32-bit internal pointer `0xE099FF84` leads to `com.hp.cdm.service.print.version.2.resource.setupStatus`. The surrounding bytes also contain `bad allocation` and C++ container diagnostic strings. This ties the CROM module region to Print v2 configuration/setup-status resource metadata. It does not identify the separate `/cdm/print/v2/alerts` or `/cdm/print/v2/printAction` resources previously traced in `CdmPrintAlertProvider`.')

# PAGE 188
doc.add_page_break(); label(188)
h1('CROM filesystem records correlate with PE, scan and other components')
h2('96.6 Twelve `.cromfs` address-pattern matches')
body('A parallel scan of `.cromfs` found twelve little-endian 32-bit values matching the address 0x0C bytes before component metadata headers. The matches span localization, PE, product properties, reporting, scan hardware, scan, sensor derivation, storage/memory initialization, and EWS control records.')
rows=[]
for r in fs_hits:
    rows.append((r['section_offset'],r['section_vma'],r['reference_value'],r['component'],r['metadata_header'],r['offset_mod4']))
table(['Section offset','Section VMA','Value (header−0x0C)','Component','Header','Off mod 4'],rows,widths=[.85,1.0,1.45,1.35,1.15,.55],font=6.15)
body('The twelve labels are `localization`, `pe`, `pe_digital_sensor`, `product_prop`, `reports_manager`, `rest_helper`, `scan_hw_mgr`, `scan`, `sense_deriv_proxy`, `smgr_init`, `smpw`, and `ews_ctrl`. No direct metadata-header matches were found; the exact relationship is to the pre-header address. The format of the packed references is not yet decoded.')
h2('96.7 The CROMFS index also references an RTP-adapter object')
body('At `.cromfs` section offset `0x36A` (VMA `0xE1FA115A`), the little-endian word is `0xE0BC0084`. This is the unique occurrence of that exact word in `.cromfs`. The target is inside `.romfs_objs` and begins a structured data block with first dword `0x00000DC8`, followed by pointers to `0xE0BC00D0`, `0xE0BC00E8`, and `0xE0BC0100`.')
body('At `0xE0BC0100` the block contains the unique ROMFS literal `rtpadapter`; at `0xE0BC010C` it contains `siriusInstance`. Three exact `/eventfifo/rtp_secure_pipe` strings occur at `0xE0BC01F1`, `0xE0BC020D`, and `0xE0BC0229`. The `siriusInstance` literal is not unique across ROMFS (233 occurrences), so it is context rather than proof of a singleton pointer or binding.')

# PAGE 189
doc.add_page_break(); label(189)
h1('RTP-adapter code references and the remaining enforcement gap')
h2('96.8 A code-pointer area is present in the RTP-adapter block')
body('The same ROMFS block contains Thumb-tagged values at `0xE0BC024C` and `0xE0BC0258–0xE0BC027C`. Each selected even target below is an exact instruction label in the full `.srtext` disassembly. Routine ownership and the table’s complete ABI are not yet established.')
ptrs=[
('0xE0BC024C','0xE093A959','0xE093A958'),('0xE0BC0258','0xE093CD69','0xE093CD68'),
('0xE0BC025C','0xE0590AA1','0xE0590AA0'),('0xE0BC0260','0xE0590AC1','0xE0590AC0'),
('0xE0BC0264','0xE093C819','0xE093C818'),('0xE0BC0268','0xE093CE19','0xE093CE18'),
('0xE0BC026C','0xE093CF09','0xE093CF08'),('0xE0BC0270','0xE093D2F1','0xE093D2F0'),
('0xE0BC0274','0xE093D349','0xE093D348'),('0xE0BC0278','0xE093D3A1','0xE093D3A0'),
('0xE0BC027C','0xE093D421','0xE093D420')]
table(['ROMFS slot','Stored Thumb value','Even disassembly target'],ptrs,widths=[1.25,1.75,1.9],font=6.2)
body('A separate callback pointer at `0xE0BC00CC` stores `0xE093C521` (target `0xE093C520`). Another helper pointer `0xE0981339` (target `0xE0981338`) repeats in 25 word slots between `0xE0BC0124` and `0xE0BC018C`. These are preserved as code-pointer candidates, not assigned guessed roles.')
body('The code at `0xE0590AA0` increments a counter field after a helper call; `0xE0590AC0` decrements a counter and returns the object only when the count reaches zero. The routine at `0xE093CD68` writes `0xE0BC0250` to the first word of its `this` object and invokes cleanup helpers for fields at offsets `+0x0C`, `+0x10`, and `+0x14`. Several later targets (`0xE093CE18`, `0xE093CF08`, `0xE093D3A0`, `0xE093D420`) contain indirect `BLX` callbacks. These are observed operations, not semantic names for the methods.')
h2('96.9 What this does and does not prove')
body('Confirmed: the FHX CROM tail contains a 22-entry set of address-pattern references to known component-record prefixes; `.crommodule` references a Print v2 configuration resource; `.cromfs` references a separate `rtpadapter` ROMFS object with Sirius and RTP secure-event-pipe strings plus code-pointer candidates.')
body('Not established: that the `rtpadapter` block is the `rtp_manager` provider; that `siriusInstance` is a live pointer rather than a string; that `/eventfifo/rtp_secure_pipe` is used for print-block enforcement; or that this code supplies the alert-list field `0xC136E704`. No exact raw occurrence of `0xE0B621E0` (RTP manager header−0x0C), `0xE0B621EC` (RTP manager header), `0xE0B6242C` (service record `0x1229F`), `0xE0277130`, or `0x0061862B` occurs in these tail sections.')
body('The original distinction remains: native RTP block/unblock (`0xE07C1211/0xE07C1219`), the PE blocked-state writer (`0xE0251788`), and the alert-provider interface are separate until a concrete handoff is recovered.')
h2('96.10 Next bounded step — subject to approval')
body('Trace the `rtpadapter` block’s code-pointer targets and their indirect callbacks, starting from the ROMFS data at `0xE0BC0084` and method-pointer region `0xE0BC024C–0xE0BC027C`. Search for an exact registration, event subscription, or collaborator pointer relationship to `siriusInstance`, the RTP service binder `0xE07BCF10`, and the native `rtp_manager` slot. Stop if the runtime callback target remains unavailable; do not infer a print restriction merely from the `/eventfifo/rtp_secure_pipe` strings.')
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(5); p.paragraph_format.space_after=Pt(0)
r=p.add_run('PART 22 STEP 9 COMPLETE — WAIT FOR APPROVAL BEFORE STEP 10'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(8.0); r.font.color.rgb=RGBColor.from_string(NAVY)

props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing and Scanning Investigation — Revision 96'
props.subject='Part 22 Step 9: CROM tail, component metadata and RTP-adapter resource trace'
props.comments='Appended to Revision 95. Static-only offline analysis. Raw address-pattern matches and embedded strings are kept distinct from proven runtime bindings.'
doc.save(OUT)
print(OUT)
