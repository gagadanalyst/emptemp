# Part 1 evidence package — RTP service binding and provider component trace

## Source and section verification

The package is derived from the verified LBI firmware image already in the Library root:
- `tassel_LBI_verified.bin` SHA-256: `2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e`
- `dump.bin` SHA-256: `b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496`

The source/derived files retained in this package are:
- `hp_lbi_sections.elf` — SHA-256 `25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7`
- `srtext_rebuilt.bin` — VMA `0xE0246070`, size `0x743634`, SHA-256 `10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7`
- `romfs_objs_rebuilt.bin` — VMA `0xE09919C0`, size `0x440D0C`, SHA-256 `227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3`
- `fhx_secure_payload_rebuilt.bin` — size `0xC4A900` / 12,888,320 bytes; SHA-256 `aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858`

`srtext_rebuilt.bin` and `romfs_objs_rebuilt.bin` were compared byte-for-byte with their section ranges inside `hp_lbi_sections.elf` (section file offsets `0x54` and `0x743688` respectively). Both comparisons passed.

## Part 1 result

1. `rtp_manager.block_print` (Thumb entry `0xE07C1211`) and `rtp_manager.unblock_print` (`0xE07C1219`) set `r0=1` and `r0=0`, then branch to the common helper `0xE07BDFA8`.
2. `0xE07BDFA8` reads the service pointer at `0xC19FD4C8` (slot 12; table base `0xC19FD498` + `0x30`). When non-null, it loads the object's vtable entry at `+0xA0` and invokes it with the requested boolean-like state.
3. `0xE07C0C28` is an initialization path that obtains the same slot-12 object and invokes its adjacent vtable method at `+0x9C`, passing the local object/context.
4. The method at `0xE07BCF10` is an RTP-manager service-binding method. It compares its service-ID argument with `0x0001229F`; on a match it stores its provider-object argument at `[0xC19FD498 + 0x30]`, i.e. `0xC19FD4C8`.
5. In `.romfs_objs`, a component/service registration record at file offset `0x1A10F0` contains ID `0x0001229F`, enabled/value flag `1`, component index `0x0D`, and is immediately followed by the ASCII label `pe` at `0x1A1100`. A separate record at `0x1D0A6C` contains the same ID and consumer index `0x0C`; the adjacent component label is `rtp_manager`.

**Conclusion:** the metadata places service ID `0x1229F` against a component entry labelled `pe` (index `0x0D`) and a corresponding entry labelled `rtp_manager` (index `0x0C`). Combined with the runtime setter on the RTP manager object, this makes `pe` the strong provider-side candidate. The table schema/direction and concrete provider C++ class/instance constructor are not yet independently proven. The short `pe` label is consistent with the Print Engine schemas/events but is not sufficient to claim a fully identified class.

## Explicitly not established

- No proven call edge yet from RTP slot-12 `+0xA0` to the writer of `DSID_PRINT_ENGINE_BLOCKED` (`0xE0251788`).
- No proof that IPP print submission reads `DSID_PRINT_ENGINE_BLOCKED` or the internal `inpr` cached lock.
- No proof that eSCL scan acquisition reads either of those states.
- Shared EventFIFO infrastructure between IPP and eSCL remains a transport/dispatch observation, not proof of a shared policy gate.

## Next part (approval required)

Trace the `pe` component's concrete service object creation/registration, resolve the vtable entries at `+0x9C` and `+0xA0`, and test whether the `+0xA0` state change reaches `DSID_PRINT_ENGINE_BLOCKED` or another Print Engine state. Do not proceed into that next part until approval.

## Files

- `part1_rtp_provider_trace.dis` — curated native disassembly excerpts.
- `romfs_service_records.txt` — raw little-endian words and VMA/file-offset context around the PE and RTP records.
- `elf_sections.txt` — ELF section table snapshot.
