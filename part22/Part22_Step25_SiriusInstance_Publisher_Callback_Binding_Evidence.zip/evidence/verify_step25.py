from pathlib import Path
import hashlib, struct, zipfile
ROOT=Path(__file__).resolve().parent; E=ROOT/'evidence'; D=E/'disassembly'; C=E/'crosswalks'
checks=[]
def ck(n,v): checks.append((n,bool(v)))
for line in (E/'SOURCE_HASHES.txt').read_text().splitlines():
 h,n=line.split('  ',1); p=E/n; ck('source hash '+n,p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==h)
ctor=(D/'C1443000_constructor.dis').read_text().lower()
call=(D/'C1443000_constructor_call.dis').read_text().lower()
thunk=(D/'C1443000_service_setter_thunk.dis').read_text().lower()
setter=(D/'C1443000_service_setter.dis').read_text().lower()
pub87=(D/'PINK_publish_event_0x87.dis').read_text().lower(); pub90=(D/'PINK_publish_event_0x90.dis').read_text().lower()
waitset=(D/'pe_wait_service_setter.dis').read_text().lower(); reg=(D/'pe_wait_condition_registration.dis').read_text().lower(); cb=(D/'pe_wait_callback.dis').read_text().lower(); sub=(D/'pe_wait_subscribe_unsubscribe.dis').read_text().lower()
ck('constructor call materializes C1443000','0xc144' in call and '#0x3000' in call and '0xe0308e70' in call)
ck('constructor writes interface pointer at root +0x18','#0xf194' in ctor and '[r0, #0x18]' in ctor)
ck('constructor clears publisher field +0x28','[r0, #0x28]' in ctor and 'movs\tr2, #0x0' in ctor)
ck('vtable setter thunk adjusts this -0x18','sub.w\tr0, r0, #0x18' in thunk)
ck('vtable setter thunk calls E0308D90','0xe0308d90' in thunk)
# Service-id arithmetic: r1 = id - 0x223EE5 - 0xFFFDB32C - 0xFFF7D79B - 0xFFF2A672.
id=0x000A701E; r=(id-0x00223EE5)&0xffffffff
for c in (0xFFFDB32C,0xFFF7D79B,0xFFF2A672): r=(r-c)&0xffffffff
ck('service 0xA701E hits setter equality branch',r==0)
ck('setter equality branch stores pointer at root +0x28','0xe0308e20' in setter and 'str\tr3, [r0, #0x28]' in setter)
id=0x0005742E; r=(id-0x00223EE5)&0xffffffff
for c in (0xFFFDB32C,0xFFF7D79B,0xFFF2A672): r=(r-c)&0xffffffff
ck('service 0x5742E does not map to C1443000 +0x28',r!=0)
ck('PINK publisher loads root field +0x28','[r0, #0x28]' in pub87)
ck('PINK publisher invokes vtable +0x18','[r1, #0x18]' in pub87)
ck('PINK publisher emits event 0x87','#0x87' in pub87)
ck('sibling publisher emits event 0x90','#0x90' in pub90 and '[r1, #0x18]' in pub90)
ck('pe_wait setter maps 0xA701E to +0x0C','#0x701e' in waitset and '[r0, #0xc]' in waitset)
ck('pe_wait setter maps 0x5742E to +0x10','#0x742e' in waitset and '[r0, #0x10]' in waitset)
ck('condition registration loads SiriusInstance field +0x0C','[r0, #0xc]' in reg)
ck('condition registration uses vtable +0x08','[r1, #0x8]' in reg)
ck('condition registration token is one','movs\tr3, #0x1' in reg)
ck('condition registration uses callback E0726850','#0x6851' in reg and '#0xe072' in reg)
ck('pe_wait callback handles 0x87 branch','#0x6d' in cb and '#0x9' in cb)
ck('pe_wait callback unsubscribes through 0x5742E provider','0xe0726798' in cb)
ck('pe_wait callback re-queries CanPrint','0xe07267b8' in cb)
ck('topic subscribe uses provider at +0x10','[r0, #0x10]' in sub)
ck('topic subscribe vtable +0x08 and type 0x3C','[r1, #0x8]' in sub and '#0x3c' in sub)
ck('topic unsubscribe vtable +0x10','[r1, #0x10]' in sub)
ck('binding distinction documented','0x5742e is a separate' in (E/'STEP25_FINDINGS.txt').read_text().lower())
ck('raw pointer equality caveat documented','raw runtime pointer' in (E/'STEP25_FINDINGS.txt').read_text().lower())
report=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision111_Part22_Step25_SiriusInstance_Publisher_Callback_Binding_Addendum.docx'
ck('Revision111 DOCX exists',report.exists() and report.stat().st_size>10000)
fail=[x for x in checks if not x[1]]
out=[f'Step 25 focused verification: {len(checks)-len(fail)}/{len(checks)} PASS','']+[(('PASS' if ok else 'FAIL')+' | '+n) for n,ok in checks]
(E/'verification_output.txt').write_text('\n'.join(out)+'\n')
print('\n'.join(out))
if fail: raise SystemExit(1)
