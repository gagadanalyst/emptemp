# Part 22 Step 25 — SiriusInstance service-binding identity

This evidence proves that the PINK publisher and the `pe_wait_for_canprint` condition callback both use service ID `0x000A701E` (SiriusInstance). It distinguishes this from the wait-topic provider `0x0005742E`.

## Central chain
- `0xE0309260` constructs PINK root `0xC1443000` using `0xE0308E70`.
- The root's secondary vtable contains setter thunk `0xE03091F1`, which adjusts `this` by `-0x18` and calls dependency setter `0xE0308D90`.
- Setter `0xE0308D90` maps service ID `0xA701E` to root offset `+0x28`, which is the publisher used by `0xE0305708` / `0xE0305748`.
- `pe_wait_for_canprint` setter `0xE07269B0` maps the same service ID to `+0x0C`; `0xE07268A8` registers callback `0xE0726850` through that service.
- `0x5742E` is a separate `pe_wait` dependency at `+0x10`, used for topic subscribe/unsubscribe.

## Caveat
Logical dependency identity by service key is confirmed. The generic resolver's runtime pointer values are not exposed in the static image, so exact pointer equality is not asserted. The active runtime condition on the physical printer and the missing `0x13` reason conversion remain unresolved.

## Package contents
`STEP25_FINDINGS.txt`, scoped Thumb disassembly, ROMFS vtable/service-ID crosswalk CSVs, source binaries and hashes, Step 23/24 baselines, verifier and final Revision 111 DOCX/PDF.

Static-only: no printer communication, print, scan, firmware write, or physical device action.
