# Part 22, Step 30 - PE event aggregate and RTP method-dispatch audit

This evidence package preserves the static firmware findings for Revision 116.

## Main result
The PE publisher calculates a 32-record listener/token aggregate (base `0xC190A148`, stride `0x5C8`) and emits subtype `0x8B` for nonzero aggregate or `0x8C` for zero. The `smgr_pe` subscriber writes `DSID_PRINT_ENGINE_BLOCKED=1` for 0x8B and `=0` for 0x8C, while ROMFS enum names label 0x8B as `printing_unblocked` and 0x8C as `ink_sub_block_trial_print`. This contradiction is confirmed; its semantic explanation is unresolved.

The RTP manager table does register `rtp_manager.unblock_print`, but the dispatcher transport and authorization surface are unproven. This is not a safe user command.

## Files
- `STEP30_FINDINGS.txt` - full findings, confidence boundaries, and next targets.
- `disassembly/` - focused Thumb disassembly excerpts.
- `crosswalks/` - event label/action, aggregate mapping, direct DSID writer callsites, RTP method table and service 0x1FF211 crosswalks.
- `pe_event_metadata_strings.txt` - ROMFS event metadata strings.
- `SOURCE_INPUTS.txt` - provenance and SHA-256 values for source inputs.
- `SHA256SUMS.txt` - checksums for all evidence files (not including itself or final ZIP).
- `verification_output.txt` - focused static assertions.

## Verification scope
The verifier checks exact code and metadata anchors reproduced in this package. It is not a proof of all runtime behavior and does not emulate firmware. The package was generated from preserved static firmware inputs and disassembly. No device communication or modification occurred.
