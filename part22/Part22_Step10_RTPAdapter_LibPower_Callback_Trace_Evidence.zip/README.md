# HP DeskJet 2855e firmware investigation — Part 22 Step 10

This package preserves the offline/static analysis of RTP-adapter code-pointer candidates, the separate `lib_power` API, power-client identifiers, and a statically constructed `siriusInstance`-named dependency descriptor.

## Main findings

- The full ROMFS block at `0xE0BC0084` is included as `romfs/rtpadapter_full_0xDC8.bin` and verified byte-for-byte against the rebuilt `.romfs_objs` section.
- Selected adapter function pointers resolve to exact `.srtext` instruction labels. Several methods invoke indirect callbacks whose runtime targets remain unresolved.
- `lib_pwr` exposes five methods. Its 24-client taxonomy includes `POWER_CLIENT_SCAN` (`0x00000400`) and `POWER_CLIENT_PE_POLICY` (`0x00800000`). The existence of PE_POLICY does not prove it gates print admission.
- The inspected `lib_pwr.control` matched-resource path uses `POWER_CLIENT_PEN` (`0x10`); the clock/resource path uses a separate helper.
- A Thumb-pointer run contains an initializer that creates a three-word dependency descriptor whose third field names `siriusInstance`. A ROMFS method pointer exposes an accessor to that descriptor. The initializer runner, dependency resolver and live object binding are not established.
- No direct branch/call from the inspected adapter/lib_power regions reaches the Sirius alert-list setter, native RTP binder/helper or PE blocked-state writer.

## Limits

Static firmware analysis only. No printer commands, network requests, state changes or firmware modifications were performed. Indirect `BLX` targets and runtime dependency resolution remain unresolved. Do not treat the PE_POLICY identity or the RTP adapter label as proof of subscription print enforcement.

## Contents

- Revision 97 DOCX: complete updated investigation (194 pages).
- `evidence/`: extracted disassembly, inventories, source hashes, verifier and output.
- `romfs/`: exact 0xDC8-byte extracted ROMFS block.
- `work/`: scripts used to produce the Step 10 evidence/document.
- `evidence/QA_REPORT.md`: exact DOCX render, inherited-page comparison and new-page inspection results.
- `evidence/SHA256SUMS`: checksums for the packaged payload files, excluding the checksum file itself.

## Reproduction

Run `python evidence/verify_part22_step10.py` in an environment with the exact source inputs available at the paths recorded in `evidence/SOURCE_INPUTS.txt`.
