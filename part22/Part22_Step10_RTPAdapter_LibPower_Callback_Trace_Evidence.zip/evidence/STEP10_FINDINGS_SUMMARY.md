# Part 22 Step 10 — RTP-adapter, lib_power and named-dependency trace

## Scope
Offline/static analysis only. No printer interaction, network activity or firmware writes.

## Verified findings
- The full ROMFS block at `0xE0BC0084` is `0xDC8` bytes (file offset `0x22E6C4` in `.romfs_objs`), SHA-256 `8c35f96b5053fc23304027978de4af659303d097faf907ae26ba7a1d0b0a1714`.
- Its early region contains the `rtpadapter` label, a `siriusInstance` string and three `/eventfifo/rtp_secure_pipe` strings. A separate region in the same block contains `lib_power` names and tables. Co-location is not proof that the data belongs to one object or ABI.
- Seven adapter function-pointer candidates in the inspected record resolve to exact `.srtext` instruction labels. The cleanup and parsing/normalization methods use indirect callback dispatch; their runtime callback targets remain unresolved.
- `lib_pwr` exposes five name/function entries: `enable_error_chks`, `disable_error_chks`, `control`, `get_active_clients`, and `clear_clients`.
- A 24-slot fixed-stride client table names power clients. `POWER_CLIENT_SCAN` is position 11 (zero-based slot 10), mask `0x00000400`; `POWER_CLIENT_PE_POLICY` is position 24 (zero-based slot 23), mask `0x00800000`.
- `lib_pwr.control` scans **403** resource-name rows (indices 0–402; termination bound `0x193`) and, on the matched-resource path, uses mask `0x10` (`POWER_CLIENT_PEN`) with the shared acquire/release helpers. It separately scans **19** clock/resource names (indices 0–18; termination bound `0x13`) and invokes a different helper with mask `0x400`.
- **Count correction:** an earlier interim note described 404 resource rows and 20 clock entries. That was an off-by-one reading of the loop termination checks. The instruction bounds establish 403 and 19, respectively; the earlier counts are superseded.
- `get_active_clients` enumerates 403 resource rows and reads active-client masks; `clear_clients` traverses those rows and the 24 client bits, invoking the release helper for set bits.
- Direct users of the generic acquire helper include callers passing PHOTO (`0x100`), SCAN (`0x400`), OPT_SENSOR (`0x200`), PEN (`0x10`), AASIC2 (`0x8`), NONE (`0x1`) and SYS (`0x800`), plus callers forwarding values dynamically. No reviewed direct call site passed a constant `0x800000` (`PE_POLICY`) mask. This does not prove the PE_POLICY client is unused.
- The aligned ROMFS word run `[0xE0DD2014,0xE0DD26C0)` contains 427 unique, ascending Thumb-tagged pointers into `.srtext`; each even target is an exact disassembly label. Slot `0xE0DD26B0` (entry 424) stores `0xE093E311`, targeting initializer `0xE093E310`. The run is consistent with an initializer/registration-function list, but its runner and execution semantics were not recovered.
- The initializer at `0xE093E310` writes a three-word descriptor at `0xC1D62B4C`: `[+0]=0xE0BC05EC`, `[+4]=0xE0BC0630`, `[+8]=0xE0BC0654`; the third word points to the string `siriusInstance`. ROMFS slot `0xE0BC0534` stores Thumb pointer `0xE093E291`, exposing accessor `0xE093E290`, which returns descriptor base `0xC1D62B4C`. The invoker remains unknown.

## Boundaries / unresolved
- The descriptor establishes a statically constructed Sirius-named dependency descriptor and a ROMFS method-pointer exposure of its accessor. It does not establish resolution to the live PE singleton at `0xC190662C`; no runtime pointer observation or direct binding edge was recovered.
- `POWER_CLIENT_PE_POLICY` is an explicit member of the power-client taxonomy. The inspected call-site set does not show a constant `0x800000` acquisition; dynamic or indirect uses remain possible. A power-client identity alone does not prove print-job denial.
- The `lib_pwr.control` method's matched-resource path uses `POWER_CLIENT_PEN`, not `POWER_CLIENT_PE_POLICY`. The separate clock path uses another helper and must not be conflated with the generic power acquire API.
- No direct branch/call from the inspected adapter/parser and lib_power code ranges was found to the alert-list setter `0xE0277130`, native RTP binder `0xE07BCF10`, RTP helper `0xE07BDFA8`, or PE blocked-state writer `0xE0251788`. Indirect callback targets remain runtime-resolved.
- The most useful next step is to identify callers and data flow for `POWER_CLIENT_PE_POLICY` and the descriptor accessor, while keeping power management distinct from RTP/PE print-block enforcement until a concrete edge is found.
