from pathlib import Path
import hashlib,struct,re,csv
ROOT=Path(__file__).resolve().parent
ROM_PATH=Path("/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/romfs_objs_rebuilt.bin")
SR_PATH=Path("/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/srtext_rebuilt.bin")
DIS_PATH=Path("/mnt/data/hp_fw_inputs/srtext_disasm_all.txt")
ROM=ROM_PATH.read_bytes(); DIS=DIS_PATH.read_text(errors="replace")
BASE=0xE09919C0; SRLO=0xE0246070; SRHI=SRLO+SR_PATH.stat().st_size
def w(a): return struct.unpack_from("<I",ROM,a-BASE)[0]
def cstr(a,n=128): return ROM[a-BASE:a-BASE+n].split(b"\0")[0].decode("ascii","replace")
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
line_map={int(m.group(1)[:8],16):m.group(0) for m in re.finditer(r"^([0-9a-fA-F]{8}:.*)$",DIS,re.M)}
labels=set(line_map)
checks=[]
def ck(n,cond): checks.append((n,bool(cond)))
def has_line(addr,pattern):
    line=line_map.get(addr)
    return bool(line and re.search(pattern,line,re.I))
run=[w(a) for a in range(0xE0DD2014,0xE0DD26C0,4)]
ck("427 pointer-run entries",len(run)==427)
ck("pointer-run values unique",len(set(run))==427)
ck("pointer-run strictly ascending",all(a<b for a,b in zip(run,run[1:])))
ck("all pointer-run values Thumb-tagged",all(v&1 for v in run))
ck("all pointer-run targets inside srtext",all(SRLO <= (v&~1) < SRHI for v in run))
ck("all pointer-run targets exact disassembly labels",all((v&~1) in labels for v in run))
ck("initializer ROMFS slot exact",w(0xE0DD26B0)==0xE093E311)
ck("initializer is pointer-run entry 424",run[423]==0xE093E311)
ck("initializer instruction constructs descriptor base",has_line(0xE093E314,r"movw\s+r0, #0x2b4c") and has_line(0xE093E31C,r"movt\s+r0, #0xc1d6"))
ck("initializer points to Sirius name string",has_line(0xE093E310,r"movw\s+r1, #0x654") and has_line(0xE093E318,r"movt\s+r1, #0xe0bc") and cstr(0xE0BC0654)=="siriusInstance")
ck("descriptor store helper writes three words",has_line(0xE093E262,r"stm\.w\s+r0, \{r2, r3, r12\}"))
ck("ROMFS exposes descriptor accessor pointer",w(0xE0BC0534)==0xE093E291)
ck("descriptor accessor constructs C1D62B4C",has_line(0xE093E290,r"movw\s+r1, #0x2b4c") and has_line(0xE093E294,r"movt\s+r1, #0xc1d6"))
# Descriptor fields point to ROMFS method/data arrays; validate actual contents without assuming the runner/ABI.
field0=[w(a) for a in range(0xE0BC05F4,0xE0BC0630,4)]
field4=[w(a) for a in range(0xE0BC0638,0xE0BC0654,4)]
ck("descriptor field-0 ROMFS method values are Thumb SR labels",len(field0)==15 and all(v&1 and SRLO <= (v&~1) < SRHI and (v&~1) in labels for v in field0))
ck("descriptor field-4 ROMFS method values are Thumb SR labels",len(field4)==7 and all(v&1 and SRLO <= (v&~1) < SRHI and (v&~1) in labels for v in field4))
clients=list(csv.DictReader((ROOT/"POWER_CLIENT_TABLE_24.csv").open()))
ck("power-client table has 24 rows",len(clients)==24)
ck("power-client masks follow one-hot index mapping",all(int(x["mask"],16)==(1<<int(x["table_slot_zero_based"])) for x in clients))
ck("SCAN client slot and mask",clients[10]["name"]=="POWER_CLIENT_SCAN" and clients[10]["mask"]=="0x00000400")
ck("PE_POLICY client slot and mask",clients[23]["name"]=="POWER_CLIENT_PE_POLICY" and clients[23]["mask"]=="0x00800000")
methods=list(csv.DictReader((ROOT/"LIB_POWER_METHOD_TABLE.csv").open()))
ck("lib_power method table has five entries",len(methods)==5)
ck("lib_power exported names exact",[x["name"] for x in methods]==["lib_pwr.enable_error_chks","lib_pwr.disable_error_chks","lib_pwr.control","lib_pwr.get_active_clients","lib_pwr.clear_clients"])
clocks=list(csv.DictReader((ROOT/"POWER_CLOCK_RESOURCE_NAMES_19.csv").open()))
ck("clock/resource-name table has 19 entries",len(clocks)==19)
ck("resource loop bound 0x193 = 403",has_line(0xE093E3F8,r"movw\s+r0, #0x193") and has_line(0xE093E40A,r"movw\s+r0, #0x193"))
ck("clock loop bound 0x13 = 19",has_line(0xE093E446,r"cmp\s+r4, #0x13") and has_line(0xE093E454,r"cmp\s+r4, #0x13"))
ck("get_active_clients loops across 403 rows",has_line(0xE093E4EC,r"cmp\.w\s+r4, #0x192") and has_line(0xE093E4F0,r"ble\s+0xe093e484"))
ck("clear_clients loops across 403 rows",has_line(0xE093E564,r"cmp\.w\s+r5, #0x192") and has_line(0xE093E568,r"ble\s+0xe093e4fc"))
ck("power control matched-resource call uses PEN mask",has_line(0xE093E3EE,r"movs\s+r1, #0x10") and has_line(0xE093E3F4,r"bl\s+0xe093dc50"))
ck("clock control matched-resource call uses separate helper and mask",has_line(0xE093E43A,r"mov\.w\s+r1, #0x400") and has_line(0xE093E442,r"bl\s+0xe045b4b0"))
ck("lib_power ROMFS name/function pairs match five methods",all(w(int(x["descriptor_slot"],16))==int(x["name_ptr"],16) and w(int(x["descriptor_slot"],16)+4)==int(x["function_ptr"],16) for x in methods))
calls=list(csv.DictReader((ROOT/"POWER_ACQUIRE_CALLSITE_MASKS.csv").open()))
ck("14 acquire-helper callers are inventoried",len(calls)==14)
ck("all inventoried callers branch to acquire helper",all(has_line(int(x["call_site"],16),r"(?:bl|b\.w)\s+0xe093dc50") for x in calls))
# For constant masks, confirm the immediate r1 setup appears in the few instructions preceding each call.
constant_ok=True
for x in calls:
    if x["client_mask"].startswith("0x"):
        ca=int(x["call_site"],16); ctx="\n".join(line_map.get(a,"") for a in range(ca-12,ca,2))
        imm=int(x["client_mask"],16)
        if not re.search(rf"mov(?:\.w|s)?\s+r1, #0x{imm:x}\b",ctx,re.I): constant_ok=False
ck("constant acquire masks are present before their calls",constant_ok)
# Scope direct-call negatives to the adapter and lib_power code ranges only.
scoped_absent=True
for src,line in line_map.items():
    if not ((0xE093C4C0 <= src < 0xE093D440) or (0xE093DCA0 <= src < 0xE093E570)): continue
    if re.search(r"\b(?:blx?|b\.w|bne\.w|beq\.w)\s+0x(?:e0277130|e07bcf10|e07bdfa8|e0251788)\b",line,re.I): scoped_absent=False
ck("no scoped direct branch to alert/RTP/PE blockers",scoped_absent)
ck("RTP secure event-pipe string appears three times",ROM.count(b"/eventfifo/rtp_secure_pipe")==3)
ck("adapter cleanup target is exact code label",0xE093CD68 in labels)
ck("adapter event wrapper targets are exact code labels",all(a in labels for a in [0xE093CE18,0xE093CF08,0xE093D2F0,0xE093D3A0,0xE093D420]))
# Verify source provenance from the current local inputs.
source_rows={}
for line in (ROOT/"SOURCE_INPUTS.txt").read_text().splitlines():
    if line.startswith("/"): source_rows[line]=[]
    elif line.startswith("size_bytes=") or line.startswith("sha256="): source_rows[list(source_rows)[-1]].append(line)
for path in [str(ROM_PATH),str(SR_PATH),str(ELF_PATH),str(DIS_PATH),str(LBI_PATH)]:
    rows=source_rows.get(path,[])
    ck(f"source hash and size match: {Path(path).name}",len(rows)==2 and rows[0]==f"size_bytes={Path(path).stat().st_size}" and rows[1]==f"sha256={sha(path)}")
failed=[n for n,p in checks if not p]
for n,p in checks: print(("PASS" if p else "FAIL"),n)
print(f"TOTAL {len(checks)} PASS {sum(p for _,p in checks)} FAIL {len(failed)}")
if failed: raise SystemExit(1)
