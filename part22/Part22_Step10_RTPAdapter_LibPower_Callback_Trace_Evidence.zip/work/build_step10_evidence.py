from pathlib import Path
import struct, hashlib, csv, re, json, zipfile, shutil

ROOT=Path('/mnt/data/hp_part22_step10')
E=ROOT/'evidence'; W=ROOT/'work'; R=ROOT/'romfs'
E.mkdir(parents=True,exist_ok=True); W.mkdir(parents=True,exist_ok=True); R.mkdir(parents=True,exist_ok=True)
ROM_PATH=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/romfs_objs_rebuilt.bin')
SR_PATH=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/srtext_rebuilt.bin')
ELF_PATH=Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/hp_lbi_sections.elf')
DIS_PATH=Path('/mnt/data/hp_fw_inputs/srtext_disasm_all.txt')
LBI_PATH=Path('/mnt/data/hp_fw_inputs/tassel_LBI_verified.bin')
rom=ROM_PATH.read_bytes(); sr=SR_PATH.read_bytes(); dis=DIS_PATH.read_text(errors='replace')
ROM_BASE=0xE09919C0; SR_BASE=0xE0246070; SR_SIZE=len(sr)

def sha(b): return hashlib.sha256(b).hexdigest()
def va_bytes(va,n):
    off=va-ROM_BASE
    assert 0 <= off and off+n <= len(rom),(hex(va),n)
    return rom[off:off+n]
def word(va): return struct.unpack('<I',va_bytes(va,4))[0]
def cstr(va,maxlen=256): return va_bytes(va,maxlen).split(b'\0')[0].decode('ascii','replace')
def write_csv(path,rows,fields):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

# Exact RTP adapter / power-library block
block=va_bytes(0xE0BC0084,0xDC8)
(R/'rtpadapter_full_0xDC8.bin').write_bytes(block)
# Raw hex excerpt for key structures
with (E/'ROMFS_key_regions_hex.txt').open('w') as f:
    f.write('ROMFS base 0xE09919C0; selected ranges are absolute VA.\n')
    for start,end in [(0xE0BC0240,0xE0BC0290),(0xE0BC03E8,0xE0BC0568),(0xE0BC05E0,0xE0BC0780),(0xE0BC098C,0xE0BC0C68)]:
        f.write(f'\n[{start:#010x}, {end:#010x})\n')
        for a in range(start,end,16):
            row=va_bytes(a,min(16,end-a))
            txt=''.join(chr(x) if 32<=x<127 else '.' for x in row)
            f.write(f'{a:08x}: {row.hex(" ")}  {txt}\n')

# Disassembly symbol/address labels and direct branch/call edges
labels=set()
for line in dis.splitlines():
    m=re.match(r'^([0-9a-fA-F]{8}):',line)
    if m: labels.add(int(m.group(1),16))

def extract_dis(start,end,name):
    lines=[]
    for line in dis.splitlines():
        m=re.match(r'^([0-9a-fA-F]{8}):',line)
        if m:
            a=int(m.group(1),16)
            if start<=a<end: lines.append(line)
    (E/name).write_text('\n'.join(lines)+'\n')
    return lines
extract_dis(0xE093C4C0,0xE093D440,'rtpadapter_code_cluster_disassembly.txt')
extract_dis(0xE093DCA0,0xE093E570,'lib_power_disassembly.txt')
extract_dis(0xE093E240,0xE093E3A8,'sirius_dependency_descriptor_disassembly.txt')

# Build label-to-address set only exact instruction starts; disassembler labels include data words too, mark separately.
# Identify every direct branch/call reference text to exact methods.
branch_lines=[]
for line in dis.splitlines():
    if re.search(r'\b(?:blx?|b\.w|bne\.w|beq\.w)\s+0x',line,re.I):
        branch_lines.append(line)

# Pointer run at tail of ROMFS
run_start=0xE0DD2014; run_end=0xE0DD26C0
ptr_rows=[]; ptr_vals=[]
for va in range(run_start,run_end,4):
    v=word(va); ptr_vals.append(v)
    target=v & ~1
    ptr_rows.append({'romfs_slot':f'0x{va:08X}','stored_value':f'0x{v:08X}','target_even':f'0x{target:08X}',
                     'thumb_tag':bool(v&1),'target_in_srtext':SR_BASE<=target<SR_BASE+SR_SIZE,
                     'exact_disassembly_label':target in labels})
write_csv(E/'ROMFS_function_pointer_run_427.csv',ptr_rows,list(ptr_rows[0].keys()))
assert len(ptr_rows)==427
assert all(r['thumb_tag'] and r['target_in_srtext'] and r['exact_disassembly_label'] for r in ptr_rows)
assert len(set(ptr_vals))==427 and all(a<b for a,b in zip(ptr_vals,ptr_vals[1:]))
initializer_va=0xE0DD26B0
assert word(initializer_va)==0xE093E311
initializer_index=(initializer_va-run_start)//4+1
# Descriptor initializer disassembly and descriptor bytes
# E093E310 constructs C1D62B4C and E0BC0654; E093E250 writes E0BC05EC/E0BC0630/r12.
desc={'global_base':'0xC1D62B4C','field_0':'0xE0BC05EC','field_4':'0xE0BC0630','field_8':'0xE0BC0654',
      'field_8_string':cstr(0xE0BC0654,64),'initializer_fn':'0xE093E310','romfs_thumb_pointer':'0xE093E311',
      'pointer_table_slot':'0xE0DD26B0','pointer_table_index_1based':initializer_index}
(E/'SIRIUS_DEPENDENCY_DESCRIPTOR.json').write_text(json.dumps(desc,indent=2)+'\n')
# Verify initializer code exact address constructors and setter body.
assert 'e093e310:' in dis.lower() and 'movw\tr1, #0x654' in dis.lower()
assert 'movw\tr0, #0x2b4c' in dis.lower()
assert 'e093e250:' in dis.lower() and 'stm.w\tr0, {r2, r3, r12}' in dis.lower()
assert desc['field_8_string']=='siriusInstance'
# accessor pointer at ROMFS E0BC0534
assert word(0xE0BC0534)==0xE093E291
# E093E290 returns descriptor base; E093E278 returns +4 pointer.
# Full disassembly xrefs: function direct calls count; dynamic registration is via stored pointer.
refs={}
for target in [0xE093E310,0xE093E290,0xE093E278,0xE093DC50,0xE093DC68,0xE093DC80,0xE07BCF10,0xE07BDFA8,0xE0277130,0xE0251788]:
    pat=f'0x{target:08x}'
    refs[pat]=[l for l in branch_lines if pat in l.lower()]
(E/'DIRECT_CALL_XREF_AUDIT.txt').write_text('\n'.join(f'{k} ({len(v)} direct branch/call refs):\n'+'\n'.join(v) for k,v in refs.items())+'\n')
# Check no direct branch refs from adapter cluster itself to core binding/alert/PE targets.
cluster=[l for l in branch_lines if re.match(r'^e093c[4-9a-f][0-9a-f]{2}:|^e093d[0-4][0-9a-f]{2}:',l.lower())]
for t in [0xE07BCF10,0xE07BDFA8,0xE0277130,0xE0251788]:
    assert not any(f'0x{t:08x}' in l.lower() for l in cluster)

# Power clients table, 24 x 30 bytes
client_base=0xE0BC098C; stride=30
clients=[]
for i in range(24):
    name=va_bytes(client_base+i*stride,stride).split(b'\0')[0].decode('ascii','replace')
    clients.append({'table_slot_zero_based':i,'table_position_one_based':i+1,'mask':f'0x{1<<i:08X}','name':name})
write_csv(E/'POWER_CLIENT_TABLE_24.csv',clients,list(clients[0].keys()))
assert clients[10]['name']=='POWER_CLIENT_SCAN' and clients[10]['mask']=='0x00000400'
assert clients[23]['name']=='POWER_CLIENT_PE_POLICY' and clients[23]['mask']=='0x00800000'

# lib_power exported method descriptor pair inventory
methods=[
 {'descriptor_slot':'0xE0BC06AC','name_ptr':'0xE0BC06F4','name':cstr(0xE0BC06F4,64),'function_ptr':'0xE093E399','function':'0xE093E398','observed':'Sets diagnostic/error-check flag to 1 via 0xE093DCA0'},
 {'descriptor_slot':'0xE0BC06B8','name_ptr':'0xE0BC0710','name':cstr(0xE0BC0710,64),'function_ptr':'0xE093E3A1','function':'0xE093E3A0','observed':'Sets diagnostic/error-check flag to 0 via 0xE093DCB0'},
 {'descriptor_slot':'0xE0BC06C4','name_ptr':'0xE0BC072C','name':cstr(0xE0BC072C,64),'function_ptr':'0xE093E3A9','function':'0xE093E3A8','observed':'Matches resource names in 403-entry registry; control path uses POWER_CLIENT_PEN mask 0x10'},
 {'descriptor_slot':'0xE0BC06D0','name_ptr':'0xE0BC073C','name':cstr(0xE0BC073C,64),'function_ptr':'0xE093E481','function':'0xE093E480','observed':'Enumerates 403 resource rows and active client bitmasks; emits client labels'},
 {'descriptor_slot':'0xE0BC06DC','name_ptr':'0xE0BC0758','name':cstr(0xE0BC0758,64),'function_ptr':'0xE093E4F9','function':'0xE093E4F8','observed':'Enumerates resources and 24 client bits; invokes shared release helper to clear entries'},
]
write_csv(E/'LIB_POWER_METHOD_TABLE.csv',methods,list(methods[0].keys()))

# 20 clock/resource names from pointer table at E0BC0770
clock_names=[]
for i in range(19):
    p=word(0xE0BC0770+i*4)
    clock_names.append({'slot':i,'pointer':f'0x{p:08X}','name':cstr(p,96)})
write_csv(E/'POWER_CLOCK_RESOURCE_NAMES_19.csv',clock_names,list(clock_names[0].keys()))

# Power acquire/release direct caller inventory with recoverable immediate masks from disassembly context
call_sites=[
 ('0xE0561B64','dynamic','dynamic','resource/client arguments are computed before tail branch'),
 ('0xE073C4D8','dynamic','dynamic','mask forwarded from caller argument r5'),
 ('0xE093E2A4','forwarded','forwarded','wrapper forwards caller-supplied client mask into acquire helper'),
 ('0xE058C654','0x00000100','POWER_CLIENT_PHOTO','immediate in r1 immediately before branch'),
 ('0xE058C6AA','0x00000400','POWER_CLIENT_SCAN','immediate in r1 immediately before branch'),
 ('0xE058C8BC','0x00000400','POWER_CLIENT_SCAN','immediate in r1 immediately before BL'),
 ('0xE058CB22','0x00000400','POWER_CLIENT_SCAN','immediate in r1 immediately before BL'),
 ('0xE0671B46','0x00000200','POWER_CLIENT_OPT_SENSOR','immediate in r1 immediately before BL'),
 ('0xE071447C','0x00000010','POWER_CLIENT_PEN','immediate in r1 immediately before BL'),
 ('0xE0741712','0x00000008','POWER_CLIENT_AASIC2','immediate in r1 immediately before BL'),
 ('0xE0928584','0x00000001','POWER_CLIENT_NONE','immediate in r1 immediately before BL'),
 ('0xE093DF2E','0x00000800','POWER_CLIENT_SYS','inside helper with resource index 0x31'),
 ('0xE093E354','0x00000800','POWER_CLIENT_SYS','inside helper with resource index 0x31'),
 ('0xE093E3F4','0x00000010','POWER_CLIENT_PEN','within lib_pwr.control resource-name path'),
]
call_rows=[]
for addr,mask,name,note in call_sites:
    call_rows.append({'call_site':addr,'client_mask':mask,'client_name':name,'note':note})
write_csv(E/'POWER_ACQUIRE_CALLSITE_MASKS.csv',call_rows,list(call_rows[0].keys()))

# The E093E290 method pointer is present in ROMFS but no direct branch/call xref exists in srtext.
# Also no direct branch refs to core binder/setter from the inspected adapter/lib_power address band.
# Record whole exact source provenance.
source_files=[ROM_PATH,SR_PATH,ELF_PATH,DIS_PATH,LBI_PATH]
with (E/'SOURCE_INPUTS.txt').open('w') as f:
    for p in source_files:
        data=p.read_bytes()
        f.write(f'{p}\nsize_bytes={len(data)}\nsha256={sha(data)}\n\n')
# Include key sections from block, source hashes, and verifier context.
(E/'STEP10_FINDINGS_SUMMARY.md').write_text('''# Part 22 Step 10 — RTP-adapter, lib_power and named-dependency trace

## Scope
Offline/static analysis only. No printer interaction, network activity or firmware writes.

## Verified findings
- The full ROMFS block at `0xE0BC0084` is `0xDC8` bytes (file offset `0x22E6C4` in `.romfs_objs`), SHA-256 `8c35f96b5053fc23304027978de4af659303d097faf907ae26ba7a1d0b0a1714`.
- Its early region contains the `rtpadapter` label, a `siriusInstance` string and three `/eventfifo/rtp_secure_pipe` strings. A separate region in the same block contains `lib_power` names and tables. Co-location is not proof that the data belongs to one object or ABI.
- Seven adapter function-pointer candidates in the inspected record resolve to exact `.srtext` instruction labels. The cleanup and parsing/normalization methods use indirect callback dispatch; their runtime callback targets remain unresolved.
- `lib_pwr` exposes five name/function entries: `enable_error_chks`, `disable_error_chks`, `control`, `get_active_clients`, and `clear_clients`.
- A 24-slot fixed-stride client table names power clients. `POWER_CLIENT_SCAN` is position 11 (zero-based slot 10), mask `0x00000400`; `POWER_CLIENT_PE_POLICY` is position 24 (zero-based slot 23), mask `0x00800000`.
- `lib_pwr.control` scans **403** resource-name rows (indices 0–402; termination bound `0x193`) and, on the matched-resource path, uses mask `0x10` (`POWER_CLIENT_PEN`) with the shared acquire/release helpers. It separately scans **19** clock/resource names (indices 0–18; termination bound `0x13`) and invokes a different helper with mask `0x400`.
- **Count correction:** an earlier interim note described 404 resource rows and 20 clock entries. That was an off-by-one reading of the loop termination checks. The instruction bounds establish 403 and 19, respectively; the earlier counts are superseded.
- `get_active_clients` enumerates 403 resource rows and reads active-client masks; `clear_clients` traverses those rows and the 24 client bits, invoking the release helper for set bits.
- Direct users of the generic acquire helper include callers passing PHOTO (`0x100`), SCAN (`0x400`), OPT_SENSOR (`0x200`), PEN (`0x10`), AASIC2 (`0x8`), NONE (`0x1`) and SYS (`0x800`), plus callers forwarding values dynamically. No reviewed direct call site passed a constant `0x800000` (`PE_POLICY`) mask. This does not prove the PE_POLICY client is unused.
- The aligned ROMFS word run `[0xE0DD2014,0xE0DD26C0)` contains 427 unique, ascending Thumb-tagged pointers into `.srtext`; each even target is an exact disassembly label. Slot `0xE0DD26B0` (entry 424) stores `0xE093E311`, targeting initializer `0xE093E310`. The run is consistent with an initializer/registration-function list, but its runner and execution semantics were not recovered.
- The initializer at `0xE093E310` writes a three-word descriptor at `0xC1D62B4C`: `[+0]=0xE0BC05EC`, `[+4]=0xE0BC0630`, `[+8]=0xE0BC0654`; the third word points to the string `siriusInstance`. ROMFS slot `0xE0BC0534` stores Thumb pointer `0xE093E291`, exposing accessor `0xE093E290`, which returns descriptor base `0xC1D62B4C`. The invoker remains unknown.

## Boundaries / unresolved
- The descriptor establishes a statically constructed Sirius-named dependency descriptor and a ROMFS method-pointer exposure of its accessor. It does not establish resolution to the live PE singleton at `0xC190662C`; no runtime pointer observation or direct binding edge was recovered.
- `POWER_CLIENT_PE_POLICY` is an explicit member of the power-client taxonomy. The inspected call-site set does not show a constant `0x800000` acquisition; dynamic or indirect uses remain possible. A power-client identity alone does not prove print-job denial.
- The `lib_pwr.control` method's matched-resource path uses `POWER_CLIENT_PEN`, not `POWER_CLIENT_PE_POLICY`. The separate clock path uses another helper and must not be conflated with the generic power acquire API.
- No direct branch/call from the inspected adapter/parser and lib_power code ranges was found to the alert-list setter `0xE0277130`, native RTP binder `0xE07BCF10`, RTP helper `0xE07BDFA8`, or PE blocked-state writer `0xE0251788`. Indirect callback targets remain runtime-resolved.
- The most useful next step is to identify callers and data flow for `POWER_CLIENT_PE_POLICY` and the descriptor accessor, while keeping power management distinct from RTP/PE print-block enforcement until a concrete edge is found.
''')

# Lightweight static verifier script generated after this build.
verifier=r'''from pathlib import Path
import hashlib,struct,re,csv
ROOT=Path(__file__).resolve().parent
ROM_PATH=Path("/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/romfs_objs_rebuilt.bin")
SR_PATH=Path("/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/srtext_rebuilt.bin")
DIS_PATH=Path("/mnt/data/hp_fw_inputs/srtext_disasm_all.txt")
ROM=ROM_PATH.read_bytes(); DIS=DIS_PATH.read_text(errors="replace")
BASE=0xE09919C0; SRLO=0xE0246070; SRHI=SRLO+SR_PATH.stat().st_size
def w(a): return struct.unpack_from("<I",ROM,a-BASE)[0]
def cstr(a,n=128): return ROM[a-BASE:a-BASE+n].split(b"\0")[0].decode("ascii","replace")
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
line_map={int(m.group(1)[:8],16):m.group(0) for m in re.finditer(r"^([0-9a-fA-F]{8}:.*)$",DIS,re.M)}
labels=set(line_map)
checks=[]
def ck(n,cond): checks.append((n,bool(cond)))
def has_line(addr,pattern):
    line=line_map.get(addr)
    return bool(line and re.search(pattern,line,re.I))
run=[w(a) for a in range(0xE0DD2014,0xE0DD26C0,4)]
ck("427 pointer-run entries",len(run)==427)
ck("pointer-run values unique",len(set(run))==427)
ck("pointer-run strictly ascending",all(a<b for a,b in zip(run,run[1:])))
ck("all pointer-run values Thumb-tagged",all(v&1 for v in run))
ck("all pointer-run targets inside srtext",all(SRLO <= (v&~1) < SRHI for v in run))
ck("all pointer-run targets exact disassembly labels",all((v&~1) in labels for v in run))
ck("initializer ROMFS slot exact",w(0xE0DD26B0)==0xE093E311)
ck("initializer is pointer-run entry 424",run[423]==0xE093E311)
ck("initializer instruction constructs descriptor base",has_line(0xE093E314,r"movw\s+r0, #0x2b4c") and has_line(0xE093E31C,r"movt\s+r0, #0xc1d6"))
ck("initializer points to Sirius name string",has_line(0xE093E310,r"movw\s+r1, #0x654") and has_line(0xE093E318,r"movt\s+r1, #0xe0bc") and cstr(0xE0BC0654)=="siriusInstance")
ck("descriptor store helper writes three words",has_line(0xE093E262,r"stm\.w\s+r0, \{r2, r3, r12\}"))
ck("ROMFS exposes descriptor accessor pointer",w(0xE0BC0534)==0xE093E291)
ck("descriptor accessor constructs C1D62B4C",has_line(0xE093E290,r"movw\s+r1, #0x2b4c") and has_line(0xE093E294,r"movt\s+r1, #0xc1d6"))
# Descriptor fields point to ROMFS method/data arrays; validate actual contents without assuming the runner/ABI.
field0=[w(a) for a in range(0xE0BC05F4,0xE0BC0630,4)]
field4=[w(a) for a in range(0xE0BC0638,0xE0BC0654,4)]
ck("descriptor field-0 ROMFS method values are Thumb SR labels",len(field0)==15 and all(v&1 and SRLO <= (v&~1) < SRHI and (v&~1) in labels for v in field0))
ck("descriptor field-4 ROMFS method values are Thumb SR labels",len(field4)==7 and all(v&1 and SRLO <= (v&~1) < SRHI and (v&~1) in labels for v in field4))
clients=list(csv.DictReader((ROOT/"POWER_CLIENT_TABLE_24.csv").open()))
ck("power-client table has 24 rows",len(clients)==24)
ck("power-client masks follow one-hot index mapping",all(int(x["mask"],16)==(1<<int(x["table_slot_zero_based"])) for x in clients))
ck("SCAN client slot and mask",clients[10]["name"]=="POWER_CLIENT_SCAN" and clients[10]["mask"]=="0x00000400")
ck("PE_POLICY client slot and mask",clients[23]["name"]=="POWER_CLIENT_PE_POLICY" and clients[23]["mask"]=="0x00800000")
methods=list(csv.DictReader((ROOT/"LIB_POWER_METHOD_TABLE.csv").open()))
ck("lib_power method table has five entries",len(methods)==5)
ck("lib_power exported names exact",[x["name"] for x in methods]==["lib_pwr.enable_error_chks","lib_pwr.disable_error_chks","lib_pwr.control","lib_pwr.get_active_clients","lib_pwr.clear_clients"])
clocks=list(csv.DictReader((ROOT/"POWER_CLOCK_RESOURCE_NAMES_19.csv").open()))
ck("clock/resource-name table has 19 entries",len(clocks)==19)
ck("resource loop bound 0x193 = 403",has_line(0xE093E3F8,r"movw\s+r0, #0x193") and has_line(0xE093E40A,r"movw\s+r0, #0x193"))
ck("clock loop bound 0x13 = 19",has_line(0xE093E446,r"cmp\s+r4, #0x13") and has_line(0xE093E454,r"cmp\s+r4, #0x13"))
ck("get_active_clients loops across 403 rows",has_line(0xE093E4EC,r"cmp\.w\s+r4, #0x192") and has_line(0xE093E4F0,r"ble\s+0xe093e484"))
ck("clear_clients loops across 403 rows",has_line(0xE093E564,r"cmp\.w\s+r5, #0x192") and has_line(0xE093E568,r"ble\s+0xe093e4fc"))
ck("power control matched-resource call uses PEN mask",has_line(0xE093E3EE,r"movs\s+r1, #0x10") and has_line(0xE093E3F4,r"bl\s+0xe093dc50"))
ck("clock control matched-resource call uses separate helper and mask",has_line(0xE093E43A,r"mov\.w\s+r1, #0x400") and has_line(0xE093E442,r"bl\s+0xe045b4b0"))
ck("lib_power ROMFS name/function pairs match five methods",all(w(int(x["descriptor_slot"],16))==int(x["name_ptr"],16) and w(int(x["descriptor_slot"],16)+4)==int(x["function_ptr"],16) for x in methods))
calls=list(csv.DictReader((ROOT/"POWER_ACQUIRE_CALLSITE_MASKS.csv").open()))
ck("14 acquire-helper callers are inventoried",len(calls)==14)
ck("all inventoried callers branch to acquire helper",all(has_line(int(x["call_site"],16),r"(?:bl|b\.w)\s+0xe093dc50") for x in calls))
# For constant masks, confirm the immediate r1 setup appears in the few instructions preceding each call.
constant_ok=True
for x in calls:
    if x["client_mask"].startswith("0x"):
        ca=int(x["call_site"],16); ctx="\n".join(line_map.get(a,"") for a in range(ca-12,ca,2))
        imm=int(x["client_mask"],16)
        if not re.search(rf"mov(?:\.w|s)?\s+r1, #0x{imm:x}\b",ctx,re.I): constant_ok=False
ck("constant acquire masks are present before their calls",constant_ok)
# Scope direct-call negatives to the adapter and lib_power code ranges only.
scoped_absent=True
for src,line in line_map.items():
    if not ((0xE093C4C0 <= src < 0xE093D440) or (0xE093DCA0 <= src < 0xE093E570)): continue
    if re.search(r"\b(?:blx?|b\.w|bne\.w|beq\.w)\s+0x(?:e0277130|e07bcf10|e07bdfa8|e0251788)\b",line,re.I): scoped_absent=False
ck("no scoped direct branch to alert/RTP/PE blockers",scoped_absent)
ck("RTP secure event-pipe string appears three times",ROM.count(b"/eventfifo/rtp_secure_pipe")==3)
ck("adapter cleanup target is exact code label",0xE093CD68 in labels)
ck("adapter event wrapper targets are exact code labels",all(a in labels for a in [0xE093CE18,0xE093CF08,0xE093D2F0,0xE093D3A0,0xE093D420]))
# Verify source provenance from the current local inputs.
source_rows={}
for line in (ROOT/"SOURCE_INPUTS.txt").read_text().splitlines():
    if line.startswith("/"): source_rows[line]=[]
    elif line.startswith("size_bytes=") or line.startswith("sha256="): source_rows[list(source_rows)[-1]].append(line)
for path in [str(ROM_PATH),str(SR_PATH),str(ELF_PATH),str(DIS_PATH),str(LBI_PATH)]:
    rows=source_rows.get(path,[])
    ck(f"source hash and size match: {Path(path).name}",len(rows)==2 and rows[0]==f"size_bytes={Path(path).stat().st_size}" and rows[1]==f"sha256={sha(path)}")
failed=[n for n,p in checks if not p]
for n,p in checks: print(("PASS" if p else "FAIL"),n)
print(f"TOTAL {len(checks)} PASS {sum(p for _,p in checks)} FAIL {len(failed)}")
if failed: raise SystemExit(1)
'''
(E/'verify_part22_step10.py').write_text(verifier)
print('Built Step 10 evidence files.')
print('ROM block SHA256',sha(block),'size',len(block))
print('init list len',len(ptr_rows),'entry index',initializer_index)
print('clients:',', '.join(x['name'] for x in clients))
