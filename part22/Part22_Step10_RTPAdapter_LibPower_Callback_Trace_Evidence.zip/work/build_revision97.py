from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path
import csv, hashlib

BASE=Path('/mnt/data/hp_part22_step9/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision96_Part22_Step9_CROM_Tail_Module_Resource_Trace.docx')
OUT=Path('/mnt/data/hp_part22_step10/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision97_Part22_Step10_RTPAdapter_LibPower_Callback_Trace.docx')
E=Path('/mnt/data/hp_part22_step10/evidence')
W=Path('/mnt/data/hp_part22_step10/work')
doc=Document(BASE)
NAVY='17365D'; BLUE='21618C'; PALE='D9EAF7'; GRAY='666666'; WARN='9C5700'; GREEN='38761D'; PALE2='EAF2F8'

def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def cell_text(cell,text,bold=False,color=None,size=6.6):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers,rows,widths=None,font=6.5):
    t=doc.add_table(rows=1,cols=len(headers)); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    for i,h in enumerate(headers): cell_text(t.rows[0].cells[i],h,True,NAVY,font); shade(t.rows[0].cells[i],PALE)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row): cell_text(cells[i],v,size=font)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t

def body(text,size=7.55,before=0,after=3,bold_lead=None,color=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(before); p.paragraph_format.space_after=Pt(after); p.paragraph_format.line_spacing=1.0
    if bold_lead and text.startswith(bold_lead):
        r=p.add_run(bold_lead); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(size)
        r=p.add_run(text[len(bold_lead):]); r.font.name='Aptos'; r.font.size=Pt(size)
    else:
        r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size)
        if color: r.font.color.rgb=RGBColor.from_string(color)
    return p

def h1(s):
    p=doc.add_paragraph(style='Heading 1'); p.paragraph_format.space_before=Pt(0); p.paragraph_format.space_after=Pt(4); p.add_run(s)
def h2(s):
    p=doc.add_paragraph(style='Heading 2'); p.paragraph_format.space_before=Pt(3); p.paragraph_format.space_after=Pt(2); p.add_run(s)
def code(s,size=6.35):
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(.12); p.paragraph_format.right_indent=Inches(.05); p.paragraph_format.space_before=Pt(1); p.paragraph_format.space_after=Pt(2); p.paragraph_format.line_spacing=1.0
    r=p.add_run(s); r.font.name='Consolas'; r.font.size=Pt(size); r.font.color.rgb=RGBColor.from_string('333333')
def label(page):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(f'REVISION 97 | PART 22 STEP 10 | PAGE {page}'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(7.0); r.font.color.rgb=RGBColor.from_string(GRAY)

# Load evidence inventories generated from the exact ROMFS/SR section inputs.
clients=list(csv.DictReader((E/'POWER_CLIENT_TABLE_24.csv').open()))
methods=list(csv.DictReader((E/'LIB_POWER_METHOD_TABLE.csv').open()))
acq=list(csv.DictReader((E/'POWER_ACQUIRE_CALLSITE_MASKS.csv').open()))
ptr_rows=list(csv.DictReader((E/'ROMFS_function_pointer_run_427.csv').open()))
clock=list(csv.DictReader((E/'POWER_CLOCK_RESOURCE_NAMES_19.csv').open()))

# PAGE 190 — adapter object and its pointers

doc.add_page_break(); label(190)
h1('Part 22 Step 10 — RTP-adapter object and callback targets')
h2('97.1 Complete ROMFS block recovered')
body('The ROMFS target reached from `.cromfs` at section offset `0x36A` is the full `0xDC8`-byte block beginning at `0xE0BC0084` (ROMFS file offset `0x22E6C4`). Its SHA-256 is `8c35f96b5053fc23304027978de4af659303d097faf907ae26ba7a1d0b0a1714`. This step expands the earlier `0x300`-byte excerpt so references beyond `0xE0BC0384` are included.')
body('The block contains an early `rtpadapter` data area, then separate method/metadata regions and a `lib_power` region. `rtpadapter`, `siriusInstance`, and the three `/eventfifo/rtp_secure_pipe` strings are literal data. Their co-location with the later power-library tables does not prove one object, one vtable, or one ABI.')
table(['ROMFS address','Observed data'],[
('`0xE0BC0100`','`rtpadapter` label'),
('`0xE0BC010C`','`siriusInstance` literal'),
('`0xE0BC01F1`','`/eventfifo/rtp_secure_pipe`'),
('`0xE0BC020D`','`/eventfifo/rtp_secure_pipe`'),
('`0xE0BC0229`','`/eventfifo/rtp_secure_pipe`'),
('`0xE0BC0534`','Thumb pointer `0xE093E291` → accessor `0xE093E290`'),
('`0xE0BC05E0`','`lib_power` label; following power-library method/data tables'),
],widths=[1.35,5.15],font=6.5)
h2('97.2 Selected adapter code-pointer targets')
rows=[
('`0xE0BC0258`','`0xE093CD69`','`0xE093CD68`','Object cleanup / field cleanup path'),
('`0xE0BC0268`','`0xE093CE19`','`0xE093CE18`','Record/event wrapper; indirect callback'),
('`0xE0BC026C`','`0xE093CF09`','`0xE093CF08`','Record/event wrapper; indirect callback'),
('`0xE0BC0270`','`0xE093D2F1`','`0xE093D2F0`','Typed parsing/dispatch helper'),
('`0xE0BC0278`','`0xE093D3A1`','`0xE093D3A0`','Date/year normalization helper'),
('`0xE0BC027C`','`0xE093D421`','`0xE093D420`','Parse handler; indirect callback'),
]
table(['ROMFS slot','Stored Thumb','Even target','Observed code behavior'],rows,widths=[1.0,1.15,1.15,3.2],font=6.15)
body('All listed even targets are exact instruction labels in the full `.srtext` disassembly. The methods include indirect `BLX` dispatch; concrete callback targets are resolved at runtime and were not statically recovered. These methods cannot yet be assigned a proven print-block or subscription-enforcement role.')

# PAGE 191 — power interface

doc.add_page_break(); label(191)
h1('The co-located lib_power interface is a distinct subsystem')
h2('97.3 Five exported method descriptors')
rows=[]
for x in methods:
    rows.append((x['name'].replace('lib_pwr.',''),x['function'],x['observed']))
table(['Export name','Even code entry','Observed role'],rows,widths=[1.45,1.25,3.8],font=6.15)
body('The method names are read from ROMFS descriptor/name pairs and paired with Thumb function pointers. `enable_error_chks` and `disable_error_chks` toggle a diagnostic/error-check flag through helpers. `control` matches resource names and dispatches state operations. `get_active_clients` reports active-client bits and labels. `clear_clients` walks resource rows and calls the shared release helper for active client bits.')
h2('97.4 Resource and clock registries are different tables')
table(['Table','Backing location','Loop bound','Actual entries','Use'],[
('Resource-name registry','`0xC0229DDC`','`0x193` (indices 0–402)','403','Matched by `lib_pwr.control`; used by active-client reporting/clearing.'),
('Clock/resource-name pointers','`0xE0BC0770`','`0x13` (indices 0–18)','19','Separate clock/resource operation via `0xE045B4B0`.'),
('Active-client mask rows','`0xC1D624F4`','`0x192` with inclusive `ble`','403','One 32-bit active-client mask per resource row.'),
],widths=[1.2,1.35,1.0,.65,2.3],font=6.0)
body('The 403 resource count follows from a loop that processes indices 0 through 402 and exits after testing against 0x193. The active-client and clear routines use an inclusive comparison against 0x192, likewise processing indices 0 through 402. The separate clock loop uses a strict `blo` comparison against 0x13, processing indices 0 through 18.')
h2('97.5 The control path does not use PE_POLICY')
body('For a matched resource row, `lib_pwr.control` passes `r1 = 0x10` (`POWER_CLIENT_PEN`) into the shared acquire helper at `0xE093DC50`; the release branch uses `0xE093DC68`. Its separate clock path passes `r1 = 0x400` to `0xE045B4B0`, a different helper. Neither path demonstrates a `POWER_CLIENT_PE_POLICY` acquisition.')

# PAGE 192 — power client table and callsite masks

doc.add_page_break(); label(192)
h1('Power-client identities and observed acquire call sites')
h2('97.6 Fixed 24-slot client taxonomy')
rows=[]
for i in range(0,24,2):
    a=clients[i]; b=clients[i+1]
    rows.append((a['table_position_one_based'],a['name'].replace('POWER_CLIENT_',''),a['mask'],b['table_position_one_based'],b['name'].replace('POWER_CLIENT_',''),b['mask']))
table(['Pos.','Client suffix','Mask','Pos.','Client suffix','Mask'],rows,widths=[.35,1.8,.9,.35,1.8,.9],font=5.75)
body('The table displays the suffix after the common `POWER_CLIENT_` prefix; the full identifiers are preserved in the evidence CSV. The masks are one-hot bit positions derived from the 24 fixed-stride name records. `POWER_CLIENT_SCAN` is position 11 / mask `0x00000400`. `POWER_CLIENT_PE_POLICY` is position 24 / mask `0x00800000`. The latter is a real named client in the table, but its presence alone does not show that it gates print-job acceptance.')
h2('97.7 Direct users of the shared power acquire helper')
# Keep table compact and include dynamic/forwarded call sites.
rows=[]
for x in acq:
    if x['client_mask'] in ('dynamic','forwarded'):
        m=x['client_mask']; n=x['client_name']
    else:
        m=x['client_mask']; n=x['client_name']
    rows.append((x['call_site'],m,n,x['note']))
table(['Call site','r1 mask','Client / source','Observed argument detail'],rows,widths=[.9,.8,1.45,2.9],font=5.9)
body('The sampled direct callers provide positive examples for PHOTO, SCAN, OPT_SENSOR, PEN, AASIC2, NONE and SYS. Several wrappers forward a caller-supplied mask. No reviewed direct call site loads the constant `0x00800000` immediately before calling the shared acquire helper. That is a scoped negative, not proof that PE_POLICY is unused elsewhere or not passed dynamically.')

# PAGE 193 — Sirius dependency descriptor

doc.add_page_break(); label(193)
h1('A registered Sirius-named dependency descriptor is exposed')
h2('97.8 The aligned ROMFS pointer run')
body('The ROMFS word range `[0xE0DD2014, 0xE0DD26C0)` contains 427 aligned words. Every value is unique, strictly ascending, Thumb-tagged, points into `.srtext`, and resolves to an exact instruction label in the retained full disassembly. This structure is consistent with an initializer/registration-function run, but its runner and execution semantics have not been recovered.')
code('ROMFS slot 0xE0DD26B0  →  stored Thumb pointer 0xE093E311\nEntry 424 of 427         →  even function entry 0xE093E310')
h2('97.9 The initializer creates a three-word descriptor')
code('0xE093E310: builds r0 = 0xC1D62B4C and r1 = 0xE0BC0654\n0xE093E250: stores {0xE0BC05EC, 0xE0BC0630, 0xE0BC0654} at [r0]\n0xE0BC0654: ASCII "siriusInstance"')
body('This is stronger than a free-standing string occurrence: an initializer-like function referenced by the 427-word run constructs the descriptor, and a ROMFS method pointer at `0xE0BC0534` exposes the accessor `0xE093E290`, which returns `0xC1D62B4C`. The first two descriptor fields point into ROMFS method/data arrays whose values are Thumb-tagged `.srtext` addresses. Their table ABI and consumers remain unknown.')
h2('97.10 The boundary of the Sirius finding')
body('Confirmed: a statically constructed three-word dependency descriptor is named `siriusInstance`, its initializer is stored in the ROMFS pointer run, and a method-pointer slot exposes an accessor that returns its base. Not confirmed: that the initializer list is executed, that the descriptor is resolved, or that it resolves to the live PE singleton at `0xC190662C`. No direct `.srtext` caller of the accessor or runner was recovered.')

# PAGE 194 — conclusions and correction

doc.add_page_break(); label(194)
h1('Step 10 conclusion — useful leads, print enforcement still open')
h2('97.11 Explicit correction to the interim counts')
body('An earlier progress message described 404 resource rows and 20 clock/resource entries. That was an off-by-one estimate. The verified resource-loop bound is 0x193 with indices 0–402, giving 403 rows. The clock-loop bound is 0x13 with indices 0–18, giving 19 entries. The corrected counts are used throughout Revision 97 and in the evidence verifier; the earlier figures are superseded.',bold_lead='An earlier progress message')
h2('97.12 What Step 10 adds to the original investigation')
body('The strongest new result is the combination of (1) a Sirius-named dependency descriptor constructed by a function in a 427-entry Thumb-pointer run and exposed through a ROMFS method pointer, and (2) a concrete power-management API with an explicit `POWER_CLIENT_PE_POLICY` identity. These supply specific next targets: the descriptor accessor’s caller, the dependency resolver, and code that actually passes the PE_POLICY mask to the shared power acquire/release helpers.')
body('This does not yet explain the print restriction. The `lib_pwr.control` matched-resource path uses `POWER_CLIENT_PEN` rather than PE_POLICY; no inspected direct caller acquired power with mask `0x00800000`; and no direct calls were found from the inspected adapter/lib_power regions to `0xE0277130`, `0xE07BCF10`, `0xE07BDFA8`, or `0xE0251788`. Indirect callback targets and dynamic masks remain unresolved.')
h2('97.13 Recommended next bounded step — subject to approval')
body('Trace every direct caller and data-flow source for `POWER_CLIENT_PE_POLICY` (`0x00800000`) and identify which code calls the descriptor accessor at `0xE093E290` or resolves the name `siriusInstance`. Compare any concrete caller to PE print-state transitions and the known RTP binder only after a direct edge is found. Keep power-resource management separate from print admission/blocking unless the code proves they are connected.')
body('No printer commands, network requests, device-state changes, or firmware modifications were performed. Static indirect `BLX` targets and the runtime dependency resolver remain outside what the retained offline artifacts prove.',size=7.1)
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(6); p.paragraph_format.space_after=Pt(0)
r=p.add_run('PART 22 STEP 10 COMPLETE — WAIT FOR APPROVAL BEFORE STEP 11'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(8.2); r.font.color.rgb=RGBColor.from_string(GREEN)

props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing and Scanning Investigation — Revision 97'
props.subject='Part 22 Step 10: RTP-adapter callbacks, lib_power API, and Sirius dependency descriptor'
props.comments='Appended to Revision 96. Static offline analysis only. Corrected resource and clock counts from interim off-by-one estimates.'
doc.save(OUT)
print(OUT)
print('Bytes',OUT.stat().st_size,'SHA256',hashlib.sha256(OUT.read_bytes()).hexdigest())
