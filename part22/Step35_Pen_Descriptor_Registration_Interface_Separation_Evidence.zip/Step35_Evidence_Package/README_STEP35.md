# Step 35 — Pen descriptor registration and interface separation

## Scope
Read-only static analysis of the recovered DeskJet firmware. This step follows the Step 34 `siriusInstance +0x24` identity-provider boundary and checks the nearby object initialization and registration paths. No printer communication, print/scan operation, firmware write, hardware change, or live runtime instrumentation was performed.

## Confirmed findings

1. The `siriusInstance` primary vtable at `0xE0B4C838` contains distinct virtual entries at offsets `+0x260`, `+0x264`, `+0x268`, and `+0x26C`:
   - `+0x260` -> `0xE07470C8`, which branches to the separate setup routine `0xE072C8E0`.
   - `+0x264` -> `0xE07470D0`, the field-address resolver documented in Step 34.
   - `+0x268` -> `0xE0747130`, the field setter documented in Step 34.
   - `+0x26C` -> `0xE07472B0`, which branches to Pen initialization routine `0xE072C958`.

   Important control-flow correction: `0xE072C8E0` returns at `0xE072C954`; it does not directly call `0xE072D530`. The following routine begins at `0xE072C958` and contains the descriptor-registration call.

2. Constructor `0xE0746A08` initializes the object fields at `+0x1C`, `+0x20`, `+0x24`, and `+0x28` to zero before publishing the singleton through global `0xC193B3C0`. Thus the two interface slots discussed below are initially null in the static constructor path.

3. Pen initializer `0xE072C958` calls `0xE072D530`. That routine loads `siriusInstance +0x20` and invokes its virtual method at `+0x08` three times with ROMFS descriptors (the descriptor-name pointer is passed on the stack; the first register argument is a separate numeric descriptor identifier):
   - descriptor name `PEN` (`0xE0B3A1FC`), data table `0xE0B3A218`, type argument `0x67`;
   - descriptor name `PEN_G3_K` (`0xE0B3A20C`), data table `0xE0B3AA38`, type argument `0x8F`;
   - descriptor name `PEN_G3_C` (`0xE0B3A200`), data table `0xE0B3B578`, type argument `0x8F`.

   The first data table contains Pen configuration properties such as `PEN_PACING_DELAY_US`, `PEN_NOMINAL_AMB_REF`, and other `PEN_*` entries. The G3 tables include firing-parameter fields. This is confirmed Pen descriptor/configuration registration through the `+0x20` interface; it is not proof that this interface reads the physical Pen identity.

4. The same Pen initializer `0xE072C958` copies the ROMFS Pen table beginning at `0xE0B3A058` (0xC8 bytes), performs per-entry registration through the separate `siriusInstance +0x4C` interface, calls `0xE072D530` to register the `PEN` / `PEN_G3_*` descriptors through `+0x20`, and then calls methods on `siriusInstance +0x24` at vtable offsets `+0xE4` and `+0xE8`. Conditional follow-on calls use `+0x120` and `+0x124`. The snapshot wrapper `0xE0736078` separately calls the same `+0x24` interface at `+0xEC`.

   The `+0x24` member is therefore a broader Pen-service interface with multiple consumers. The semantic contract of its individual methods, including `+0xEC`, is not fully recovered here. The separate `+0x260` method `0xE072C8E0` is retained as a related setup path, but this step does not attribute the Pen descriptor registration to it.

5. Setter `0xE0747130` contains distinct field-selector cases. Its branch arithmetic maps `0x00D7ADED` to a store at `siriusInstance +0x20` (`0xE074725E`) and `0x00DFB904` to a store at `siriusInstance +0x24` (`0xE0747262`). The first key is derived from `0x006D5DBC + 0x006A5031` = `0x00D7ADED`; the second adds `0x00073F67` and `0x0000CBB0`, yielding the Step 34 selector `0x00DFB904`.

6. `0x00D7ADED` occurs ten times in the retained ROMFS metadata, while `0x00DFB904` occurs three times. Both are repeated in generic metadata records and neither is uniquely Pen-specific. The earlier value `0x00D80DED` was an arithmetic error and has zero literal occurrences. Neither selector occurrence count identifies the runtime setter caller.

## What remains unresolved

- No direct static call/argument handoff to `0xE0747130` has been recovered for either interface slot.
- The runtime pointer values delivered to `siriusInstance +0x20` and `+0x24` are unknown.
- The registration framework that supplies those pointers remains unidentified. The `lib_handle` callbacks and static singleton constructor examined in Step 34 do not, by themselves, provide the missing direct edge.
- The return structure and precise meaning of provider method `+0xEC` are not yet enough to label it specifically as a Pen serial-number/ID read.
- No conclusion is made about subscription state, Instant Ink entitlement, account association, or whether changing any internal state would restore physical printing.

## Step 35 conclusion
**Partial static resolution:** the two separate Pen-related interface fields and their distinct initialization consumers are now identified. Pen descriptor registration through `+0x20` and broader Pen-service calls through `+0x24` are verified. The actual runtime provider-injection edge remains unresolved. Stop here for review before Step 36.

## Evidence and reproducibility
- `step35_verified_disassembly.txt` contains exact address-labelled disassembly excerpts.
- `step35_romfs_records.txt` records the vtable words and Pen descriptor/property structures.
- `step35_source_hashes.txt` records immutable-source SHA-256 values.
- `verify_step35.py` checks the source hashes, vtable slot addresses, selector mapping excerpts, Pen descriptor strings, and selector occurrence counts.
- `QA_SUMMARY.txt` records the verifier result.

The original firmware and earlier Revision 88/89 findings are not modified. This package is additive to the Step 34 evidence.
