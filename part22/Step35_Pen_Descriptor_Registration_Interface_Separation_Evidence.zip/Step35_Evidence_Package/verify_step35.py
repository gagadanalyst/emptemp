#!/usr/bin/env python3
"""Focused, read-only verifier for Step 35 Pen descriptor/interface findings."""
from __future__ import annotations

import hashlib
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "extracted/Part1_RTP_Provider_Trace_Evidence_Package/part1_rtp_provider_trace"
ELF = SRC / "hp_lbi_sections.elf"
TEXT = SRC / "srtext_rebuilt.bin"
ROMFS = SRC / "romfs_objs_rebuilt.bin"
DIS = ROOT / "srtext_full.dis"
BASE = 0xE09919C0

EXPECTED = {
    ELF: "25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7",
    TEXT: "10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7",
    ROMFS: "227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3",
    DIS: "33da87a4babddaa1c6407d69e9a6a190781f0503a653b89b52f682e3fb015956",
}

checks: list[str] = []

def check(name: str, ok: bool) -> None:
    if not ok:
        raise AssertionError(name)
    checks.append(name)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def word(addr: int) -> int:
    off = addr - BASE
    if off < 0 or off + 4 > len(rom):
        raise ValueError(hex(addr))
    return struct.unpack_from("<I", rom, off)[0]

def cstr(addr: int) -> str:
    off = addr - BASE
    b = rom[off:off + 128].split(b"\0", 1)[0]
    return b.decode("ascii", errors="replace")

for path, digest in EXPECTED.items():
    check(f"source hash {path.name}", path.exists() and sha256(path) == digest)

rom = ROMFS.read_bytes()
dis = DIS.read_text(errors="replace")

# Exact virtual table words (Thumb addresses).
for offset, expected, label in [
    (0x260, 0xE07470C9, "setup method +0x260"),
    (0x264, 0xE07470D1, "resolver +0x264"),
    (0x268, 0xE0747131, "setter +0x268"),
    (0x26C, 0xE07472B1, "Pen initializer +0x26C"),
    (0x270, 0xE07472B9, "following method +0x270"),
]:
    check(f"vtable {label}", word(0xE0B4C838 + offset) == expected)

# Code control-flow and data-field use.
check("+0x260 thunk reaches separate setup", "e07470c8:" in dis and "b.w\t0xe072c8e0" in dis[dis.find("e07470c8:"):dis.find("e07470d0:")])
check("+0x26C thunk reaches Pen initializer", "e07472b0:" in dis and "b.w\t0xe072c958" in dis[dis.find("e07472b0:"):dis.find("e07472b8:")])
fn_958 = dis[dis.find("e072c958:"):dis.find("e072cae6:")]
fn_8e0 = dis[dis.find("e072c8e0:"):dis.find("e072c954:")]
check("Pen initializer calls descriptor registrar", "bl\t0xe072d530" in fn_958)
check("separate setup does not call descriptor registrar", "e072d530" not in fn_8e0)
check("Pen initializer calls +0x24 vtable +0xE4", "[r1, #0xe4]" in fn_958 and "blx\tr2" in fn_958)
check("Pen initializer calls +0x24 vtable +0xE8", "[r1, #0xe8]" in fn_958)
check("snapshot wrapper dispatches +0x24 vtable +0xEC", "[r1, #0xec]" in dis[dis.find("e0736078:"):dis.find("e0736110:")])
registrar = dis[dis.find("e072d530:"):dis.find("e072d5a4:")]
check("descriptor registrar loads siriusInstance +0x20", "ldr\tr0, [r0, #0x20]" in registrar)
check("descriptor registrar dispatches method +0x08 three times", registrar.count("blx\tr4") == 3)
check("descriptor numeric IDs 0x95F, 0x97F, 0x980", all(x in registrar for x in ["#0x95f", "#0x97f", "#0x980"]))
check("descriptor labels passed as stack args", registrar.count("str\tr1, [sp]") == 3)
check("constructor zeroes member slots including +0x20/+0x24", "add.w\tlr, r4, #0x1c" in dis[dis.find("e0746a08:"):dis.find("e0746a80:")] and "stm.w\tlr, {r0, r2, r3, r12}" in dis[dis.find("e0746a08:"):dis.find("e0746a80:")])

# Setter mapping: arithmetic is verified by disassembly, then store offsets.
setter = dis[dis.find("e0747130:"):dis.find("e07472b0:")]
check("setter contains +0x20 store", "str\tr3, [r0, #0x20]" in setter)
check("setter contains +0x24 store", "str\tr3, [r0, #0x24]" in setter)
check("no direct BL call to setter in retained disassembly", "bl\t0xe0747130" not in dis)
check("derived +0x20 selector arithmetic", (0x006D5DBC + 0x006A5031) == 0x00D7ADED)
check("derived +0x24 selector arithmetic", (0x006D5DBC + 0x006A5031 + 0x00073F67 + 0x0000CBB0) == 0x00DFB904)

# ROMFS descriptors and property strings.
check("ROMFS PEN descriptor", cstr(0xE0B3A1FC) == "PEN")
check("ROMFS PEN_G3_C descriptor", cstr(0xE0B3A200) == "PEN_G3_C")
check("ROMFS PEN_G3_K descriptor", cstr(0xE0B3A20C) == "PEN_G3_K")
check("ROMFS PEN_PACING_DELAY_US property", cstr(0xE0B3C0B8) == "PEN_PACING_DELAY_US")
check("ROMFS PEN_NOMINAL_AMB_REF property", cstr(0xE0B3C0CC) == "PEN_NOMINAL_AMB_REF")

# Selector literal occurrence counts.
def count_u32(value: int) -> int:
    return rom.count(struct.pack("<I", value))
check("selector 0x00DFB904 has three ROMFS occurrences", count_u32(0x00DFB904) == 3)
check("selector 0x00D7ADED has ten ROMFS occurrences", count_u32(0x00D7ADED) == 10)
check("incorrect preliminary selector 0x00D80DED absent from ROMFS", count_u32(0x00D80DED) == 0)
# Every occurrence starts a generic metadata record whose first four words are
# [key, 1, 0, 0xFFFFFFFF]. The repeated shape is evidence of shared metadata,
# not a component-specific service ID.
def metadata_record_shape(value: int) -> bool:
    raw = struct.pack("<I", value)
    pos = 0
    found = 0
    while True:
        off = rom.find(raw, pos)
        if off < 0:
            break
        if off + 16 > len(rom):
            return False
        words = struct.unpack_from("<4I", rom, off)
        if words != (value, 1, 0, 0xFFFFFFFF):
            return False
        found += 1
        pos = off + 1
    return found == count_u32(value)
check("0x00D7ADED occurrences share generic metadata prefix", metadata_record_shape(0x00D7ADED))
# The first DFB904 record is embedded after a two-word prefix, while the other
# occurrences start the generic four-word record. Verify the three local contexts.
check("0x00DFB904 occurrence count is stable", count_u32(0x00DFB904) == 3)

print(f"Step 35 focused verification: {len(checks)}/{len(checks)} PASS")
for item in checks:
    print("PASS | " + item)
