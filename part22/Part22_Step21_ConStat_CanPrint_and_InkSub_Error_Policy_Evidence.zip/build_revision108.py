from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

ROOT = Path('/mnt/data/hp_part22_step21')
BASE = Path('/mnt/data/hp_part22_step20/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision107_Part22_Step20_PE_Wait_For_CanPrint_Readiness_State_Machine_Addendum.docx')
OUT = ROOT / 'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision108_Part22_Step21_ConStat_CanPrint_and_InkSub_Error_Policy_Addendum.docx'

doc = Document(str(BASE))
sec = doc.sections[-1]
sec.top_margin = Inches(0.62)
sec.bottom_margin = Inches(0.60)
sec.left_margin = Inches(0.68)
sec.right_margin = Inches(0.68)

styles = doc.styles
normal = styles['Normal']
normal.font.name = 'Aptos'
normal.font.size = Pt(8.8)
normal.paragraph_format.space_after = Pt(3)
normal.paragraph_format.line_spacing = 1.03
for name, size, color in [('Title',18,'163A5F'),('Heading 1',14,'163A5F'),('Heading 2',10.5,'24527A')]:
    st=styles[name]
    st.font.name='Aptos Display' if name in ('Title','Heading 1') else 'Aptos'
    st.font.size=Pt(size)
    st.font.bold=True
    st.font.color.rgb=RGBColor.from_string(color)
    st.paragraph_format.space_before=Pt(5)
    st.paragraph_format.space_after=Pt(4)


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_text(cell, text, bold=False, color=None, size=8.2):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    r = p.add_run(str(text))
    r.bold = bold
    r.font.name = 'Aptos'
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def table(headers, rows, widths=None, font=8.0):
    t=doc.add_table(rows=1, cols=len(headers))
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    t.style='Table Grid'
    for i,h in enumerate(headers):
        set_cell_text(t.rows[0].cells[i], h, True, 'FFFFFF', font)
        shade(t.rows[0].cells[i], '244A6B')
    trPr=t.rows[0]._tr.get_or_add_trPr()
    rep=OxmlElement('w:tblHeader')
    rep.set(qn('w:val'),'true')
    trPr.append(rep)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row):
            set_cell_text(cells[i], v, False, None, font)
            if len(t.rows)%2==0:
                shade(cells[i], 'EEF3F7')
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths):
                row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t


def para(text='', bold_lead=None, size=8.8, color=None, italic=False):
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(3)
    p.paragraph_format.line_spacing=1.03
    if bold_lead and text.startswith(bold_lead):
        a=p.add_run(bold_lead); a.bold=True
        b=p.add_run(text[len(bold_lead):])
        for r in (a,b):
            r.font.name='Aptos'; r.font.size=Pt(size)
            if color: r.font.color.rgb=RGBColor.from_string(color)
            r.italic=italic
    else:
        r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size)
        if color: r.font.color.rgb=RGBColor.from_string(color)
        r.italic=italic
    return p


def bullet(text, level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    p.paragraph_format.space_after=Pt(2)
    p.paragraph_format.line_spacing=1.0
    r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(8.6)
    return p


def title(kicker, heading, subtitle):
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(2)
    r=p.add_run(kicker.upper()); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(8); r.font.color.rgb=RGBColor(91,112,133)
    h=doc.add_paragraph(style='Heading 1')
    h.paragraph_format.space_after=Pt(3)
    h.add_run(heading)
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(5)
    rr=p.add_run(subtitle); rr.italic=True; rr.font.name='Aptos'; rr.font.size=Pt(8.4); rr.font.color.rgb=RGBColor(80,95,110)


def pagebreak():
    doc.add_page_break()

# PAGE 13 — structure and query field
pagebreak()
title('Part 22 • Step 21', 'ConStatSystemInfoT resolves the CanPrint status field',
      'The previously anonymous status-buffer offset is now tied to a named firmware type and a source object field.')
para('The pe_wait_for_canprint status query at 0xE07267B8 allocates a 0xD0-byte output buffer, calls the injected service 0x0038948E through virtual slot +0x08, and checks the 32-bit value at output +0x8C when the service returns success.')
para('The ROMFS type descriptor identifies the returned structure as ConstatSystemInfoT. Its declared size is 0xCC bytes with 19 fields. The 0xD0-byte stack allocation is consistent with that structure plus four bytes of alignment/padding.')
table(['Evidence','Address / value','Interpretation'],[
 ['ConStat type descriptor','ROMFS 0xE0C3F968','Declares ConstatSystemInfoT, size 0xCC, 19 fields'],
 ['C type name','0xE0C41F00','constat_system_info_t'],
 ['C++ type name','0xE0C41F18','ConstatSystemInfoT'],
 ['Field descriptor','ROMFS 0xE0C420B4','Member name can_print; field offset 0x8C'],
 ['Query buffer','0xD0 bytes at 0xE07267B8','Matches 0xCC-byte structure with alignment margin'],
], [1.45,1.55,3.75], 7.8)
doc.add_paragraph('The field-to-source data flow', style='Heading 2')
table(['Step','Function / address','Verified operation'],[
 ['1','0xE0307A38','ConStat getter accepts an object and output pointer; initializes ConstatSystemInfoT'],
 ['2','0xE0308520','Copies internal object field +0x2F8 to output structure +0x8C'],
 ['3','0xE07267B8','Reads output +0x8C as the readiness predicate after a successful provider call'],
], [0.55,1.35,4.85], 7.8)
para('This closes the semantic gap: pe_wait_for_canprint is checking ConStatSystemInfoT.can_print, not an arbitrary status word. The status-query interface at service ID 0x0038948E is therefore expected to supply this ConStat structure. A ConStat method-table segment contains a matching getter at 0xE0307A38 in the +0x08 slot position, but the service-ID-to-runtime-object binding is not explicitly recoverable from the static image; provider identity is treated as a high-confidence candidate, not an independently observed runtime binding.', bold_lead='This closes the semantic gap:')

# PAGE 14 — internal state and aggregator
pagebreak()
title('Part 22 • Step 21', 'The internal CanPrint value is a ConStat aggregate',
      'The field returned to pe_wait_for_canprint is copied from a mutable ConStat object member.')
para('The ConStat getter at 0xE0307A38 calls 0xE0308520. The latter copies the internal source field at object +0x2F8 into ConstatSystemInfoT.can_print at output +0x8C. The same getter conditionally clears output fields +0x8C and +0x90 when its status-validity flag is false.')
table(['Internal location','Behavior','Evidence'],[
 ['ConStat object +0x2F8','Source value for can_print','0xE0308520'],
 ['ConStat object +0x8F4','Start of six reason-group records','0xE0308988'],
 ['Reason-group record +0x10','Stored ConStat consumable error code','0xE03076C0'],
 ['ConStat object +0x2F8','Cleared on insertion of any code other than 0x25','0xE03076C0'],
], [1.55,3.25,1.65], 7.8)
doc.add_paragraph('Six-group policy recomputation', style='Heading 2')
para('Function 0xE0308988 initializes the aggregate result to 1 and scans up to six reason groups rooted at object +0x8F4. For each stored record it reads the code at record +0x10. If any code differs from 0x25, it changes the aggregate to 0. It then writes the result to object +0x2F8 if the value changed.')
para('Function 0xE03076C0 inserts the incoming reason code into a record at +0x10 and invokes the aggregate recomputation. The insertion path also directly clears object +0x2F8 for a code other than 0x25.')
table(['Observed rule','Result'],[
 ['No reason records, or all stored codes equal 0x25','can_print = 1'],
 ['At least one stored code differs from 0x25','can_print = 0'],
], [4.2,2.0], 8.0)
para('This is a ConStat consumable-error policy, not the earlier 32-slot PE event registry. The two structures participate in different stages: ConStat computes the CanPrint predicate; pe_wait_for_canprint consumes it and registers condition token 1 with the PE event system.', bold_lead='This is a ConStat consumable-error policy,')

# PAGE 15 — enum meanings and subscription DSID
pagebreak()
title('Part 22 • Step 21', 'Ink Subscription errors are explicit CanPrint blockers',
      'The numeric reason codes in the ConStat policy map to named consumable-error enum members.')
table(['Code','ConStat consumable error enum','Policy effect'],[
 ['0x12','CONSTAT_CONSUMABLE_ERROR_INKSUB_NOT_ENROLLED','Blocking: differs from 0x25'],
 ['0x13','CONSTAT_CONSUMABLE_ERROR_INKSUB_REPLACED_EARLY','Blocking: differs from 0x25'],
 ['0x14','CONSTAT_CONSUMABLE_ERROR_INKSUB_NO_RTP','Blocking: differs from 0x25'],
 ['0x25','CONSTAT_CONSUMABLE_ERROR_BAD_MFG_BATCH','Sole non-blocking numeric exception in the six-group scan'],
], [0.65,3.65,2.0], 7.6)
para('The primary constat_consumable_error_t enum metadata maps 0x25 to BAD_MFG_BATCH. An adjacent metadata table uses the alternate/related label USING_BAD_MFG_BATCH for the same numeric value. Since executable code checks only the numeric value, this addendum does not treat the two labels as separate policy outcomes.')
doc.add_paragraph('Subscription-level metadata', style='Heading 2')
table(['Item','Value','Meaning'],[
 ['DSID','0x00012FB0','DSID_CONSTAT_INK_SUBSCRIPTION_LEVEL'],
 ['Enum type','PINK_subscription_status_e','Typed subscription-level value'],
 ['1','pink_ss_registered_current_e','Registered/current'],
 ['2','pink_ss_registered_issue_e','Registered but issue state'],
 ['3','pink_ss_not_registered_e','Not registered'],
], [1.1,2.35,2.85], 7.7)
para('Function 0xE0302AA6 queries DSID 0x12FB0 through an injected provider virtual method at +0x10 and writes the returned value to its output argument. This proves that the ConStat code can read the typed PINK subscription level. The exact conversion from these three PINK status values to the three consumable-error codes 0x12/0x13/0x14 has not yet been established.')

# PAGE 16 — integrated causal model and limits
pagebreak()
title('Part 22 • Step 21', 'What this means for the print-block investigation',
      'The subscription-specific block mechanism is now explicit in ConStat policy, but the active runtime reason remains unknown.')
table(['Stage','Recovered path','Confidence'],[
 ['Subscription status source','DSID_CONSTAT_INK_SUBSCRIPTION_LEVEL (0x12FB0), typed as PINK_subscription_status_e','Confirmed'],
 ['Consumable error registry','ConStat reason code stored at record +0x10 in one of six groups','Confirmed'],
 ['CanPrint policy','Codes 0x12/0x13/0x14 are non-0x25 and therefore force can_print=0','Confirmed'],
 ['Status query','ConstatSystemInfoT.can_print at +0x8C is returned to pe_wait_for_canprint','Confirmed'],
 ['PE condition path','pe_wait_for_canprint registers token 1; PE aggregate and 0x8B/0x8C events were traced in prior steps','Confirmed as separate connected stages'],
 ['Exact live cause on this printer','Which ConStat reason was active during the failed Print-Job','Unknown without runtime state'],
], [1.25,4.15,1.1], 7.3)
doc.add_paragraph('Important boundaries', style='Heading 2')
bullet('The firmware explicitly treats INKSUB_NOT_ENROLLED, INKSUB_REPLACED_EARLY, and INKSUB_NO_RTP as CanPrint-blocking error codes when they are present in the ConStat reason groups.')
bullet('This does not prove that any of those three codes was active on the user’s printer during the failed job. No runtime state was read from the printer in this static-only step.')
bullet('The PINK subscription-level DSID is queryable in firmware, but its exact value-to-error conversion remains open. The injected provider behind service 0x0038948E is strongly matched to the ConStatSystemInfoT getter by type and ABI, but its runtime binding has not been directly observed.')
bullet('The six ConStat reason groups are distinct from the 32-entry PE event-condition registry. Do not merge their record layouts or treat their offsets as interchangeable.')
doc.add_paragraph('Next golden target', style='Heading 2')
para('Trace the ConStat supply/ACF policy path that reads DSID 0x12FB0 and determine which PINK status/violation/trigger combination inserts reason code 0x12, 0x13, or 0x14 into the six ConStat groups. Then identify whether the printer’s observed “Cartridge or Account Issue” corresponds to one of those conditions. This is the shortest remaining static route toward naming the likely blocker. No printer interaction or print retry is authorized by this analysis.')

# Add revision footer to final page only; original section footer remains inherited.
for p in doc.paragraphs[-1:]:
    p.paragraph_format.keep_together=True

# Metadata
doc.core_properties.title = 'HP DeskJet 2855e Independent Printing/Scanning Investigation — Revision 108, Part 22 Step 21'
doc.core_properties.subject = 'ConStatSystemInfoT CanPrint data flow and Ink Subscription consumable-error blocking policy'
doc.core_properties.comments = 'Cumulative update from Revision 107; Step 21 static-only addendum.'
doc.save(OUT)
print(OUT)
