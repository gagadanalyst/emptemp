from pathlib import Path
import hashlib, re, sys
ROOT=Path(__file__).resolve().parent
rom=(ROOT/'romfs_objs_rebuilt.bin').read_bytes()
base=0xE09919C0
checks=[]

def check(name, ok, detail=''):
    checks.append((name,bool(ok),detail))

def u32(vma):
    off=vma-base
    if off<0 or off+4>len(rom): return None
    return int.from_bytes(rom[off:off+4],'little')

def s(vma):
    off=vma-base
    if off<0 or off>=len(rom): return ''
    return rom[off:off+256].split(b'\0',1)[0].decode('latin1','replace')

# ConStatSystemInfoT type and field layout.
check('ConstatSystemInfoT C type string',s(0xE0C41F00)=='constat_system_info_t',s(0xE0C41F00))
check('ConstatSystemInfoT C++ type string',s(0xE0C41F18)=='ConstatSystemInfoT',s(0xE0C41F18))
check('ConstatSystemInfoT declared size 0xCC',u32(0xE0C3F974)==0xCC,hex(u32(0xE0C3F974) or 0))
check('ConstatSystemInfoT field count 19',u32(0xE0C3F978)==0x13,hex(u32(0xE0C3F978) or 0))
check('can_print field name',s(0xE0C4EE08)=='can_print',s(0xE0C4EE08))
check('can_print field offset 0x8C',u32(0xE0C420C8)==0x8C,hex(u32(0xE0C420C8) or 0))

# Canonical and alternate ConStat error enum names.
expected={
 0x12:(0xE0C52E8C,'CONSTAT_CONSUMABLE_ERROR_INKSUB_NOT_ENROLLED'),
 0x13:(0xE0C52EBC,'CONSTAT_CONSUMABLE_ERROR_INKSUB_REPLACED_EARLY'),
 0x14:(0xE0C52EC4,'CONSTAT_CONSUMABLE_ERROR_INKSUB_NO_RTP'),
 0x25:(0xE0C531D0,'CONSTAT_CONSUMABLE_ERROR_BAD_MFG_BATCH'),
}
for value,(addr,name) in expected.items():
    actual=s(addr)
    check(f'ConStat error enum name {value:#04x}',actual==name,actual)
    pair=value.to_bytes(4,'little')+addr.to_bytes(4,'little')
    check(f'ConStat error enum numeric mapping {value:#04x}',pair in rom,'value followed by name pointer')
check('Alternate 0x25 label preserved',s(0xE0C531A0)=='CONSTAT_CONSUMABLE_ERROR_USING_BAD_MFG_BATCH',s(0xE0C531A0))

# DSID and PINK status enum names.
check('ConStat subscription DSID name',s(0xE09AAFB0)=='DSID_CONSTAT_INK_SUBSCRIPTION_LEVEL',s(0xE09AAFB0))
check('ConStat subscription DSID numeric ID',u32(0xE09AAE74)==0x12FB0,hex(u32(0xE09AAE74) or 0))
check('PINK subscription status enum type',s(0xE0D48554)=='PINK_subscription_status_e',s(0xE0D48554))
pink={1:(0xE0D49514,'pink_ss_registered_current_e'),2:(0xE0D49534,'pink_ss_registered_issue_e'),3:(0xE0D49550,'pink_ss_not_registered_e')}
for value,(addr,name) in pink.items():
    check(f'PINK enum name {value}',s(addr)==name,s(addr))
    pair=addr.to_bytes(4,'little')+value.to_bytes(4,'little')
    check(f'PINK enum numeric mapping {value}',pair in rom,'name pointer followed by value')

# Disassembly-level behavior.
def read_dis(name): return (ROOT/'disassembly'/name).read_text(errors='replace').lower()
copy=read_dis('constat_system_info_copy_e0308520.dis')
check('ConStat getter copies object +0x2F8', '#0x2f8' in copy, 'source internal state field')
check('ConStat getter writes output +0x8C', '#0x8c' in copy, 'ConstatSystemInfoT.can_print')
agg=read_dis('constat_can_print_aggregate_e0308988.dis')
check('CanPrint aggregate uses 0x25 exception', '#0x25' in agg, 'numeric allowlist comparison')
check('CanPrint aggregate scans six-group table', '#0x8f4' in agg, 'reason table root')
check('CanPrint aggregate writes +0x2F8', '#0x2f8' in agg, 'source can_print field')
upd=read_dis('constat_reason_record_update_e03076c0.dis')
check('Reason insertion records +0x10 field', '#0x10' in upd, 'reason code field')
check('Reason insertion compares 0x25', '#0x25' in upd, 'non-exception clear path')
check('Reason insertion clears can_print +0x2F8', '#0x2f8' in upd, 'source can_print field')
dsid=read_dis('constat_ink_subscription_dsid_read_e0302aa6.dis')
check('Ink-subscription DSID getter contains 0x2FB0', '#0x2fb0' in dsid, 'DSID lower half')
check('Ink-subscription DSID getter contains high half 0x1', '#0x1' in dsid, 'DSID upper half')
query=read_dis('pe_wait_status_query_e07267b8.dis')
check('PE wait query uses output offset 0x8C', '#0x8c' in query, 'status predicate field')

# Report/document presence, hashes handled in DELIVERY_SHA256SUMS separately.
for name in ['STEP21_FINDINGS.txt','STEP21_CAN_PRINT_DATAFLOW.csv','STEP21_CONSTAT_CONSUMABLE_ERROR_ENUMS.csv','STEP21_PINK_SUBSCRIPTION_STATUS.csv','README_STEP21.md']:
    check(f'Evidence file exists: {name}',(ROOT/name).exists())

fails=[x for x in checks if not x[1]]
lines=[f'Step 21 focused verifier: {len(checks)-len(fails)}/{len(checks)} PASS; {len(fails)} FAIL']
for name,ok,detail in checks:
    lines.append(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
(ROOT/'verification_output.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines[:1]))
if fails:
    print('\n'.join(x[0]+' :: '+x[2] for x in fails))
    sys.exit(1)
