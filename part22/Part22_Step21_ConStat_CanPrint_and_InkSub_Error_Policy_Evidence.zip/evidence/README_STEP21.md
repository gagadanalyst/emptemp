# Part 22 — Step 21 evidence package

## Golden result
`pe_wait_for_canprint` is checking `ConstatSystemInfoT.can_print` at offset `0x8C`. The field is populated from ConStat object `+0x2F8`. A six-group ConStat consumable-error aggregate makes this field false whenever any stored reason code differs from `0x25`. The ConStat enum metadata names `0x12`, `0x13`, and `0x14` as `INKSUB_NOT_ENROLLED`, `INKSUB_REPLACED_EARLY`, and `INKSUB_NO_RTP`, respectively. Those codes therefore block the CanPrint predicate when present in the reason groups.

## Evidence layout
- `STEP21_FINDINGS.txt`: detailed findings and limits.
- `STEP21_CAN_PRINT_DATAFLOW.csv`: query/type/source-field crosswalk.
- `STEP21_CONSTAT_CONSUMABLE_ERROR_ENUMS.csv`: verified reason-code labels and policy interpretation.
- `STEP21_PINK_SUBSCRIPTION_STATUS.csv`: DSID and PINK enum values.
- `disassembly/`: focused Thumb disassemblies for query, copy, reason insertion, aggregate, and subscription-level DSID read.
- `romfs/`: exact ROMFS byte slices, VMA/file-offset index, and key-word dump.
- `Step20_Previous_Evidence.zip`: prior cumulative evidence and source input hashes.
- `Revision107_Step20_Baseline.docx` and `.pdf`: prior report baseline.
- `verify_part22_step21.py` and `verification_output.txt`: focused verifier.
- `SHA256SUMS`: package file hashes.

## Static-only scope
No printer I/O, print submission, scan submission, firmware installation, or live memory modification was performed. Runtime activation of any reason code remains unknown.
