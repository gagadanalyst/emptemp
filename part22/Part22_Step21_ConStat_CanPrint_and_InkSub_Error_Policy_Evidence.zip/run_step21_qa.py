from pathlib import Path
import subprocess, re, hashlib, sys
from PIL import Image, ImageChops
ROOT=Path('/mnt/data/hp_part22_step21')
NEWPDF=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision108_Part22_Step21_ConStat_CanPrint_and_InkSub_Error_Policy_Addendum.pdf'
BASEPDF=Path('/mnt/data/hp_part22_step20/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision107_Part22_Step20_PE_Wait_For_CanPrint_Readiness_State_Machine_Addendum.pdf')
QA=ROOT/'qa'
QA.mkdir(exist_ok=True)

def run(cmd):
    return subprocess.run(cmd,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

# Convert DOCX to PDF if needed.
DOCX=ROOT/'HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision108_Part22_Step21_ConStat_CanPrint_and_InkSub_Error_Policy_Addendum.docx'
if not NEWPDF.exists():
    run(['libreoffice','--headless','--convert-to','pdf','--outdir',str(ROOT),str(DOCX)])

def page_count(pdf):
    info=run(['pdfinfo',str(pdf)]).stdout
    m=re.search(r'^Pages:\s+(\d+)',info,re.M)
    if not m: raise RuntimeError('pdfinfo did not report page count')
    return int(m.group(1)), info

new_n,new_info=page_count(NEWPDF)
base_n,base_info=page_count(BASEPDF)
# Rasterize both at the same resolution.
for label,pdf in [('base',BASEPDF),('new',NEWPDF)]:
    out=QA/f'{label}_120'
    out.mkdir(exist_ok=True)
    run(['pdftoppm','-png','-r','120',str(pdf),str(out/'page')])
base_imgs=sorted((QA/'base_120').glob('page-*.png'),key=lambda p:int(re.search(r'(\d+)$',p.stem).group(1)))
new_imgs=sorted((QA/'new_120').glob('page-*.png'),key=lambda p:int(re.search(r'(\d+)$',p.stem).group(1)))
identical=0
for i in range(min(12,len(base_imgs),len(new_imgs))):
    a=Image.open(base_imgs[i]).convert('RGB')
    b=Image.open(new_imgs[i]).convert('RGB')
    if a.size==b.size and ImageChops.difference(a,b).getbbox() is None:
        identical+=1
# Ensure new pages exist and have visible content; count near-white pixels not >98%.
new_page_stats=[]
for i,p in enumerate(new_imgs[12:],start=13):
    im=Image.open(p).convert('L')
    hist=im.histogram(); total=sum(hist)
    white=sum(hist[245:])
    ratio=white/total if total else 1
    new_page_stats.append((i,im.size,ratio))

report=[]
report.append(f'Revision 107 baseline pages: {base_n}')
report.append(f'Revision 108 pages: {new_n}')
report.append(f'Inherited pages pixel-identical at 120 dpi: {identical}/12')
report.append(f'New rendered pages after inherited baseline: {len(new_imgs)-12}')
for i,size,ratio in new_page_stats:
    report.append(f'Page {i}: raster={size[0]}x{size[1]}, white_fraction={ratio:.4f}')
pass_all=(base_n==12 and new_n==16 and identical==12 and len(new_imgs)==16 and len(new_page_stats)==4 and all(x[2]<0.985 for x in new_page_stats))
report.append(('PASS' if pass_all else 'CHECK')+' — document render QA')
report.append('PDF page size details:')
report.extend([ln for ln in new_info.splitlines() if ln.startswith('Page size:') or ln.startswith('File size:')])
(ROOT/'qa'/'QA_STEP21.txt').write_text('\n'.join(report)+'\n')
print('\n'.join(report))
if not pass_all:
    sys.exit(1)
