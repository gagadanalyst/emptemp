#!/usr/bin/env python3
"""Focused, read-only verifier for the Step 40 final static audit."""
from pathlib import Path
import hashlib, re, subprocess

BASE=Path('/mnt/data/firmware_recovery/step40_work')
PART1=BASE/'part1/part1_rtp_provider_trace'
ELF=PART1/'hp_lbi_sections.elf'; SR=PART1/'srtext_rebuilt.bin'; RO=PART1/'romfs_objs_rebuilt.bin'; FHX=PART1/'fhx_secure_payload_rebuilt.bin'
DIS=BASE/'full_srtext_step40.dis'; DUMP=BASE/'library_sources/dump.bin'; TASSEL=BASE/'library_sources/tassel_LBI_verified.bin'
EVID=Path('/mnt/data/firmware_recovery/Step40_Final_Audit_Evidence')
checks=[]
def check(name, condition): checks.append((name,bool(condition)))
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def offsets(buf, value):
    pat=value.to_bytes(4,'little'); out=[]; i=0
    while True:
        i=buf.find(pat,i)
        if i<0: return out
        out.append(i); i+=1
expected={
'hp_lbi_sections.elf':'25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
'srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
'romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
'fhx_secure_payload_rebuilt.bin':'aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858',
'dump.bin':'b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496',
'tassel_LBI_verified.bin':'2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e',
'full_srtext_step40.dis':'bc61ed25f5cee705735d7d7aee6bbc367a0554182931e83eabdb426f6d0e1da4'}
for p in [ELF,SR,RO,FHX,DUMP,TASSEL,DIS]: check('SHA-256 '+p.name,digest(p)==expected[p.name])
check('dump.bin size is 16 MiB',DUMP.stat().st_size==16777216)
check('tassel_LBI_verified.bin size is 15,369,810 bytes',TASSEL.stat().st_size==15369810)
hdr=subprocess.run(['readelf','-h',str(ELF)],capture_output=True,text=True,check=True).stdout
ph=subprocess.run(['readelf','-l',str(ELF)],capture_output=True,text=True,check=True).stdout
sh=subprocess.run(['readelf','-S',str(ELF)],capture_output=True,text=True,check=True).stdout
check('ELF has zero program headers','Number of program headers:         0' in hdr and 'There are no program headers' in ph)
check('.srtext VMA is 0xE0246070','e0246070' in sh.lower())
check('.romfs_objs VMA is 0xE09919C0','e09919c0' in sh.lower())
check('ELF has only two substantive PROGBITS sections',sh.count('PROGBITS')==2 and '.srtext' in sh and '.romfs_objs' in sh)
# ROMFS exact-word census
rom=RO.read_bytes(); rb=0xE09919C0
check('Sirius setter Thumb pointer occurs exactly at E0B4CAA0',offsets(rom,0xE0747131)==[0xE0B4CAA0-rb])
check('Sirius resolver Thumb pointer occurs exactly at E0B4CA9C',offsets(rom,0xE07470D1)==[0xE0B4CA9C-rb])
check('Pen-init thunk Thumb pointer occurs exactly at E0B4CAA4',offsets(rom,0xE07472B1)==[0xE0B4CAA4-rb])
check('No ROMFS pointer to adjustor thunk 0xE0746F75',len(offsets(rom,0xE0746F75))==0)
check('Selector 0x00D7ADED appears 10 times',len(offsets(rom,0x00D7ADED))==10)
check('Selector 0x00DFB904 appears 3 times',len(offsets(rom,0x00DFB904))==3)
check('Withdrawn selector 0x00D80DED has zero occurrences',len(offsets(rom,0x00D80DED))==0)
check('E0747089 occurs in code-address index at E0DD24E8',offsets(rom,0xE0747089)==[0xE0DD24E8-rb])
# Stream complete disassembly once; avoid loading the 130 MiB file into memory.
call_targets={'0xe0303558':0,'0xe030feb8':0,'0xe0308b70':0,'0xe0981500':0,'0xe0747130':0,'0xe0747088':0}
setter_bl=[]; setter_br=[]; line_count=0; key_lines={}
ldr268_count=0; local_dispatch=[]; pending=[]; pending_low=[]; addr_pairs=[]
load_pat=re.compile(r'\bldr(?:\.w)?\s+(r\d+),\s*\[r\d+,\s*#0x268\]',re.I)
bl_pat=re.compile(r'\bbl(?:\.w)?\s+(0x[0-9a-f]+)',re.I)
branch_pat=re.compile(r'\b(?:b\.w|b)\s+(0x[0-9a-f]+)',re.I)
write_pat_cache={}
with DIS.open('r',errors='replace') as f:
    for line in f:
        line_count+=1
        low=line.lower()
        # Full MOVW/MOVT pairing avoids confusing matching low-half literals.
        mm=re.search(r'\bmovw\s+(r\d+),\s*#(0x[0-9a-f]+)',line,re.I)
        mt=re.search(r'\bmovt\s+(r\d+),\s*#(0x[0-9a-f]+)',line,re.I)
        if mt:
            treg=mt.group(1).lower(); hi=int(mt.group(2),16)
            for row in pending_low[:]:
                idx,reg,lo,txt=row
                if line_count-idx>5: pending_low.remove(row); continue
                if reg==treg:
                    addr_pairs.append((lo,hi,idx,line_count,txt.rstrip(),low.rstrip()))
                    pending_low.remove(row)
        if mm:
            lo=int(mm.group(2),16)
            if lo in (0xec30,0xec34,0xec38): pending_low.append((line_count,mm.group(1).lower(),lo,line))
        # Exact disassembly landmarks used by the verifier and excerpt provenance.
        if re.match(r'^(e0746a08|e0746a48|e0746a4c|e0746a72|e0747088|e074709a|e074709e|e07470a2|e07470a6|e08fd8a0|e08fd8a8|e0747130|e074725e|e0747262|e0746f70|e0746f74|e0303558|e03035c4|e03035cc|e0303678|e030367a|e0308b70|e0308c48|e0308c70|e0308c78|e030feb8|e09811e4|e09811ee|e09811f0|e09811f4|e09811f6|e09811f8|e09811fc|e0981206|e0981216|e098122e|e0981230|e0983dc2|e0983dd2|e093e746):',low):
            key_lines[low.split(':',1)[0]]=low.rstrip()
        m=bl_pat.search(line)
        if m:
            t=m.group(1).lower()
            if t in call_targets: call_targets[t]+=1
            if t=='0xe0747130': setter_bl.append(low.rstrip())
        m=branch_pat.search(line)
        if m and m.group(1).lower()=='0xe0747130': setter_br.append(low.rstrip())
        # Track local same-register LDR [obj,#0x268] -> BLX rN, with intervening write-kill.
        m=load_pat.search(line)
        if m: ldr268_count+=1
        for cand in pending[:]:
            idx,reg,loadline=cand
            blx=re.search(r'\bblx\s+'+re.escape(reg)+r'\b',line,re.I)
            if blx:
                local_dispatch.append((idx,line_count,reg,loadline.rstrip(),low.rstrip())); pending.remove(cand); continue
            if line_count-idx>=14:
                pending.remove(cand); continue
            wpat=write_pat_cache.setdefault(reg,re.compile(r'\b(?:mov|movs|movw|movt|ldr\w*|add\w*|sub\w*|eor\w*|orr\w*|and\w*)\s+'+re.escape(reg)+r'\b',re.I))
            if wpat.search(line): pending.remove(cand)
        if m: pending.append((line_count,m.group(1),line))
check('Full .srtext disassembly has 2,943,721 lines',line_count==2943721)
check('No direct BL/BL.W calls target 0xE0747130',call_targets['0xe0747130']==0 and len(setter_bl)==0)
check('Exactly one direct branch target to setter is B.W at E0746F74',len(setter_br)==1 and setter_br[0].startswith('e0746f74:'))
check('Adjustor thunk subtracts 0x10 from r0 before tail-branch',key_lines.get('e0746f70','').startswith('e0746f70: f1a0 0010') and key_lines.get('e0746f74','').startswith('e0746f74: f000'))
check('Constructor 0xE0746A08 is present',key_lines.get('e0746a08','').startswith('e0746a08: b510'))
check('Constructor zeroes words beginning at object +0x1C',key_lines.get('e0746a4c','').startswith('e0746a4c: e88e 100d'))
check('Constructor publishes object pointer in singleton cell C193B3C0',key_lines.get('e0746a72','').startswith('e0746a72: f24b 30c0'))
check('Wrapper E0747088 calls constructor then queues node C020EC30',key_lines.get('e074709a','').startswith('e074709a: f7ff fcb5') and key_lines.get('e074709e','').startswith('e074709e: f64e 4030') and key_lines.get('e07470a6','').startswith('e07470a6: f23a f8b6'))
check('Wrapper E0747088 has no direct BL/BL.W callers',call_targets['0xe0747088']==0)
check('Unique full MOVW/MOVT construction of C020EC30 is E074709E/E07470A2',len([x for x in addr_pairs if x[0]==0xec30 and x[1]==0xc020])==1 and any(x[2]==2026048 and x[3]==2026049 for x in addr_pairs if x[0]==0xec30 and x[1]==0xc020))
check('Near-address E08FD8A0 constructs C021EC30, not C020EC30',any(x[0]==0xec30 and x[1]==0xc021 and x[2]==2714808 and x[3]==2714810 for x in addr_pairs))
check('No C020EC34 or C020EC38 absolute MOVW/MOVT construction',not any(x[0] in (0xec34,0xec38) and x[1]==0xc020 for x in addr_pairs))
check('Setter stores supplied r3 at +0x20',key_lines.get('e074725e','').startswith('e074725e: 6203'))
check('Setter stores supplied r3 at +0x24',key_lines.get('e0747262','').startswith('e0747262: 6243'))
check('Generic dispatcher direct-call count is 2',call_targets['0xe0303558']==2)
check('Secondary context accessor direct-call count is 12',call_targets['0xe030feb8']==12)
check('Context initializer wrapper E0308C70 tail-branches to E0308B70',key_lines.get('e0308c70','').startswith('e0308c70: f64e 1004') and '0xe0308b70' in key_lines.get('e0308c78',''))
check('Generic dispatcher LDR +0x268 census contains 67 loads',ldr268_count==67)
check('Unique local LDR +0x268 -> BLX same-register path is E03035C4 to E03035CC',len(local_dispatch)==1 and local_dispatch[0][3].lower().startswith('e03035c4:') and local_dispatch[0][4].lower().startswith('e03035cc:'))
check('Context vtable +0x268 target is zero-return stub E0303678',key_lines.get('e0303678','').startswith('e0303678: 2000') and key_lines.get('e030367a','').startswith('e030367a: 4770'))
vt=(BASE/'step39/step39_romfs_vtable_comparison.txt').read_text()
check('Context A and B vtables both point +0x268 to E0303678',all(x in vt for x in ['[context_object_A] vtable base 0xE09AF1B8','[context_object_B_embedded] vtable base 0xE09AEA54','+0x268 @0xE09AF420 -> raw 0xE0303679; resolved 0xE0303678','+0x268 @0xE09AECBC -> raw 0xE0303679; resolved 0xE0303678']))
check('Sirius primary vtable +0x268 points to E0747130', '[siriusInstance_primary] vtable base 0xE0B4C838' in vt and '+0x268 @0xE0B4CAA0 -> raw 0xE0747131; resolved 0xE0747130' in vt)
check('Callback walker reads node +4 and +8',key_lines.get('e09811ee','').startswith('e09811ee: 6848') and key_lines.get('e09811f0','').startswith('e09811f0: 6889'))
check('Callback walker performs conditional callback invocation',key_lines.get('e09811f4','').startswith('e09811f4: 460a') and key_lines.get('e09811f6','').startswith('e09811f6: 2102') and key_lines.get('e09811f8','').startswith('e09811f8: 4790') and key_lines.get('e09811fc','').startswith('e09811fc: 4788'))
check('Queue insertion writes the node next pointer at +0',key_lines.get('e098122e','').startswith('e098122e: 6002') and key_lines.get('e0981230','').startswith('e0981230: 6008'))
check('Queue drain wrapper E0981500 is a real function',call_targets['0xe0981500']==1 and key_lines.get('e0981206','').startswith('e0981206: b500'))
check('Only one direct caller to drain wrapper is E0983DD2',call_targets['0xe0981500']==1 and key_lines.get('e0983dd2','').startswith('e0983dd2: f7fd fb95'))
check('Parser/registration route tail-branches to E0983DC2',key_lines.get('e093e746','').startswith('e093e746: f045 bb3c') and key_lines.get('e0983dc2','').startswith('e0983dc2: b520'))
# raw source coverage
seg=[(0xC01E3C40,0xC01E45F4),(0xE01D0000,0xE01DE942),(0xE01DE944,0xE01E3628),(0xE01E3658,0xE01E3680)]
check('S3 initialization intervals do not contain callback node C020EC30',not any(a<=0xC020EC30<b for a,b in seg))
check('S3 initialization intervals do not contain singleton cell C193B3C0',not any(a<=0xC193B3C0<b for a,b in seg))
dump=DUMP.read_bytes(); fhx=FHX.read_bytes()
check('dump.bin has no exact little-endian callback-node address word',len(offsets(dump,0xC020EC30))==0)
check('dump.bin has no exact little-endian singleton-cell address word',len(offsets(dump,0xC193B3C0))==0)
check('dump.bin has no exact selector keys or Sirius primary-vtable address',all(len(offsets(dump,v))==0 for v in (0x00D7ADED,0x00DFB904,0xE0B4C838,0xE0747131)))
check('FHX payload has no exact little-endian callback-node address word',len(offsets(fhx,0xC020EC30))==0)
check('FHX payload has no exact little-endian singleton-cell address word',len(offsets(fhx,0xC193B3C0))==0)
check('FHX payload has no exact selector key 0x00D7ADED',len(offsets(fhx,0x00D7ADED))==0)
check('FHX payload has no exact selector key 0x00DFB904',len(offsets(fhx,0x00DFB904))==0)
check('FHX payload has no exact Sirius vtable address word',len(offsets(fhx,0xE0B4C838))==0)
# Prior exact source fingerprints show originals, not a RAM collection; separate Part5 object reference is preserved.
p5=(BASE/'part5/README_PART5.md').read_text()
check('Part5 Sirius-named implementation is distinguished by C190662C / E070B750','0xC190662C' in p5 and '0xE070B750' in p5)
# The metadata callback excerpt is checked for all five callback target chains.
meta=(EVID/'step40_metadata_callback_trace.txt').read_text()
check('Five lib_handle callback target chains preserved in evidence',all(x in meta for x in ['0xE0469E20','0xE0469CD8','0xE0469E50','0xE0469D98','0xE0469DD8']))

print('STEP 40 FOCUSED STATIC VERIFIER')
for i,(name,ok) in enumerate(checks,1): print(f'{i:02d}. {"PASS" if ok else "FAIL"}  {name}')
print(f'\nRESULT: {sum(ok for _,ok in checks)}/{len(checks)} PASS')
if not all(ok for _,ok in checks): raise SystemExit(1)
