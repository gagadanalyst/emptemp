# Step 40 — Final Sirius dependency pointer-handoff audit

**Scope:** Final bounded, offline audit of independent setter, constructor, metadata and callback candidates for the Part22 `siriusInstance` object. No printer interaction, live execution, reset, configuration change, flash read, firmware write or firmware modification was performed.

## Result

The setter `0xE0747130` and its selector-to-field stores are confirmed, but no runtime provider pointer handoff is proven. There are no direct BL calls to the setter in the full `.srtext` disassembly. The one code edge is a secondary-base adjustor thunk at `0xE0746F74` (`this -= 0x10; B.W 0xE0747130`), and the setter's only ROMFS method pointer is its primary-vtable entry at `0xE0B4CAA0`.

The suspected generic dispatcher `0xE0303558` is now ruled out as the Sirius setter route: its receiver is chosen from the separate context array, and both A/B receiver vtables target the `0xE0303678` zero-return stub at +0x268. The adjacent `lib_handle` metadata remains an association, not a demonstrated binder. The callback queue is real, but the Part22 node's runtime +4 mode and +8 callback fields are absent from the retained mapped image. A second apparent low-half address hit at 0xE08FD8A0 builds 0xC021EC30, not the Sirius node at 0xC020EC30; full MOVW/MOVT pairing resolves that false positive.

## Source coverage

The Library originals `dump.bin` and `tassel_LBI_verified.bin` were materialized read-only and their SHA-256 values match prior source records exactly. They are firmware-source artifacts, not a fresh RAM capture. The ELF contains no program headers and only `.srtext` and `.romfs_objs`; the S-record memory segments do not include `0xC020EC30` or `0xC193B3C0`. FHX/CROM secondary regions were not fully mapped into a trustworthy global code/data image, so the result is a precise evidence boundary, not proof that no binder exists anywhere in the firmware.

## Deliverable contents

- `step40_verified_disassembly.txt` — constructor, adjustor thunk, setter, context dispatcher, list insertion/walker, drain path and metadata callback code excerpts.
- `step40_code_reference_census.txt` — complete disassembly target counts and local vtable-dispatch census.
- `step40_romfs_reference_census.txt` — method-pointer and selector word counts with mapped ROMFS addresses.
- `step40_metadata_callback_trace.txt` — five `lib_handle` callback wrappers and their resolved generic target chains.
- `step40_elf_coverage.txt` / `step40_ram_coverage.txt` — section/program-header and RAM-coverage limits, including original source identity.
- `step40_source_hashes.txt` — source SHA-256 fingerprints.
- `step40_literal_address_census.txt` — full-address MOVW/MOVT analysis distinguishing the actual `0xC020EC30` node from the `0xC021EC30` near-address hit.
- `step40_conclusion.txt` — final confirmed/unresolved distinction and precise evidence needed to close the gap.
- `verify_step40.py` / `verification_output.txt` — focused static evidence checks.
- `hash_manifest.sha256` — package file fingerprints (excluding itself).

**Verification:** see `verification_output.txt` for the exact focused-check result; archive integrity is tested separately with `unzip -t`.
