# Step 34 evidence package — Pen snapshot provider boundary and setter trace

## Scope

Offline, read-only static analysis of the already reconstructed firmware sections. This increment identifies the shared injected-interface call path used by the Pen-oriented snapshot routine, verifies the `siriusInstance` singleton and its `+0x24` member initialization, identifies the vtable resolver/setter methods, and cross-checks the setter selector against ROMFS metadata.

This package does **not** identify the concrete provider class, prove the runtime call that injects its pointer, or establish the semantic meaning of the provider's virtual method at `+0xEC`.

## Inputs and provenance

All analysis is based on the retained Part 1 ELF and reconstructed sections. The full source ELF and sections remain in the Library in `Part1_RTP_Provider_Trace_Evidence_Package.zip` and are not duplicated here.

- ELF SHA-256: `25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7`
- `.srtext` SHA-256: `10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7`
- `.romfs_objs` SHA-256: `227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3`
- Full disassembly SHA-256: `33da87a4babddaa1c6407d69e9a6a190781f0503a653b89b52f682e3fb015956`

## Verified findings

1. `0xE0736078` calls `0xE073C0D8`. That helper clears `r0` and then ANDs it with a shifted bit mask, so it always returns zero. The wrapper therefore takes the injected-provider path at `0xE07360A6` in this build.
2. `0xE0746B00` returns the singleton pointer from global `0xC193B3C0`. `0xE0736078` loads `siriusInstance + 0x24`, then dispatches via the loaded interface's vtable slot `+0xEC`.
3. Constructor `0xE0746A08` zeros the object member at `+0x24`, stores the descriptor pointer at `+0x54`, and publishes the object through global `0xC193B3C0`. The descriptor pointer resolves to the string `siriusInstance`.
4. The primary vtable entries at `0xE0B4CA9C` and `0xE0B4CAA0` point to `0xE07470D0` and `0xE0747130` respectively. The first is a field-address resolver; the second is the generic field setter.
5. The setter's branch arithmetic maps selector `0x00DFB904` to `STR r3,[r0,#0x24]` at `0xE0747262`. The selector is the sum `0x006D5DBC + 0x006A5031 + 0x00073F67 + 0x0000CBB0`.
6. The selector occurs exactly three times in `.romfs_objs`: at VMAs `0xE0AB0CDC`, `0xE0B4AA50`, and `0xE0B5B074`. The first occurrence is adjacent to a metadata string block containing `lib_hda` and `siriusInstance`; the second is in a longer generic 24-byte record sequence; the third is adjacent to `pixel_gen` metadata. It is therefore **not unique to Pen or to this object** and cannot be named as a Pen service ID on this evidence alone.
7. Other callers load the same `siriusInstance + 0x24` interface and call different slots (including `+0x190` and `+0x10C`). This is a shared injected interface, not a method that can be named from the wrapper alone.
8. `0xE0737140` is a separate table-access helper used for indexed data lookups. The `0x24` in `0xE0734548` is a selector passed to generic aggregator `0xE073ECA0`; neither fact establishes a direct connection to the provider at `+0x24`.

## Confidence and unresolved edge

**Confirmed:** callsite mechanics, singleton/global, constructor initialization of member `+0x24`, resolver/setter vtable placement, setter store to `+0x24`, ROMFS selector occurrence count and contexts.

**Unresolved:** which registration/binding routine invokes the setter with selector `0x00DFB904`; what concrete provider pointer it supplies; whether this interface is Pen-specific; and the semantics of slot `+0xEC`.

## Files

- `step34_verified_disassembly.txt` — exact Thumb instruction excerpts for the wrapper, helper, constructor, accessor, resolver/setter, secondary slot and representative callers.
- `step34_romfs_selector_occurrences.txt` — raw little-endian words surrounding all three ROMFS occurrences.
- `step34_source_hashes.txt` — immutable source hashes and key address mappings.
- `verify_step34.py` — checks the retained ELF sections and the static invariants in this increment.
- `QA_SUMMARY.txt` — package verification result.

## Reproduction

Extract the retained Part 1 source package and run:

```bash
python verify_step34.py /path/to/hp_lbi_sections.elf
```

No device communication, printer state changes, printing, scanning, firmware patching or flashing occurred.
