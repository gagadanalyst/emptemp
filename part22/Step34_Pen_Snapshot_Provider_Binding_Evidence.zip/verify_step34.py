#!/usr/bin/env python3
"""Verify Step 34 claims against the retained hp_lbi_sections.elf."""
from pathlib import Path
import hashlib, struct, sys

EXPECTED = {
    'elf': '25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
    'srtext': '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
    'romfs': '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
}
ELF_OFF = 0x54
STEXT_SIZE = 0x743634
ROM_OFF = 0x743688
ROM_SIZE = 0x440D0C
ROM_BASE = 0xE09919C0
TEXT_BASE = 0xE0246070

def digest(b): return hashlib.sha256(b).hexdigest()
def main(path):
    b=Path(path).read_bytes()
    print('PASS' if digest(b)==EXPECTED['elf'] else 'FAIL', 'ELF SHA-256')
    assert digest(b)==EXPECTED['elf']
    s=b[ELF_OFF:ELF_OFF+STEXT_SIZE]
    r=b[ROM_OFF:ROM_OFF+ROM_SIZE]
    assert len(s)==STEXT_SIZE and len(r)==ROM_SIZE
    assert digest(s)==EXPECTED['srtext']; print('PASS .srtext SHA-256')
    assert digest(r)==EXPECTED['romfs']; print('PASS .romfs_objs SHA-256')
    def t(addr): return s[addr-TEXT_BASE:addr-TEXT_BASE+4]
    assert t(0xE0747262)[:2] == bytes.fromhex('4362'); print('PASS setter stores r3 at object +0x24')
    assert t(0xE0746B08)[:2] == bytes.fromhex('0868'); print('PASS singleton accessor loads global pointer')
    assert sum(1 for i in range(len(r)) if r.startswith(bytes.fromhex('04b9df00'),i)) == 3
    print('PASS selector 0x00DFB904 has exactly three ROMFS occurrences')
    def word(addr): return struct.unpack_from('<I',r,addr-ROM_BASE)[0]
    assert word(0xE0B4CA9C)==0xE07470D1
    assert word(0xE0B4CAA0)==0xE0747131
    print('PASS vtable entries: resolver 0xE07470D0; setter 0xE0747130')
    print('PASS Step 34 source integrity and binary invariants')
if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: verify_step34.py /path/to/hp_lbi_sections.elf')
    main(sys.argv[1])
