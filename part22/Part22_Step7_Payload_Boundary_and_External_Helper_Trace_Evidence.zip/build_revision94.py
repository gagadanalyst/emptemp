from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

src = Path('/mnt/data/hp_part22_step6/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision93_Part22_Step6_Alert_List_Binding_Framework_Trace.docx')
out = Path('/mnt/data/hp_part22_step7/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision94_Part22_Step7_Payload_Boundary_External_Helper_Trace.docx')
doc = Document(src)
NAVY='17365D'; BLUE='21618C'; PALE='D9EAF7'; GRAY='666666'; WARN='9C5700'

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def cell_text(cell,text,bold=False,color=None,size=7.0):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color: r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers,rows,widths=None,font=7.0):
    t=doc.add_table(rows=1,cols=len(headers)); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    for i,h in enumerate(headers): cell_text(t.rows[0].cells[i],h,True,NAVY,font); shade(t.rows[0].cells[i],PALE)
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row): cell_text(cells[i],v,size=font)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0)
    return t

def body(text,size=8.0,before=0,after=4,bold_lead=None):
    p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(before); p.paragraph_format.space_after=Pt(after); p.paragraph_format.line_spacing=1.0
    if bold_lead and text.startswith(bold_lead):
        r=p.add_run(bold_lead); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(size)
        r=p.add_run(text[len(bold_lead):]); r.font.name='Aptos'; r.font.size=Pt(size)
    else:
        r=p.add_run(text); r.font.name='Aptos'; r.font.size=Pt(size)
    return p

def h1(s):
    p=doc.add_paragraph(style='Heading 1'); p.paragraph_format.space_before=Pt(0); p.paragraph_format.space_after=Pt(5); p.add_run(s)

def h2(s):
    p=doc.add_paragraph(style='Heading 2'); p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(2); p.add_run(s)

def code(s,size=7.0):
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(.12); p.paragraph_format.right_indent=Inches(.05); p.paragraph_format.space_before=Pt(1); p.paragraph_format.space_after=Pt(3); p.paragraph_format.line_spacing=1.0
    r=p.add_run(s); r.font.name='Consolas'; r.font.size=Pt(size); r.font.color.rgb=RGBColor.from_string('333333')

def label(page):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(f'REVISION 94 | PART 22 STEP 7 | PAGE {page}'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(7.3); r.font.color.rgb=RGBColor.from_string(GRAY)

# PAGE 180
doc.add_page_break(); label(180)
h1('External veneer targets: FHX payload and memory-region inventory')
h2('94.1 Source artifacts and version separation')
body('The current updater lineage is represented by the package-verified `tassel_LBI_verified.bin` (15,369,810 bytes, SHA-256 2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e). Its embedded firmware marker is TBP1CN2629AR and its recorded build text is Fri Jul 17, 2026. The reconstructed FHX payload is 12,888,320 bytes (SHA-256 aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858). The copies materialized from Library match the local input hashes exactly.')
body('A separate 16 MiB `dump.bin` was also preserved. It identifies itself as TJP1FN1702CR and contains the timestamp Sat Jan 14, 2017 03:32:35PM (SHA-256 b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496). This is a distinct, older firmware artifact; it is not assumed to be the executable image or reset-hole implementation for TBP1CN2629AR.')
table(['Artifact','Verified identity / role','Use in Step 7'],[
('tassel_LBI_verified.bin','15,369,810 bytes; current marker TBP1CN2629AR','Authoritative update package input for the S-record coverage audit.'),
('fhx_secure_payload_rebuilt.bin','12,888,320 bytes; 125-entry FHX directory','Authoritative descriptor source for memory-region mapping.'),
('dump.bin','16 MiB; TJP1FN1702CR; 2017 timestamp','Older comparison image only; no current target mapping assumed.'),
],widths=[1.55,2.45,2.55],font=6.7)
h2('94.2 `.reset_hole` descriptor')
body('The FHX directory begins at payload offset 0xBD8. Parsing the name plus aligned six-word descriptor records reproduces 125 entries through `.endram`. The first entry is `.reset_hole`; the third word is the VMA and the fourth word is the size, consistent with the previously verified Part 9/10 descriptor layout.')
code('.reset_hole  VMA=0x38100040  size=0x00000814  end=0x38100854  flags=0x00000001\n.nosi_text    VMA=0x38100854  size=0x00000000  flags=0x00000004\n.nosi_rodata  VMA=0x38100858  size=0x00000280  flags=0x00000001')
table(['External target','Offset within `.reset_hole`','Descriptor containment'],[
('0x38100424','+0x3E4','Inside [0x38100040, 0x38100854).'),
('0x381005A0','+0x560','Inside [0x38100040, 0x38100854).'),
],widths=[1.6,2.0,2.95],font=7.0)
body('The name `.reset_hole` is recorded exactly as present. Its flag semantics and whether it denotes ROM, reserved memory, a retained boot region or another platform-specific mapping are not established by this descriptor alone.')

# PAGE 181
doc.add_page_break(); label(181)
h1('LBI S-record coverage: reset-hole bytes are not supplied')
h2('94.3 S-record integrity and reconstructed address ranges')
body('The S-record prefix of the verified LBI contains seven SA27 lines, one S0 record, 4,098 S3 data records and one S7 terminator. Every S3 count field and checksum passed. The records are not globally address-sorted in the file; after sorting them by their 32-bit addresses, they are non-overlapping and reconstruct into four disjoint segments totalling 81,922 bytes.')
table(['Segment','Address range (end-exclusive)','Bytes','S3 records'],[
('1','0xC01E3C40 - 0xC01E45F4','2,484','125'),
('2','0xE01D0000 - 0xE01DE942','59,714','2,986'),
('3','0xE01DE944 - 0xE01E3628','19,684','985'),
('4','0xE01E3658 - 0xE01E3680','40','2'),
('Total','4 disjoint segments','81,922','4,098'),
],widths=[.7,3.0,1.0,1.0],font=6.9)
body('The segments were rebuilt as independent byte arrays. Their SHA-256 values and the record-to-file reconstruction are retained in the Step 7 evidence ZIP; the original LBI is not modified.')
h2('94.4 Exact negative result for both external targets')
code('S3 address coverage intersected with .reset_hole [0x38100040, 0x38100854): 0 bytes\n0x38100424: inside .reset_hole at +0x3E4; no S3 record covers this address\n0x381005A0: inside .reset_hole at +0x560; no S3 record covers this address')
body('This is a payload-coverage conclusion, not proof that the device has no code at those addresses. It establishes that the current LBI update stream does not deliver bytes for the `.reset_hole` region. The external helper bodies therefore cannot be reconstructed from this package alone.')
h2('94.5 Other FHX image regions are not alternate mappings for these addresses')
table(['FHX section','VMA / size','Interpretation'],[
('.srtext','0xE0246070 / 0x743634','Verified main LBI code image used for Part 22 analysis.'),
('.text','0x801A86B8 / 0x7E7940','Candidate projection from older dump; executable identity and base remain provisional.'),
('.cromsrtext','0xE1A76480 / 0x529E00','Separate secondary code region; includes branch-skipped inline data islands.'),
('.cromtext / module / fs','0xE1FA0280 onward','Separate smaller CROM metadata/resources.'),
],widths=[1.35,2.0,3.1],font=6.7)
body('The 2017 dump’s candidate `.text` range is byte-exact against the FHX descriptor size under a provisional 0x80000000 flash-base assumption, but it is not validated as a decoded executable image for this 2026 firmware. It must not be repurposed as a source for 0x381... target bodies.')

# PAGE 182
doc.add_page_break(); label(182)
h1('External target ABI: zero-fill and byte-copy helpers')
h2('94.6 Veneer literals and direct caller inventory')
code('0xE02795D8: ldr.w pc, [pc, #0]  -> literal at 0xE02795DC = 0x38100424\n0xE02795E0: ldr.w pc, [pc, #0]  -> literal at 0xE02795E4 = 0x381005A0')
table(['External target','Direct calls via veneer','Observed argument setup','ABI interpretation'],[
('0x38100424','3','r0=destination; r1=0; r2=0xDC0 or 0x10','Zero-fill / `memset`-style helper.'),
('0x381005A0','12','r0=destination; r1=source; r2=0x4144','Byte-copy / `memcpy`-style helper.'),
],widths=[1.25,1.0,2.65,1.55],font=6.7)
body('At 0xE0276A96, the siriusInstance constructor passes `this + 0x14`, a zero-valued r1, and a 0xDC0-byte length to the 0x38100424 veneer. The same veneer is used twice to clear 16-byte temporary buffers. This is strong call-site evidence for zero-fill semantics.')
body('At 0xE0277646 and repeated alert-provider record-copy sites, code prepares a destination in r0, a source pointer in r1, and size 0x4144 in r2 before calling the 0x381005A0 veneer. This matches a bulk byte-copy ABI. The target implementations and exported symbol names are not present; the identifications are ABI-based rather than symbol recovery.')
h2('94.7 ROMFS occurrence and interpretation limit')
body('A raw little-endian word equal to 0x38100424 occurs once in `.romfs_objs` at VMA 0xE09B7098. It is embedded in a text-heavy table containing alphabet characters, `%02x`, `%02X` and repeated `os.h` strings. That context is not a recognized vtable or standalone function-pointer record, so this occurrence is not treated as a runtime registration reference. No raw 0x381005A0 word occurs in `.romfs_objs`.')
h2('94.8 Step 7 conclusion and remaining gap')
body('The two unresolved targets from Step 6 are now functionally narrowed to generic memory helpers: 0x38100424 is `memset`-like and 0x381005A0 is `memcpy`-like. Both addresses are inside the FHX `.reset_hole` region, and neither helper body is carried by this LBI’s S-record payload. This resolves the external-veneer question; it does not identify the framework caller for selector 0x0061862B or the concrete provider stored at 0xC136E704.')
table(['Resolved in Step 7','Still unresolved'],[
('The `.reset_hole` VMA/size and exact containment of both targets.','Why the platform labels this region `.reset_hole`; exact flags and persistence semantics.'),
('No S3 update bytes cover either address.','Actual function bodies or symbol names for the two external helpers.'),
('Call-site ABI strongly supports zero-fill and byte-copy roles.','Framework dispatcher and pointer passed as r3 to the alert-list setter.'),
('Older dump is a distinct 2017 firmware image.','Any causal path from the alert provider to RTP block/unblock or PE blocked-state write.'),
],widths=[3.15,3.15],font=6.6)
h2('94.9 Recommended next bounded step')
body('Inspect the separate `.cromsrtext` image at 0xE1A76480 in a branch-aware, bounded way around its `sirius` references and component/service descriptors. The aim is to identify the framework dispatcher for the secondary-vtable binding path while preserving the inline-data boundaries already established in Part 10. Do not infer function bodies from a single flat disassembly.')
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(5); p.paragraph_format.space_after=Pt(0)
r=p.add_run('PART 22 STEP 7 COMPLETE - WAIT FOR APPROVAL BEFORE STEP 8'); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(8.2); r.font.color.rgb=RGBColor.from_string(NAVY)

props=doc.core_properties
props.title='HP DeskJet 2855e Independent Printing and Scanning Investigation - Revision 94'
props.subject='Part 22 Step 7: payload boundary, reset-hole coverage and external helper ABI trace'
props.comments='Appended to Revision 93. Static-only analysis; no printer access, network operations or firmware modification. External target interpretations are ABI-based and bounded by payload coverage.'
doc.save(out)
print(out)
