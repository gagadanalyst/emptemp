from pathlib import Path
import hashlib, re, struct, csv, json, textwrap, zipfile, sys

ROOT = Path('/mnt/data/hp_part22_step7')
EV = ROOT / 'evidence'
SEGDIR = ROOT / 'rebuilt_srecords'
EV.mkdir(parents=True, exist_ok=True)
SEGDIR.mkdir(parents=True, exist_ok=True)

LBI_PATH = Path('/mnt/data/hp_fw_inputs/tassel_LBI_verified.bin')
FHX_PATH = Path('/mnt/data/hp_fw_inputs/extracted/part1_rtp_provider_trace/fhx_secure_payload_rebuilt.bin')
DUMP_PATH = Path('/mnt/data/hp_fw_inputs/dump.bin')
SR_PATH = Path('/mnt/data/hp_fw_inputs/extracted/inputs/srtext_rebuilt.bin')
ROM_PATH = Path('/mnt/data/hp_fw_inputs/extracted/inputs/romfs_objs_rebuilt.bin')
DIS_PATH = Path('/mnt/data/hp_fw_inputs/srtext_disasm_all.txt')
CROSSWALK_PATH = Path('/mnt/data/hp_fw_inputs/extracted/part8_service_descriptor_crosswalk_A_B.csv')

LBI = LBI_PATH.read_bytes()
FHX = FHX_PATH.read_bytes()
DUMP = DUMP_PATH.read_bytes()
SR = SR_PATH.read_bytes()
ROM = ROM_PATH.read_bytes()
DIS = DIS_PATH.read_text(errors='replace').splitlines()

EXPECTED = {
    LBI_PATH: '2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e',
    FHX_PATH: 'aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858',
    DUMP_PATH: 'b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496',
    SR_PATH: '10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
    ROM_PATH: '227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
    DIS_PATH: 'f900a16029dd0a8d9a1a87cb74c41ce616ebd556ae503c0591212ef241400377',
    CROSSWALK_PATH: '90c0f8ce15dd7287db01a849c0ebf932ee1b3ff6815a214d98953732c51bad34',
}

def sha256_bytes(b): return hashlib.sha256(b).hexdigest()
def sha256_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()
def write_text(name, text): (EV/name).write_text(text, encoding='utf-8')

# Reconstruct section descriptor directory from the FHX header.
DIR_OFF = 0xBD8
entries=[]
pos=DIR_OFF
for idx in range(200):
    z=FHX.find(b'\0', pos)
    if z < 0 or z-pos > 48:
        break
    name=FHX[pos:z].decode('ascii','replace')
    if not name.startswith('.'):
        break
    fields_off=(z+1+3)&~3
    if fields_off+24>len(FHX):
        break
    fields=struct.unpack_from('<6I', FHX, fields_off)
    entries.append({'index':idx,'entry_offset':pos,'name':name,'fields_offset':fields_off,'fields':fields})
    pos=fields_off+24
    if name=='.endram': break
if len(entries) != 125:
    raise RuntimeError(f'Expected 125 FHX descriptors, found {len(entries)}')
with (EV/'FHX_DIRECTORY_125.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['index','entry_file_offset','section_name','fields_file_offset','meta_ptr_1','meta_ptr_2','vma','size','flags','extra_ptr'])
    for e in entries:
        w.writerow([e['index'],f"0x{e['entry_offset']:X}",e['name'],f"0x{e['fields_offset']:X}",*[f'0x{x:08X}' for x in e['fields']]])
byname={e['name']:e for e in entries}
reset=byname['.reset_hole']; nosi_text=byname['.nosi_text']; nosi_ro=byname['.nosi_rodata']

def desc_line(e):
    f=e['fields']
    return (f"{e['name']}: entry_offset=0x{e['entry_offset']:X}, fields_offset=0x{e['fields_offset']:X}, "
            f"meta1=0x{f[0]:08X}, meta2=0x{f[1]:08X}, VMA=0x{f[2]:08X}, size=0x{f[3]:X}, flags=0x{f[4]:08X}, extra=0x{f[5]:08X}")
relevant=['.reset_hole','.nosi_text','.nosi_rodata','.srtext','.text','.setup_text','.romstartup_text','.cromsrtext','.cromtext','.crommodule','.cromfs','.endram']
write_text('FHX_RELEVANT_DESCRIPTORS.txt',
    'FHX directory located at payload file offset 0xBD8. Parsed 125 six-word entries through .endram.\n'
    'The documented descriptor layout uses the third word as VMA and fourth word as byte size.\n'
    'Flags are retained numerically; their semantic meaning is not assumed.\n\n'+
    '\n'.join(desc_line(byname[n]) for n in relevant)+'\n')

# Parse all S-record lines through S7 terminator.
end_match=re.search(rb'S7[0-9A-Fa-f]+\r?\n', LBI)
if not end_match: raise RuntimeError('S7 terminator not found')
prefix=LBI[:end_match.end()]
lines=prefix.decode('ascii').splitlines()
sa27=[x for x in lines if x.startswith('SA27')]
s0=[x for x in lines if x.startswith('S0')]
s3lines=[x for x in lines if x.startswith('S3')]
s7=[x for x in lines if x.startswith('S7')]
records=[]
for line_no,line in enumerate(lines,1):
    if not line.startswith('S3'): continue
    raw=bytes.fromhex(line[2:])
    if raw[0] != len(raw)-1:
        raise RuntimeError(f'S3 count mismatch at prefix line {line_no}')
    if sum(raw)&0xFF != 0xFF:
        raise RuntimeError(f'S3 checksum mismatch at prefix line {line_no}')
    address=int.from_bytes(raw[1:5],'big')
    data=raw[5:-1]
    if not data:
        raise RuntimeError(f'Empty S3 payload at line {line_no}')
    records.append((address,data,line_no,line))
if len(records)!=4098:
    raise RuntimeError(f'Expected 4098 S3 records, found {len(records)}')

# Rebuild contiguous S3 address segments by address. The S3 records are not globally sorted;
# sort the validated records, then detect any address overlap.
segments=[]
record_map=[]
for address,data,line_no,line in sorted(records, key=lambda x: x[0]):
    end=address+len(data)
    if segments and address < segments[-1]['end']:
        raise RuntimeError(f'S3 overlap/out-of-order at line {line_no}: 0x{address:X}')
    if not segments or address != segments[-1]['end']:
        segments.append({'start':address,'end':end,'data':bytearray(data),'records':[line_no]})
    else:
        segments[-1]['data'].extend(data)
        segments[-1]['end']=end
        segments[-1]['records'].append(line_no)

with (EV/'S3_SEGMENTS.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['segment_index','start_address','end_exclusive','size_bytes','record_count','sha256','rebuilt_file'])
    for i,s in enumerate(segments,1):
        payload=bytes(s['data']); fn=f'segment_{i}_{s["start"]:08X}_{s["end"]:08X}.bin'
        (SEGDIR/fn).write_bytes(payload)
        w.writerow([i,f'0x{s["start"]:08X}',f'0x{s["end"]:08X}',len(payload),len(s['records']),sha256_bytes(payload),f'../rebuilt_srecords/{fn}'])

reset_start=reset['fields'][2]; reset_size=reset['fields'][3]; reset_end=reset_start+reset_size
intersections=[]
for address,data,line_no,line in records:
    a=max(address,reset_start); b=min(address+len(data),reset_end)
    if a<b: intersections.append((a,b,line_no))
if intersections: raise RuntimeError('Unexpected S3 records overlap .reset_hole')

targets=[0x38100424,0x381005A0]
for target in targets:
    if not (reset_start <= target < reset_end):
        raise RuntimeError(f'{target:#x} not within .reset_hole')
    if any(a <= target < a+len(d) for a,d,_,_ in records):
        raise RuntimeError(f'{target:#x} unexpectedly supplied by S3')

s3_total=sum(len(d) for _,d,_,_ in records)
segment_summary='\n'.join(
    f"{i}. 0x{s['start']:08X}-0x{s['end']:08X} (end-exclusive), size=0x{len(s['data']):X} ({len(s['data'])} bytes), records={len(s['records'])}, sha256={sha256_bytes(bytes(s['data']))}"
    for i,s in enumerate(segments,1))
write_text('S3_RECORD_AUDIT.txt',
    f"S-record prefix ends at 0x{end_match.end():X} in the LBI file, at the S7 terminator.\n"
    f"SA27 lines: {len(sa27)}; S0 records: {len(s0)}; S3 records: {len(records)}; S7 terminators: {len(s7)}.\n"
    f"All S3 count fields and checksums passed. Total S3 data bytes: {s3_total}.\n"
    f"The S3 records are not globally address-sorted in the file; when sorted by address they are non-overlapping and rebuild into {len(segments)} disjoint address segments:\n{segment_summary}\n\n"
    f".reset_hole descriptor: VMA 0x{reset_start:08X}, size 0x{reset_size:X}, end-exclusive 0x{reset_end:08X}.\n"
    f"S3 intersections with .reset_hole: 0.\n"
    f"Target 0x38100424: offset +0x{targets[0]-reset_start:X} inside .reset_hole; no S3 data covers it.\n"
    f"Target 0x381005A0: offset +0x{targets[1]-reset_start:X} inside .reset_hole; no S3 data covers it.\n")

# Exact veneer literals and call-site contexts from full disassembly.
addr_line={}
for i,line in enumerate(DIS):
    m=re.match(r'^([0-9a-fA-F]{8}):',line)
    if m: addr_line[int(m.group(1),16)]=i

def get_lines(a,b):
    ia=addr_line[a]; ib=addr_line[b]
    return '\n'.join(DIS[ia:ib+1])+'\n'
veneer_text=get_lines(0xE02795D8,0xE02795EA)
write_text('EXTERNAL_VENEERS.txt',
    'Verified veneer disassembly from the retained complete .srtext disassembly.\n\n'+veneer_text+
    'Literal values at 0xE02795DC and 0xE02795E4 are confirmed by the linker-generated veneer instructions.\n'
    'The values are external targets, not recovered function bodies.\n')

call_sites=[]
for i,line in enumerate(DIS):
    if 'bl\t0xe02795d8' in line.lower() or 'bl\t0xe02795e0' in line.lower():
        m=re.match(r'^([0-9a-fA-F]{8}):',line)
        if not m: continue
        a=int(m.group(1),16)
        target=0x38100424 if '95d8' in line.lower() else 0x381005A0
        call_sites.append((a,target,i))

def get_context(i,pre=5,post=2):
    return '\n'.join(DIS[max(0,i-pre):min(len(DIS),i+post+1)])
with (EV/'EXTERNAL_CALL_SITE_CONTEXTS.txt').open('w') as f:
    f.write('Direct calls through the two import veneers; contexts show argument setup.\n')
    f.write(f'0x38100424 veneer call count: {sum(t==0x38100424 for _,t,_ in call_sites)}\n')
    f.write(f'0x381005A0 veneer call count: {sum(t==0x381005A0 for _,t,_ in call_sites)}\n\n')
    for a,t,i in call_sites:
        f.write(f'--- call at 0x{a:08X} -> veneer -> 0x{t:08X} ---\n')
        f.write(get_context(i,6,2)+'\n\n')

# Record specific argument setups.
memset_calls=[a for a,t,i in call_sites if t==0x38100424]
memcpy_calls=[a for a,t,i in call_sites if t==0x381005A0]
if len(memset_calls)!=3: raise RuntimeError(f'Expected 3 zero-fill call sites, got {len(memset_calls)}')
if len(memcpy_calls)!=12: raise RuntimeError(f'Expected 12 byte-copy call sites, got {len(memcpy_calls)}')

# ROMFS context for the only raw exact word occurrence of 0x38100424.
rom_base=0xE09919C0
ptr_bytes=struct.pack('<I',0x38100424)
rom_pos=[m.start() for m in re.finditer(re.escape(ptr_bytes),ROM)]
rom_pos_5a0=[m.start() for m in re.finditer(re.escape(struct.pack('<I',0x381005A0)),ROM)]
if len(rom_pos)!=1 or len(rom_pos_5a0)!=0:
    raise RuntimeError(f'Unexpected ROMFS raw match counts: {len(rom_pos)} / {len(rom_pos_5a0)}')
off=rom_pos[0]
lo=max(0,off-0x60); hi=min(len(ROM),off+0x80); context=ROM[lo:hi]
write_text('ROMFS_RAW_WORD_CONTEXT.txt',
    f'Raw little-endian 0x38100424 occurs once in .romfs_objs at VMA 0x{rom_base+off:08X} (file offset 0x{off:X}).\n'
    f'It is inside a text-heavy table containing printable alphabet characters, "%02x", "%02X", and repeated "os.h" strings.\n'
    f'Bytes [{lo:#x}:{hi:#x}] at VMA 0x{rom_base+lo:08X}:\n{context.hex(" ")}\n'
    f'ASCII view: {"".join(chr(x) if 32<=x<127 else "." for x in context)}\n'
    'This context is not a recognized function-pointer table or vtable. The raw occurrence is retained as a caution, not used as proof of runtime binding.\n'
    f'Raw little-endian 0x381005A0 occurrences in .romfs_objs: {len(rom_pos_5a0)}.\n')

# Older dump.bin provenance markers and relation limitations.
markers=[(b'TJP1FN1702CR','firmware version marker'),(b'Sat Jan 14, 2017 03:32:35PM','build timestamp')]
marker_text=[]
for marker,label in markers:
    found=[m.start() for m in re.finditer(re.escape(marker),DUMP)]
    marker_text.append(f'{label}: {marker!r}; offsets={[hex(x) for x in found]}')
# exact target words absent from old raw dump
old_dump_target_counts={hex(v):len(list(re.finditer(re.escape(struct.pack('<I',v)),DUMP))) for v in targets}
# Known .text projection as recorded in Part 10: address mapping remains provisional.
proj_off=0x1A86B8; proj_len=0x7E7940
proj=DUMP[proj_off:proj_off+proj_len]
write_text('OLDER_DUMP_INVENTORY.txt',
    f'dump.bin size={len(DUMP)} bytes, sha256={sha256_bytes(DUMP)}.\n'+
    '\n'.join(marker_text)+'\n'+
    f'Raw exact little-endian target-word occurrence counts in the full dump: {old_dump_target_counts}.\n'+
    f'Part 10 candidate .text projection: dump.bin[0x{proj_off:X}:0x{proj_off+proj_len:X}], size={len(proj)}, sha256={sha256_bytes(proj)}.\n'
    'The projection is byte-exact against the FHX .text descriptor size under a provisional 0x80000000 flash-base assumption, but decoded executable identity and address mapping are not proven. It must not be used as a target image for 0x381... addresses.\n'
    'The TJP1FN1702CR marker and 2017 timestamp establish that this is an older/different firmware artifact from the current TBP1CN2629AR LBI.\n')

# CROM section exact slice/hash; no disassembly conclusions from blind raw matches.
crom=FHX[0x71E640:0x71E640+0x529E00]
if len(crom)!=0x529E00: raise RuntimeError('CROM slice length mismatch')
write_text('CROM_SECTION_INVENTORY.txt',
    f'FHX .cromsrtext descriptor: VMA 0xE1A76480, size 0x529E00.\n'
    f'Payload offset 0x71E640, extracted bytes={len(crom)}, sha256={sha256_bytes(crom)}.\n'
    'Prior Part 10 analysis found branch-skipped inline data islands (including the pe_oop literal), so this section must not be decoded as a single uninterrupted Thumb stream.\n'
    'The section is a separate region from .reset_hole. Its base is 0xE1A76480; it does not provide file-backed bytes for the targets 0x38100424/0x381005A0.\n')

# Source inventory hashes, with both materialized Library files checked against local source.
write_text('SOURCE_INPUTS.txt', '\n'.join(
    f'{p}\n  bytes={p.stat().st_size}\n  sha256={sha256_file(p)}\n  expected={expected}\n  match={sha256_file(p)==expected}'
    for p,expected in EXPECTED.items())+'\n\n'+
    'Library-materialized source copies (exact hash equality checked):\n'
    f"/mnt/data/hp_step7_library_inputs/tassel_LBI_verified.bin sha256={sha256_file(Path('/mnt/data/hp_step7_library_inputs/tassel_LBI_verified.bin'))}\n"
    f"/mnt/data/hp_step7_library_inputs/dump.bin sha256={sha256_file(Path('/mnt/data/hp_step7_library_inputs/dump.bin'))}\n")

# Findings, README, verification script.
findings = f'''# Part 22 Step 7 — payload boundary and external helper identification

## Scope
Static-only inspection of the package-verified `TBP1CN2629AR` LBI, its reconstructed FHX payload, the preserved 16 MiB raw `dump.bin`, and retained `.srtext` / `.romfs_objs` sections. No printer access, network operations, debug activation, firmware write or device-state change.

## Firmware and image inventory
- `tassel_LBI_verified.bin`: {len(LBI):,} bytes; SHA-256 `{sha256_bytes(LBI)}`. Its metadata contains `TBP1CN2629AR` and `Fri Jul 17, 2026`.
- Reconstructed FHX payload: {len(FHX):,} bytes; SHA-256 `{sha256_bytes(FHX)}`. Its directory begins at offset `0xBD8` and contains 125 descriptors through `.endram`.
- `dump.bin`: {len(DUMP):,} bytes; SHA-256 `{sha256_bytes(DUMP)}`. It contains `TJP1FN1702CR` and `Sat Jan 14, 2017 03:32:35PM`, so it is a distinct older artifact, not a matching current-version runtime image.

## `.reset_hole` mapping
The first FHX descriptor is `.reset_hole`: VMA `0x38100040`, size `0x814`, end-exclusive `0x38100854`, flags word `0x00000001` (semantics not decoded). The two imported targets lie within this range:
- `0x38100424` = `.reset_hole + 0x3E4`
- `0x381005A0` = `.reset_hole + 0x560`

Adjacent descriptors: `.nosi_text` begins at `0x38100854` with size zero; `.nosi_rodata` begins at `0x38100858` with size `0x280`. The FHX file-backed primary regions include `.srtext` at `0xE0246070`, the `.text` candidate at `0x801A86B8`, and `.cromsrtext` at `0xE1A76480`; none overlaps the `0x381...` reset-hole address range. The meaning of the name `reset_hole` and its flags is not assumed.

## S-record payload coverage
The LBI update's S-record prefix contains 7 SA27 lines, one S0, 4,098 S3 records and one S7 terminator. All S3 count fields and checksums passed. The records are not globally address-sorted in the file; sorting by address yields four disjoint, non-overlapping segments documented in `S3_SEGMENTS.csv`. The 81,922 S3 data bytes reconstruct into those segments. No S3 record overlaps `.reset_hole`, and no S3 byte is supplied at either external target. The missing target bodies are therefore not delivered by this LBI's S-record payload.

## External target ABI identification
The two `.srtext` import veneers are:
- `0xE02795D8` loads the external target word at `0xE02795DC` = `0x38100424`.
- `0xE02795E0` loads the external target word at `0xE02795E4` = `0x381005A0`.

Call-site register setup strongly identifies their roles:
- `0x38100424`: three calls; `r0` is a destination, `r1=0`, and `r2` is a byte length (`0xDC0` in the alert-provider constructor; `0x10` in two temporary-buffer clears). This matches a zero-fill / `memset`-style ABI.
- `0x381005A0`: twelve calls; representative call sites pass destination in `r0`, source in `r1`, and `0x4144` bytes in `r2`, matching a byte-copy / `memcpy`-style ABI. The helper body and exported symbol name are not present, so this is ABI-based identification, not symbol recovery.

These are generic memory helpers used by the alert-provider implementation, not the missing framework dispatcher. The actual implementations reside in the `.reset_hole` address window, but their bytes are absent from the package payload examined here.

## Other image checks and caution
The older `dump.bin` is not a trustworthy source for these current firmware targets. Its candidate `.text` projection is based on a provisional flash-base mapping; it is not established as decoded executable code for the current target. The separate `.cromsrtext` region is a 5,414,400-byte region at `0xE1A76480` and previously was shown to contain branch-skipped inline data. It cannot be treated as one flat Thumb instruction stream. A single raw ROMFS occurrence of `0x38100424` is inside a text-heavy block with `%02x`, `%02X` and `os.h` strings; it is not evidence of a callable vtable or binding.

## Step 7 conclusion
The two unexplained addresses from Step 6 are now identified as `memset`-like and `memcpy`-like external helper interfaces by their call-site ABI. They live within the FHX `.reset_hole` range, for which the current LBI S-record payload supplies no bytes. This closes the external-veneer question but **does not** recover the framework caller that passes selector `0x0061862B` or the concrete alert-list provider stored at `0xC136E704`. No connection to RTP block/unblock or the PE blocked-state writer has been proven.

## Proposed next bounded step
Inspect the separate `.cromsrtext` image in a branch-aware, bounded way around the three `sirius` references and known component/service descriptor strings, looking for the dispatcher that calls the secondary-vtable binding method. Preserve inline-data boundaries and do not infer a full function map from linear decoding.
'''
write_text('STEP7_FINDINGS.md',findings)

readme='''# Part 22 Step 7 evidence package

This archive contains the bounded, reproducible evidence for the payload inventory, `.reset_hole` address mapping, S-record coverage audit and call-site ABI classification of the external helper veneers. All analysis is offline/static.

## Contents
- `STEP7_FINDINGS.md` — summary, conclusions and limitations.
- `FHX_RELEVANT_DESCRIPTORS.txt`, `FHX_DIRECTORY_125.csv` — reconstructed FHX directory evidence.
- `S3_RECORD_AUDIT.txt`, `S3_SEGMENTS.csv`, `../rebuilt_srecords/*.bin` — verified S-record ranges and rebuilt segments.
- `EXTERNAL_VENEERS.txt`, `EXTERNAL_CALL_SITE_CONTEXTS.txt` — external branch veneers and call-site register setup.
- `ROMFS_RAW_WORD_CONTEXT.txt` — context for one raw pointer-value occurrence in ROMFS.
- `OLDER_DUMP_INVENTORY.txt`, `CROM_SECTION_INVENTORY.txt` — other payload inventory and boundaries.
- `SOURCE_INPUTS.txt` — source sizes and SHA-256 checks.
- `verify_part22_step7.py`, `verification_output.txt` — independent reproducibility checks.
- `DOCX_QA.txt` — findings document QA summary.
- `SHA256SUMS.txt` — archive member SHA-256 manifest.

## Source requirements
The verifier expects the seven source artifacts listed in `SOURCE_INPUTS.txt` to exist at their recorded paths under `/mnt/data/hp_fw_inputs/`. It does not need the physical printer or network access.

## Interpretation limits
`memset`-like and `memcpy`-like are ABI-based identifications from the register arguments and call-site behavior. The symbol names and implementation bytes are not available. The `.reset_hole` flags and its actual persistence/boot-ROM semantics are not decoded.
'''
write_text('README.md',readme)

# Build verifier as an independent script using recorded paths and invariants.
verifier=r'''from pathlib import Path
import hashlib,re,struct,sys

BASE=Path('/mnt/data/hp_fw_inputs')
LBI=BASE/'tassel_LBI_verified.bin'
FHX=BASE/'extracted/part1_rtp_provider_trace/fhx_secure_payload_rebuilt.bin'
DUMP=BASE/'dump.bin'
DIS=BASE/'srtext_disasm_all.txt'
ROM=BASE/'extracted/inputs/romfs_objs_rebuilt.bin'

def check(label,cond):
    if not cond: raise AssertionError(label)
    print('PASS',label)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def u32(data,off): return struct.unpack_from('<I',data,off)[0]

lbi=LBI.read_bytes(); fhx=FHX.read_bytes(); dump=DUMP.read_bytes(); dis=DIS.read_text(errors='replace').splitlines(); rom=ROM.read_bytes()
check('verified LBI hash',sha(LBI)=='2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e')
check('reconstructed FHX hash',sha(FHX)=='aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858')
check('older dump hash',sha(DUMP)=='b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496')
check('full srtext disassembly hash',sha(DIS)=='f900a16029dd0a8d9a1a87cb74c41ce616ebd556ae503c0591212ef241400377')
check('ROMFS source hash',sha(ROM)=='227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3')
check('LBI contains current firmware marker',b'TBP1CN2629AR' in lbi)
check('FHX magic prefix',fhx[:4]==bytes.fromhex('bad2bfed'))

# Directory: 125 entries, name + aligned 6-word descriptor.
pos=0xBD8; ents=[]
for i in range(200):
    z=fhx.find(b'\0',pos)
    if z<0 or z-pos>48: break
    name=fhx[pos:z].decode('ascii','replace')
    if not name.startswith('.'): break
    fo=(z+1+3)&~3
    vals=struct.unpack_from('<6I',fhx,fo)
    ents.append((name,vals,pos,fo)); pos=fo+24
    if name=='.endram': break
check('125 FHX section descriptors',len(ents)==125)
d={x[0]:x for x in ents}
check('.reset_hole VMA',d['.reset_hole'][1][2]==0x38100040)
check('.reset_hole size',d['.reset_hole'][1][3]==0x814)
check('.reset_hole flags retained',d['.reset_hole'][1][4]==1)
check('.nosi_text immediately follows reset hole',d['.nosi_text'][1][2]==0x38100854 and d['.nosi_text'][1][3]==0)
check('.nosi_rodata follows with expected range',d['.nosi_rodata'][1][2]==0x38100858 and d['.nosi_rodata'][1][3]==0x280)
check('.srtext section descriptor',d['.srtext'][1][2]==0xE0246070 and d['.srtext'][1][3]==0x743634)
check('.text candidate descriptor',d['.text'][1][2]==0x801A86B8 and d['.text'][1][3]==0x7E7940)
check('.cromsrtext descriptor',d['.cromsrtext'][1][2]==0xE1A76480 and d['.cromsrtext'][1][3]==0x529E00)

# S-record parser and address coverage.
m=re.search(rb'S7[0-9A-Fa-f]+\r?\n',lbi); check('S7 terminator present',m is not None)
lines=lbi[:m.end()].decode('ascii').splitlines()
records=[]
for n,line in enumerate(lines,1):
    if line.startswith('S3'):
        raw=bytes.fromhex(line[2:]); check(f'S3 count/checksum line {n}',raw[0]==len(raw)-1 and (sum(raw)&0xff)==0xff)
        records.append((int.from_bytes(raw[1:5],'big'),raw[5:-1]))
check('4098 S3 records',len(records)==4098)
check('81922 total S3 bytes',sum(len(x[1]) for x in records)==81922)
segments=[]
for a,b in sorted(records, key=lambda x: x[0]):
    if segments and a<segments[-1][1]: raise AssertionError('S3 address overlap/order')
    if segments and a==segments[-1][1]: segments[-1]=(segments[-1][0],a+len(b))
    else: segments.append((a,a+len(b)))
check('four disjoint contiguous S3 segments after address sort',len(segments)==4)
rs=d['.reset_hole'][1][2]; re_=rs+d['.reset_hole'][1][3]
check('no S3 overlap with .reset_hole',all(not (a<re_ and b>rs) for a,b in segments))
check('0x38100424 is inside .reset_hole',rs<=0x38100424<re_)
check('0x381005A0 is inside .reset_hole',rs<=0x381005A0<re_)
check('no S3 byte supplied at 0x38100424',not any(a<=0x38100424<b for a,b in segments))
check('no S3 byte supplied at 0x381005A0',not any(a<=0x381005A0<b for a,b in segments))

# Veneer loads and call-site counts.
line_map={}
for line in dis:
    mm=re.match(r'^([0-9a-fA-F]{8}):',line)
    if mm: line_map[int(mm.group(1),16)]=line.lower()
check('zero-fill veneer is indirect PC load', 'ldr.w\tpc' in line_map[0xE02795D8])
check('zero-fill target literal', '0x38100424' in line_map[0xE02795DC] or '0x38100424' in line_map.get(0xE02795DA,'') or u32((BASE/'extracted/inputs/srtext_rebuilt.bin').read_bytes(),0xE02795DC-0xE0246070)==0x38100424)
check('copy veneer is indirect PC load','ldr.w\tpc' in line_map[0xE02795E0])
sr=(BASE/'extracted/inputs/srtext_rebuilt.bin').read_bytes()
check('copy target literal',u32(sr,0xE02795E4-0xE0246070)==0x381005A0)
call1=[a for a,l in line_map.items() if 'bl\t0xe02795d8' in l]
call2=[a for a,l in line_map.items() if 'bl\t0xe02795e0' in l]
check('three calls use zero-fill veneer',len(call1)==3)
check('twelve calls use byte-copy veneer',len(call2)==12)

# Specific call setup proves ABI signatures.
def idxof(addr):
    for i,line in enumerate(dis):
        m=re.match(r'^([0-9a-fA-F]{8}):',line)
        if m and int(m.group(1),16)==addr: return i
    raise KeyError(hex(addr))
def context(addr,n=6):
    i=idxof(addr); return '\n'.join(dis[max(0,i-n):i+1]).lower()
c=context(0xE0276A96,6)
check('constructor zero-fill passes destination/value/size',all(x in c for x in ['add.w\tr0, r4, #0x14','mov.w\tr2, #0xdc0','mov\tr1, r5']))
check('zero-fill value is initialized zero', 'movs\tr5, #0x0' in context(0xE0276A96,60))
c=context(0xE0277646,6)
check('copy call sets 0x4144 byte length', 'movw\tr2, #0x4144' in c)
check('copy call computes destination and source', 'ldr.w\tr1, [r3, r4, lsl #2]' in c and 'mla\tr0, r4, r2, r0' in c)

# Old artifact not the current target.
check('old dump has TJP1FN1702CR marker',b'TJP1FN1702CR' in dump)
check('old dump has 2017 timestamp',b'Sat Jan 14, 2017 03:32:35PM' in dump)

# ROMFS raw occurrence is contextual data, not interpreted as runtime binding.
occ=[]; p=0; pat=struct.pack('<I',0x38100424)
while True:
    i=rom.find(pat,p)
    if i<0: break
    occ.append(i); p=i+1
check('single raw ROMFS 0x38100424 occurrence',len(occ)==1)
check('no raw ROMFS 0x381005A0 occurrence',rom.find(struct.pack('<I',0x381005A0))<0)
print('SUMMARY: all Step 7 checks passed')
'''
write_text('verify_part22_step7.py',verifier)

# Run the verifier now; line-by-line S3 checks are noisy, but are useful in the reproducible output.
import subprocess
vp=EV/'verify_part22_step7.py'
proc=subprocess.run([sys.executable,str(vp)],capture_output=True,text=True)
(EV/'verification_output.txt').write_text(proc.stdout+proc.stderr)
if proc.returncode:
    raise RuntimeError(f'Step 7 verifier failed: {proc.stderr[-2000:]}')

# Document QA placeholder will be updated after rendering.
write_text('DOCX_QA.txt','Pending final Revision 94 render and page comparison.\n')

# Hash manifest excludes itself.
files=sorted([p for p in ROOT.rglob('*') if p.is_file() and p.name not in {'SHA256SUMS.txt'}])
manifest=''.join(f'{sha256_file(p)}  {p.relative_to(ROOT)}\n' for p in files if 'qa' not in p.parts)
write_text('SHA256SUMS.txt',manifest)

# Build zip at root with `evidence/` and `rebuilt_srecords/`.
zip_path=ROOT/'Part22_Step7_Payload_Boundary_and_External_Helper_Trace_Evidence.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p != zip_path and 'qa' not in p.parts:
            z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip()
    if bad: raise RuntimeError(f'ZIP CRC failure: {bad}')

print('Evidence built:',zip_path,zip_path.stat().st_size)
print('verifier output lines',len(proc.stdout.splitlines()))
print(proc.stdout[-1200:])
print('ZIP members',len(z.namelist()) if False else 'CRC passed')
