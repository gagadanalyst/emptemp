# Part 22 Step 7 — payload boundary and external helper identification

## Scope
Static-only inspection of the package-verified `TBP1CN2629AR` LBI, its reconstructed FHX payload, the preserved 16 MiB raw `dump.bin`, and retained `.srtext` / `.romfs_objs` sections. No printer access, network operations, debug activation, firmware write or device-state change.

## Firmware and image inventory
- `tassel_LBI_verified.bin`: 15,369,810 bytes; SHA-256 `2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e`. Its metadata contains `TBP1CN2629AR` and `Fri Jul 17, 2026`.
- Reconstructed FHX payload: 12,888,320 bytes; SHA-256 `aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858`. Its directory begins at offset `0xBD8` and contains 125 descriptors through `.endram`.
- `dump.bin`: 16,777,216 bytes; SHA-256 `b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496`. It contains `TJP1FN1702CR` and `Sat Jan 14, 2017 03:32:35PM`, so it is a distinct older artifact, not a matching current-version runtime image.

## `.reset_hole` mapping
The first FHX descriptor is `.reset_hole`: VMA `0x38100040`, size `0x814`, end-exclusive `0x38100854`, flags word `0x00000001` (semantics not decoded). The two imported targets lie within this range:
- `0x38100424` = `.reset_hole + 0x3E4`
- `0x381005A0` = `.reset_hole + 0x560`

Adjacent descriptors: `.nosi_text` begins at `0x38100854` with size zero; `.nosi_rodata` begins at `0x38100858` with size `0x280`. The FHX file-backed primary regions include `.srtext` at `0xE0246070`, the `.text` candidate at `0x801A86B8`, and `.cromsrtext` at `0xE1A76480`; none overlaps the `0x381...` reset-hole address range. The meaning of the name `reset_hole` and its flags is not assumed.

## S-record payload coverage
The LBI update's S-record prefix contains 7 SA27 lines, one S0, 4,098 S3 records and one S7 terminator. All S3 count fields and checksums passed. The records are not globally address-sorted in the file; sorting by address yields four disjoint, non-overlapping segments documented in `S3_SEGMENTS.csv`. The 81,922 S3 data bytes reconstruct into those segments. No S3 record overlaps `.reset_hole`, and no S3 byte is supplied at either external target. The missing target bodies are therefore not delivered by this LBI's S-record payload.

## External target ABI identification
The two `.srtext` import veneers are:
- `0xE02795D8` loads the external target word at `0xE02795DC` = `0x38100424`.
- `0xE02795E0` loads the external target word at `0xE02795E4` = `0x381005A0`.

Call-site register setup strongly identifies their roles:
- `0x38100424`: three calls; `r0` is a destination, `r1=0`, and `r2` is a byte length (`0xDC0` in the alert-provider constructor; `0x10` in two temporary-buffer clears). This matches a zero-fill / `memset`-style ABI.
- `0x381005A0`: twelve calls; representative call sites pass destination in `r0`, source in `r1`, and `0x4144` bytes in `r2`, matching a byte-copy / `memcpy`-style ABI. The helper body and exported symbol name are not present, so this is ABI-based identification, not symbol recovery.

These are generic memory helpers used by the alert-provider implementation, not the missing framework dispatcher. The target addresses resolve into the `.reset_hole` address window, but the helper bodies themselves are absent from the package payload examined here.

## Other image checks and caution
The older `dump.bin` is not a trustworthy source for these current firmware targets. Its candidate `.text` projection is based on a provisional flash-base mapping; it is not established as decoded executable code for the current target. The separate `.cromsrtext` region is a 5,414,400-byte region at `0xE1A76480` and previously was shown to contain branch-skipped inline data. It cannot be treated as one flat Thumb instruction stream. A single raw ROMFS occurrence of `0x38100424` is inside a text-heavy block with `%02x`, `%02X` and `os.h` strings; it is not evidence of a callable vtable or binding.

## Step 7 conclusion
The two unexplained addresses from Step 6 are now identified as `memset`-like and `memcpy`-like external helper interfaces by their call-site ABI. They live within the FHX `.reset_hole` range, for which the current LBI S-record payload supplies no bytes. This closes the external-veneer question but **does not** recover the framework caller that passes selector `0x0061862B` or the concrete alert-list provider stored at `0xC136E704`. No connection to RTP block/unblock or the PE blocked-state writer has been proven.

## Proposed next bounded step
Inspect the separate `.cromsrtext` image in a branch-aware, bounded way around the three `sirius` references and known component/service descriptor strings, looking for the dispatcher that calls the secondary-vtable binding method. Preserve inline-data boundaries and do not infer a full function map from linear decoding.
