# Part 22 Step 7 evidence package

This archive contains the bounded, reproducible evidence for the payload inventory, `.reset_hole` address mapping, S-record coverage audit and call-site ABI classification of the external helper veneers. All analysis is offline/static.

## Contents
- `STEP7_FINDINGS.md` — summary, conclusions and limitations.
- `FHX_RELEVANT_DESCRIPTORS.txt`, `FHX_DIRECTORY_125.csv` — reconstructed FHX directory evidence.
- `S3_RECORD_AUDIT.txt`, `S3_SEGMENTS.csv`, `../rebuilt_srecords/*.bin` — verified S-record ranges and rebuilt segments.
- `EXTERNAL_VENEERS.txt`, `EXTERNAL_CALL_SITE_CONTEXTS.txt` — external branch veneers and call-site register setup.
- `ROMFS_RAW_WORD_CONTEXT.txt` — context for one raw pointer-value occurrence in ROMFS.
- `OLDER_DUMP_INVENTORY.txt`, `CROM_SECTION_INVENTORY.txt` — other payload inventory and boundaries.
- `SOURCE_INPUTS.txt` — source sizes and SHA-256 checks.
- `verify_part22_step7.py`, `verification_output.txt` — independent reproducibility checks.
- `DOCX_QA.txt` — findings document QA summary.
- `SHA256SUMS.txt` — archive member SHA-256 manifest.

## Source requirements
The verifier expects the seven source artifacts listed in `SOURCE_INPUTS.txt` to exist at their recorded paths under `/mnt/data/hp_fw_inputs/`. It does not need the physical printer or network access.

## Interpretation limits
`memset`-like and `memcpy`-like are ABI-based identifications from the register arguments and call-site behavior. The symbol names and implementation bytes are not available. The `.reset_hole` flags and its actual persistence/boot-ROM semantics are not decoded.
