from pathlib import Path
import hashlib,re,struct,sys

BASE=Path('/mnt/data/hp_fw_inputs')
LBI=BASE/'tassel_LBI_verified.bin'
FHX=BASE/'extracted/part1_rtp_provider_trace/fhx_secure_payload_rebuilt.bin'
DUMP=BASE/'dump.bin'
DIS=BASE/'srtext_disasm_all.txt'
ROM=BASE/'extracted/inputs/romfs_objs_rebuilt.bin'

def check(label,cond):
    if not cond: raise AssertionError(label)
    print('PASS',label)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def u32(data,off): return struct.unpack_from('<I',data,off)[0]

lbi=LBI.read_bytes(); fhx=FHX.read_bytes(); dump=DUMP.read_bytes(); dis=DIS.read_text(errors='replace').splitlines(); rom=ROM.read_bytes()
check('verified LBI hash',sha(LBI)=='2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e')
check('reconstructed FHX hash',sha(FHX)=='aaeb7197100755740b0bbf759526b851b5b26708ba2328bdf9db2710aea80858')
check('older dump hash',sha(DUMP)=='b791436cf9152785fb5d3f6954aa5949d4ae7c7458af0e2031b9a41f5534c496')
check('full srtext disassembly hash',sha(DIS)=='f900a16029dd0a8d9a1a87cb74c41ce616ebd556ae503c0591212ef241400377')
check('ROMFS source hash',sha(ROM)=='227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3')
check('LBI contains current firmware marker',b'TBP1CN2629AR' in lbi)
check('FHX magic prefix',fhx[:4]==bytes.fromhex('bad2bfed'))

# Directory: 125 entries, name + aligned 6-word descriptor.
pos=0xBD8; ents=[]
for i in range(200):
    z=fhx.find(b'\0',pos)
    if z<0 or z-pos>48: break
    name=fhx[pos:z].decode('ascii','replace')
    if not name.startswith('.'): break
    fo=(z+1+3)&~3
    vals=struct.unpack_from('<6I',fhx,fo)
    ents.append((name,vals,pos,fo)); pos=fo+24
    if name=='.endram': break
check('125 FHX section descriptors',len(ents)==125)
d={x[0]:x for x in ents}
check('.reset_hole VMA',d['.reset_hole'][1][2]==0x38100040)
check('.reset_hole size',d['.reset_hole'][1][3]==0x814)
check('.reset_hole flags retained',d['.reset_hole'][1][4]==1)
check('.nosi_text immediately follows reset hole',d['.nosi_text'][1][2]==0x38100854 and d['.nosi_text'][1][3]==0)
check('.nosi_rodata follows with expected range',d['.nosi_rodata'][1][2]==0x38100858 and d['.nosi_rodata'][1][3]==0x280)
check('.srtext section descriptor',d['.srtext'][1][2]==0xE0246070 and d['.srtext'][1][3]==0x743634)
check('.text candidate descriptor',d['.text'][1][2]==0x801A86B8 and d['.text'][1][3]==0x7E7940)
check('.cromsrtext descriptor',d['.cromsrtext'][1][2]==0xE1A76480 and d['.cromsrtext'][1][3]==0x529E00)

# S-record parser and address coverage.
m=re.search(rb'S7[0-9A-Fa-f]+\r?\n',lbi); check('S7 terminator present',m is not None)
lines=lbi[:m.end()].decode('ascii').splitlines()
records=[]
for n,line in enumerate(lines,1):
    if line.startswith('S3'):
        raw=bytes.fromhex(line[2:]); check(f'S3 count/checksum line {n}',raw[0]==len(raw)-1 and (sum(raw)&0xff)==0xff)
        records.append((int.from_bytes(raw[1:5],'big'),raw[5:-1]))
check('4098 S3 records',len(records)==4098)
check('81922 total S3 bytes',sum(len(x[1]) for x in records)==81922)
segments=[]
for a,b in sorted(records, key=lambda x: x[0]):
    if segments and a<segments[-1][1]: raise AssertionError('S3 address overlap/order')
    if segments and a==segments[-1][1]: segments[-1]=(segments[-1][0],a+len(b))
    else: segments.append((a,a+len(b)))
check('four disjoint contiguous S3 segments after address sort',len(segments)==4)
rs=d['.reset_hole'][1][2]; re_=rs+d['.reset_hole'][1][3]
check('no S3 overlap with .reset_hole',all(not (a<re_ and b>rs) for a,b in segments))
check('0x38100424 is inside .reset_hole',rs<=0x38100424<re_)
check('0x381005A0 is inside .reset_hole',rs<=0x381005A0<re_)
check('no S3 byte supplied at 0x38100424',not any(a<=0x38100424<b for a,b in segments))
check('no S3 byte supplied at 0x381005A0',not any(a<=0x381005A0<b for a,b in segments))

# Veneer loads and call-site counts.
line_map={}
for line in dis:
    mm=re.match(r'^([0-9a-fA-F]{8}):',line)
    if mm: line_map[int(mm.group(1),16)]=line.lower()
check('zero-fill veneer is indirect PC load', 'ldr.w\tpc' in line_map[0xE02795D8])
check('zero-fill target literal', '0x38100424' in line_map[0xE02795DC] or '0x38100424' in line_map.get(0xE02795DA,'') or u32((BASE/'extracted/inputs/srtext_rebuilt.bin').read_bytes(),0xE02795DC-0xE0246070)==0x38100424)
check('copy veneer is indirect PC load','ldr.w\tpc' in line_map[0xE02795E0])
sr=(BASE/'extracted/inputs/srtext_rebuilt.bin').read_bytes()
check('copy target literal',u32(sr,0xE02795E4-0xE0246070)==0x381005A0)
call1=[a for a,l in line_map.items() if 'bl\t0xe02795d8' in l]
call2=[a for a,l in line_map.items() if 'bl\t0xe02795e0' in l]
check('three calls use zero-fill veneer',len(call1)==3)
check('twelve calls use byte-copy veneer',len(call2)==12)

# Specific call setup proves ABI signatures.
def idxof(addr):
    for i,line in enumerate(dis):
        m=re.match(r'^([0-9a-fA-F]{8}):',line)
        if m and int(m.group(1),16)==addr: return i
    raise KeyError(hex(addr))
def context(addr,n=6):
    i=idxof(addr); return '\n'.join(dis[max(0,i-n):i+1]).lower()
c=context(0xE0276A96,6)
check('constructor zero-fill passes destination/value/size',all(x in c for x in ['add.w\tr0, r4, #0x14','mov.w\tr2, #0xdc0','mov\tr1, r5']))
check('zero-fill value is initialized zero', 'movs\tr5, #0x0' in context(0xE0276A96,60))
c=context(0xE0277646,6)
check('copy call sets 0x4144 byte length', 'movw\tr2, #0x4144' in c)
check('copy call computes destination and source', 'ldr.w\tr1, [r3, r4, lsl #2]' in c and 'mla\tr0, r4, r2, r0' in c)

# Old artifact not the current target.
check('old dump has TJP1FN1702CR marker',b'TJP1FN1702CR' in dump)
check('old dump has 2017 timestamp',b'Sat Jan 14, 2017 03:32:35PM' in dump)

# ROMFS raw occurrence is contextual data, not interpreted as runtime binding.
occ=[]; p=0; pat=struct.pack('<I',0x38100424)
while True:
    i=rom.find(pat,p)
    if i<0: break
    occ.append(i); p=i+1
check('single raw ROMFS 0x38100424 occurrence',len(occ)==1)
check('no raw ROMFS 0x381005A0 occurrence',rom.find(struct.pack('<I',0x381005A0))<0)
print('SUMMARY: all Step 7 checks passed')
