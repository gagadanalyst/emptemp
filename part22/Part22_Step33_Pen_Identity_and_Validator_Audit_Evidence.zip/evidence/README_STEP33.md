# Part 22, Step 33 - evidence index

This package traces the Pen identity snapshots and classifier inputs used by the conditional TooEarly mask reconciliation.

## Contents
- `STEP33_FINDINGS.txt`: complete findings and qualifications.
- `disassembly/`: focused Thumb disassembly for identity DSID access, Pen Type normalization, validator, classifier, comparator, parent lifecycle and the Step 31 mask/reconciliation baseline.
- `crosswalks/pen_identity_dsid_crosswalk.csv`: all 36 left/right DSID mappings for Pen Type, Pen ID Version and ID Bits 0-15.
- `crosswalks/pen_identity_classifier_table.csv`: all 45 decoded classifier rows.
- `crosswalks/pen_type_normalization.csv`: executable raw-to-normalized Pen Type mapping.
- `crosswalks/crosswalk_summary.json`: row counts, groups and ROMFS provenance hash.
- `source/`: Step 31 report and Part 1 source/evidence bundle retained to preserve lineage.
- `SOURCE_INPUTS.txt`: source hashes and extraction notes.
- `SHA256SUMS.txt`: per-file checksums for this package.
- `verification_output.txt`: reproducible focused checks.

## Source / address basis
- `.srtext` virtual base: `0xE0246070`.
- ROMFS virtual base: `0xE09919C0`.
- Identity DSID pointer table: `0xE0B3EC40`.
- Identity classifier table: `0xE0B3E244`.
- Original Part 1 firmware evidence archive is retained under `source/Part1_RTP_Provider_Trace_Evidence_Package.zip`.

All conclusions are static-analysis conclusions. The package contains no device-side instructions and no state-changing scripts.
