# Part 22 Step 6 evidence package

This archive supports Revision 93, Part 22 Step 6. It is a reproducibility bundle of selected static-analysis evidence, not a firmware patch and not a runtime test.

## Contents
- `STEP6_FINDINGS.md` — concise conclusions and limits.
- `SOURCE_INPUTS.txt` — byte lengths and SHA-256 of source inputs.
- `01`–`08` — retained disassembly excerpts for the field lifecycle, setter, consumer, startup wrapper and out-of-section veneers.
- `09_secondary_vtable_romfs.txt` — ROMFS secondary-vtable-like block with decoded words.
- `10_sirius_instance_descriptor_romfs.txt` — ROMFS descriptor-like block bytes and strings.
- `11_corrected_selector_crosswalk_matches.csv` — Part 7/8 A/B rows matching the four corrected smaller selectors.
- `verify_part22_step6.py` and `verification_output.txt` — deterministic offline verifier and its result.
- `DOCX_QA.txt` — document page-count and visual regression checks.
- `SHA256SUMS.txt` — checksums for every evidence member except the checksum manifest itself.

## Main result
The selector-controlled setter at `0xE0277130` writes `r3` to the singleton's `+0x10` field when the incoming selector is `0x0061862B`; this is exactly `0xC136E704`, which the alert-list consumer later dereferences. The framework caller and actual runtime provider pointer are not recovered.

## Important correction
Revision 92 / Step 5's selector arithmetic was wrong for all but the exact base branch because the code modifies `r1` between comparisons. Revision 93 and this package carry the corrected cumulative map. The obsolete values must not be reused.

## Reproduction
Run:
```bash
python3 verify_part22_step6.py
```
The script checks the source hashes, key disassembly instructions, ROMFS vtable pointer and descriptor strings, selector arithmetic, crosswalk matches and direct reference counts. It expects the preserved source inputs at `/mnt/data/hp_fw_inputs` (the original analysis workspace) or those paths must be updated in the script. The full 107 MB disassembly is not duplicated in this compact evidence ZIP. It does not resolve runtime-indirect callbacks.
