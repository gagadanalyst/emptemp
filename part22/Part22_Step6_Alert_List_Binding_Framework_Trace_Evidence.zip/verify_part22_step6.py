#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, re, struct, sys

BASE = Path(__file__).resolve().parent
SRC = Path('/mnt/data/hp_fw_inputs')
EXPECT = {
 'tassel_LBI_verified.bin':'2ae39ef1771c5f9a23c1bf0d6bd606d360fbe76fbbb8210226cfb42df6d4925e',
 'extracted/inputs/srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
 'extracted/inputs/romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
 'srtext_disasm_all.txt':'f900a16029dd0a8d9a1a87cb74c41ce616ebd556ae503c0591212ef241400377',
 'extracted/part8_service_descriptor_crosswalk_A_B.csv':'90c0f8ce15dd7287db01a849c0ebf932ee1b3ff6815a214d98953732c51bad34',
}
checks=[]
def check(name, ok, detail=''):
 checks.append((name, bool(ok), detail))
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
for rel,expected in EXPECT.items():
 p=SRC/rel; actual=digest(p)
 check('SHA256 '+rel, actual==expected, actual)

dis=(SRC/'srtext_disasm_all.txt').read_text(errors='replace')
rom=(SRC/'extracted/inputs/romfs_objs_rebuilt.bin').read_bytes()
sr=(SRC/'extracted/inputs/srtext_rebuilt.bin').read_bytes()

def has(s): return s in dis
# Exact code-path evidence.
for s in [
 'e0277040:      \tsub.w\tr0, r0, #0x4',
 'e0277044:      \tb.w\t0xe0277130',
 'e0277130:      \tstr\tr8, [sp, #-4]!',
 'e027719a:      \tstr\tr3, [r0, #0x10]',
 'e02769e4:      \tstm.w\tr4, {r0, r2, r3, r5, r12}',
 'e0276a86:      \tstr\tr4, [r6]',
 'e0277566:      \tldr\tr0, [r0, #0x10]',
 'e027756e:      \tldr\tr3, [r2, #0x14]',
 'e0277574:      \tblx\tr3',
 'e027690e:      \tstr\tr0, [r4, #0x10]',
 'e02795d8:      \tldr.w\tpc, [pc, #0x0]',
 'e02795e0:      \tldr.w\tpc, [pc, #0x0]',
]:
 check('DISASM '+s.split(':')[0], has(s), s)

# Exact references: single direct branch/call occurrence and no additional direct source.
refs=[ln for ln in dis.splitlines() if '0xe0277130' in ln]
check('single direct branch/call target reference to 0xE0277130', len(refs)==1 and refs[0].startswith('e0277044:'), f'count={len(refs)}; {refs[:3]}')

# ROMFS vtable pointer.
rom_base=0xE09919C0; vtable=0xE0998A4C
blob=rom[vtable-rom_base:vtable-rom_base+0x24]
words=struct.unpack('<7I',blob[8:8+28])
check('secondary-vtable word[3] at 0xE0998A60 is Thumb 0xE0277041', words[3]==0xE0277041, f'words={[hex(w) for w in words]}')
ptr=struct.pack('<I',0xE0277041)
positions=[]; at=0
while True:
 i=rom.find(ptr,at)
 if i<0: break
 positions.append(i); at=i+1
check('single ROMFS instance of exact Thumb method pointer', len(positions)==1 and positions[0]==0xE0998A60-rom_base, f'offsets={[hex(x) for x in positions]}')

# Descriptor bytes.
desc=rom[0xE09986CC-rom_base:0xE09987A0-rom_base]
check('descriptor-like block begins with siriusInstance', desc.startswith(b'siriusInstance'))
check('alert service name at 0xE0998704', b'com.hp.cdm.service.alert.version.1.resource.alert' in desc)

# Out-of-section veneers.
check('veneer 0xE02795D8 literal = 0x38100424', struct.unpack_from('<I',sr,0xE02795DC-0xE0246070)[0]==0x38100424)
check('veneer 0xE02795E0 literal = 0x381005A0', struct.unpack_from('<I',sr,0xE02795E4-0xE0246070)[0]==0x381005A0)

# Compute cumulative selector values as the exact sequential arithmetic in the method.
base=0x12D5D
sel_slot3=base
sel_slot1=base-0xA11
sel_slot0=base-0xA11-0x2DD
sel_slot2=base-0xA11-0x2DD-0xB25
sel_alert=base+0x6058CE
sel_objc=base+0x6058CE+0x3ABDA4
sel_obje=base+0x6058CE+0x3ABDA4+0xF0F5
actual={sel_slot0:0xC136E4A4,sel_slot1:0xC136E4A8,sel_slot2:0xC136E4AC,sel_slot3:0xC136E4B0,sel_alert:0xC136E704,sel_objc:0xC136E700,sel_obje:0xC136E6FC}
expected={0x1206F:0xC136E4A4,0x1234C:0xC136E4A8,0x1154A:0xC136E4AC,0x12D5D:0xC136E4B0,0x61862B:0xC136E704,0x9C43CF:0xC136E700,0x9D34C4:0xC136E6FC}
check('cumulative seven-selector map',actual==expected,repr({hex(k):hex(v) for k,v in actual.items()}))
check('obsolete Step 5 selector values excluded', not ({0x12A80,0x12238,0x3BEB01,0x21E52}&set(actual)), 'old erroneous values not in corrected map')

# Crosswalk rows contain the four small selectors, and not the three large interface selectors.
with (SRC/'extracted/part8_service_descriptor_crosswalk_A_B.csv').open(newline='') as f: rows=list(csv.DictReader(f))
found={}
for selector in actual:
 hits=[]
 for row in rows:
  if any(v.lower()==f'0x{selector:08x}' for v in row.values() if isinstance(v,str)):
   hits.append(row)
 found[selector]=hits
check('four smaller selectors present in A/B crosswalk', all(found[x] for x in (0x1206F,0x1234C,0x1154A,0x12D5D)), {hex(k):len(v) for k,v in found.items()})
check('three larger selectors absent from A/B crosswalk', all(not found[x] for x in (0x61862B,0x9C43CF,0x9D34C4)), {hex(k):len(v) for k,v in found.items()})

# Confirm exact expected selected crosswalk identities.
expected_components={
 0x1206F:{'rest_fw_update','rest_helper','ews_ctrl'},
 0x1234C:{'jm_reports','job_tracker','ews_ctrl'},
 0x1154A:{'job_tracker','pe'},
 0x12D5D:{'pen','persona_manager','rtp_manager','udn'},
}
for selector,names in expected_components.items():
 observed={r['component'] for r in found[selector]}
 check(f'crosswalk component identities for 0x{selector:08X}', observed==names, repr(sorted(observed)))

# Check global addresses and field arithmetic.
check('singleton field arithmetic C136E6F4 + 0x10 = C136E704',0xC136E6F4+0x10==0xC136E704)
check('registry slot range spans 4 x 4 bytes',0xC136E4B0-0xC136E4A4==12)

for name,ok,detail in checks:
 print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+str(detail)) if detail else ''))
print(f'\nRESULT: {sum(ok for _,ok,_ in checks)}/{len(checks)} PASS')
if not all(ok for _,ok,_ in checks): sys.exit(1)
