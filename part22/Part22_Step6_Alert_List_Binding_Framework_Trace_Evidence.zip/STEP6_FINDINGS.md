# Part 22 Step 6 — alert-list binding and framework trace

## Scope
Static analysis of the verified DeskJet 2800e/2855e-family LBI reconstruction and retained `.srtext` disassembly / `.romfs_objs` data. No printer interaction, network access, firmware write, or device-state change was performed.

## Confirmed local binding mechanism
- `siriusInstance` complete object base: `0xC136E6F4`.
- Global singleton pointer: `0xC136E6F0`.
- Secondary vtable-like block: `0xE0998A4C`.
- Registration pointer: ROMFS word at `0xE0998A60` = Thumb `0xE0277041`.
- Adjustor thunk: `0xE0277040` subtracts 4 from `r0` and branches to `0xE0277130`, restoring the complete object pointer before the method body.
- Registration method: `0xE0277130`, selector in `r1`, dependency pointer in `r3`.
- Incoming selector `0x0061862B` reaches `0xE027719A`, which executes `str r3,[r0,#0x10]`.
- `0xC136E6F4 + 0x10 = 0xC136E704`, exactly the nested field loaded by alert consumer `0xE0277500`.
- Consumer reads the pointer and invokes virtual slot `+0x14`, passing list-range and capacity output storage.
- Constructor `0xE02769C8` zero-initializes `this+0x10` and publishes `this` at global `0xC136E6F0`.
- Clear/release method `0xE02768F8` releases and clears `this+0x10` if non-null.

## Corrected selector arithmetic — supersedes Revision 92 / Step 5 Section 92.5
The method subtracts `0x12D5D` from `r1`, then subsequent `SUBS` operate on the already-modified register. Correct selector-to-store map:

| Incoming selector | Destination | Explanation |
|---|---|---|
| `0x0001206F` | `0xC136E4A4` | `0x12D5D - 0xA11 - 0x2DD`; store `[r2]` |
| `0x0001234C` | `0xC136E4A8` | `0x12D5D - 0xA11`; store `[r2,#4]` |
| `0x0001154A` | `0xC136E4AC` | `0x12D5D - 0xA11 - 0x2DD - 0xB25`; store `[r2,#8]` |
| `0x00012D5D` | `0xC136E4B0` | exact base selector; store `[r2,#0xC]` |
| `0x0061862B` | `0xC136E704` | `0x12D5D + 0x6058CE`; store `[r0,#0x10]` |
| `0x009C43CF` | `0xC136E700` | `0x12D5D + 0x6058CE + 0x3ABDA4`; store `[r0,#0xC]` |
| `0x009D34C4` | `0xC136E6FC` | previous cumulative sum + `0xF0F5`; store `[r0,#8]` |

The earlier Step 5 values `0x12A80`, `0x12238`, `0x003BEB01`, and `0x00021E52` were wrong because they treated sequential comparisons as independent offsets. Do not use those earlier values.

The four smaller selectors are present in the preserved Part 7/8 A/B descriptor crosswalk. The three larger selectors are absent from that crosswalk. This establishes only that the small identifiers also occur in that metadata inventory; it does not identify the provider object passed in `r3` for this singleton.

## Upstream framework audit and limitations
- Full retained `.srtext` disassembly contains one direct branch/call target reference to `0xE0277130`: the adjustor thunk at `0xE0277044`.
- ROMFS contains one instance of the exact Thumb pointer `0xE0277041` at `0xE0998A60` in the secondary-vtable-like block.
- No direct invocation site of the thunk/method was recovered in the available `.srtext` disassembly.
- Initializer wrapper `0xE0277070` constructs the singleton and registers a different node pointer `0xC01DD864` through `0xE0981216`; that helper inserts into list globals `0xC1D63BD4`/`0xC1D63BD8`. No available evidence proves this list is the dependency resolver or that it invokes the secondary-vtable method.
- The `siriusInstance` descriptor-like ROMFS block at `0xE09986CC` contains service name `com.hp.cdm.service.alert.version.1.resource.alert`. It is not one of the 59 standard A/B headers inventoried in Part 7.
- Two nearby veneers at `0xE02795D8` and `0xE02795E0` load out-of-section targets `0x38100424` and `0x381005A0`. These targets are not present in the examined LBI sections; they may be useful leads only if additional executable payloads are available.

## Current stopping point
The local binding contract is established: `siriusInstance` accepts a dependency pointer via selector `0x0061862B`, stores it at `0xC136E704`, and later invokes its virtual method at `+0x14`. The framework call site, runtime pointer value in `r3`, and concrete provider vtable are unresolved. No path from this provider to RTP block/unblock or the PE blocked-state writer has been demonstrated.

## Suggested next bounded step
Inspect other firmware payloads / runtime images or a trace source that could contain the external dispatcher and the out-of-section veneer targets. Re-scanning the same `.srtext` / `.romfs_objs` inputs is unlikely to recover the absent caller.
