#!/usr/bin/env python3
"""Reproduce Part 22 Step 12 static checks against the preserved LBI ELF/ROMFS."""
from pathlib import Path
import argparse, hashlib, re, struct, subprocess, sys

ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--source-dir', type=Path, default=Path('/mnt/data/hp_step11_work/base/part1_rtp_provider_trace'))
p.add_argument('--disasm', type=Path, default=Path('/mnt/data/hp_step11_work/srtext_full.dis'))
args = p.parse_args()
SRC=args.source_dir
ELF=SRC/'hp_lbi_sections.elf'
SRTEXT=SRC/'srtext_rebuilt.bin'
ROMFS=SRC/'romfs_objs_rebuilt.bin'
checks=[]
def check(label, ok):
    checks.append((label,bool(ok)))
    print(('PASS' if ok else 'FAIL')+'  '+label)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

expected={
 'hp_lbi_sections.elf':'25f96849938f55976e7f63cd9950d27c6d2a20cc3b9938fdaf9c6ac286f5a8f7',
 'srtext_rebuilt.bin':'10f63166b5d7940c43a271214f5296c6714479f514d90cd31a270f1feb5306e7',
 'romfs_objs_rebuilt.bin':'227cf6f8a8e7551dbd5dce710eef7e0866fb3212db8e717f334125619ae90fd3',
}
for nm,h in expected.items():
    q=SRC/nm
    check(f'{nm} exists and SHA-256 matches preserved source',q.exists() and sha(q)==h)
if not all((SRC/n).exists() for n in expected):
    print('ERROR: source files missing'); sys.exit(2)
elf=ELF.read_bytes(); sr=SRTEXT.read_bytes(); rom=ROMFS.read_bytes()
check('.srtext rebuilt size is 0x743634',len(sr)==0x743634)
check('.romfs_objs rebuilt size is 0x440D0C',len(rom)==0x440D0C)
check('ELF embeds exact .srtext bytes at file offset 0x54',elf[0x54:0x54+len(sr)]==sr)
check('ELF embeds exact .romfs_objs bytes at file offset 0x743688',elf[0x743688:0x743688+len(rom)]==rom)
ROM_BASE=0xE09919C0

def rom_bytes(vma,n):
    off=vma-ROM_BASE
    return rom[off:off+n]
def word(vma):
    b=rom_bytes(vma,4)
    return struct.unpack('<I',b)[0] if len(b)==4 else None
def cstr(vma):
    off=vma-ROM_BASE
    if off<0 or off>=len(rom): return ''
    e=rom.find(b'\0',off)
    if e<0:return ''
    return rom[off:e].decode('ascii','replace')
def raw_count(val):
    pat=struct.pack('<I',val); return len(re.findall(re.escape(pat),rom))

# Complete adapter record and critical names.
obj_vma=0xE0BC0084; obj_len=0xDC8
obj=rom_bytes(obj_vma,obj_len)
check('rtpadapter record is exactly 0xDC8 bytes and in ROMFS bounds',len(obj)==obj_len)
check('rtpadapter first word declares 0xDC8 bytes',word(obj_vma)==obj_len)
check('rtpadapter root label at 0xE0BC0100',cstr(0xE0BC0100)=='rtpadapter')
check('provider-side key at 0xE0BC010C is siriusInstance',cstr(0xE0BC010C)=='siriusInstance')
check('lib_power interface label at 0xE0BC05E0',cstr(0xE0BC05E0)=='lib_power')
check('descriptor-side key at 0xE0BC0654 is siriusInstance',cstr(0xE0BC0654)=='siriusInstance')
check('provider and descriptor key strings are byte-identical',rom_bytes(0xE0BC010C,14)==rom_bytes(0xE0BC0654,14))

# Provider-side named registry entry.
check('provider accessor pointer at 0xE0BC00CC is E093C521',word(0xE0BC00CC)==0xE093C521)
check('provider accessor pointer occurs exactly once in ROMFS',raw_count(0xE093C521)==1)
check('first initializer pointer at 0xE0DD26AC is E093C781',word(0xE0DD26AC)==0xE093C781)
check('E093C781 initializer pointer occurs exactly once in ROMFS',raw_count(0xE093C781)==1)

# Descriptor-side dependency output accessor and descriptor contents.
check('descriptor output accessor pointer at 0xE0BC0534 is E093E291',word(0xE0BC0534)==0xE093E291)
check('descriptor output accessor pointer occurs exactly once in ROMFS',raw_count(0xE093E291)==1)
check('second adjacent initializer pointer at 0xE0DD26B0 is E093E311',word(0xE0DD26B0)==0xE093E311)
check('E093E311 initializer pointer occurs exactly once in ROMFS',raw_count(0xE093E311)==1)
check('two sirius initializers are adjacent 32-bit entries in ROMFS init table',word(0xE0DD26AC+4)==0xE093E311)

# lib_power API method table.
check('lib_power acquire method pointer at 0xE0BC05F4 is E093E2A1',word(0xE0BC05F4)==0xE093E2A1)
check('lib_power release method pointer at 0xE0BC05F8 is E093E2A9',word(0xE0BC05F8)==0xE093E2A9)
check('acquire method pointer occurs exactly once in ROMFS',raw_count(0xE093E2A1)==1)
check('release method pointer occurs exactly once in ROMFS',raw_count(0xE093E2A9)==1)

# Correct power-client mapping retained from Step 11.
name_base=0xE0BC098C; stride=0x1E
expected_names=['POWER_CLIENT_NONE','POWER_CLIENT_MECH','POWER_CLIENT_AASIC1','POWER_CLIENT_AASIC2','POWER_CLIENT_PEN','POWER_CLIENT_UDW','POWER_CLIENT_REPORTS','POWER_CLIENT_UIAUX_SVC','POWER_CLIENT_PHOTO','POWER_CLIENT_OPT_SENSOR','POWER_CLIENT_SCAN','POWER_CLIENT_SYS','POWER_CLIENT_BOARD','POWER_CLIENT_ISC','POWER_CLIENT_USBHC','POWER_CLIENT_SERVO','POWER_CLIENT_SHAID','POWER_CLIENT_IMAGE_MGR','POWER_CLIENT_FP','POWER_CLIENT_EC','POWER_CLIENT_U232','POWER_CLIENT_WID_SENSOR','POWER_CLIENT_RDD','POWER_CLIENT_PE_POLICY']
parsed=[]
for i in range(24):
    o=name_base-ROM_BASE+i*stride
    parsed.append(rom[o:o+stride].split(b'\0',1)[0].decode('ascii','replace'))
check('all 24 power-client names decode in the expected order',parsed==expected_names)
check('POWER_CLIENT_NONE is a sentinel at slot 0',parsed[0]=='POWER_CLIENT_NONE')
check('POWER_CLIENT_PEN at slot 4 maps to 0x00000008',parsed[4]=='POWER_CLIENT_PEN' and 1<<(4-1)==0x8)
check('POWER_CLIENT_SCAN at slot 10 maps to 0x00000200',parsed[10]=='POWER_CLIENT_SCAN' and 1<<(10-1)==0x200)
check('POWER_CLIENT_PE_POLICY at slot 23 maps to 0x00400000',parsed[23]=='POWER_CLIENT_PE_POLICY' and 1<<(23-1)==0x400000)
check('0x00800000 is outside the 23-active-client mapping',1<<(23-1)!=0x800000)

# Use provided full .srtext disassembly, or regenerate it with LLVM if absent.
if args.disasm and args.disasm.exists():
    dis=args.disasm.read_text(errors='replace')
else:
    proc=subprocess.run(['llvm-objdump','-D','--triple=thumbv7em-none-eabi','--section=.srtext',str(ELF)],capture_output=True,text=True)
    if proc.returncode:
        print('ERROR: llvm-objdump failed; pass --disasm with a full .srtext disassembly'); sys.exit(2)
    dis=proc.stdout
lines=dis.splitlines()

def direct_refs(target):
    return [line for line in lines if re.search(r'\b(?:bl|b\.w)\s+0x'+target+r'\b',line,re.I)]

check('no direct BL/B.W caller targets provider accessor E093C520',len(direct_refs('e093c520'))==0)
check('no direct BL/B.W caller targets named registry initializer E093C780',len(direct_refs('e093c780'))==0)
check('no direct BL/B.W caller targets descriptor accessor E093E290',len(direct_refs('e093e290'))==0)
check('no direct BL/B.W caller targets lib_power acquire wrapper E093E2A0',len(direct_refs('e093e2a0'))==0)
check('no direct BL/B.W caller targets lib_power acquire entry E093E2A4',len(direct_refs('e093e2a4'))==0)

acq=[int(x,16) for x in re.findall(r'^([0-9a-f]+):.*\b(?:bl|b\.w)\s+0xe093dc50\b',dis,re.M|re.I)]
rel=[int(x,16) for x in re.findall(r'^([0-9a-f]+):.*\b(?:bl|b\.w)\s+0xe093dc68\b',dis,re.M|re.I)]
expected_acq=[0xE0561B64,0xE058C654,0xE058C6AA,0xE058C8BC,0xE058CB22,0xE0671B46,0xE071447C,0xE073C4D8,0xE0741712,0xE0928584,0xE093DF2E,0xE093E2A4,0xE093E354,0xE093E3F4]
expected_rel=[0xE0561B6C,0xE058C67C,0xE058C6D4,0xE0671B72,0xE071449C,0xE073C4F8,0xE074172E,0xE0928578,0xE093DF1E,0xE093E2AC,0xE093E402,0xE093E548]
check('14 direct BL/B.W acquire-helper xrefs match complete audit',sorted(acq)==sorted(expected_acq))
check('12 direct BL/B.W release-helper xrefs match complete audit',sorted(rel)==sorted(expected_rel))

# No fixed PE_POLICY immediate in direct helper caller windows.
call_windows=[]
for i,line in enumerate(lines):
    if re.search(r'\b(?:bl|b\.w)\s+0xe093dc50\b',line,re.I):
        call_windows.append('\n'.join(lines[max(0,i-8):i]))
fixed_pe=[]
for w in call_windows:
    if re.search(r'mov(?:s|\.w)?\s+r1,\s*#0x400000\b',w,re.I): fixed_pe.append(w)
check('no direct acquire-call window supplies fixed immediate 0x00400000',len(fixed_pe)==0)

# Exact instruction-pattern checks for the two registration initializers and wrapper.
check('named registry initializer E093C780 constructs global C1D5E880',re.search(r'e093c782:.*#0xe880',dis,re.I) is not None and re.search(r'e093c786:.*#0xc1d5',dis,re.I) is not None)
check('named registry initializer uses ROMFS key at E0BC010C',re.search(r'e093c79e:.*#0x10c',dis,re.I) is not None and re.search(r'e093c7a2:.*#0xe0bc',dis,re.I) is not None)
check('registry builder E093C4E0 loads vtable data at E0BC0410 and E0BC0480','e093c4e0:' in dis and '#0x410' in dis and '#0x480' in dis)
check('registry builder stores name pointer at object offset 0x44','e093c4f4:' in dis and 'str\tr1, [r0, #0x44]' in dis)
check('provider accessor E093C520 builds address C1D5E884','e093c520:' in dis and '#0xe880' in dis and '#0xc1d5' in dis and 'addne\tr0, r1, #0x4' in dis)
check('descriptor initializer E093E310 uses key pointer E0BC0654','e093e310:' in dis and '#0x654' in dis and '#0xe0bc' in dis)
check('descriptor initializer targets global C1D62B4C','e093e314:' in dis and '#0x2b4c' in dis and 'e093e31c:' in dis and '#0xc1d6' in dis)
check('descriptor builder E093E250 stores three fields in one operation','e093e262:' in dis and 'stm.w\tr0, {r2, r3, r12}' in dis)
check('descriptor accessor E093E290 returns address C1D62B50','e093e290:' in dis and '#0x2b4c' in dis and 'e093e29c:' in dis and 'addne\tr0, r1, #0x4' in dis)
check('lib_power acquire wrapper E093E2A0 forwards r1/r2 to shared helper','e093e2a0:' in dis and 'mov\tr0, r1' in dis and 'mov\tr1, r2' in dis and 'e093e2a4:' in dis)

# Source and report assets created in this evidence folder.
check('focused ROMFS object excerpt exists', (ROOT/'rtpadapter_romfs_block_0xDC8.bin').exists() and (ROOT/'rtpadapter_romfs_block_0xDC8.bin').stat().st_size==0xDC8)
check('ROMFS initializer pointer block excerpt exists',(ROOT/'romfs_initializer_pointer_block.bin').exists() and (ROOT/'romfs_initializer_pointer_block.bin').stat().st_size==0x3C)
check('focused registration/power disassembly excerpts exist',all((ROOT/(n+'.disasm.txt')).exists() for n in ['sirius_named_registry_initializer_and_accessors','sirius_descriptor_builder_accessor_initializer_and_power_api','power_acquire_release_core_and_dynamic_registry']))

passed=sum(x for _,x in checks); failed=len(checks)-passed
summary=f'RESULT: {passed}/{len(checks)} PASS; {failed} FAIL\n'
(ROOT/'verification_output.txt').write_text('\n'.join(('PASS' if ok else 'FAIL')+'  '+name for name,ok in checks)+'\n\n'+summary)
print('\n'+summary)
if failed: sys.exit(1)
