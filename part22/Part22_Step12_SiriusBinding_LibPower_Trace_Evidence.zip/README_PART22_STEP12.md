# HP DeskJet 2855e firmware investigation — Part 22, Step 12

## Result

Step 12 identifies a stronger, paired `siriusInstance` registration pattern in the verified LBI ROMFS object:

- The ROMFS initializer pointer block contains `0xE093C781` at `0xE0DD26AC` and `0xE093E311` at `0xE0DD26B0`.
- Initializer `0xE093C780` constructs a named registry object rooted at `0xC1D5E880`, using the key string at `0xE0BC010C` (`siriusInstance`). Its builder stores vtable pointers `0xE0BC0410` and `0xE0BC0480`, plus the key pointer at object offset `+0x44`. Accessor `0xE093C520` returns the address `0xC1D5E884`; its Thumb pointer `0xE093C521` is stored at `0xE0BC00CC`.
- Initializer `0xE093E310` builds a descriptor at `0xC1D62B4C` from three values: `0xE0BC05EC`, `0xE0BC0630`, and the key string at `0xE0BC0654` (also `siriusInstance`). Accessor `0xE093E290` returns the address `0xC1D62B50`; its Thumb pointer `0xE093E291` is stored at `0xE0BC0534`.

These are separate pointer slots associated with the same name and registered by adjacent initializer entries. This is strong static evidence of a provider/consumer or named-service binding pair. The generic runtime resolver and actual pointer transfer are not recovered, so the live binding is not claimed as proven.

## lib_power acquire path

- Interface label: `lib_power` at `0xE0BC05E0`.
- Acquire method pointer: `0xE0BC05F4` contains Thumb pointer `0xE093E2A1`.
- Method body `0xE093E2A0` forwards `r1` to `r0` and `r2` to `r1`, then branches to shared helper `0xE093DC50`.
- The helper has 14 direct BL/B.W references in `.srtext`; release helper `0xE093DC68` has 12.
- There is no direct BL/B.W reference to `0xE093E2A0` or `0xE093E290`; their pointers are data-driven ROMFS entries. No reviewed direct acquire call site loads fixed mask `0x00400000` (the corrected `POWER_CLIENT_PE_POLICY` mask) into `r1`.

This does not exclude an indirect caller passing a dynamic mask, a caller in another firmware image, or a runtime dependency resolver outside the analyzed `.srtext` call graph. PE_POLICY remains a real client identity (slot 23, bit 22, mask `0x00400000`), but its use by a concrete print-engine caller remains unproven.

## What was not done

No printer connection, network request, updater execution, firmware write, debug activation, physical print/scan action, or runtime-state change was performed. Analysis was static and used the preserved source ELF and rebuilt section binaries.

## Reproduction

Run:

```bash
python verify_part22_step12.py
```

The verifier reads the preserved Step 1 source evidence under `/mnt/data/hp_step11_work/base/part1_rtp_provider_trace` by default. Use `--source-dir` and `--disasm` to override those locations.
