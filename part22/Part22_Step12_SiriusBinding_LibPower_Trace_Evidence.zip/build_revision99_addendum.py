from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

BASE=Path('/mnt/data/hp_part22_step11/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision98_Part22_Step11_PowerClient_SiriusDescriptor_Addendum.docx')
OUT=Path('/mnt/data/hp_part22_step12/HP_DeskJet_2855e_Independent_Printing_Scanning_Investigation_Revision99_Part22_Steps11-12_SiriusBinding_LibPower_Trace_Addendum.docx')
doc=Document(BASE)

# Add a separate section so the six inherited Step 11 pages retain their original header/footer.
sec=doc.add_section(WD_SECTION.NEW_PAGE)
sec.top_margin=Inches(0.62); sec.bottom_margin=Inches(0.62)
sec.left_margin=Inches(0.68); sec.right_margin=Inches(0.68)
sec.header_distance=Inches(0.28); sec.footer_distance=Inches(0.28)
sec.header.is_linked_to_previous=False
sec.footer.is_linked_to_previous=False

NAVY='17365D'; BLUE='1F4E79'; CYAN='00A6C7'; LIGHT='D9EAF7'; PALE='EEF5FA'; GRAY='595959'; MID='7F8C8D'; WHITE='FFFFFF'; WARN='FFF2CC'; GREEN='E2F0D9'
header=sec.header.paragraphs[0]
header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
rr=header.add_run('HP DESKJET 2855e  |  INDEPENDENT PRINTING / SCANNING INVESTIGATION')
rr.font.name='Aptos'; rr.font.size=Pt(7); rr.font.bold=True; rr.font.color.rgb=RGBColor.from_string(MID)
footer=sec.footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
rr=footer.add_run('Revision 99 - Part 22, Steps 11-12 addendum  |  19 November 2026  |  Page ')
rr.font.name='Aptos'; rr.font.size=Pt(7); rr.font.color.rgb=RGBColor.from_string(MID)
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); footer._p.append(fld)

# Helpers
def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def celltxt(cell,text,bold=False,color=None,size=8.2):
    cell.text=''; p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0); p.paragraph_format.space_before=Pt(0); p.paragraph_format.line_spacing=1.0
    r=p.add_run(str(text)); r.font.name='Aptos'; r.font.size=Pt(size); r.bold=bold
    if color:r.font.color.rgb=RGBColor.from_string(color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers,rows,widths=None,font=8.0):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False; t.style='Table Grid'
    for i,h in enumerate(headers): celltxt(t.rows[0].cells[i],h,True,WHITE,font); shade(t.rows[0].cells[i],BLUE)
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            celltxt(cells[i],val,False,None,font)
            if ri%2: shade(cells[i],PALE)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t

def para(text='',style=None,boldlead=None,color=None,italic=False,size=None):
    p=doc.add_paragraph(style=style)
    if boldlead and text.startswith(boldlead):
        a=p.add_run(boldlead); a.bold=True; b=p.add_run(text[len(boldlead):]); runs=[a,b]
    else:runs=[p.add_run(text)]
    for r in runs:
        if color:r.font.color.rgb=RGBColor.from_string(color)
        if italic:r.italic=True
        if size:r.font.size=Pt(size)
    return p

def bullet(text):
    p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(text); return p

def callout(title,body,fill=LIGHT):
    t=doc.add_table(rows=1,cols=1); t.autofit=False; t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0); shade(c,fill); c.text=''
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(2)
    r=p.add_run(title); r.bold=True; r.font.name='Aptos'; r.font.size=Pt(10); r.font.color.rgb=RGBColor.from_string(NAVY)
    p2=c.add_paragraph(body); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.04
    for r in p2.runs:r.font.size=Pt(8.4)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

# PAGE 7
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(28); p.paragraph_format.space_after=Pt(6)
r=p.add_run('PART 22  /  STEP 12'); r.bold=True; r.font.size=Pt(11); r.font.color.rgb=RGBColor.from_string(CYAN)
p=doc.add_paragraph(style='Title'); p.add_run('Sirius named binding and\nlib_power caller trace')
p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(5); p.paragraph_format.space_after=Pt(14)
r=p.add_run('Revision 99 addendum extending Revision 98  |  Static firmware analysis  |  19 November 2026'); r.font.size=Pt(10); r.font.color.rgb=RGBColor.from_string(GRAY)
callout('Principal Step 12 finding',
        'Two adjacent ROMFS initializer entries construct separate structures carrying the exact same key, "siriusInstance". One exposes a provider-side pointer slot at 0xC1D5E884; the other exposes a descriptor-side output slot at 0xC1D62B50. This is strong evidence of a named provider/consumer binding pair, but the generic resolver and actual pointer transfer remain unresolved.',WARN)
para('The registration evidence is more useful than a string-only association: both initializers are present in the same ROMFS initializer pointer block, each builds an addressable structure, and each structure exposes a callback returning the address of a pointer slot. The two string keys match byte-for-byte.')
para('The parallel power-interface trace confirms that the same rtpadapter record exports a lib_power method table. Its acquire entry forwards a caller-provided client mask into the shared power engine. No resolved direct caller in the retained .srtext passes the corrected PE_POLICY mask 0x00400000.')
para('What is established',style='Heading 2')
bullet('Provider-side initializer: 0xE0DD26AC -> Thumb pointer 0xE093C781 -> initializer 0xE093C780; key string at 0xE0BC010C.')
bullet('Descriptor-side initializer: 0xE0DD26B0 -> Thumb pointer 0xE093E311 -> initializer 0xE093E310; key string at 0xE0BC0654.')
bullet('The acquire method is exported at 0xE0BC05F4 as Thumb pointer 0xE093E2A1; its wrapper forwards the mask argument into 0xE093DC50.')
callout('Boundary of the result',
        'The matching names and pointer-slot accessors strongly suggest a generic dependency resolver connects the two structures. However, no direct BL/B.W call to either accessor or the lib_power acquire wrapper was found in .srtext. Runtime resolution, actual pointer contents, and identity with the separate singleton at 0xC190662C are not proven.',PALE)

# PAGE 8
p=doc.add_page_break()
doc.add_paragraph('6. A paired siriusInstance registration pattern',style='Heading 1')
para('The final ROMFS initializer pointer block contains these two adjacent entries:')
table(['ROMFS entry','Stored Thumb pointer','Resolved initializer','Observed role'],[
 ('0xE0DD26AC','0xE093C781','0xE093C780','Constructs named registry object'),
 ('0xE0DD26B0','0xE093E311','0xE093E310','Builds descriptor with output slot'),
],[1.15,1.35,1.25,2.55],8.0)
para('Provider-side registry object',style='Heading 2')
bullet('Initializer 0xE093C780 uses global object base 0xC1D5E880 and the key string at ROMFS address 0xE0BC010C ("siriusInstance").')
bullet('Builder 0xE093C4E0 stores the two ROMFS interface/vtable pointers 0xE0BC0410 and 0xE0BC0480 at the start of the global object, then stores the key pointer at object offset +0x44.')
bullet('Accessor 0xE093C520 returns the address 0xC1D5E884. Its Thumb pointer 0xE093C521 is stored in the rtpadapter ROMFS record at 0xE0BC00CC.')
para('Descriptor-side structure',style='Heading 2')
para('Initializer 0xE093E310 calls builder 0xE093E250 with global base 0xC1D62B4C and key pointer 0xE0BC0654. The builder stores three fields:')
table(['Global field','Stored value','Interpretation'],[
 ('0xC1D62B4C','0xE0BC05EC','Interface descriptor associated with lib_power'),
 ('0xC1D62B50','0xE0BC0630','Descriptor/method metadata pointer'),
 ('0xC1D62B54','0xE0BC0654','Pointer to the same siriusInstance key'),
],[1.45,1.45,3.4],8.0)
para('Accessor 0xE093E290 returns the address 0xC1D62B50 (global +4), not the current contents at that slot. Its Thumb pointer 0xE093E291 appears at 0xE0BC0534 in the same rtpadapter ROMFS record.')
callout('Interpretation',
        'The provider and descriptor accessors expose different writable/readable pointer slots while carrying the same service key. The structure is consistent with a name-based registration/binding contract. The static evidence does not include the resolver call that matches the key and transfers a pointer, so this remains a strongly supported binding candidate rather than a proven live binding.',WARN)

# PAGE 9
p=doc.add_page_break()
doc.add_paragraph('7. lib_power acquire method and caller audit',style='Heading 1')
para('The rtpadapter record embeds a lib_power operation table and a separate set of client-name and method descriptors. The acquire method can forward any dynamic client mask supplied by its caller; the method itself does not hard-code PE_POLICY.')
table(['Location','Observed value / code','Meaning'],[
 ('ROMFS 0xE0BC05E0','"lib_power"','Power API interface label'),
 ('ROMFS 0xE0BC05F4','Thumb pointer 0xE093E2A1','Acquire method entry'),
 ('Code 0xE093E2A0','r0 <- r1; r1 <- r2; tail branch to 0xE093DC50','Forwards resource ID and client mask'),
 ('Code 0xE093DC50','Shared acquire entry; core at 0xE093DF60','Updates per-resource client state'),
],[1.5,2.5,2.3],8.0)
para('Direct-call audit',style='Heading 2')
bullet('The full retained .srtext disassembly contains 14 direct BL/B.W references to the shared acquire helper 0xE093DC50 and 12 to release helper 0xE093DC68.')
bullet('There is no direct BL/B.W caller of the ROMFS-exposed wrapper at 0xE093E2A0 (or its branch at 0xE093E2A4). The acquire method is therefore an indirect, data-driven API entry in the examined image.')
bullet('None of the 14 direct acquire-helper call-site windows loads a fixed 0x00400000 value into r1. The previously corrected client taxonomy maps PE_POLICY to slot 23, bit 22, mask 0x00400000.')
para('Examples of fixed masks seen at direct helper call sites',style='Heading 2')
table(['Mask','Client under corrected map','Representative call site(s)'],[
 ('0x00000008','POWER_CLIENT_PEN','0xE0741712'),
 ('0x00000100','POWER_CLIENT_OPT_SENSOR','0xE058C654'),
 ('0x00000200','POWER_CLIENT_SCAN','0xE0671B46'),
 ('0x00000400','POWER_CLIENT_SYS','0xE058C6AA, 0xE058C8BC, 0xE058CB22'),
 ('0x00000800','POWER_CLIENT_BOARD','0xE093DF2E, 0xE093E354'),
],[1.25,2.3,2.75],7.7)
callout('What the negative result means',
        'No resolved direct call site in this image proves a PE_POLICY request. It does not exclude a dynamic mask passed through the lib_power method table, a caller in a different firmware image, or a runtime-loaded component. The power subsystem supports PE_POLICY; actual use by the print engine remains unproven.',PALE)

# PAGE 10
p=doc.add_page_break()
doc.add_paragraph('8. Step 12 conclusions and next target',style='Heading 1')
para('Confirmed',style='Heading 2')
bullet('The ROMFS initializer table contains adjacent initializer pointers for two structures carrying the exact same siriusInstance key.')
bullet('The provider-side named object exposes pointer slot 0xC1D5E884; the descriptor-side accessor exposes slot 0xC1D62B50. Their relationship is consistent with a named provider/consumer binding pair.')
bullet('The rtpadapter ROMFS object contains the lib_power interface, with acquire and release method pointers at 0xE0BC05F4 and 0xE0BC05F8.')
bullet('The acquire method forwards its second method argument as a client mask into the shared power helper. The corrected PE_POLICY mask is 0x00400000.')
para('Not confirmed',style='Heading 2')
bullet('The generic component/dependency resolver that invokes 0xE093E291 and resolves the siriusInstance key has not been identified in the retained .srtext call graph.')
bullet('No proof the two pointer slots are actually connected at runtime, or that the resolved object is the previously identified singleton at 0xC190662C.')
bullet('No direct acquire-helper call site supplies fixed mask 0x00400000. A dynamic caller or caller in another image remains possible.')
bullet('No path has been established from this registration/power path to rtp_manager.block_print, unblock_print, or the PE blocked-state writer 0xE0251788.')
para('Proposed Step 13',style='Heading 2')
para('Trace the firmware component loader/resolver that consumes the ROMFS initializer and descriptor tables, then identify the PE component’s import/call path to lib_power. The narrow test is whether the PE component resolves the siriusInstance key and supplies client mask 0x00400000 through the acquire interface. Prioritize the remaining CROM/module loader and PE component metadata rather than another broad string scan.')
para('Evidence provenance',style='Heading 2')
para('The source ELF, rebuilt .srtext and .romfs_objs were restored from the previously saved Part 1 RTP Provider Trace Evidence Package. Their hashes are recorded in SOURCE_INPUTS.txt in the accompanying Step 12 evidence package. The 0xDC8-byte rtpadapter object, focused ROMFS pointer blocks, exact disassembly excerpts, full direct-call xref inventory and verifier output are included.')
para('Verification: 54/54 reproducible static checks passed. The verifier confirms source hashes and embedded section equality, initializer pointers, the two same-key fields and accessor slots, lib_power method pointers, the corrected PE_POLICY mask, the 14/12 helper xref counts, and the absence of direct calls to the generic accessors/acquire wrapper.',italic=False)
para('Operational boundary: no printer connection, network request, updater execution, firmware write, debug activation, print/scan request or runtime-state change was performed in Step 12.',italic=True,color=GRAY,size=8.2)

# Metadata
doc.core_properties.title='HP DeskJet 2855e Independent Printing/Scanning Investigation - Revision 99 Steps 11-12 Addendum'
doc.core_properties.subject='Sirius named binding pair and lib_power acquire caller trace'
doc.core_properties.author='OpenAI'
doc.core_properties.keywords='HP DeskJet 2855e, firmware, siriusInstance, lib_power, POWER_CLIENT_PE_POLICY'
doc.save(OUT)
print(OUT)
