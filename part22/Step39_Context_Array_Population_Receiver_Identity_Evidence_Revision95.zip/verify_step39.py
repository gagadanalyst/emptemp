#!/usr/bin/env python3
from pathlib import Path
import re, struct, hashlib, subprocess, sys
ROOT=Path('/mnt/data/firmware_recovery')
WORK=ROOT/'step38_work'; BASE=WORK/'base'/'part1_rtp_provider_trace'
DIS=WORK/'full_srtext.dis'; ELF=BASE/'hp_lbi_sections.elf'; ROM=BASE/'romfs_objs_rebuilt.bin'
text=DIS.read_text(); lines=text.splitlines(); rom=ROM.read_bytes(); rom_base=0xE09919C0
checks=[]
def check(name, ok):
    checks.append((name,bool(ok)))
def has(s): return s in text

def word(addr): return struct.unpack_from('<I',rom,addr-rom_base)[0]

def find_hits(target, opname):
    # Search the already-loaded disassembly string rather than rescanning 3M lines in Python.
    return re.findall(opname+r'\s+'+re.escape(target)+r'\b',text)

# Initializer slots and gating.
check('wrapper passes C143E904 to initializer', has('e0308c70: f64e 1004') and has('e0308c74: f2cc 1043') and has('e0308c78: f7ff bf7a'))
check('initializer clears three consecutive slots', has('e0308b7e: f844 2021') and has('e0308b82: d3f8'))
check('initializer conditionally constructs object A', has('e0308b96: f278 f25c') and has('e0308b9c: 4628') and has('e0308b9e: f004 f9d3'))
check('initializer registers A callback node', has('e0308ba2: f240 50e8') and has('e0308baa: f278 f334'))
check('slot zero assigned address C143E910', has('e0308bbe: 6025'))
check('initializer conditionally constructs embedded B object', has('e0308bc0: f278 f247') and has('e0308bc6: f505 7007') and has('e0308bca: f7fd fb39'))
check('initializer registers B callback node', has('e0308bce: f240 50f4') and has('e0308bd6: f278 f31e'))
check('slot plus four assigned C143E910 plus 0x21c', has('e0308be0: f505 7007') and has('e0308be4: 6060'))
check('slot plus eight left zero in this initializer', has('e0308b7e: f844 2021') and has('e0308be4: 6060') and has('e0308be6: 4620'))
check('A object vtable initialized to E09AF1B8', has('e030cf52: f24f 11b8') and has('e030cf56: f2ce 019a') and has('e030cf6a: e884 000e'))
check('B embedded object vtable initialized to E09AEA54', has('e030624c: f64e 2054') and has('e0306250: f2ce 009a') and has('e0306264: e884 000d'))
check('B initial active predicate cleared', has('e030626a: f884 0224'))
# Selector and B state methods.
check('selector reads slot plus four and calls predicate +298', has('e0308c52: 686c') and has('e0308c58: f8d0 1298') and has('e0308c5e: 4788'))
check('B predicate returns byte at +224', has('e03067e0: f890 0224') and has('e03067e4: 4770'))
check('B activation method loads context slot zero', has('e03067be: f64e 1304') and has('e03067c6: 681a'))
check('B activation method stores A pointer to B+220', has('e03067ca: f8c0 2220'))
check('B activation method updates active flag', has('e03067ce: f880 1224'))
# Dispatcher method targets.
check('generic dispatcher has virtual +264 branch', has('e03035b4: f8d0 3264'))
check('generic dispatcher has virtual +268 branch', has('e03035c4: f8d0 3268'))
check('generic +264 target exists as E0303610', has('e0303610: b5f0'))
check('generic +268 target is zero-return stub', has('e0303678: 2000') and has('e030367a: 4770'))
# Distinguish actual vtables.
A=0xE09AF1B8; B=0xE09AEA54; S=0xE0B4C838
check('context A vtable +264 -> E0303610', word(A+0x264)==0xE0303611)
check('context A vtable +268 -> E0303678', word(A+0x268)==0xE0303679)
check('context B vtable +264 -> E0303610', word(B+0x264)==0xE0303611)
check('context B vtable +268 -> E0303678', word(B+0x268)==0xE0303679)
check('Sirius vtable +264 -> E07470D0', word(S+0x264)==0xE07470D1)
check('Sirius vtable +268 -> E0747130', word(S+0x268)==0xE0747131)
check('context A/B vtables differ from Sirius primary vtable', A!=S and B!=S and word(A+0x268)!=word(S+0x268) and word(B+0x268)!=word(S+0x268))
# Lifecycle and unrelated registry.
check('context cleanup may clear +4 and +8', has('e0308bfa: 2000') and has('e0308bfc: 6060'))
check('adjacent registry clear targets C143E8E8', has('e0308c9e: f64e 00e8') and has('e0308ca2: f2cc 1043'))
check('adjacent registry setter compares distinct key', has('e0308cd0: f642 53da'))
# Calls, refs, binary boundaries.
check('context initializer has one direct B.W caller', len(find_hits('0xe0308b70',r'b(?:\.w)?'))==1)
check('slot+4 accessor has twelve direct BL callers', len(find_hits('0xe030feb8',r'bl(?:\.w)?'))==12)
check('generic dispatcher has two direct BL callers', len(find_hits('0xe0303558',r'bl(?:\.w)?'))==2)
check('no direct BL call targets Sirius setter in .srtext', len(find_hits('0xe0747130',r'bl(?:\.w)?'))==0)
# ELF layout (no program headers / RAM section).
e=subprocess.check_output(['readelf','-h','-l','-S',str(ELF)],text=True)
check('ELF contains zero program headers', re.search(r'Number of program headers:\s+0',e) is not None)
check('ELF substantive sections are srtext and romfs only', '[ 2] .srtext' in e and '[ 3] .romfs_objs' in e and re.search(r'Number of section headers:\s+4',e) is not None)

failed=[x for x in checks if not x[1]]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+'  '+name)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} passed')
if failed: sys.exit(1)
