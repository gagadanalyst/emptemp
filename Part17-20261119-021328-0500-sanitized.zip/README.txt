Part 17 is a read-only IPP format/capability preflight.

The ZIP contains only an allowlist of document formats, supported operations,
job-creation attributes, media/quality capabilities, and selected printer state.
It omits the printer IP/URI, UUID, serial number, MAC address, SSID, device ID,
and the raw IPP transcript. Full output remains in the local private/ folder.

Exactly one IPP Get-Printer-Attributes request was sent. No job operation,
physical print, scan, DELETE, setting change, account action, Web Services
change, or firmware action was performed.

Do not submit a print job based only on this preflight. Review the returned
formats and operations first. A separate explicit approval is required before
any physical print attempt.
