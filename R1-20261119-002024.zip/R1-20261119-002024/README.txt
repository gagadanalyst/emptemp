HP DeskJet runtime evidence — R1 read-only baseline

Target: 192.168.2.180
Started: 2026-11-19T00:20:33-05:00

This run performs only:
- local route lookup to the printer
- HTTP GET /eSCL/ScannerStatus
- HTTP GET /eSCL/ScannerCapabilities
- IPP Get-Printer-Attributes to ipp://192.168.2.180/ipp/print
- scanimage -L discovery (does not acquire an image)

It does NOT:
- POST /eSCL/ScanJobs
- issue IPP Print-Job or any other job-creation request
- change printer settings, Web Services, accounts, cartridges, or locks
- call RTP block_print/unblock_print or inpr.set_lock_state
- update, reset, or flash firmware

Review the *.meta, *.headers, *.body, *.stdout, *.stderr and *.status files.
No post-reset status is inferred unless the corresponding response is present here.
