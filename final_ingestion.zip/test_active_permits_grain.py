import requests

url = "https://ckan0.cf.opendata.inter.prod-toronto.ca/api/action/datastore_search"

params = {
    "resource_id": "a96c0ba4-3026-402b-b09d-5b1268b8f810",
    "filters": '{"PERMIT_NUM":"22 188270 BLD","REVISION_NUM":"00"}',
    "limit": 10,
}

response = requests.get(url, params=params, timeout=60)
response.raise_for_status()

for row in response.json()["result"]["records"]:
    print(row)
