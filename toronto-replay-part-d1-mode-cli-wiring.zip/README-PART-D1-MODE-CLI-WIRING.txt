Toronto Housing Bottleneck Analytics — Replay Part D1
Mode-aware CLI and target wiring

Apply this update after the previously delivered replay Parts 1–4 and Parts A/B/C.
It is a small overlay; it does not replace the extraction package or extraction workflow.

Files
- scripts/replay_snapshots.py
- tests/test_replay_snapshots.py

What changed
1. Adds the --mode argument already supplied by snapshot-replay.yml:
   --mode incremental  -> Mode 1 production-derived candidate path
   --mode rebuild      -> Mode 2 isolated reconstruction path
2. Passes that mode to DuckDBReplayTarget and SnowflakeReplayTarget.
   This is required because the target constructors enforce different candidate
   roots/schema-name patterns and different staging behavior for the two modes.
3. Keeps rebuild as the CLI default for backwards compatibility with direct
   invocations that do not yet pass --mode.
4. Adds focused tests for argument parsing, default mode, backend mode propagation,
   and missing Snowflake credentials.

Apply from the repository root

  unzip -o toronto-replay-part-d1-mode-cli-wiring.zip -d .

Focused verification

  pytest -q tests/test_replay_snapshots.py
  python -m compileall -q scripts/replay_snapshots.py tests/test_replay_snapshots.py

Results in the packaging environment
- 8 replay CLI tests passed.
- Python compilation passed.
- CLI --help displays --mode {incremental,rebuild}.

Scope / not yet complete
This increment does NOT implement N/date-range archive selection, $GITHUB_OUTPUT
signals, history_scope evidence, additional staged-data quality gates, downstream
dbt/Snowflake serving refresh, or explicit Mode 2 promotion. Those remain separate
increments. Do not run the production loader workflow based on this increment alone.

Extraction remains out of scope and must remain untouched.
