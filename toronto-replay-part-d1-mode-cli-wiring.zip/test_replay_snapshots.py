from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from types import SimpleNamespace

from scripts import replay_snapshots


def test_asset_names_normalize_v1_and_v2_identity():
    assert (
        replay_snapshots._asset_snapshot_id("toronto-raw-snapshot-bundle-123-2.zip")
        == "123:2"
    )
    assert (
        replay_snapshots._asset_snapshot_id(
            "toronto-raw-snapshot-v2-bundle-ed44fa3159ec485ba73fa70cfae938b8.zip"
        )
        == "ed44fa3159ec485ba73fa70cfae938b8"
    )
    assert replay_snapshots._asset_snapshot_id("unrelated.zip") is None


def test_discovery_filters_completed_assets_before_download_and_sorts(
    tmp_path, monkeypatch
):
    releases = [
        {"id": 1, "tag_name": "toronto-raw-snapshot-archive-2026-11"},
        {"id": 2, "tag_name": "toronto-raw-snapshot-v2-archive-2026-11"},
        {"id": 3, "tag_name": "draft", "draft": True},
    ]
    assets = {
        1: [
            {"name": "toronto-raw-snapshot-bundle-123-1.zip", "size": 100},
            {"name": "toronto-raw-snapshot-bundle-124-1.zip", "size": 100},
        ],
        2: [
            {
                "name": (
                    "toronto-raw-snapshot-v2-bundle-"
                    "ed44fa3159ec485ba73fa70cfae938b8.zip"
                ),
                "size": 100,
            }
        ],
    }

    def fake_gh_json(endpoint):
        if endpoint.endswith("releases?per_page=100"):
            return [releases]
        release_id = int(endpoint.split("/releases/")[1].split("/")[0])
        return [assets[release_id]]

    downloaded = []

    def fake_run(command, **kwargs):
        if command[1] == "release":
            tag = command[3]
            name = command[command.index("--pattern") + 1]
            directory = Path(command[command.index("--dir") + 1])
            directory.mkdir(parents=True, exist_ok=True)
            (directory / name).write_bytes(b"archive")
            downloaded.append((tag, name))
        return SimpleNamespace(stdout="", stderr="", returncode=0)

    inspected = []

    def fake_inspect(path, tag, asset, repository):
        snapshot_id = replay_snapshots._asset_snapshot_id(asset)
        order_time = {"123:1": 1, "124:1": 2}.get(snapshot_id, 0)
        inspected.append(snapshot_id)
        return SimpleNamespace(
            snapshot_id=snapshot_id,
            order=(order_time, 123, 1, snapshot_id),
        )

    monkeypatch.setattr(replay_snapshots, "_gh_json", fake_gh_json)
    monkeypatch.setattr(replay_snapshots.subprocess, "run", fake_run)
    monkeypatch.setattr(replay_snapshots, "inspect_archive", fake_inspect)

    found = replay_snapshots.discover_archives(
        "owner/repo",
        tmp_path,
        exclude_snapshot_ids={"123:1"},
    )

    assert inspected == ["124:1", "ed44fa3159ec485ba73fa70cfae938b8"]
    assert [item.snapshot_id for item in found] == [
        "ed44fa3159ec485ba73fa70cfae938b8",
        "124:1",
    ]
    assert all("123-1.zip" not in name for _, name in downloaded)


def test_discovery_rejects_invalid_release_asset_size(tmp_path, monkeypatch):
    monkeypatch.setattr(
        replay_snapshots,
        "_gh_json",
        lambda endpoint: [
            [{"id": 1, "tag_name": "toronto-raw-snapshot-archive-2026-11"}]
        ]
        if endpoint.endswith("releases?per_page=100")
        else [[{"name": "toronto-raw-snapshot-bundle-123-1.zip", "size": 0}]],
    )
    try:
        replay_snapshots.discover_archives("owner/repo", tmp_path)
    except ValueError as exc:
        assert "invalid size" in str(exc)
    else:
        raise AssertionError("invalid archive size was accepted")


def test_parser_accepts_workflow_mode_argument(tmp_path):
    args = replay_snapshots._parser().parse_args(
        [
            "--backend",
            "duckdb",
            "--mode",
            "incremental",
            "--ledger",
            str(tmp_path / "ledger.sqlite"),
            "--output",
            str(tmp_path / "summary.json"),
        ]
    )

    assert args.mode == "incremental"


def test_parser_defaults_to_isolated_rebuild_mode(tmp_path):
    args = replay_snapshots._parser().parse_args(
        [
            "--backend",
            "duckdb",
            "--ledger",
            str(tmp_path / "ledger.sqlite"),
            "--output",
            str(tmp_path / "summary.json"),
        ]
    )

    assert args.mode == "rebuild"


def test_build_target_passes_incremental_mode_to_duckdb(monkeypatch, tmp_path):
    captured = {}

    def fake_target(database, *, dataset_name, mode):
        captured.update(database=database, dataset_name=dataset_name, mode=mode)
        return object()

    monkeypatch.setattr(replay_snapshots, "DuckDBReplayTarget", fake_target)
    args = SimpleNamespace(
        backend="duckdb",
        mode="incremental",
        database=tmp_path / "candidate.duckdb",
        dataset="raw",
    )

    target = replay_snapshots._build_target(args)

    assert target is not None
    assert captured == {
        "database": tmp_path / "candidate.duckdb",
        "dataset_name": "raw",
        "mode": "incremental",
    }


def test_build_target_passes_rebuild_mode_to_snowflake(monkeypatch):
    captured = {}

    def fake_target(credentials, schema, *, mode):
        captured.update(credentials=credentials, schema=schema, mode=mode)
        return object()

    monkeypatch.setattr(replay_snapshots, "SnowflakeReplayTarget", fake_target)
    args = SimpleNamespace(
        backend="snowflake",
        mode="rebuild",
        snowflake_credentials="account=user;password=secret",
        schema="TORONTO_SNAPSHOT_REPLAY_123",
    )

    target = replay_snapshots._build_target(args)

    assert target is not None
    assert captured == {
        "credentials": "account=user;password=secret",
        "schema": "TORONTO_SNAPSHOT_REPLAY_123",
        "mode": "rebuild",
    }


def test_build_target_requires_snowflake_credentials():
    args = SimpleNamespace(
        backend="snowflake",
        mode="incremental",
        snowflake_credentials=None,
        schema="RAW_STAGE_123_1",
    )

    try:
        replay_snapshots._build_target(args)
    except ValueError as exc:
        assert "SNOWFLAKE_DLT_CONNECTION" in str(exc)
    else:
        raise AssertionError("Snowflake target accepted missing credentials")
