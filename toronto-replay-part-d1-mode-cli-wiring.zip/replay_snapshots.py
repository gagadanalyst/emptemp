"""Discover immutable V1/V2 Releases and replay them into one candidate backend."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from scripts.replay_archive import SnapshotArchive, inspect_archive
from scripts.replay_ledger import ReplayLedger
from scripts.replay_targets import (
    DEFAULT_DUCKDB_ROOT,
    DuckDBReplayTarget,
    SnowflakeReplayTarget,
    replay_backend,
)

V1_TAG = re.compile(r"toronto-raw-snapshot-archive-\d{4}-\d{2}\Z")
V2_TAG = re.compile(r"toronto-raw-snapshot-v2-archive-\d{4}-\d{2}\Z")
V1_ASSET = re.compile(r"toronto-raw-snapshot-bundle-(\d+)-(\d+)\.zip\Z")
V2_ASSET = re.compile(
    r"toronto-raw-snapshot-v2-bundle-([A-Za-z0-9][A-Za-z0-9._-]{0,127})\.zip\Z"
)


def _gh_json(*args: str) -> Any:
    result = subprocess.run(
        ["gh", "api", "--paginate", "--slurp", *args],
        check=True,
        capture_output=True,
        text=True,
    )
    try:
        return json.loads(result.stdout or "[]")
    except json.JSONDecodeError as exc:
        raise RuntimeError("GitHub CLI returned invalid JSON.") from exc


def _flatten_pages(value: Any) -> list[dict[str, Any]]:
    flattened: list[dict[str, Any]] = []
    if isinstance(value, list):
        for item in value:
            flattened.extend(_flatten_pages(item))
    elif isinstance(value, dict):
        flattened.append(value)
    return flattened


def _asset_snapshot_id(name: str) -> str | None:
    if match := V1_ASSET.fullmatch(name):
        return f"{match.group(1)}:{match.group(2)}"
    if match := V2_ASSET.fullmatch(name):
        return match.group(1)
    return None


def discover_archives(
    repository: str,
    destination: Path,
    *,
    exclude_snapshot_ids: set[str] | None = None,
) -> list[SnapshotArchive]:
    """Download and validate pending V1/V2 archive assets in Release order."""
    excluded = exclude_snapshot_ids or set()
    releases = _flatten_pages(_gh_json(f"repos/{repository}/releases?per_page=100"))
    candidates: list[tuple[str, str, int]] = []

    for release in releases:
        tag = str(release.get("tag_name", ""))
        if (
            release.get("draft") is True
            or release.get("prerelease") is True
            or not (V1_TAG.fullmatch(tag) or V2_TAG.fullmatch(tag))
        ):
            continue
        release_id = release.get("id")
        if not isinstance(release_id, int):
            raise ValueError(f"Release {tag!r} has no valid numeric ID.")
        assets = _flatten_pages(
            _gh_json(f"repos/{repository}/releases/{release_id}/assets?per_page=100")
        )
        for asset in assets:
            name = str(asset.get("name", ""))
            snapshot_id = _asset_snapshot_id(name)
            if snapshot_id is None or snapshot_id in excluded:
                continue
            size = asset.get("size")
            if not isinstance(size, int) or size <= 0 or size >= 2_147_483_648:
                raise ValueError(f"Release asset {tag}/{name} has an invalid size.")
            candidates.append((tag, name, release_id))

    destination.mkdir(parents=True, exist_ok=True)
    archives: list[SnapshotArchive] = []
    seen: set[str] = set()
    for index, (tag, name, _release_id) in enumerate(candidates):
        folder = destination / f"archive-{index:05d}"
        folder.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            [
                "gh",
                "release",
                "download",
                tag,
                "--repo",
                repository,
                "--pattern",
                name,
                "--dir",
                str(folder),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        path = folder / name
        if not path.is_file() or path.stat().st_size == 0:
            raise RuntimeError(f"GitHub did not download {tag}/{name}.")
        archive = inspect_archive(path, tag, name, repository=repository)
        if archive.snapshot_id in seen:
            raise ValueError(
                f"Duplicate immutable snapshot identity: {archive.snapshot_id}."
            )
        seen.add(archive.snapshot_id)
        archives.append(archive)

    return sorted(archives, key=lambda item: item.order)


def _source_configs(config_path: Path) -> dict[str, Any]:
    from toronto_housing_ingestion.config import load_config

    app = load_config(config_path)
    sources = {source.name: source for source in app.sources if source.warehouse_load}
    expected = {"active_permits", "cleared_permits"}
    if set(sources) != expected:
        raise ValueError("Configuration must enable Active and Cleared permit sources.")
    for source in sources.values():
        if source.warehouse_strategy != "scd2":
            raise ValueError(f"{source.name} must use the SCD2 strategy for replay.")
    return sources


def _build_target(args: argparse.Namespace) -> Any:
    """Construct the selected backend target with the requested safety mode."""
    mode = getattr(args, "mode", "rebuild")
    if mode not in {"incremental", "rebuild"}:
        raise ValueError(f"Unsupported replay mode: {mode!r}.")

    if args.backend == "duckdb":
        return DuckDBReplayTarget(
            args.database,
            dataset_name=args.dataset,
            mode=mode,
        )

    if args.backend == "snowflake":
        credentials = args.snowflake_credentials
        if not credentials:
            raise ValueError(
                "SNOWFLAKE_DLT_CONNECTION is required for Snowflake replay."
            )
        return SnowflakeReplayTarget(credentials, args.schema, mode=mode)

    raise ValueError(f"Unsupported replay backend: {args.backend!r}.")


def run(args: argparse.Namespace) -> dict[str, Any]:
    source_configs = _source_configs(args.config)
    ledger = ReplayLedger(args.ledger)
    pending_exclusion = ledger.completed_snapshot_ids(args.backend)
    archives = discover_archives(
        args.repository,
        args.archive_dir,
        exclude_snapshot_ids=pending_exclusion,
    )

    target = _build_target(args)

    report = replay_backend(
        archives,
        source_configs=source_configs,
        target=target,
        ledger_path=args.ledger,
        staging_root=args.staging_dir,
    )
    report.update(
        {
            "snapshot_count_discovered": len(archives),
            "snapshots": [
                {
                    "snapshot_id": archive.snapshot_id,
                    "format_version": archive.format_version,
                    "extracted_at_utc": archive.extracted_at.isoformat(),
                    "source_commit": archive.source_commit,
                    "run_id": archive.run_id,
                    "run_attempt": archive.run_attempt,
                    "release_tag": archive.release_tag,
                    "asset_name": archive.asset_name,
                    "archive_sha256": archive.archive_sha256,
                }
                for archive in archives
            ],
            "ledger_path": str(args.ledger),
            # Persisted entries include completed snapshots from earlier workflow
            # attempts, not only archives downloaded during this invocation.
            "ledger_entries": ledger.snapshot_records(args.backend),
            "candidate": (
                str(args.database)
                if args.backend == "duckdb"
                else f"TORONTO.{args.schema}"
            ),
        }
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return report


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=("duckdb", "snowflake"), required=True)
    parser.add_argument(
        "--mode",
        choices=("incremental", "rebuild"),
        default="rebuild",
        help=(
            "incremental applies archives to a prepared production-derived candidate; "
            "rebuild writes directly to an isolated historical-reconstruction target"
        ),
    )
    parser.add_argument(
        "--repository", default="gagadanalyst/toronto-housing-bottleneck-analytics"
    )
    parser.add_argument("--config", type=Path, default=Path("open_data_config.yml"))
    parser.add_argument(
        "--archive-dir",
        type=Path,
        default=Path("data/recovery/snapshot-replay/archives"),
    )
    parser.add_argument(
        "--staging-dir",
        type=Path,
        default=Path("data/recovery/snapshot-replay/staging"),
    )
    parser.add_argument("--ledger", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--database",
        type=Path,
        default=DEFAULT_DUCKDB_ROOT / "toronto-replay.duckdb",
    )
    parser.add_argument("--dataset", default="raw")
    parser.add_argument("--schema", default="TORONTO_SNAPSHOT_REPLAY_0")
    parser.add_argument(
        "--snowflake-credentials",
        default=os.getenv("SNOWFLAKE_DLT_CONNECTION"),
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        report = run(args)
    except Exception as exc:
        print(f"Replay failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
