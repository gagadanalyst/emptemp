"""Validate both replay reports and prove their archives and histories agree."""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

SOURCE_NAMES = ("active_permits", "cleared_permits")
BACKENDS = ("duckdb", "snowflake")
INTEGRITY_FIELDS = (
    "invalid_intervals",
    "overlapping_intervals",
    "duplicate_current_business_keys",
    "null_business_keys",
)
IDENTITY_FIELDS = (
    "format_version",
    "order_timestamp",
    "run_id",
    "run_attempt",
    "source_commit",
    "archive_sha256",
    "release_tag",
    "asset_name",
)


def _load_json(path: Path, backend: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot read {backend} replay report {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{backend} replay report must be a JSON object.")
    return value


def _validate_report(
    report: dict[str, Any], backend: str
) -> dict[str, dict[str, dict[str, Any]]]:
    if report.get("backend") != backend or report.get("status") != "passed":
        raise ValueError(f"{backend} replay did not pass or report the expected backend.")

    streams = report.get("sources")
    if not isinstance(streams, dict) or set(streams) != set(SOURCE_NAMES):
        raise ValueError(f"{backend} report is missing a source stream.")
    for source_name in SOURCE_NAMES:
        stream = streams[source_name]
        if (
            not isinstance(stream, dict)
            or stream.get("status") != "passed"
            or stream.get("failed")
            or stream.get("blocked")
        ):
            raise ValueError(f"{backend}/{source_name} replay stream did not pass.")

    validation = report.get("history_validation")
    if not isinstance(validation, dict) or validation.get("status") != "passed":
        raise ValueError(f"{backend} SCD2 history validation did not pass.")
    validated_sources = validation.get("sources")
    if not isinstance(validated_sources, dict) or set(validated_sources) != set(
        SOURCE_NAMES
    ):
        raise ValueError(f"{backend} history validation is incomplete.")

    for source_name in SOURCE_NAMES:
        result = validated_sources[source_name]
        if not isinstance(result, dict) or result.get("status") != "passed":
            raise ValueError(f"{backend}/{source_name} SCD2 validation did not pass.")
        required_metrics = {"total", "current", "expired", "export_rows", *INTEGRITY_FIELDS}
        missing = sorted(required_metrics - result.keys())
        if missing:
            raise ValueError(
                f"{backend}/{source_name} validation omitted metrics: {missing}."
            )
        total = int(result["total"])
        current = int(result["current"])
        expired = int(result["expired"])
        if (
            total <= 0
            or current < 0
            or expired < 0
            or total != current + expired
            or int(result["export_rows"]) != total
        ):
            raise ValueError(
                f"{backend}/{source_name} SCD2 counts or history export do not reconcile."
            )
        violations = {
            field: int(result[field])
            for field in INTEGRITY_FIELDS
            if int(result[field]) != 0
        }
        if violations:
            raise ValueError(
                f"{backend}/{source_name} has SCD2 integrity violations: {violations}."
            )

    records = report.get("ledger_entries")
    if not isinstance(records, list) or not records:
        raise ValueError(f"{backend} report has no persisted archive ledger evidence.")

    grouped: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for record in records:
        if not isinstance(record, dict):
            raise ValueError(f"{backend} ledger entry is invalid.")
        source_name = record.get("source_name")
        snapshot_id = record.get("snapshot_id")
        if source_name not in SOURCE_NAMES or not isinstance(snapshot_id, str) or not snapshot_id:
            raise ValueError(f"{backend} ledger entry has invalid identity.")
        if source_name in grouped[snapshot_id]:
            raise ValueError(
                f"{backend} ledger has duplicate {snapshot_id}/{source_name} entries."
            )
        if record.get("status") != "succeeded":
            raise ValueError(
                f"{backend}/{source_name}/{snapshot_id} ledger status is not succeeded."
            )
        missing = [field for field in IDENTITY_FIELDS if field not in record]
        if missing:
            raise ValueError(
                f"{backend}/{source_name}/{snapshot_id} ledger identity omits {missing}."
            )
        if record["format_version"] not in (1, 2):
            raise ValueError(f"{backend}/{snapshot_id} has an unsupported archive version.")
        if not str(record["run_id"]).isdecimal() or int(record["run_id"]) < 1:
            raise ValueError(f"{backend}/{snapshot_id} has an invalid GitHub run ID.")
        if int(record["run_attempt"]) < 1:
            raise ValueError(f"{backend}/{snapshot_id} has an invalid run attempt.")
        if not re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", str(record["source_commit"]), re.IGNORECASE):
            raise ValueError(f"{backend}/{snapshot_id} has an invalid source commit.")
        if not re.fullmatch(r"[0-9a-f]{64}", str(record["archive_sha256"]), re.IGNORECASE):
            raise ValueError(f"{backend}/{snapshot_id} has an invalid archive SHA-256.")
        try:
            order_timestamp = float(record["order_timestamp"])
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{backend}/{snapshot_id} has an invalid ordering timestamp.") from exc
        if not math.isfinite(order_timestamp):
            raise ValueError(f"{backend}/{snapshot_id} has an invalid ordering timestamp.")
        if not str(record["release_tag"]).strip() or not str(record["asset_name"]).strip():
            raise ValueError(f"{backend}/{snapshot_id} has incomplete Release identity.")
        grouped[snapshot_id][source_name] = record

    for snapshot_id, sources in grouped.items():
        if set(sources) != set(SOURCE_NAMES):
            raise ValueError(
                f"{backend} ledger is incomplete for snapshot {snapshot_id}."
            )
        active = sources["active_permits"]
        cleared = sources["cleared_permits"]
        for field in (
            "format_version",
            "run_id",
            "run_attempt",
            "source_commit",
            "archive_sha256",
            "release_tag",
            "asset_name",
        ):
            if active[field] != cleared[field]:
                raise ValueError(
                    f"{backend} source ledger identity mismatch for {snapshot_id}: {field}."
                )

    return dict(grouped)


def validate_reports(
    duckdb_report: dict[str, Any], snowflake_report: dict[str, Any]
) -> dict[str, Any]:
    """Validate each backend and require identical successful archive coverage."""
    checked = {
        "duckdb": _validate_report(duckdb_report, "duckdb"),
        "snowflake": _validate_report(snowflake_report, "snowflake"),
    }
    allowed_scopes = {"full", "partial", "incremental", "unspecified"}
    duck_scope = str(duckdb_report.get("history_scope", "unspecified"))
    snow_scope = str(snowflake_report.get("history_scope", "unspecified"))
    if duck_scope not in allowed_scopes or snow_scope not in allowed_scopes:
        raise ValueError(
            f"Unsupported replay history scope: DuckDB={duck_scope!r}, "
            f"Snowflake={snow_scope!r}."
        )
    if duck_scope != snow_scope:
        raise ValueError(
            "Backend history scopes differ: "
            f"DuckDB={duck_scope!r}, Snowflake={snow_scope!r}."
        )
    duck_ids = set(checked["duckdb"])
    snow_ids = set(checked["snowflake"])
    if duck_ids != snow_ids:
        raise ValueError(
            "Backend snapshot coverage differs: "
            f"DuckDB-only={sorted(duck_ids - snow_ids)}, "
            f"Snowflake-only={sorted(snow_ids - duck_ids)}."
        )

    for snapshot_id in sorted(duck_ids):
        for source_name in SOURCE_NAMES:
            left = checked["duckdb"][snapshot_id][source_name]
            right = checked["snowflake"][snapshot_id][source_name]
            for field in IDENTITY_FIELDS:
                if left[field] != right[field]:
                    raise ValueError(
                        f"Archive provenance mismatch for {snapshot_id}/{source_name}: {field}."
                    )

    snapshots = []
    for snapshot_id in sorted(
        duck_ids,
        key=lambda item: (
            min(
                checked["duckdb"][item][source]["order_timestamp"]
                for source in SOURCE_NAMES
            ),
            item,
        ),
    ):
        active = checked["duckdb"][snapshot_id]["active_permits"]
        snapshots.append(
            {
                "snapshot_id": snapshot_id,
                "format_version": active["format_version"],
                "run_id": active["run_id"],
                "run_attempt": active["run_attempt"],
                "source_commit": active["source_commit"],
                "archive_sha256": active["archive_sha256"],
                "release_tag": active["release_tag"],
                "asset_name": active["asset_name"],
                "source_order_timestamps": {
                    source: checked["duckdb"][snapshot_id][source]["order_timestamp"]
                    for source in SOURCE_NAMES
                },
            }
        )

    return {
        "status": "passed",
        "history_scope": duck_scope,
        "full_history": duck_scope == "full",
        "explicit_promotion_required": True,
        "snapshot_count": len(duck_ids),
        "source_ledger_entries": len(duck_ids) * len(SOURCE_NAMES),
        "archive_provenance": "passed",
        "backend_snapshot_coverage": "identical",
        "scd2_integrity": "passed",
        "snapshots": snapshots,
        "backends": {
            backend: {
                "candidate": report.get("candidate"),
                "sources": report["history_validation"]["sources"],
            }
            for backend, report in (
                ("duckdb", duckdb_report),
                ("snowflake", snowflake_report),
            )
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--duckdb-summary", type=Path, required=True)
    parser.add_argument("--snowflake-summary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    try:
        result = validate_reports(
            _load_json(args.duckdb_summary, "duckdb"),
            _load_json(args.snowflake_summary, "snowflake"),
        )
    except Exception as exc:
        print(f"REPLAY VALIDATION FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    args.output.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
