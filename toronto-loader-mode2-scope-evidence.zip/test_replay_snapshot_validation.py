from __future__ import annotations

from copy import deepcopy

import pytest

from scripts.validate_snapshot_replay import validate_reports


def _report(backend: str, *, checksum: str = "b" * 64) -> dict:
    records = []
    for snapshot_id, minute, run_id in (("snapshot-a", 10, "1001"), ("snapshot-b", 20, "1002")):
        for source_name in ("active_permits", "cleared_permits"):
            records.append(
                {
                    "source_name": source_name,
                    "snapshot_id": snapshot_id,
                    "format_version": 2,
                    "order_timestamp": 1793534400.0 + minute * 60,
                    "run_id": run_id,
                    "run_attempt": 1,
                    "source_commit": "a" * 40,
                    "archive_sha256": checksum,
                    "release_tag": "toronto-raw-snapshot-v2-archive-2026-11",
                    "asset_name": f"toronto-raw-snapshot-v2-bundle-{snapshot_id}.zip",
                    "status": "succeeded",
                }
            )
    source_metrics = {
        "status": "passed",
        "total": 10,
        "current": 8,
        "expired": 2,
        "invalid_intervals": 0,
        "overlapping_intervals": 0,
        "duplicate_current_business_keys": 0,
        "null_business_keys": 0,
        "export": f"{backend}/exports/permit_history.csv.gz",
        "export_rows": 10,
    }
    return {
        "backend": backend,
        "status": "passed",
        "history_scope": "full",
        "candidate": "candidate",
        "sources": {
            name: {"status": "passed", "failed": [], "blocked": []}
            for name in ("active_permits", "cleared_permits")
        },
        "history_validation": {
            "status": "passed",
            "sources": {
                name: deepcopy(source_metrics) for name in ("active_permits", "cleared_permits")
            },
        },
        "ledger_entries": records,
    }


def test_identical_backend_reports_pass_with_complete_ledger_and_history():
    result = validate_reports(_report("duckdb"), _report("snowflake"))

    assert result["status"] == "passed"
    assert result["snapshot_count"] == 2
    assert result["source_ledger_entries"] == 4
    assert result["archive_provenance"] == "passed"
    assert result["backend_snapshot_coverage"] == "identical"
    assert [item["snapshot_id"] for item in result["snapshots"]] == [
        "snapshot-a",
        "snapshot-b",
    ]


def test_partial_date_or_limit_rebuild_is_marked_non_full_and_not_auto_promoted():
    duckdb = _report("duckdb")
    snowflake = _report("snowflake")
    duckdb["history_scope"] = "partial"
    snowflake["history_scope"] = "partial"

    result = validate_reports(duckdb, snowflake)

    assert result["status"] == "passed"
    assert result["history_scope"] == "partial"
    assert result["full_history"] is False
    assert result["explicit_promotion_required"] is True


def test_backend_history_scope_mismatch_is_rejected():
    duckdb = _report("duckdb")
    snowflake = _report("snowflake")
    snowflake["history_scope"] = "partial"

    with pytest.raises(ValueError, match="history scopes differ"):
        validate_reports(duckdb, snowflake)


def test_different_snapshot_coverage_is_rejected():
    duckdb = _report("duckdb")
    snowflake = _report("snowflake")
    snowflake["ledger_entries"] = [
        row for row in snowflake["ledger_entries"] if row["snapshot_id"] != "snapshot-b"
    ]

    with pytest.raises(ValueError, match="coverage differs"):
        validate_reports(duckdb, snowflake)


def test_archive_checksum_mismatch_between_backends_is_rejected():
    with pytest.raises(ValueError, match="provenance mismatch.*archive_sha256"):
        validate_reports(_report("duckdb"), _report("snowflake", checksum="c" * 64))


def test_missing_source_ledger_entry_is_rejected():
    duckdb = _report("duckdb")
    duckdb["ledger_entries"].pop()

    with pytest.raises(ValueError, match="ledger is incomplete"):
        validate_reports(duckdb, _report("snowflake"))


def test_failed_backend_stream_is_rejected():
    snowflake = _report("snowflake")
    snowflake["sources"]["active_permits"]["status"] = "failed"

    with pytest.raises(ValueError, match="active_permits replay stream did not pass"):
        validate_reports(_report("duckdb"), snowflake)


def test_scd2_overlap_is_rejected_even_when_report_claims_passed():
    duckdb = _report("duckdb")
    duckdb["history_validation"]["sources"]["active_permits"][
        "overlapping_intervals"
    ] = 1

    with pytest.raises(ValueError, match="SCD2 integrity violations"):
        validate_reports(duckdb, _report("snowflake"))


def test_unreconciled_history_export_count_is_rejected():
    snowflake = _report("snowflake")
    snowflake["history_validation"]["sources"]["cleared_permits"]["export_rows"] = 9

    with pytest.raises(ValueError, match="do not reconcile"):
        validate_reports(_report("duckdb"), snowflake)


def test_source_identity_mismatch_inside_one_backend_is_rejected():
    duckdb = _report("duckdb")
    duckdb["ledger_entries"][1]["asset_name"] = "different.zip"

    with pytest.raises(ValueError, match="source ledger identity mismatch"):
        validate_reports(duckdb, _report("snowflake"))


def test_pending_or_failed_ledger_entry_is_rejected():
    snowflake = _report("snowflake")
    snowflake["ledger_entries"][0]["status"] = "failed"

    with pytest.raises(ValueError, match="ledger status is not succeeded"):
        validate_reports(_report("duckdb"), snowflake)
