Mode 2 rebuild-scope evidence update
===================================

Apply these replacements at the repository root:

  scripts/validate_snapshot_replay.py
  tests/test_replay_snapshot_validation.py
  .github/workflows/snapshot-replay.yml

The joint validator now preserves the selected history scope from both backend
reports. It accepts `full`, `partial`, `incremental`, or (for older report fixtures)
`unspecified` scope, but rejects a mismatch between DuckDB and Snowflake.

For `partial` rebuilds (a date range and/or --limit N), the joint evidence explicitly
sets `full_history=false`. A partial history can pass integrity and parity checks,
but must not be treated as a complete reconstruction. The summary also records that
promotion remains a separate, explicit operation. This workflow does not promote a
Mode 2 rebuild candidate.

The snapshot-replay workflow also has a duplicate manual-production-confirmation
message removed; production guards are otherwise unchanged.

Validation: 59 replay-specific tests passed across the full replay suite, Python
compilation passed, and the workflow YAML parsed successfully.
