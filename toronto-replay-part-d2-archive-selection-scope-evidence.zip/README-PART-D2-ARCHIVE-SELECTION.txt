Part D2 — archive selection and cross-backend history-scope evidence
====================================================================

Apply this increment after Part D1. The replay_snapshots.py and
test_replay_snapshots.py files below are replacements for the D1 versions.

Files
-----
  scripts/replay_snapshots.py
  tests/test_replay_snapshots.py
  scripts/validate_snapshot_replay.py
  tests/test_replay_snapshot_validation.py

Behavior
--------

Mode 1 — daily/incremental production update
- Discovers only complete archived snapshots not already recorded as complete by
  the warehouse-native ledger or replay ledger.
- Rejects --from-date, --to-date, and --limit/--last-n in incremental mode.
- Passes mode='incremental' into the target, preserving the separate Mode 1 input
  staging path introduced by Part A and carried forward in Part C/D1.
- Report scope is 'incremental'; full_history is false.

Mode 2 — historical rebuild candidate
- Discovers and validates the complete available V1/V2 archive set before applying
  any date or N-snapshot selection.
- --from-date and --to-date are inclusive UTC extraction dates.
- --limit N and --last-n N select the MOST RECENT N archives in the selected date
  window; the selected archives are then replayed oldest-first for SCD2 boundaries.
- N is fixed before retry/idempotency skips so a retry cannot silently expand scope.
- An unfiltered rebuild is labelled 'full' only when it selects every discovered
  complete archive. Any explicit date or N selection is labelled 'partial'.
- Mode 2 continues to target an isolated rebuild database/schema directly; no
  additional warehouse input-staging layer is introduced.

Joint validator
---------------
The DuckDB/Snowflake validator now requires both reports to state a supported mode,
matching history scope, matching selection parameters and matching archive counts.
It rejects a partial rebuild that claims full_history=true, a full rebuild that did
not select every discovered archive, or reports with inconsistent promotion flags.
The joint evidence records mode, history_scope, full_history,
explicit_promotion_required=true and promotion_performed=false. This does not
implement or authorize Mode 2 production promotion.

Validation performed in the packaging environment
--------------------------------------------------
- Focused CLI/selector and joint-validator tests: 29 passed.
- Full replay-focused suite: 75 passed, 5 blocked because DuckDB is not installed
  in this environment (ModuleNotFoundError: duckdb).
- Python compilation: passed.
- snapshot-replay.yml YAML parsing: passed.
- Ruff could not be run because Ruff is not installed in this environment.
- No live DuckDB or Snowflake integration was run.

Do not start a production workflow yet. Later increments still need to wire the
workflow inputs/outputs and complete the downstream serving/promotion safeguards.
