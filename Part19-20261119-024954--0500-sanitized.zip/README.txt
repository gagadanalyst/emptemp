Sanitized Part 19 corrected Validate-Job result. No printer IP/URI, raw transcript, or device identity included.
Private raw captures remain in the matching *-private directory.
ipptool exit code: 0
IPP status: successful-ok
