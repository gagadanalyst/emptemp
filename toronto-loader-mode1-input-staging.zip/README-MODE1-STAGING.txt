Mode 1 input staging update
===========================

This increment completes the warehouse-side input staging step for incremental
production loading. Apply the two replacement files at the repository root:

  scripts/replay_targets.py
  tests/test_replay_targets.py

Mode 1 (incremental)
--------------------
DuckDB materializes each incoming source snapshot into a separate, temporary
DuckDB file with schema `snapshot_input_stage`. Snowflake materializes each
incoming source into a separate `RAW_INPUT_STAGE_<run_id>_<attempt>` schema.

The stage load uses the existing `load_scd2()` with `warehouse_strategy=replace`
and with the configured warehouse date window disabled. This ensures the full
incoming source snapshot is staged. Before applying SCD2 to the production-derived
candidate, the loader verifies the staged row count and that all archived columns
are present. The SCD2 step then reads the same immutable, checksum-verified Parquet
snapshot, preserving its original source types and values rather than re-exporting
warehouse-converted values from the staging table.

DuckDB's temporary stage database and Snowflake's input-stage schema are removed
when the replay target finalizes. They are not included in the candidate promotion.
The production-derived candidate retains only the SCD2 changes and its persistent
snapshot ledger.

Mode 2 (rebuild)
----------------
No input staging database/schema is created. The selected immutable archives are
loaded directly into the isolated rebuild database/schema, then validated.

Validation performed for this increment
---------------------------------------
The replay regression suite covers staging config behavior, full-row staging,
row-count/schema mismatch rejection, DuckDB and Snowflake incremental load order,
and the no-extra-stage rebuild path.
