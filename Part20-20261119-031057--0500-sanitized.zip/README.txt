Sanitized Part 20 one-page monochrome Print-Job result.
No printer IP/URI, serial number, MAC address, UUID, or raw IPP transcript is included.
The matching *-private directory contains sensitive raw logs; do not share it.
Exactly one Print-Job at most; read-only preflight and optional single job-status readback.
