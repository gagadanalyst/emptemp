Part C — legacy ledger compatibility and Snowflake schema isolation

Apply these files over the existing replay implementation:
- scripts/replay_warehouse_ledger.py
- scripts/replay_targets.py
- tests/test_replay_warehouse_ledger.py
- tests/test_replay_targets.py

Also apply the included concurrency patch to:
- .github/workflows/snowflake-canonical-raw-refresh.yml

Reason:
- Early V1 production ledger rows may have NULL release_tag/asset_name and
  NULL V2 archive metadata. The reader now accepts those missing legacy fields,
  but still rejects any populated value that conflicts with the immutable archive.
  A successful V1 row is preserved as succeeded while absent provenance fields
  are backfilled.
- All newly created or reused Snowflake replay schemas must be owned by
  TORONTO_INGEST_ROLE after account/role/database/warehouse preflight.
- The canonical Snowflake RAW refresh and the new staged incremental loader use
  the same GitHub Actions concurrency group. This prevents automated candidate
  clone/promote workflows from racing one another.

After extraction:
  ruff check scripts tests --fix
  ruff format scripts tests
  ruff check scripts tests
  python -m pytest -q tests/test_replay_archive.py tests/test_replay_ledger.py \
    tests/test_replay_snapshot_validation.py tests/test_replay_snapshots.py \
    tests/test_replay_targets.py tests/test_replay_warehouse_ledger.py
