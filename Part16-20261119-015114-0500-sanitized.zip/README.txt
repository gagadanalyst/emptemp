Part 16 is a read-only IPP printer-status preflight.

The sanitized archive contains only a small allowlist of IPP state, queue, alert, and firmware attributes.
It omits the printer IP, printer URI, device ID, UUID, serial number, MAC address, SSID, raw headers, and full raw IPP transcript.
The unredacted transcript and local route details remain in the private/ folder on the Fedora workstation.

Exactly one IPP operation was issued: Get-Printer-Attributes to the established /ipp/print resource.
No print job, scan job, DELETE, configuration change, Web Services change, account operation, or firmware action was sent.

If you complete the optional manual EWS Status Log observation, edit EWS_STATUS_LOG_NOTES.txt in the share/ folder,
then rebuild the sanitized ZIP with:
  python3 part16_ipp_preflight.py --package-only "<this-run-directory>"
Review the notes for private identifiers before sharing the ZIP.
