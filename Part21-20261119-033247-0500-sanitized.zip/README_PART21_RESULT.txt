Part 21 result

Share only the sanitized ZIP. Do not share this private directory.
Visually inspect the output tray. If any uncertainty remains about delivery, do not submit again.
