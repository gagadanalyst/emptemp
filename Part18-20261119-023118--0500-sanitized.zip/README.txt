Sanitized Part 18 Validate-Job result. Contains no printer IP/URI or raw device identity.
Private raw captures remain in the matching *-private directory.
ipptool exit code: 1
IPP status: client-error-bad-request
